/*
 * rdbe_common.h
 *
 *  Created on: Jun 3, 2009
 *      Author: Mikael Taveniku XCube Communication Inc.
 */


#ifndef RDBE_EXPORTS_H_
#define RDBE_EXPORTS_H_

#include <linux/ioctl.h>  // macros for setting IOCTL numbers




/**
 * RDBE Device control definitions
 */
#define RDBE_DEV_MAGIC 69
#define RDBE_DEV_RESET       _IO(RDBE_DEV_MAGIC, 0)
/** configure the FPGA with data from the given file (need to be opened) */
#define RDBE_DEV_CONFIGURE   _IO(RDBE_DEV_MAGIC, 1)
/*
 * Read and Write methods to the devices on the boards. These are provided to explicitly read or write
 * byte, shorts, or longs to the specific sub-device on the board.
 * These commands take an RDBE_DEV_RW_T struct as an argument which also will hold the result after the operation
 */


#define RDBE_FPGA_READ      _IOR(RDBE_DEV_MAGIC, 2, rdbe_rdwr_cmd_t)
#define RDBE_CPLD_READ      _IOR(RDBE_DEV_MAGIC, 3, rdbe_rdwr_cmd_t)
#define RDBE_SMAP_READ      _IOR(RDBE_DEV_MAGIC, 4, rdbe_rdwr_cmd_t)

#define RDBE_FPGA_WRITE      _IOWR(RDBE_DEV_MAGIC, 5, rdbe_rdwr_cmd_t)
#define RDBE_CPLD_WRITE      _IOWR(RDBE_DEV_MAGIC, 6, rdbe_rdwr_cmd_t)
#define RDBE_SMAP_WRITE      _IOWR(RDBE_DEV_MAGIC, 7, rdbe_rdwr_cmd_t)
/** This call is a blocking call to wait for an ISR from the FPGA */
#define RDBE_ISR_READ        _IOR(RDBE_DEV_MAGIC, 8, rdbe_rdwr_cmd_t)

#define RDBE_DEV_MAXNR 8


/**
 * Type definitions for RDBE_DEV_IOCTL function calls
 *
 */

/**
 * Passed as argument to IOCTL with a RDBE_DEV_CONFIGURE cmd to configure the FPGA
 * buf - points to a memory mapped file, or a buffer that holds the bytes for the FPGA configuration
 * len - is the length of the (buffer/file) in bytes. No checks are done by the driver
 */
typedef struct {
	void *buf;
	unsigned long len;
} rdbe_configure_cmd_t;

/**
 * Passed as argument to IOCTL with a RDBE_XXXX_READ/WRITE command
 * access_type defines number of bytes per item 1=1byte, 2=2byte, 4=4byte
 * len - length in access_type items to read or write
 * buf - pointer to a buffer that can hold the data to be read or written
 * ofs - offset into the device memory to write (must be aligned to access_type bytes
 */
typedef struct {
	unsigned long  access_type;  // 1=byte, 2=2byte, 4=4byte error otherwise
	unsigned long  ofs;          // offset in device memory to write to
	unsigned long  len;          // length in number of access_type items to read or write
	void          *buf;          // buffer to hold the data -- must be allocated of sufficient size
} rdbe_rdwr_cmd_t;


/*
 * Definitions of exported memory layout.
 * The Read and Write methods map the dive spaces into a common linear address range mapping
 * The FPGA Start at offset 0 to 0x7FFFFFF, the SMAP start at offset 0x00800000 to 0x080FFFFF
 * the CPLD addresses are mapped to 0x08100000 - 0x0801FFFFF
 */
#define RDBE_DEV_FPGA_OFFSET 0
#define RDBE_DEV_SMAP_OFFSET 0x08000000
#define RDBE_DEV_CPLD_OFFSET 0x08100000



#endif /* RDBE_COMMON_H_ */
