/*
 * string_buffer.c
 *
 *  Created on: Jul 16, 2009
 *      Author: Mikael Taveniku XCube Communication Inc.
 *      License: GPL
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "string_buffer.h"

/* private */

typedef struct sb
{
  char data[64];
  struct sb* next;
} stringbuffer;

typedef struct
{
  stringbuffer *first, *last;
  char cnt;
  int numChunks;
} sentinel;

static void createChunk(sentinel* sen)
{
  sen->last = sen->last->next = (stringbuffer*)malloc(sizeof(stringbuffer));
  sen->cnt = 0;
  sen->numChunks++;
}

/* public */
/**
 *
 */
void* sb_new()
{
  sentinel* res = (sentinel*)malloc(sizeof(sentinel));

  res->numChunks = 0;
  res->first = res->last = (stringbuffer*)malloc(sizeof(stringbuffer));
  res->cnt = 0;
  return (void*)res;
}

void sb_addString(void* sb, const char* str)
{
  sentinel* sen = (sentinel*)sb;
  int len = strlen(str), delta = 63-sen->cnt;
  char* dup = sen->last->data + sen->cnt;

  while (sen->cnt+len > 63)
  {
    strncpy(dup, str, delta);
    sen->last->data[63] = 0;
    str += delta;
    len -= delta;
    createChunk(sen);
    dup = sen->last->data;
    delta = 63;
  }

  strcpy(dup, str);

  sen->cnt += len&63;
}

char* sb_getString(void* sb)
{
  sentinel* sen = (sentinel*)sb;
  int len = sb_getLength(sb);
  char* res = (char*)malloc((len+1)*sizeof(char));
  stringbuffer* act = sen->first;

  while (1)
  {
    strcpy(res, act->data);
    if (act == sen->last)
    {
      res += sen->cnt;
      break;
    }

    res += 63;
    act = act->next;
  }

  res -= len;
  return res;
}

int sb_getLength(void* sb)
{
  sentinel* sen = (sentinel*)sb;
  return sen->numChunks*63+sen->cnt;
}

void sb_free(void* sb)
{
  sentinel* sen = (sentinel*)sb;
  stringbuffer *next;

  while (sen->first != sen->last)
  {
    next = sen->first->next;
    free(sen->first);
    sen->first = next;
  }

  free(sen->first);
  free(sen);
}

/*
int main()
{
  void* sb = sb_new();
  int i = 0;

  for (; i < 100; i++)
  {
    sb_addString(sb, "123456789 123456789 123456789 123456789 123456789 123456789 123456789 123456789 123456789 123456789");
  }

  printf("Length %d\n", sb_getLength(sb));
  printf("String: %s", sb_getString(sb));

  return 0;
}
*/

