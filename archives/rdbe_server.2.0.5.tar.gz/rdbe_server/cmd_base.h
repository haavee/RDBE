/*
 * cmd_base.h
 *
 *  Created on: Aug 27, 2009
 *      Author: micke
 */

#ifndef CMD_BASE_H_
#define CMD_BASE_H_

/* --- the base number for Jan 1 2010 in truncated modifed julian date. */
#define tmjd_base 197

#define RESP_BUF_SIZE         0x2000
#define IP_STR_LEN            16

enum DataSendActionType
{
  DBE_DATA_SEND_ON,
  DBE_DATA_SEND_OFF,
  DBE_DATA_SEND_ENABLE,
  DBE_DATA_SEND_DISABLE,
  DBE_DATA_SEND_UNKOWN
};

void cmd_base_initialize(void);

extern int InitRdbeAppStat(void);


#endif /* CMD_BASE_H_ */
