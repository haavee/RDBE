/*
 * server_main.c
 *
 *  Created on: Jul 24, 2009
 *      Author: Mikael Taveniku XCube Communication Inc.
 *      License: GPL
 *		Description: Provides a TCP service to external programs to communicate with the Roach board
 */

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>     // open, etc
#include <unistd.h>    // close, read
#include <pthread.h>

#include <syslog.h> // syslog

#include <signal.h>

#include <string.h>
#include <sys/types.h>

#include <signal.h>
#include <sys/time.h>

#include <sys/socket.h>
#include <sys/un.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include <sys/ioctl.h>

#include "server_error.h"
#include "cmd_parser.h"
#include "cmd_low_level.h" // low level VSI-S compatible access to RDBE
#include "cmd_common.h" // common commands for the RDBE device
#include "cmd_base.h"   // basic command set for RDBE
#include "cmd_hal.h"    // developer level direct access to FPGA HAL
#include "rdbe_emulate.h"
#include "serv_storage.h"
#include "rdbe_exports.h"  // Function control macros for rdbe device
#include "hal.h"

#include "ioctl_util.h"  // TO BE REMOVED 

#define RDBE_SERVER_VERSION "0.01"
#define RDBE_DEV            "/dev/rdbe_dev0"
#define SERVER_CONN_MAX	    16


#define RDBE_PRESENT // remove/comment for emulation

 // #define DBE_SEND_PROMPT // remove/comment for python gui

/* ****************************************************************************
 * Internal global variables
 *
 * ****************************************************************************
 */

const char * RessourcesError = "Sorry! no ressources available. Connection dropped.\n";

/**
 * mutex to serialize access the RDBE device
 */
pthread_mutex_t rdbeMutex;

/** this is the descriptor for the open RDBE device */
int servRdbeDev = 0;

/**
 * Structure that keep state information about a client server connection
 */
typedef struct {
	int users;                    // 0 if available
	int sockFd;                   // file descriptor
	struct sockaddr_in clientAddr; // client address record
	pthread_t handlerThread;      // Thread information
} serv_connection_t;

/** handle to an array of server connections */
serv_connection_t *servConnections = NULL;
int servConnectionsMax = 0;


/* holder for the RDBE IP address */
char roach_ip[IP_STR_LEN];

/* log file */
FILE * logfp;

/* keeps track of the day the log file was created */
int file_day_stamp;

/*
 * Keeps track of the current settings for the rdbe.
 * Every time a member is updated, write the structure
 * into .rdbe_xxxx file.
 */


extern rdbe_settings_t current_settings;

/**
 * Initialize the list of available connections
 * @param maxConnections
 * @return number of connections available or -1 on error
 */
int serv_connection_init(int maxConnections)
{
	int i;
	if(servConnections == NULL){
		if((servConnections = (serv_connection_t *)malloc(maxConnections * sizeof(serv_connection_t))) == 0) {
			return -1; // no connections
		}
		for(i=0;i<maxConnections;i++){
			servConnections[i].users = 0;
		}
		servConnectionsMax = maxConnections;
		return maxConnections;
	}
	return -1; // error
}

/**
 * returns a pointer to the first available server connection object.
 * when an object is returned the user count is increased by one. the user is
 * responsible for returning the object to the pool when done.
 * @return a server connection object if found, 0 otherwise
 */
serv_connection_t *serv_connection_get_first_available(void)
{
	int i;
	for(i=0; i<servConnectionsMax; i++) {
		if(servConnections[i].users == 0) {
			servConnections[i].users ++;
			return &servConnections[i];
		}
	}
	return 0;
}

/**
 * Find a server connection record based on a thread id
 * @param tId - the thread Id
 * @return - a pointer to the server connection - 0 if not found.
 */
serv_connection_t *serv_connection_find(pthread_t tId)
{
	int i;
	for(i=0; i<servConnectionsMax; i++) {
		if(servConnections[i].handlerThread == tId) {
			return &servConnections[i];
		}
	}
	return 0;
}

/**
 * Decrease the user count on a particular connection
 * @param conn - the connection to operate on
 * @return 0 if successful
 */
int serv_connection_release(serv_connection_t *conn)
{
  if(conn){    
    if(conn->users > 0) 	
      conn->users--;
    /* close the socket */
    close(conn->sockFd);
    return 0;
  }
  return -1;
}

/**
 * Return all connections and memory allocated to them
 */
void serv_connection_destroy(void)
{
	if(servConnections) free(servConnections);
	servConnectionsMax = 0;
}


/**
 * Create a socket to listen for connections on at port "portNo" with tcp protocol.
 * @param devNo - return value for the device number of the socket
 * @param portNo - the port number to listen to
 * @return - 0 if successful, negative error value otherwise
 */
int serv_open_socket(int *devNo, int portNo)
{
  int sockFd;
  int yes = 1;         // reuse option for the port number
  struct sockaddr_in serv_addr;

  // try to open streaming socket default protocol (tcp)
  sockFd = socket(AF_INET, SOCK_STREAM, 0);
  if(sockFd <= 0)	return -ERR_SOCKET_OPEN;

  /* set the reuse option to avoid EADDRINUSE error */
  setsockopt(sockFd, SOL_SOCKET,SO_REUSEADDR,&yes,sizeof(int));

  bzero((char *) &serv_addr, sizeof(serv_addr));
  serv_addr.sin_family      = AF_INET;
  serv_addr.sin_addr.s_addr = INADDR_ANY;
  serv_addr.sin_port        = htons(portNo);

  if (bind(sockFd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0)
    {
      perror("bind");
      return -ERR_SOCKET_BIND;
    }

  *devNo = sockFd;
  return 0;
}


/**
 * Reads a line of input from the open file "fd" and create a null terminated string placed into the
 * buffer "buf" terminated with "null" and max length of max_len (-1) characters. If the input is longer
 * it is truncated and terminated with a null character.
 * @param buf - pointer to output buffer.
 * @param max_len - length of buffer, not to be exceeded.
 * @param fd - file descriptor to the input.
 * @return - number of characters read.
 */
int get_cmd_line(char *buf, int max_len, int dev)
{
	int i;
	int ch;
	char tmpBuf[128];
	int ch_read;
	int bytesToRead = 1;
	/*
	 * TODO: Rewrite this function to read a full line until it sees a ';'
	 */
	i      = 0;
	buf[0] = '\0';      // initialize return buffer

	ch_read = read(dev, &tmpBuf, bytesToRead); // read one byte from the device ...
	if(ch_read <= 0) {
		return -1; //EOF==0, error negative just propagate up
	}

	ch = tmpBuf[0];

	while ((ch_read > 0) && (ch != '\n') && i < (max_len-1))
	{
		if(ch == '\b' || ch == 0x7F /*delete*/) {
			i = i > 0 ? i-1 : 0; // decrement i with 1 but not less than 0
			buf[i] = '\0';
		} else {
			buf[i++] = (unsigned char)(ch & 0xFF);
			buf[i]   = '\0'; // always keep buffer null terminated
		}
		if(i < (max_len -1)) {
			ch_read = read(dev,&tmpBuf,bytesToRead); // read one byte from the device ... phew...
			ch = tmpBuf[0];
		}
	}
	return i;
}

/**
 * Read a set number of bytes from this input stream
 * @param buf - buffer to read to
 * @param len - number of bytes to read
 * @param dev - the device to read from
 * @return - number of bytes read
 */
long serv_int_get_data(unsigned char *buf, unsigned long len, int dev)
{
	long dataRead;
	long bytesToRead;
	ssize_t tmpRead; // signed size type

	dataRead    = 0; // so far not read anything
	bytesToRead = len; // this is what is left

	while (dataRead < len)	{
		tmpRead = read(dev,&buf[dataRead], bytesToRead); // read  from the device
		if(tmpRead <= 0) {
			printf("error on read at %lu \n", dataRead);
			return tmpRead;
		} else {
			dataRead    += tmpRead; // read this many
			bytesToRead -= tmpRead; // this many left
			printf("read %ld bytes in this read %ld total of %lu", (long)tmpRead, (long)dataRead, len);
		}
	}
	return dataRead;
}


/**
 * Gets data from the client and puts it into the specified buffer.
 * No error checking is done, this will hang until connection is broken or
 * all data is received.
 * @param bufNo - which buffer to read data into
 * @param length - how much data
 * @return - 0 if successful
 */
int serv_get_data(int bufNo, unsigned long length) {
	unsigned char *buf;
	pthread_t tId;
	serv_connection_t *con;

	tId = pthread_self(); // who am I
	con = serv_connection_find(tId); // find my connection data
	if (con) {
		ss_free_buf(tId, bufNo);
		buf = ss_allocate_buf(tId, bufNo, length);
		if (buf) {
			printf("loading data to buffer\n");
			serv_int_get_data(buf, length, con->sockFd);
		} else {
			printf("could not allocate memory for buffer %d of length %lu\n", bufNo, length);
			return -1;
		}
	} else {
		printf("Error could not find an active server connection\n");
		return -1;
	}
	return 0;
}

/**
 * Wrapper to access IOCTL function on the rdbe device
 * @param funNo - ioctl function
 * @param arg - argument
 * @return - ioctl result
 */
int serv_rdbe_ioctl(int funNo, char*arg) {
  int retVal = 0;
  
  if (RDBE_ISR_READ == funNo)
    retVal = ioctl(servRdbeDev, funNo, arg);
  else
    {
      pthread_mutex_lock(&rdbeMutex);
      if (servRdbeDev != 0) {
	retVal = ioctl(servRdbeDev, funNo, arg);
      } else {
	retVal = rdbe_emulate_ioctl(servRdbeDev, funNo, arg);
      }
      pthread_mutex_unlock(&rdbeMutex);
    }
  return retVal;
}


/**
 * Debug function to print tokens from the tokenizer
 * @param nToken
 * @param tokens
 */
void debug_print_tokens(int nToken, char **tokens)
{
	int i;
	printf("Tokens Number tokens=%d\n", nToken);
	for(i=0;i<nToken;i++){
		printf("token[%d]=%s ", i, tokens[i]);
	}
	printf("\n");
}

/**
 * Writes a buffer worth of data on an open socket
 * @param sc
 * @param buf
 * @param numData
 * @return - returns the number of data written or -1 on error
 */
int sm_write(serv_connection_t *sc, void *buf, ssize_t numData)
{
  ssize_t bytesWritten = 0;

  bytesWritten = send(sc->sockFd, buf, numData, MSG_NOSIGNAL);
#if 0
  if(bytesWritten < 0) 
    {
      //TODO: Ugly write a proper exit routine here
      serv_connection_release(sc); // give back our connection
      pthread_exit(0);                   // exit the thread - no return from here
    }
#endif
  return bytesWritten;
}


/**
 * Connection Handler thread.
 * This is the main program serving each connection between a client and the server.
 * The server reads input from the input stream, tries to make a command out of it
 * executes the command and return the result.
 * this function is called from main when a connection is accepted.
 * @param arg - should be a pointer to a serv_connection_t
 */
void *conn_handler_thread(void *arg)
{
  int done;
  int  cmdBufLen = 256;
  char cmdBuf[256]; // command buffer
  int  chRead;      // number of characters in command line read.
  int retVal;
  serv_connection_t *servConn;  // pointer to our server connection object
  cmd_pkt_t *cmdPkt;
  void *retBuf = 0x0;      //will hold return value from routine
  int   retLen;      // length of return buffer
#ifdef DBE_SEND_PROMPT
  char *prompt = "RDBE Term:>" ;
#endif
  int   chW;        // temporary for write returns
  char  errBuf[255]; // used to print error messages

  time_t now;
  char filename[255];
  struct tm * ntm;
  int flush_cntr = 0;
  char conn_ip[16];

  if(!arg) 
    {
      retVal = -ERR_CONN_NULL_ARG;
      pthread_exit(&retVal);
    }
  
  servConn = (serv_connection_t*) arg; // assume this is ok assignment
  done = 0;

  /* allocate #include <signal.h>memory for this thread */
  retBuf = (char *)malloc(RESP_BUF_SIZE * sizeof(char));
  
  if ((char *)NULL == retBuf)
    {
      sm_write(servConn, (void *)RessourcesError, strlen(RessourcesError));
      close(servConn->sockFd);
      serv_connection_release(servConn);
      pthread_exit(0);
    }

  memset(conn_ip, '\0', 16);
  strncpy(conn_ip, inet_ntoa(servConn->clientAddr.sin_addr), 15);

  while(!done) 
    {
      // Get a command line worth of data to process from the input stream
      chRead = get_cmd_line(cmdBuf, cmdBufLen, servConn->sockFd);
#ifdef DEBUG_VERBOSE
      printf("server_main:conn_handler_thread - chRead=%d\n", chRead);
#endif
      if(chRead < 0) 
	{
	  // we have an error on the client socket -- probably lost the connection, so time to exit
	  // TODO: Write the exit routine for the thread here
	  serv_connection_release(servConn); // give back our connection
	  /* give back the memory */
	  if (retBuf)
	    free(retBuf);
	  pthread_exit(0);                   // exit the thread - no return from here
	}
     if(chRead > 0) 
       {
	 if (strchr(cmdBuf, '='))
	   {
	     now = time(NULL);
	     ntm = gmtime(&now);

	     ntm->tm_year += 1900;
	     ntm->tm_mon++;

	     if (file_day_stamp != ntm->tm_mday)
	       {
		 /* close the current file and open a new one */
		 fflush(logfp);
		 fclose(logfp);

		 memset(filename, 0x0, 255);
  
		 sprintf(filename, "/home/roach/rdbe_sw/src/rdbe_server_%s_%02d_%02d.log", 
			 roach_ip,
			 ntm->tm_mon,
			 ntm->tm_mday);
		 
		 logfp = fopen(filename, "w");
		 if ((FILE *)NULL == logfp)
		   {
		     logfp = stderr;
		     fprintf(logfp, "WARNING: setup log file for rdbe_server failed!\n");
		   }
  
		 file_day_stamp = ntm->tm_mday;
	       }
		 
	     fprintf(logfp, "%s%s: %s\n", ctime(&now), conn_ip, cmdBuf);
	     
	     if (flush_cntr++ > 10)
	       {
		 flush_cntr = 0;
		 fflush(logfp);
	       }
	   }
	 retVal = vsis_get_command(&cmdPkt, cmdBuf, chRead); // ask parser to build a command from the command line
	 if(retVal == 0 && cmdPkt != 0)
	   {  // parse OK, and cmdPkt exists
#ifdef DEBUG_VERBOSE
	     printf("executing command %p\n", cmdPkt);
#endif
	     /* clear the memory */
	     memset(retBuf, '\0', RESP_BUF_SIZE * sizeof(char));
	     
	     retVal = cmd_execute_cmd(cmdPkt, &retBuf, &retLen);
#ifdef DEBUG_VERBOSE
	     if( retVal == VSIS_RET_SUCCESS)
	       {
		 printf("command successful\n");
	       } 
	     else 
	       {
		 printf("command unsuccessful\n");
	       }
#endif
	     /* --- THIS SHOULD BE TO A LOG AND NOT PRINTF */
	     if( retVal != VSIS_RET_SUCCESS)
	       {
		 now = time(NULL);
		 fprintf(logfp, "%sCmd unsuccessful %p : %s from %s.\n", 
			 ctime(&now), cmdPkt, cmdBuf,
			 inet_ntoa(servConn->clientAddr.sin_addr));
	       }

	     if(retLen > 0 && retBuf != 0) 
	       {
		 chW = sm_write(servConn, retBuf, retLen);         // send result to requester
		 if (chW < 0)
		   {
		     serv_connection_release(servConn); // give back our connection
		     /* give back the memory */
		     if (retBuf)
		       free(retBuf);
#if 0
		     now = time(NULL);
		     fprintf(logfp, "%s connection from %s closed.\n", 
			     ctime(&now), inet_ntoa(servConn->clientAddr.sin_addr));
#endif
		     pthread_exit(0);
		   }
		 retLen = 0;
	       } 
	     else 
	       {
		 // we did not get a response from execution although we should have!
		 sprintf(errBuf,"!%d;\n", VSIS_RET_UNDEFINED_STATE);
		 chW = sm_write(servConn, errBuf, strlen(errBuf)); // Print error
		 if (chW < 0)
		   {
		     serv_connection_release(servConn); // give back our connection
		     /* give back the memory */
		     if (retBuf)
		       free(retBuf);
#if 0
		     now = time(NULL);
		     fprintf(logfp, "%s connection from %s closed.\n", 
			     ctime(&now), inet_ntoa(servConn->clientAddr.sin_addr));
#endif
		     pthread_exit(0);
		   }
	       }
	     parser_free_cmd(cmdPkt); //
	   } 
	 else 
	   {
	     // we had a problem parsing the command, print the error message based on retVal;
	     sprintf(errBuf, "!%d:%s;\n", -retVal, vsis_ret_code_2_str(-retVal));
	     now = time(NULL);
	     chW = sm_write(servConn, errBuf, strlen(errBuf)); // Print error
	     if (chW < 0)
	       {
		 serv_connection_release(servConn); // give back our connection
		 /* give back the memory */
		 if (retBuf)
		   free(retBuf);
#if 0
		 now = time(NULL);
		 fprintf(logfp, "%s connection from %s closed.\n", 
			 ctime(&now),inet_ntoa(servConn->clientAddr.sin_addr));
#endif
		 pthread_exit(0);
	       }
	   }
#ifdef DBE_SEND_PROMPT
	 chW = sm_write(servConn, prompt, strlen(prompt)); // send prompt?
	 if (chW < 0)
	   {
	     serv_connection_release(servConn); // give back our connection
	     /* give back the memory */
	     if (retBuf)
	       free(retBuf);
	     pthread_exit(0);
	   }
#endif
       }
     if(chRead == 0)
       {
	 // we did not get any characters but a command line
	 // print error and continue
#ifdef DBE_SEND_PROMPT
	 chW = sm_write(servConn, prompt, strlen(prompt)); // send prompt?
	 if (chW < 0)
	   {
	     serv_connection_release(servConn); // give back our connection
	     /* give back the memory */
	     if (retBuf)
	       free(retBuf);
	     pthread_exit(0);
	   }
#endif
       }
   }
 serv_connection_release(servConn);
 /* give back the memory */
 if (retBuf)
   free(retBuf);
 pthread_exit(0);
}

extern void *one_pps_thread(void *arg);
extern void *mib_raw_capture_thread(void *arg);
extern void *raw_capture_thread(void *arg);
extern int processAppStartupFile(void);
extern int LoadSavedSettings(void);

extern char * getmyIP(void);


#ifdef _DEBUG_1PPS_
void timer_handler (int signum)
{
  int val = 1;
  struct timeval tv;

  gettimeofday(&tv, NULL);
  printf("called: %ld:%ld\n", tv.tv_sec, tv.tv_usec);

  //fpga_isr_rd();
  util_write_short_fpga((unsigned int)(0x20), 1, &val);
  val = 0;
  //usleep(20000);
  util_write_short_fpga((unsigned int)(0x20), 0, &val);
}

#endif


/**
 * start the rdbe server. Command line parameters are port_number and number of connections
 * @param argc - should be 3
 * @param argv - shuold be <program_name> <port_number> <max_connections>
 * @return
 */
int main(int argc, char **argv)
{
  struct sockaddr_in  clientAddr; // address to client when connected
  unsigned  clientLen;            // length of client socket type descriptor
  int rc;
  int termDev;                   // the terminal server descriptor number
  int rdbeDev;                   // the rdbe device number
  int portNo;		       //The port to listen to
  int maxConnections;	       // Maximum number of active connections
  char * ip_ptr = (char *)0x0;

  serv_connection_t *servConPtr; // pointer to current available connection

  pthread_t mib_rawThread, rawThread, one_pps_thread_handler;

  char filename[255];
  time_t now;
  struct tm * ntm;

  signal(SIGPIPE, SIG_IGN);

  // Initialization of variables
  clientLen  = sizeof(clientAddr);

  /* open syslog to log errors */
  openlog("RdbeLog", LOG_CONS|LOG_NDELAY, LOG_LOCAL1);

  /* initialize curernt settings structure */
  memset(&current_settings, 0, sizeof(rdbe_settings_t));

  /* initialize my IP */
  memset(roach_ip, '\0', IP_STR_LEN * sizeof(char));
  ip_ptr = getmyIP();
  if (ip_ptr)
    strncpy(roach_ip, ip_ptr, IP_STR_LEN);
  else
    strncpy(roach_ip, "0.0.0.0", IP_STR_LEN);


  now = time(NULL);
  ntm = gmtime(&now);
  
  ntm->tm_year += 1900;
  ntm->tm_mon++;
  
  memset(filename, 0x0, 255);
  
  sprintf(filename, "/home/roach/rdbe_sw/src/rdbe_server_%s_%02d_%02d.log", 
	  roach_ip,
	  ntm->tm_mon,
	  ntm->tm_mday);

  logfp = fopen(filename, "a");
  if ((FILE *)NULL == logfp)
    {
      logfp = stderr;
      fprintf(logfp, "WARNING: setup log file for rdbe_server failed!\n");
    }
  
  file_day_stamp = ntm->tm_mday;
  fprintf(logfp, "# RDBE Server log started on: %s", ctime(&now));


#if 0
  rc = processAppStartupFile();
  if (rc)
    syslog(LOG_ERR, "error @ line: %d", rc);
#endif

  /*  parse command line rdbe_server [port, max_connections]	 */
  if(argc != 3) {
    fprintf(stdout, "call server with <program name> <port number> <max connections> \n");
    return -ERR_WRONG_NUM_ARGS;
  }

  // parse the Port Number Argument
  portNo = atoi(argv[1]);
  if(portNo == 0)	{
    fprintf(stdout, "Invalid port specification, call server with <program name> <port number> <max connections> \n");
    return -ERR_INVALID_PORT;
  }

  // parse the max connections argument
  maxConnections = atoi(argv[2]);
  if(maxConnections == 0 ) {
    fprintf(stdout, "Invalid max connections specification, call server with <program name> <port number> <max connections> \n");
    return -ERR_INVALID_NUM_CONNECTIONS;
  }
  if(maxConnections > SERVER_CONN_MAX) {
    fprintf(stdout, "too many connections specified (max %d), call server with <program name> <port number> <max connections> \n",SERVER_CONN_MAX);
    return -ERR_TOO_MANY_CONNECTIONS;
  }
#if 0
  /* we are ready to run */
  /* daemonize the process */
  if (daemon(0,0) < 0)
    {
      perror("can't be a daemon");
      exit(-1);
    }
  /* if we are here, we are a daemon */
#endif
  // try to open a socket to listen to at the specific port
  if((rc = serv_open_socket(&termDev, portNo)) != 0){
    fprintf(logfp,"Error Starting Server with arguments Port= %s and Protocol= %s\n", argv[1], argv[2]);
    return rc;
  }

  // Try to open the RDBE device
#ifdef RDBE_PRESENT
  rdbeDev = open(RDBE_DEV, O_RDWR);
  if(rdbeDev <= 0)
    {
      fprintf(logfp, " fatal error failed to open the RDBE device with error %d \n", rdbeDev);
      fflush(logfp);
      fclose(logfp);

      close(termDev); // close the socket
      return -ERR_OPEN_RDBE;
    }
  servRdbeDev = rdbeDev; // make this visible for units in the module
#else
  //#elif
  //#endif
  //DEBUG DEBUG
  rdbeDev     = 0;
  servRdbeDev = 0; // emulation mode
  //DEBUG DEBUG
#endif
  cmd_common_initialize_cmd(); // initialize command parser and execution with basic instructions
  cmd_low_level_initialize();
  cmd_base_initialize();
  cmd_hal_initialize();
  //	cmd_print_cmd_list(); // DBUG

  ss_init(); // initialize server storage module

#if 1
  /* read the saved settings from disk */
  LoadSavedSettings();
#endif

  /* now lets prepare our arp table */
  InitRdbeAppStat();

#if 0 /* using dbe_rms instead */
  /* startup the raw_capture server port listner */
  if (0 != pthread_create(&mib_rawThread, 0, (void*)mib_raw_capture_thread, 0))
    {
      fprintf(logfp, "Failed to start the MIB Raw Data Server on port 5020\n");
    }
  else
    fprintf(logfp, "RDBE MIB Raw Data Server Started listening on TCP port 5020, with max connections 2\n");
#endif

  /* startup the raw_capture server port listner */
  if (0 != pthread_create(&rawThread, 0, (void*)raw_capture_thread, 0))
    {
      fprintf(logfp, "Failed to start the Raw Data Server on port 5050\n");
    }
  else
    fprintf(logfp, "RDBE Raw Data Server Started listening on TCP port 5050, with max connections 2\n");

  /* start our 1pps_mon thread */
  if (0 != pthread_create(&one_pps_thread_handler, 0, (void*)one_pps_thread, 0))
    {
      fprintf(logfp, "Failed to start the 1pps monitor thread.\n");
    }
  else
    fprintf(logfp, "1pps monitor thread was started.\n");

  /* start our Tsys mon thread */
  
  // Print a nice greeting when we successfully started our server ...
  fprintf(logfp, "RDBE Server Started listening on TCP port %s, with max connections %s \n", argv[1], argv[2]);

  // Start listening for connection requests, allow 5 pending request
  listen(termDev, 5);
  /*
   * Initialize global structures
   */
  pthread_mutex_init(&rdbeMutex, NULL);
  serv_connection_init(maxConnections);  // initialize a set of connection structures
  servConPtr = serv_connection_get_first_available();

  /* do this just in case */
  fpga_set_1pps_status(1);
  /* enable the 1pps interrupt */
  fpga_isr_enable(0);
  
#ifdef _DEBUG_1PPS_
  {      
    struct itimerval tvalue;
    struct timeval tv;
    struct sigaction sa;
    long wait_time;
    short val = 1;

    while(1)
      {
	val = 1;
	gettimeofday(&tv, NULL);
	wait_time = 1000000 - tv.tv_usec;
	usleep(wait_time);
	gettimeofday(&tv, NULL);
	util_write_short_fpga((unsigned int)(0x20), 1, &val);
	val = 0;
	usleep(20000);
	util_write_short_fpga((unsigned int)(0x20), 1, &val);

	printf("called: %ld:%ld\n", tv.tv_sec, tv.tv_usec);
      }
  }
 
#endif

  /*
   * Main loop here wait for connections and create handler threads for each connection when needed
   */
  while(1) 
    {
      if(servConPtr) 
	{
	  servConPtr->sockFd = accept(termDev, (struct sockaddr *) &servConPtr->clientAddr, &clientLen);
	  
	  if (servConPtr->sockFd < 0) 
	    {
	      now = time(NULL);
	      fprintf(logfp, "%s Error in accepting socket.\n", ctime(&now));
	    } 
	  else 
	    {
#if 0
	      now = time(NULL);
	      fprintf(logfp, "%s Got connection from: %s\n", ctime(&now), inet_ntoa(servConPtr->clientAddr.sin_addr));
#endif
	      
	      // we have a socket to work on ... create a handler thread do do the work
	      rc = pthread_create(&servConPtr->handlerThread, 0, conn_handler_thread, (void*)servConPtr);
	      if (rc)
		{
		  /* there is a problem */
		  now = time(NULL);
		  fprintf(logfp, "%s Failed to create thread to handle a new connection from: %s.\n", 
			  ctime(&now), inet_ntoa(servConPtr->clientAddr.sin_addr));
		  sleep(1);
		  continue;
		}
	      else
		{
		  /* tell to detach every thing when it is done */
		  pthread_detach(servConPtr->handlerThread);
		  servConPtr = serv_connection_get_first_available();  // get a new available connection to work with
		}
	    }
	} 
      else 
	{
	  sleep(1); // put the process to sleep for a second .. waiting for available connections
	  servConPtr = serv_connection_get_first_available(); // try to get a connection
	}
    }
  
  now = time(NULL);
  fprintf(logfp, "%s Rdbe Server is quitting.\n", ctime(&now));
  fflush(logfp);
  fclose(logfp);
  
  ss_free_all();  // clear the server storage and tidy up the module
  serv_connection_destroy();  // clear all outstanding data, kill all threads
#ifdef RDBE_PRESENT
  close(rdbeDev);  // close RDBE device connection if present
#endif
  close(termDev);
  fprintf(stdout, "Exiting RDBE Server\n");
  return 0;
}
