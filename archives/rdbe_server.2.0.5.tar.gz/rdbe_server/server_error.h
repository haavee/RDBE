/*
 * server_error.h
 *
 *  Created on: Jul 24, 2009
 *      Author: micke
 */

#ifndef SERVER_ERROR_H_
#define SERVER_ERROR_H_

#define ERR_SUCCESS					0
#define ERR_WRONG_NUM_ARGS			1
#define ERR_INVALID_PORT			2
#define ERR_INVALID_NUM_CONNECTIONS	3
#define ERR_TOO_MANY_CONNECTIONS	4
#define ERR_OPEN_SOCKET				5
#define ERR_SOCKET_OPEN				6
#define ERR_SOCKET_BIND				7
#define ERR_OPEN_RDBE				8
#define ERR_CONN_NULL_ARG			9
#define ERR_PARSER_0                10
#define ERR_PARSER_1                11
#define ERR_PARSER_2				12
static char  *server_errors[] = {"Success", "Wrong Number of Arguments", "Invalid Port", "Invalid number of connections",
		"Too many connections specified", "Error Opening Socket", "Error Opening Server Socket", "Error binding socket",
		"Error opening RDBE device", "Error handler called with null", "called cmd tokenize with null buffer", "Invalid arguments to build cmd",
		"Error could not find valid command name"};

#endif /* SERVER_ERROR_H_ */
