/*
 * cmd_low_level.h
 *
 *  Created on: Aug 27, 2009
 *      Author: micke
 */

#ifndef CMD_LOW_LEVEL_H_
#define CMD_LOW_LEVEL_H_

/**
 * Initializes command lists with basic command set
 */
void cmd_low_level_initialize(void);

#endif /* CMD_LOW_LEVEL_H_ */
