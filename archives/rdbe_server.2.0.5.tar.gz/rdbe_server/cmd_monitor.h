/*
 * cmd_monitor.h
 *
 *  Created on: Sep 22, 2009
 *      Author: nrao
 */

#ifndef CMD_MONITOR_H_
#define CMD_MONITOR_H_

void cmd_base_initialize(void);


#endif /* CMD_MONITOR_H_ */
