/*
 * cmd_monitor.c
 *
 *  Created on: Sep 22, 2009
 *      Author: Mikael Taveniku XCube Communication Inc.
 *      License: GPL
 *      Description: Common commands that the rdbe server understands.
 *      this file implements VSIS compatible commands that are defined by XXX.XXX
 *
 * monitor_power_get - get switch power data points
 * monitor_pulse_cal_get() - get pulse cal data points
 * monitor_thermal_cal_get() - get thermal cal data points
} *
 */

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>     // open, etc
#include <unistd.h>    // close, read
#include <pthread.h>

#include <string.h>
#include <sys/stat.h>
#include <linux/mman.h> // memory management things
#include <sys/mman.h>   //mmap

#include <sys/socket.h>
#include <netinet/in.h>

#include "rdbe_exports.h"     // device driver information access functions and types
#include "cmd_parser.h"
#include "serv_storage.h"
#include "server_error.h"
#include "server_error.h"
#include "cmd_low_level.h" // low level vsis compatible access to rdbe
#include "cmd_common.h"    // common commands for the rdbe device
#include "cmd_base.h"      // basic command set for rdbe

extern int serv_rdbe_ioctl(int funNo, char*arg); // defined in server main for now
extern int serv_get_data(int bufNo, unsigned long length);
extern int get_cmd_line(char *buf, int max_len, int dev);

/**
 * mutex to serialize access the RDBE device
 */
pthread_mutex_t monitorMutex;

/** this is the descriptor for the open RDBE device */
int monitorHalDev = 0;

/**
 * Structure that keep state information about the monitor connection thread
 */
typedef struct
{
	int tcal_data;
   int pcal_data;
   int swpwr_data;
	int users;                     // 0 if available
	int sockFd;                    // file descriptor
	struct sockaddr_in clientAddr; // client address record
   pthread_t handlerThread;       // Thread information
} monitor_loop_t;

/** handle to monitor loop thread */
monitor_loop_t *monitorLoop = NULL;

/**
 * Monitor thread.
 * This is the main monitor loop program
 * @param arg - should be a pointer to a monitor_loop_t
 */
void *monitor_thread(void *arg)
{
	int  done;
	int  retVal;
	monitor_loop_t  *monitorLoop;

	if (!arg)
   {
		retVal = -ERR_CONN_NULL_ARG;
		pthread_exit(&retVal);
	}

	monitorLoop = (monitor_loop_t*) arg; // assume this is ok assignment
	done = 0;
	while (!done)
   {
      // lock
      pthread_mutex_lock(&monitorMutex);

      // get some data - implement function calls.

      // unlock
      pthread_mutex_unlock(&monitorMutex);

      // take a peek at the data after a second
      sleep(1);

      // sleep half a second and check if time tag has changed.

   }

	pthread_exit(0);
}

/**
 * Startup the monitor loop thread to get pcal, tcal, and power values
 * @return       - 0 on success, negative return code otherwise
 */
void startMonitorLoopThread(void)
{

}

/**
 * Implement monitor power query
 * @param argc   - 1
 * @param argv   - <channel>
 * @param retVal - <return code>
 * @param retLen - length of
 * @return       - 0 on success negative return code otherwise
 */
int monitor_power_get(int argc, void **argv, void **retVal, int *retLen)
{
  // initialize variables
  *retLen = 0;
  sprintf(*retVal,"!get_power?%d:Not Implemented;\n", VSIS_RET_NOT_IMPLEMENTED);
  *retLen = strlen(*retVal);
  return -VSIS_RET_NOT_IMPLEMENTED;
}

/**
 * Definition of the monitor_get command
 */
void insert_monitor_power_get(void)
{
  char *name = "get_power";
  char *usage= "get power?;";
  int nParams = 1;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[1] = {CMD_PARAM_UNSIGNEDLONG };
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, monitor_power_get, cmdType);
}

/**
 * Implement monitor pulse cal query
 * @param argc   - 
 * @param argv   -
 * @param retVal - <return code>
 * @param retLen - length of
 * @return       - 0 on success negative return code otherwise
 */
int monitor_pulse_cal_get(int argc, void **argv, void **retVal, int *retLen)
{
  // initialize variables
  *retLen = 0;
  sprintf(*retVal,"!pcal?%d:Not Implemented;\n", VSIS_RET_NOT_IMPLEMENTED);
  *retLen = strlen(*retVal);
  return -VSIS_RET_NOT_IMPLEMENTED;
}

/**
 * Definition of the monitor_pulse_cal_get command
 */
void insert_monitor_pulse_cal_get(void)
{
  char *name = "get_pcal";
  char *usage= "pcal?;";
  int nParams = 1;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[1] = {CMD_PARAM_UNSIGNEDLONG };
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, monitor_power_get, cmdType);
}

/**
 * Implement monitor thermal cal query
 * @param argc   -
 * @param argv   -
 * @param retVal - <return code>
 * @param retLen - length of
 * @return       - 0 on success negative return code otherwise
 */
int monitor_thermal_cal_get(int argc, void **argv, void **retVal, int *retLen)
{
  // initialize variables
  *retLen = 0;
  sprintf(*retVal,"!tcal?%d:Not Implemented;\n", VSIS_RET_NOT_IMPLEMENTED);
  *retLen = strlen(*retVal);
  return -VSIS_RET_NOT_IMPLEMENTED;
}

/**
 * Definition of the monitor_thermal_cal_get command
 */
void insert_monitor_thermal_cal_get(void)
{
  char *name = "get_tcal";
  char *usage= "tcal?;";
  int nParams = 1;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[1] = {CMD_PARAM_UNSIGNEDLONG };
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, monitor_power_get, cmdType);
}

/**
 * Initializes command lists with basic monitor set
 */
void cmd_monitor_initialize(void)
{
  insert_monitor_power_get();
  insert_monitor_pulse_cal_get();
  insert_monitor_thermal_cal_get();
};


/**
 * start the rdbe server. Command line parameters are port_number and number of connections
 * @param argc - should be 3
 * @param argv - shuold be <program_name> <port_number> <max_connections>
 * @return
 */
int mainX(int argc, char **argv)
{
  int halDev;  // the hal device number
  int rdbeDev; // the rdbe device number
  monitor_loop_t *monitorLoopPtr = 0; // pointer to monitor loop data
  
  halDev  = 0;
  rdbeDev = 0;
  monitorHalDev = 0; // emulation mode
  
  /*
   * Initialize mutex and global structures
   */
  pthread_mutex_init( &monitorMutex, NULL );
  monitorLoopPtr = (monitor_loop_t *)malloc(sizeof(monitor_loop_t));
  
  
  /*
   * Create thread, thread runs until terminated
   */
  while(1)
    {
      // we have a socket to work on ... create a handler thread do do the work
      pthread_create(&monitorLoopPtr->handlerThread, 0, monitor_thread, (void*)monitorLoopPtr);
      sleep(1); // put the process to sleep for a second ..
    }
  
  // clean up
  pthread_mutex_destroy(&monitorMutex);
  free(monitorLoopPtr);
  monitorLoopPtr = 0;
  
#ifdef RDBE_PRESENT
  close(rdbeDev);  // close RDBE device connection if present
#endif
  return 0;
}
