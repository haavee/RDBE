/*
 * PrintBuffer.h
 *
 *  Created on: Jul 15, 2009
 *      Author: Mikael Taveniku XCube Communication Inc.
 */

#ifndef PRINTBUFFER_H_
#define PRINTBUFFER_H_

int   PrintBufferCreate(unsigned long length);
int   PrintBufferDestroy(void);
char* PrintBufferGetCurrent(void);
int   PrintBufferInsert(char *str);
int   PrintBufferClear(void);
int   PrintBufferGetBuffer(void);
int   PrintBufferClear(void);


#endif /* PRINTBUFFER_H_ */
