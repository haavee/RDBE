/* 
 * File:   cmd_monitor_storage.h
 * Author: mguerra
 *
 * Created on September 28, 2009, 4:10 PM
 */

#ifndef _CMD_MONITOR_STORAGE_H
#define	_CMD_MONITOR_STORAGE_H

#ifdef	__cplusplus
extern "C" {
#endif


/**
 * Structure for switch power data
 */
typedef struct {
	int bogus;
	pthread_t handlerThread;      // Thread information
} switched_power_t;

/**
 * Structure for pulse cal data
 */
typedef struct {
	int bogus;
	pthread_t handlerThread;      // Thread information
} pulse_cal_t;

/**
 * Structure for thermal cal data
 */
typedef struct {
	int bogus;
	pthread_t handlerThread;      // Thread information
} thermal_cal_t;

#ifdef	__cplusplus
}
#endif

#endif	/* _CMD_MONITOR_STORAGE_H */

