/*
 * cmd_hal.h
 *
 *  Created on: Oct 15, 2009
 *      Author: micke
 */

#ifndef CMD_HAL_H_
#define CMD_HAL_H_

/**
 * Initializes command lists with HAL command set
 */
void cmd_hal_initialize(void);


#endif /* CMD_HAL_H_ */
