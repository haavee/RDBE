/*
 * rdbe_tcp_client.c
 *
 *  Created on: Jul 6, 2009
 *      Author: micke
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>

#include <pthread.h>

#define SERVERIP 192.52.61.177
//#define SERVERIP 192.169.0.247


/*
 * host to network hton(type)
 */
void error(char *msg)
{
    perror(msg); // display information about system call errors
    exit(0);
}

/**
 * Reader thread that reads data from the socket described in arg, and writes the
 * data to stdout. It terminates when socket is broken or when thread_exit is called.
 * @param arg  - a pointer to an int describing the open socket
 */
void *reader_thread(void *arg)
{
	int nCh;
	char buf[256];
	int sockfd;
	int nChW;
	int tmpNCh;

	sockfd = *(int*)arg;
	while(1) {
		nCh = read(sockfd,buf,255);
		if (nCh < 0) {
			error("ERROR reading from socket -- exiting reader thread");
			pthread_exit(0);
		}
		nChW  = 0;
		while(nChW < nCh){
			tmpNCh = write(STDOUT_FILENO, &buf[nChW], nCh-nChW);
			if(tmpNCh >= 0){
				nChW += tmpNCh; // increase write count
			} else {
				// error on socket or timeout, discard buffer and try again
				nChW = nCh;
			}
		}
	}
	return 0;
}


int main(int argc, char *argv[])
{
	pthread_t reader_handle;
	char *chPtr; // temp character

	int sockfd, portno, n;
    struct sockaddr_in serv_addr;
//    struct hostent *server;

    char buffer[256];
    if (argc < 3) {
       fprintf(stderr,"usage %s hostIP port\n", argv[0]);
       exit(0);
    }
    portno = atoi(argv[2]);
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0)
        error("ERROR opening socket");

    // Create server socket
    serv_addr.sin_family = AF_INET;
    if (inet_pton(AF_INET, argv[1], &serv_addr.sin_addr) == 0) {
		fprintf(stderr, "inet_aton() with argument %s failed\n", argv[1]);
		exit(1);
	}

    serv_addr.sin_port = htons(portno);

//    server = gethostbyname(argv[1]);
//    if (server == NULL) {
//        fprintf(stderr,"ERROR, no such host\n");
//        exit(0);
//    }
//    bzero((char *) &serv_addr, sizeof(serv_addr));
//    serv_addr.sin_family = AF_INET;
//    bcopy((char *)server->h_addr,
//         (char *)&serv_addr.sin_addr.s_addr,
//         server->h_length);
//    serv_addr.sin_port = htons(portno);

    // Try to connect to the server
    if (connect(sockfd,(struct sockaddr *) &serv_addr,sizeof(serv_addr)) < 0){
        error("ERROR connecting");
    }

    // create the reader thread (reads from socket output to stdout)
    pthread_create(&reader_handle, 0, reader_thread, (void*)&sockfd);
    while(1) {
		printf("\nRDBE Term:> ");
		bzero(buffer,256);
		chPtr = fgets(buffer,255,stdin);

		n = write(sockfd,buffer,strlen(buffer));
		if (n < 0)
			 error("ERROR writing to socket");
    }
    return 0;
}
