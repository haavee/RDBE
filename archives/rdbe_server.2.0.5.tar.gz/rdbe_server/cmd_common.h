/*
 * cmd_common.h
 *
 *  Created on: Jul 29, 2009
 *      Author: micke
 */

#ifndef CMD_COMMON_H_
#define CMD_COMMON_H_

/**
 * Initializes command lists with basic command set
 */
void cmd_common_initialize_cmd(void);

#endif /* CMD_COMMON_H_ */
