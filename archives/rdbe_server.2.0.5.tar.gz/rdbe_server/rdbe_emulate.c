/*
 * rdbe_fake.c
 *
 *  Created on: Jul 29, 2009
 *      Author: Mikael Taveniku
 *      License: GPL
 *      Description: Test module for rdbe_device control functions
 */

#include <stdio.h>

#include "rdbe_exports.h"     // device driver information access functions and types

/**
 * Create a emulated rdbe device for testing.
 * This function replaces ioctl for rdbe_dev
 * @param devNo
 * @param cmdNo
 * @param arg
 * @return
 */
int rdbe_emulate_ioctl(int devNo, int cmdNo, char *arg)
{
	rdbe_rdwr_cmd_t *cmd;
	rdbe_configure_cmd_t *confCmd;
	unsigned char *cBuf;
	unsigned long i;
	fprintf(stderr, "<EM>");

	//printf("called with device=%d cmdNo=%d argument=%p \n", devNo, cmdNo, arg);

	switch(cmdNo){
	case RDBE_FPGA_READ:
		cmd = (rdbe_rdwr_cmd_t*) arg;
		cBuf = (unsigned char*)cmd->buf;
		for(i=0; i<(cmd->len * cmd->access_type); i++){
			cBuf[i] = (unsigned char) (i & 0xFF);
		}
		break;
	case RDBE_FPGA_WRITE:
		cmd = (rdbe_rdwr_cmd_t*) arg;
		switch(cmd->access_type){
		case 1:
			printf("FPGAWR %d\n", *(unsigned char*)cmd->buf);
			break;
		case 2:
			printf("FPGAWR %u\n", *(unsigned short*)cmd->buf);
			break;
		case 4:
			printf("FPGAWR %lu\n", *(unsigned long*)cmd->buf);
			break;
		default:
			printf("Unknown access type %lu\n", cmd->access_type);
			break;
		}
		break;
		case RDBE_DEV_CONFIGURE:
			confCmd = (rdbe_configure_cmd_t*) arg;
			printf("Configure cmd with pointer=%p and length=%lu\n", confCmd->buf, confCmd->len);
			break;
	default:
		printf("Command not understood %d\n", cmdNo);
	}
	return 0;

}

