/*
 * serv_storage.h
 *
 *  Created on: Aug 1, 2009
 *      Author: micke
 */

#ifndef SERV_STORAGE_H_
#define SERV_STORAGE_H_
#include <pthread.h>

/**
 * Allocates a buffer of size X at storage position bufNo
 * No check is made for multiple allocations of the same storage!
 * @param tId
 * @param bufNo
 * @param len
 * @return
 */
unsigned char *ss_allocate_buf(pthread_t tId, unsigned long bufNo, unsigned long len);

/**
 * Get the buffer allocated for thread tId and position bufNo
 * @param tId - thread id
 * @param bufNo - buffer number
 * @return the buffer or 0 if not found
 */
unsigned char *ss_get_buf(pthread_t tId, unsigned long bufNo);


/**
 * Get the length of a the buffer for tId at position bufNo
 * @param tId - thread id
 * @param bufNo - buffer number
 * @return - length of buffer or 0 on error
 */
unsigned long ss_get_buf_len(pthread_t tId, unsigned long bufNo);


/**
 * Initialize server storage structures, must be the first call to this module
 * @return 0 if successful
 */
int ss_init(void);

/**
 * Free a specific memory buffer (return it to the system)
 * @param tId - thread id
 * @param bufNo - buffer number
 * @return - 0 on success
 */
int ss_free_buf(pthread_t tId, unsigned long bufNo);

/**
 * Return all allocated memory for all threads to the system
 * Should be the last call to this module
 * @return 0 on success
 */
int ss_free_all(void);



#endif /* SERV_STORAGE_H_ */
