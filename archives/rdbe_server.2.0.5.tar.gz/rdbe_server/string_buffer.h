/*
 * string_buffer.h
 *
 *  Created on: Jul 16, 2009
 *      Author: micke
 */

#ifndef STRING_BUFFER_H_
#define STRING_BUFFER_H_

/**
 * allocate a new string buffer
 */
extern void* sb_new(void);


/**
 * add a string to the buffer
 */
extern void sb_addString(void* sb, const char*);

/** get the contents of the string buffer as a string */
extern char* sb_getString(void* buf);

/** get the length of the string buffer */
extern int sb_getLength(void* buf);

/** release the string buffer */
extern void sb_free(void* sb);


#endif /* STRING_BUFFER_H_ */
