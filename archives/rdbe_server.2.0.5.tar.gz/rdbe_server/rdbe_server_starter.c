#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <unistd.h>
#include <errno.h>

#include <sys/socket.h>
#include <sys/types.h>
#include <net/if.h>

#include <sys/ioctl.h>
#include <net/if_arp.h>
#include <arpa/inet.h>

#include <netdb.h>

#include <sys/time.h>

#include <time.h>
#include <string.h>

#define MAX_IP_LEN  16
#define MAX_MAC_LEN 18

#define HOSTNAME_LEN 255

#define MAX_LEN 255
#define MAX_ARGS 10

#define ARG_LEN  30

#define MAX_FAILURES 10

#define ALERT_PORT 20011

#define MAX_BUF_SIZE 1280

#define DFM_OK 0
#define DFM_ERROR -1

#define XML_OUTPUT_FORMAT_HEADER "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>\r\n"

extern int h_errno;

int readLine(FILE * pfile, char * buf);

int sendEmail(char *, char *);

int socketPrintf(int, char *);

FILE * dLog = (FILE *)NULL;

char ipaddr[MAX_IP_LEN];

char myMac[MAX_MAC_LEN];

char myhostname[HOSTNAME_LEN];

unsigned char hwAddr[6];

int getmyIP(void);
void checkHerrno(void);

static int alertport_sockfd;

static struct sockaddr_in alertport_client_addr;
static  struct sockaddr_in alertport_server_addr;
 
/* multicast IP */
static char* alertIP= "239.193.2.3";


int init_alertport_socket(void)
{
  unsigned char ttl = 10;

 
  if( (alertport_sockfd=socket(AF_INET, SOCK_DGRAM, 0))== -1)
    {
      perror("couldn't open a socket\n");
      return DFM_ERROR;
    }
  memset(&alertport_server_addr, 0, sizeof(alertport_server_addr));

  alertport_server_addr.sin_family = AF_INET;
  alertport_server_addr.sin_port = htons(0);
  alertport_server_addr.sin_addr.s_addr = inet_addr(ipaddr);

  if(bind(alertport_sockfd, (struct sockaddr *)&alertport_server_addr, 
	  sizeof(struct sockaddr)) == -1)
    {
      perror("alert: bind");
      return DFM_ERROR;
    }
  /* set the multicast packet TTL to 10 */
  if(setsockopt(alertport_sockfd, IPPROTO_IP, IP_MULTICAST_TTL, &ttl,
		sizeof(unsigned char) )<0)
    {
      perror("setsockopt");
      return DFM_ERROR;
    }

  /* set up the ip address for the alert */
  memset(&alertport_client_addr, 0, sizeof(alertport_client_addr));
  alertport_client_addr.sin_family = AF_INET;
  alertport_client_addr.sin_port = htons(ALERT_PORT);
  inet_aton(alertIP, &(alertport_client_addr.sin_addr));
  
  return DFM_OK;
}

#define SUNBEGIN  40587  /* MJD of Jan 1, 1970 */
#define SEC_DAY    86400 /* seconds per day */

double timeStamp()
{
  struct timeval tv;
  double now_time;

  gettimeofday(&tv, NULL);

  now_time = (double)tv.tv_sec +  (double)tv.tv_usec*0.000001;

  return (now_time/SEC_DAY + SUNBEGIN);
}


void MIBForceDigitalAlert(char * location, int stat)
{
  char buf[MAX_BUF_SIZE];
  int offset = 0;
  unsigned int numberbytes;

  offset += sprintf(buf+offset, XML_OUTPUT_FORMAT_HEADER );
  offset += sprintf(buf+offset,"<EVLAMessage location='%s' timestamp='%13.7f' >", 
		      location,
		      timeStamp());
  /* write device header */
  offset += sprintf(buf+offset, "<device name='%s' >", "DBE");

  offset += sprintf(buf+offset, 
		    "<monitor name='Unexpected_SERVER_Restart' type='digital' value='%d' alert='%d' />",
		    stat,
		    stat);

  offset += sprintf(buf+offset,"%s", "</device>" );
  offset += sprintf(buf+offset,"%s", "</EVLAMessage>" );


  /* send out the alert */
  numberbytes = sendto(alertport_sockfd, buf, offset, 0,
                       (struct sockaddr *)&alertport_client_addr,
                       sizeof(struct sockaddr));

  if (-1 == numberbytes)
    {
      fprintf(dLog, "error: %s\n", strerror(errno));
      fflush(dLog);
    }
}

/*
 * monitor the RDBE MIB process and restart it if needed.
 */
int main(int argc, char** argv)
{
  pid_t proc;
  char *args[MAX_ARGS];

  time_t logTime;

  time_t conTime;
  struct tm * nowtm;

  int goforever = 1;

  int i;
  int status;

  struct stat buf;

  char * strTime;

  char msg[MAX_LEN];

  int failureCnt = 0;

  struct hostent * myHostId = (struct hostent *)NULL;
  unsigned int addr;
  char * token = (char *)NULL;

  memset(myhostname, '\0', HOSTNAME_LEN);

  dLog = fopen("/home/roach/rdbe_sw/src/servre_dlog.txt", "a");
  
  if ((FILE *)NULL == dLog)
    dLog = stderr;

  /* store the if information: IPs + MAC address for later */
  if (!getmyIP())
    {
      logTime = time(&logTime);
      fprintf(dLog, "# RDBE SERVER STARTER log started on: %s", ctime(&logTime));
      
      fprintf(dLog, "#HW Address: %02X:%02X:%02X:%02X:%02X:%02X\n",
	      hwAddr[0], hwAddr[1], 
	      hwAddr[2], hwAddr[3], 
	      hwAddr[4], hwAddr[5]);
      
      fprintf(dLog, "DHCP IP @: %s\n", ipaddr);
      fflush(dLog);

            
      /* Get my id from the DNS server */
      addr = inet_addr(ipaddr);
      myHostId = gethostbyaddr((char *)&addr, 4, AF_INET);
      
      if ((struct hostent *)NULL == myHostId)
	{
	  /* we failed to receive a reply from the DNS server */
	  fprintf(dLog, "DNS query failed...\n");
	  checkHerrno();
	  strcpy(myhostname, "unkown");
	}  
      else
	{
	  /* we got a reply from the DNS server */
	  fprintf(dLog, "DNS query successful...\n");
	  token = strtok(myHostId->h_name, ".");
	  if ((char *)NULL == token)
	    {
	      fprintf(dLog, "Failed to acquire host name. Aborting\n");
	      return 0;
	    }
	  sprintf(myhostname, "%s", token);      
	}
    }

  /* prepare the alert socket */
  if (DFM_ERROR == init_alertport_socket())
    {
      fprintf(dLog, "failed to create an alert socket\n");
      fflush(dLog);
    }
  
  for(i=0; i<MAX_ARGS; i++)
    {
      args[i] = malloc(MAX_LEN * sizeof(char));
      memset(args[i], 0, MAX_LEN * sizeof(char));
    }


  strcpy(args[0], "rdbe_server");

  /* clear any previous alerts */
  MIBForceDigitalAlert(myhostname, 0);


  daemon(1, 0);

  while(goforever)
    {
      conTime = time(&conTime);
      strTime = ctime(&conTime);

      nowtm = gmtime(&conTime);

      if (failureCnt++ > MAX_FAILURES)
	{
	  /* something wrong here */
	  sendEmail("Process failed 10 times!", strTime);
	  strTime[strlen(strTime)-1] = '\0';
	  fprintf(dLog, "Process failed 10 times @ %s! Aborting...\n", strTime);
	  fflush(dLog);

	  printf("Process failed 10 times! Aborting...\n");
	  goforever = 0;
	  continue;
	}

      proc = fork();      
      switch(proc)
	{
	case 0:
	  /* default */
	  strcpy(args[1], "5000");
	  strcpy(args[2], "4");
	  /* the child process */
	  args[3] = (char *)NULL;
	  
	  if (-1 == stat("/home/roach/rdbe_sw/src/rdbe_server", &buf))
	    {
	      fprintf(dLog, "rdbe_server executable not found! Aborting...\n");
	      fflush(dLog);
	      exit(-1);
	    }
	  else
	    {
	      status = execl("/home/roach/rdbe_sw/src/rdbe_server", args[0], args[1], 
			     args[2], (char *)NULL);
	  
	      if (-1 == status)
		{
		  printf("pid 0: execl failed!\n");
		  fprintf(dLog, "pid 0: execl failed!\n");
		  fflush(dLog);
		}
	      exit(0);
	    }
	  break;
	case -1:
	  /* failure */
	  fprintf(dLog, "process creation failed on %s", strTime);
	  fflush(dLog);
	  break;
	default:
	  memset(msg, 0x0, MAX_LEN);
	  sprintf(msg, "New Process created with pid: %d", proc);
	  sendEmail(msg, strTime);
	  fprintf(dLog, "process created: %d on (UTC Time): %s\n", proc, strTime);
	  
	  fflush(dLog);
	  /* the parent process */
	  wait (&status);
	  if (WIFEXITED(status))
	    {
	      /* program exited normally */
	      sendEmail("rdbe_server failed to start! check log file", strTime);
	      goforever = 0;
	    }
#if 0
	  if (!WIFSIGNALED(status))
	    goforever = 0;
#endif
	  /* generate an alert */
	  fprintf(dLog, "sending an alert.\n");
	  fflush(dLog);
	  MIBForceDigitalAlert(myhostname, 1);

	  sleep(5);
	  break;
	} /* end switch (... */
    } /* end while(1) */    
  fprintf(dLog, "rdbe_srver_starter quitting...\n");
  fflush(dLog);
  fclose(dLog);
  return 0;
}


#define SMTP_SERVER "smtp.aoc.nrao.edu"
#define SMTP_SERVER_IP "146.88.1.15"
#define SMTP_PORT 25

#define FAIL_LOCAL  -1

#define MAX_MSG 0x2000

char ArrayToNotify[3][MAX_LEN] = {"hbenfrej@aoc.nrao.edu"};
int notify_cnt = 1;

int sendEmail(char * ErrMsg, char * str_time)
{
  struct sockaddr_in mailServAddr;
  struct sockaddr_in cliAddr;

  struct hostent *h;
  struct protoent *proto;

  char s_buf[MAX_MSG]= "";

  int sd, rc, n_ret;

  int j;

  char msg[MAX_LEN];

  h = gethostbyname(SMTP_SERVER);
  if(NULL == h)
    {
      fprintf(dLog, "unknown host '%s' \n", SMTP_SERVER);
      fflush(dLog);
      return -1;
    }

  mailServAddr.sin_family = h->h_addrtype;
  memcpy((char *) &mailServAddr.sin_addr.s_addr,
         h->h_addr_list[0], h->h_length);
  mailServAddr.sin_port = htons(SMTP_PORT);

  /* Next get the entry for TCP protocol */
  if ((proto = getprotobyname("tcp")) == NULL)
    {
      fprintf(dLog, "Could not get the protocol for TCP. Aborting...\n");
      return FAIL_LOCAL;
    }

  /* socket creation */
  sd = socket(AF_INET,SOCK_STREAM,proto->p_proto);
  if(sd<0)
    {
      fprintf(dLog, "SendMail: cannot open socket \n");
      return FAIL_LOCAL;
    }

  /* bind any port */
  cliAddr.sin_family = AF_INET;
  cliAddr.sin_addr.s_addr = htonl(INADDR_ANY);
  cliAddr.sin_port = htons(0);

  rc = bind(sd, (struct sockaddr *) &cliAddr, sizeof(cliAddr));
  if(rc < 0)
    {
      fprintf(dLog, "SendMail: cannot bind port\n");
      return FAIL_LOCAL;
    }

  if (-1 == connect(sd, (struct sockaddr *)&mailServAddr, sizeof(mailServAddr)))
    {
      fprintf(dLog, "SendMail: Connection refused by host %s.", SMTP_SERVER);
      fflush(dLog);
      return FAIL_LOCAL;
    }

  /* Now read the welcome message */
  n_ret = recv(sd, s_buf, MAX_MSG, 0);

  /* send hello message */
  memset(msg, 0x0, MAX_LEN);
  sprintf(msg, "HELO %s\r\n", myhostname);
  socketPrintf(sd, msg);

  n_ret = recv(sd, s_buf, MAX_MSG, 0);

  /* we need to extract the domain in the format cmp-lx@xxx.nrao.edu */
  

  /* now send the mail from header */
  memset(msg, 0x0, MAX_LEN);

  if (0 == strcmp(myhostname, "unkown"))
    sprintf(msg, "MAIL FROM: <rdbe_server_starter_%s@vlba.nrao.edu>\r\n", ipaddr);
  else
    sprintf(msg, "MAIL FROM: <rdbe_server_starter_%s@vlba.nrao.edu>\r\n", myhostname);

  socketPrintf(sd, msg);

  memset(s_buf, 0x0, MAX_MSG);
  n_ret = recv(sd, s_buf, MAX_MSG, 0);

  /* notify all receipient in one email */
  /* notify who every on the list */
  for (j=0; j < notify_cnt; j++)
    {
      memset(msg, 0x0, MAX_LEN);
      sprintf(msg, "RCPT TO: <%s>\r\n", ArrayToNotify[j]);
      socketPrintf(sd, msg);
      memset(s_buf, 0x0, MAX_MSG);
      n_ret = recv(sd, s_buf, MAX_MSG, 0);
    }
  /* now send the alaram message */
  socketPrintf(sd, "DATA\r\n");
  memset(s_buf, 0x0, MAX_MSG);
  n_ret = recv(sd, s_buf, MAX_MSG, 0);

  str_time[strlen(str_time)-1] = 0x0;
  memset(msg, 0x0, MAX_LEN);

  sprintf(msg, "Subject: %s -- %s on %s UTC\r\n",
          myhostname,
          ErrMsg,
          str_time);

  socketPrintf(sd, msg);

   /* send end of message */
  socketPrintf(sd, ".\r\n");

  memset(s_buf, 0x0, MAX_MSG);
  n_ret = recv(sd, s_buf, MAX_MSG, 0);

  /* close connection */
  socketPrintf(sd, "QUIT\r\n");
  
  close(sd);
  
  return 0;
}

int socketPrintf(int soc, char * msg)
{
  return send(soc, msg, strlen(msg), 0);
}


/*
 * Retreive the IP address of the RDBE.
 * return: string representing the IP address in format xxx.xxx.xxx.xxx
 *         NULL if not found.
 */

int getmyIP()
{
  int so;
  struct if_nameindex *pIdx, *pIdx2;
  struct ifreq ifr;
  unsigned char      *u;
       
  if ((so = socket(PF_INET, SOCK_DGRAM, 0)) < 0)
    {
      perror("socket");
      return 1;
    }
   
   pIdx = pIdx2 = if_nameindex();
   while ((pIdx != NULL) && (pIdx->if_name != NULL))
   {
      if (0 == strcmp("eth0", pIdx->if_name))
	{
	  strncpy(ifr.ifr_name, pIdx->if_name, IFNAMSIZ);
	  if (ioctl(so, SIOCGIFADDR, &ifr) < 0)
	    {
	      if (errno == EADDRNOTAVAIL)
		{
		  printf("\tN/A\n");
		  pIdx++;
		  continue;
		}
	      perror("ioctl");
	      close(so);
	      if_freenameindex(pIdx2);
	      return 1;
	    }

	  strncpy(ipaddr, (char *)inet_ntoa(((struct sockaddr_in*)&ifr.ifr_addr)->sin_addr), MAX_IP_LEN);

	  if (0 == ioctl(so, SIOCGIFHWADDR, &ifr))
	    {
	      u = (unsigned char *) &ifr.ifr_addr.sa_data;
	      
	      if (u[0] | u[1] | u[2] | u[3] | u[4] | u[5])
		sprintf(myMac, "%02x.%02x.%02x.%02x.%02x.%02x",
			u[0], u[1], u[2], u[3], u[4], u[5]);
	      {
		int i;
		for (i=0; i<6; i++)
		  hwAddr[i]= u[i];
	      }
	    }
	  close(so);
	  if_freenameindex(pIdx2);
	  return 0;
	}
      pIdx++;
   }
   if_freenameindex(pIdx2);
   close(so);
   return 1;
}

void checkHerrno(void)
{
  switch(h_errno)
    {
    case HOST_NOT_FOUND:
      fprintf(dLog, "The specified host is unknown.\n");
      break;
    case NO_ADDRESS:
      fprintf(dLog, "The requested name is valid but does not have an IP address.\n");
      break;
    case NO_RECOVERY:
      fprintf(dLog, "A non-recoverable name server error occurred.\n");
      break;
    case TRY_AGAIN:
      fprintf(dLog, "A temporary error occurred on an authoritative name server.  Try again later.\n");
      break;
    default:
      break;
    }
}

int readLine(FILE * pfile, char * buf)
{
  int c;
  int bread = -1;

  while(1)
    {
      c = getc(pfile);
      if ((-1 == c) || ('\n' == c))
        {
          if ('\n' == c)
            bread++;
          break;
        }
      if (bread++ > MAX_LEN)
        /* reached the max return */
        break;
      
      if ('\n' != c)
        *buf++ = c;
    }
  return bread;
}
