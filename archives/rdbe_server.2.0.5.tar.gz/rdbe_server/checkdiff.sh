#!/bin/sh -v


for f in *.c *.h;  do 
if [ -e $f ]; then
if [ -e /home/vlba2/techdocs/DBE/etch/home/roach/rdbe_sw/src/$f ]; then
    diff --brief $f /home/vlba2/techdocs/DBE/etch/home/roach/rdbe_sw/src/$f > /dev/null
    out=$?
    if [ $out -eq 1 ]; then
	echo $f is different
    fi
fi
fi
done
diff --brief Makefile /home/vlba2/techdocs/DBE/etch/home/roach/rdbe_sw/src/Makefile > /dev/null
out=$?
if [ $out -eq 1 ]; then
    echo Makefile is different
fi

