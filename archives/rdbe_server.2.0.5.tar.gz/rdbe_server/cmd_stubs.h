/*
 * File:   cmd_stubs.h
 * Author: mguerra
 *
 * Created on October 27, 2009, 10:32 AM
 */
#include <time.h>
#include "ioctl_util.h"  // read and write functions for devices

#ifndef _CMD_STUBS_H
#define	_CMD_STUBS_H

#ifdef	__cplusplus
extern "C"
{
#endif

#define APP_VERSION_MAJOR "2"
#define APP_VERSION_MINOR "0"
#define APP_VERSION_SUBMINOR "5"
#define APP_DESCRIPTION   "rdbe_server 2.0.5"
#define OS_DESCRIPTION    "Linux 2.6.25"

#define ROACH_BOARD_VERSION  "Roach Board version 1.0"
#define TIMING_BOARD_VERSION "Timimg Board version 1.0"
#define ALC_BOARD_VERSION    "ALC Board version 1.0"


#define MAX_PORTS      4

#define LAYER_2_TX     2
#define LAYER_4_TX     4

#define MIN_MTU        64
#define MAX_MTU        9000

enum DOT_OPTIONS
{
   NO_FORCE = 0,
   FORCE    = 1
};

enum DOT_SYNCH
{
   not_synched  = 0,
   syncerr_eq_0 = 1,
   syncerr_le_3 = 2,
   syncerr_gt_3 = 3,
};

typedef struct {
	void *buf;
	unsigned long len;
} hal_dot_t;

typedef struct {
	void *buf;
	unsigned long len;
} hal_clock_t;

typedef struct {
	void *buf;
	unsigned long len;
} hal_drs_data_format_t;

typedef struct {
	void *buf;
	unsigned long len;
} hal_drs_packet_t;

enum DOT_SYNCH calc_sync_status(unsigned long synch);

int LongToBcd (unsigned long *number);
int BcdToLong (unsigned long *number);
int WordSwap (unsigned long *number);

int fpga_set_if_ip_connection(char* ipAddr, int ifPort);
int fpga_get_if_ip_connection(char* ipAddr, int* ifPort);

int fpga_10ge_get_tx_packets(unsigned port, int *packs);
int fpga_10ge_get_tx_errors(unsigned port, int *packs);
int fpga_10ge_get_tx_dropped(unsigned port, int *packs);
int fpga_10ge_get_tx_overrun(unsigned port, int *packs);
int fpga_10ge_get_tx_queuelen(unsigned port, int *length);

int fpga_10ge_set_if_tid_ip(unsigned tid, char *ips);
int fpga_10ge_get_if_tid_ip(unsigned tid, char *ips);

/**
 * Set the payload format and offsets
 * @param dpOffset -
 * @param dfOffset -
 * @param length -
 * @param psnMode -
 * @param psnOffset -
 * @return - 0 on success
*/
int fpga_drs_set_packet(int dpOffset);

/**
 * Get the payload format and offsets
 * @param dpOffset -
 * @param dfOffset -
 * @param length -
 * @param psnMode -
 * @param psnOffset -
 * @return - 0 on success
*/
int fpga_drs_get_packet(int* dpOffset);


/**
 * Set the packet transmission mode
 * @param type - format vdif, mark5B, tgvdif, tvg5b
 * @param subMode1 - vdif number of channels or mark5B bit stream mask
 * @param subMode2 - vdif decimation ratio or mark5B non-applicable
 * @return - 0 on success
 */
int hal_drs_set_transmission_mode(unsigned short type, unsigned short subMode1, unsigned short subMode2);

/**
 * Get the packet transmission mode
 * @param type - format vdif, mark5B, tgvdif, tvg5b
 * @param subMode1 - vdif number of channels or mark5B bit stream mask
 * @param subMode2 - vdif decimation ratio or mark5B non-applicable
 * @return - 0 on success
 */
int hal_drs_get_transmission_mode(unsigned short * type, unsigned short * subMode1, unsigned short * subMode2);

int hal_drs_xfer_set(void);
int hal_drs_xfer_get(void);

int hal_personality_set(void);
int hal_personality_get(void);

int hal_bc_mode_set(void);
int hal_bc_mode_get(void);

int hal_clock_set(void);
int hal_clock_get(void);

/**
 * Get the current value of the DOT clock
 * @param curTime - current DOT reading
 * @return - 0 on success
 */
int hal_dot_get_current_time(time_t* curTime);

/**
 * Get the current value of the DOT clock
 * @param syncStatus - DOT 1pps synchronization status
 * @return - 0 on success
 */
//int hal_dot_get_sync_status(char* syncStatus);
int hal_dot_get_sync_status(enum DOT_SYNCH *synched);

/**
 * Get the current OS time
 * @param osTime - Corresponding OS time
 * @return - 0 on success
 */
int hal_dot_get_os_time(time_t* osTime);

/**
 * Get the current OS time
 * @param headTime - Current second count in the VLBI header
 * @return - 0 on success
 */
int hal_dot_get_header_time(time_t* headTime);

/**
 * Set and synchronize the DOT clock
 * @param dotTime - unsigned long 'JJJSSSSS' value to set the time
 * @param option  - If "force", 1pps generator will be re-synced
 * @return - 0 on success
 */
int hal_dot_set(unsigned long dotTime, enum DOT_OPTIONS option);

/**
 * Get the time seconds and interval from DOT clock
 * @param secTime    - unsigned long 'JJJSSSSS' value to return
 * @param timeOffset - Estimated interval
 * @return - 0 on success
 */
int hal_dot_get(unsigned long* dotTime, int* timeOffset);

/**
 * Set increment of DOT clock
 * @param secs - Number of seconds to increment
 * @return - 0 on success
 */
int hal_dot_inc_set(int secs);

/**
 * Get increment of DOT clock
 * @param secs - Number of seconds incremented
 * @return - 0 on success
 */
int hal_dot_inc_get(int* secs);

/**
 * Get system status
 * @param status - Status word
 * @return - 0 on success
 */
int hal_status(short* status);

/**
 * Initialize memory
 * @param  - none
 * @return - 0 on success
 */
int hal_init(void);

#ifdef	__cplusplus
}
#endif

#endif	/* _CMD_STUBS_H */

