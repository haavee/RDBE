#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

#include "cmd_stubs.h"
#include "hal.h"

#define FPGA_DOT_BASE                0x00000000
#define FPGA_DOT_SET_TIME_OFFSET     0x00000010
#define FPGA_DOT_CURRENT_TIME_OFFSET 0x00000014
#define FPGA_PKT_BASE                0X00000000

extern rdbe_settings_t current_settings;

int ByteSwap(unsigned short *number)
{
	unsigned short rByte = 0x00;
	unsigned short lByte = 0x00;
	unsigned short swapped = 0x00;

	rByte = (*number & 0x00FF);
	lByte = (*number & 0xFF00) >> 8;
	swapped = (rByte << 8);
	swapped = (swapped | lByte);

	*number = swapped;

	//printf("ByteSwap: number=%lu (0x%04x) left byte=0x%02x right byte=0x%02x \n", number, number, lByte, rByte);

	//printf("ByteSwap: swap number=%lu (0x%04x) left byte=0x%02x right byte=0x%02x \n", swapped, swapped, rByte, lByte);

	return 0;
}

int WordSwap(unsigned long *number)
{
	unsigned short rWord = 0x0000;
	unsigned short lWord = 0x0000;
	unsigned long swapped = 0x0000;

	// Shift into word and byte swap the word
	rWord = (*number & 0x0000FFFF);
	//ByteSwap(&rWord);
	lWord = (*number & 0xFFFF0000) >> 16;
	//ByteSwap(&lWord);
	swapped = (rWord << 16);
	swapped = (swapped | lWord);

	*number = swapped;

	//printf("WordSwap: number=%lu (0x%08x) left word=0x%04x right word=0x%04x \n", number, number, lWord, rWord);

	//printf("WordSwap: swap number=%lu (0x%08x) left word=0x%04x right word=0x%04x \n", swapped, swapped, rWord, lWord);

	return 0;
}

int LongToBcdOld(unsigned long *number)
{

	unsigned long tmp1, tmp2, tmp3;
	int i;

	tmp1 = *number;
	for (i = 0; 1 < 8; i++)
	{
		tmp2 = tmp1 % 10;
		tmp1 = tmp1 / 10;
		tmp3 = tmp3 || (tmp2 << (i * 4));
	}

	*number = tmp3;
	return 0;
}

int BcdToLongOld(unsigned long *number)
{

	unsigned long tmp1, tmp2, tmp3;
	int i;

	tmp1 = *number;
	tmp3 = 0;
	for (i = 7; i >= 0; i--)
	{
		tmp3 = tmp3 * 10;
		tmp2 = tmp1 & (0xF << (i * 4));
		tmp3 += tmp2 >> (i * 4);
	}

	*number = tmp3;
	return 0;
}

int LongToBcd(unsigned long *number)
{
	unsigned long tmp1 = 0x0l;
	unsigned long tmp2 = 0x0l;
	unsigned long tmp3 = 0x0l;
	int i;

	tmp1 = *number;
	for (i = 0; i < 8; i++)
	{
		tmp2 = tmp1 % 10;
		tmp1 = tmp1 / 10;
		tmp3 = tmp3 | (tmp2 << (i * 4));
	}

	*number = tmp3;
	return 0;
}

int BcdToLong(unsigned long *number)
{
	unsigned long tmp1 = 0x0l;
	unsigned long tmp2 = 0x0l;
	unsigned long tmp3 = 0x0l;
	int i;

	tmp1 = *number;
	for (i = 7; i >= 0; i--)
	{
		tmp3 = tmp3 * 10;
		tmp2 = tmp1 & (0xF << (i * 4));
		tmp3 += tmp2 >> (i * 4);
	}

	*number = tmp3;
	return 0;
}

int fpga_set_if_ip_connection(char* ipAddr, int ifPort)
{
#ifdef DEBUG_VERBOSE
	printf("Return arguments:\n");
	printf("IP address: %s, IF Channel: %d \n", ipAddr, ifPort);
#endif
	// Connect the DBE IF port to the Mark5C IP address
	// util_write_fpga(FPGA_DBE_IF_REG, 1, &ifPort);
	// util_write_fpga(FPGA_MARK5C_IP_REG, 7, ipAddr);
	return 0;
}

int fpga_get_if_ip_connection(char* ipAddr, int* ifPort)
{
	// Read the DBE IF port to the Mark5C IP address
	// util_read_fpga(FPGA_DBE_IF_REG, 1, &ifPort);
	// util_read_fpga(FPGA_MARK5C_IP_REG, 7, ipAddr);
#ifdef DEBUG_VERBOSE
	printf("Return arguments:\n");
	printf("IP address: %s, IF Channel: %d \n", ipAddr, *ifPort);
#endif
	return 0;
}

int fpga_10ge_get_tx_packets(unsigned port, int *packs)
{
	*packs = 0;
#ifdef DEBUG_VERBOSE
	printf("Return arguments:\n");
	printf("port: %d, packs: %d \n", port, *packs);
#endif
	return 0;
};

int fpga_10ge_get_tx_errors(unsigned port, int *packs)
{
	*packs = 0;
#ifdef DEBUG_VERBOSE
	printf("Return arguments:\n");
	printf("port: %d, packs: %d \n", port, *packs);
#endif
	return 0;
};

int fpga_10ge_get_tx_dropped(unsigned port, int *packs)
{
	*packs = 0;
#ifdef DEBUG_VERBOSE
	printf("Return arguments:\n");
	printf("port: %d, packs: %d \n", port, *packs);
#endif
	return 0;
};

int fpga_10ge_get_tx_overrun(unsigned port, int *packs)
{
	*packs = 0;
#ifdef DEBUG_VERBOSE
	printf("Return arguments:\n");
	printf("port: %d, packs: %d \n", port, *packs);
#endif
	return 0;
};

int fpga_10ge_get_tx_queuelen(unsigned port, int *length)
{
	*length = 0;
#ifdef DEBUG_VERBOSE
	printf("Return arguments:\n");
	printf("port: %d, packs: %d \n", port, *length);
#endif
	return 0;
};

int fpga_10ge_set_if_tid_ip(unsigned tid, char *ips)
{
	*ips = 10;
#ifdef DEBUG_VERBOSE
	printf("Return arguments:\n");
	printf("tid: %d, ips: %d \n", tid, *ips);
#endif
	return 0;
};

int fpga_10ge_get_if_tid_ip(unsigned tid, char *ips)
{
	*ips = 100;
#ifdef DEBUG_VERBOSE
	printf("Return arguments:\n");
	printf("tid: %d, ips: %d \n", tid, *ips);
#endif
	return 0;
};

/**
 * Set the payload format and offsets
 * @param dpOffset -
 * @param dfOffset -
 * @param length -
 * @param psnMode -
 * @param psnOffset -
 * @return - 0 on success
 */
int fpga_drs_set_packet(int dpOffset)
{
	unsigned short value = 0x00;
	// read the value of control register
	//util_read_fpga(FPGA_CONTROL_REG_BASE, 1, &value);
	value |= 0x10; // set bit 4 in the word
	// write it back to the register
	// util_write_fpga(FPGA_CONTROL_REG_BASE, 1, &value);
	util_write_short_fpga(FPGA_PKT_BASE, 1, &dpOffset);
	return 0;
}

/**
 * Get the payload format and offsets
 * @param dpOffset -
 * @param dfOffset -
 * @param length -
 * @param psnMode -
 * @param psnOffset -
 * @return - 0 on success
 */
int fpga_drs_get_packet(int* dpOffset)
{
	unsigned short value = 0x00;
	// read the value of control register
	//util_read_fpga(FPGA_CONTROL_REG_BASE, 1, &value);
	value |= 0x10; // set bit 4 in the word
	// write it back to the register
	// util_write_fpga(FPGA_CONTROL_REG_BASE, 1, &value);
	util_read_short_fpga(FPGA_PKT_BASE, 1, &dpOffset);
	return 0;
}

#define DATA_FORMAT_ADDR            0xEA

#define FPGA_DF_CHANNELS_COUNTS_BASE  0x80001E

/**
 * Set the packet transmission mode
 * @param type - format vdif, mark5B, tgvdif, tvg5b
 * @param subMode1 - vdif number of channels or mark5B bit stream mask
 * @param subMode2 - vdif decimation ratio or mark5B non-applicable
 * @return - 0 on success
 */

/* #define FPGA_SYSBLOCK_BASE 0 */

int hal_drs_set_transmission_mode(unsigned short type, unsigned short subMode1, unsigned short subMode2)
{
  unsigned short value = 0x00;
  short sel_inp = 0;
  unsigned short val;
  unsigned short p_type;
  int i;

  // read the value of control register
  //util_read_fpga(FPGA_CONTROL_REG_BASE, 1, &value);
  value |= 0x10; // set bit 4 in the word
  // write it back to the register
  // util_write_fpga(FPGA_CONTROL_REG_BASE, 1, &value);
  util_write_short_fpga(FPGA_PKT_BASE, 1, &type);
  util_write_short_fpga(FPGA_PKT_BASE, 1, &subMode1);

  /* only do it for DDC */
  if (0 == strcmp("DDC", current_settings.personality_type))
    {
      /* read the format for the loaded personality */
      util_read_short_fpga(6, 1, &val); /* since FPGA_SYSBLOCK_BASE 0 */
      p_type = ((val & 0xFF00) >> 8);
      if (0x83 == p_type)
	{
	  /* This is VDIF format set a mask */
	  for (i=0; i< (int)subMode2; i++)
	    sel_inp |= (1 << i);
	  
	  util_write_short_fpga(FPGA_DF_CHANNELS_COUNTS_BASE, 1, &sel_inp);
	}
      else
	util_write_short_fpga(FPGA_DF_CHANNELS_COUNTS_BASE, 1, &subMode2);
    }
  return 0;
}
/**
 * Get the packet transmission mode
 * @param type - format vdif, mark5B, tgvdif, tvg5b
 * @param subMode1 - vdif number of channels or mark5B bit stream mask
 * @param subMode2 - vdif decimation ratio or mark5B non-applicable
 * @return - 0 on success
 */
int hal_drs_get_transmission_mode(unsigned short * type, unsigned short* subMode1, unsigned short* subMode2)
{
  unsigned short value = 0x00;
  unsigned short p_type;
  unsigned short sm2 = 0;
  unsigned short val;
  unsigned short raw_val;

  util_read_short_fpga(DATA_FORMAT_ADDR+8, 1, &value);

  value &= 0xFF;

  if ('5' == value)
    *type = 1;
  else if ('V' == value)
    *type = 0;
  else
    *type = -1;

  //util_read_short_fpga(FPGA_PKT_BASE, 1, &subMode1);
  util_read_short_fpga(FPGA_DF_CHANNELS_COUNTS_BASE, 1, &raw_val);
  raw_val &= 0xFF;

  /* read the format for the loaded personality */
  util_read_short_fpga(6, 1, &val); /* since FPGA_SYSBLOCK_BASE 0 */
  p_type = ((val & 0xFF00) >> 8);
  if (0x83 == p_type)
    {
      /* change the mask format to numbers */
      for(;raw_val != 0; raw_val >>= 1, sm2++);
      *subMode2 = sm2;      
    }
  else
    *subMode2 = raw_val;
  return 0;
}

int hal_drs_xfer_set(void)
{
	return 0;
}

int hal_drs_xfer_get(void)
{
	return 0;
}

int hal_personality_set(void)
{
	return 0;
}

int hal_personality_get(void)
{
	return 0;
}

int hal_bc_mode_set(void)
{
	return 0;
}

int hal_bc_mode_get(void)
{
	return 0;
}

int hal_clock_set(void)
{
	time_t ltime;
	time(&ltime);
	printf("Coordinated Universal Time is %s\n", asctime(gmtime(&ltime)));
	printf("the time is %s", ctime(&ltime));
	return 0;
}

int hal_clock_get(void)
{
	return 0;
}

/**
 * Get the current value of the DOT clock
 * @param curTime - current DOT reading
 * @return - 0 on success
 */
int hal_dot_get_current_time(time_t* curTime)
{
	time_t ltime;
	time(&ltime);
	*curTime = ltime;
	printf("Coordinated Universal Time is %s\n", asctime(gmtime(curTime)));
	printf("the time is %s", ctime(curTime));
	return 0;

}

/**
 * Set the current value of the DOT clock
 * @param syncStatus - DOT 1pps synchronization status
 * @return - 0 on success
 */
//int hal_dot_get_sync_status(char* syncStatus)
//{
//   syncStatus = "not_synced";
//   return 0;
//}

/**
 * Set the current value of the DOT clock
 * @param syncStatus - DOT 1pps synchronization status
 * @return - 0 on success
 */
int hal_dot_get_sync_status(enum DOT_SYNCH* synched)
{
	synched = not_synched;
	return 0;
}

/**
 * Calc the DOT sync status
 * @param sync - actual sync time
 * @return - syncStatus - DOT 1pps synchronization status
 */
enum DOT_SYNCH calc_sync_status(unsigned long synch)
{
	enum DOT_SYNCH synchStatus;
	time_t osTime = time(NULL);
	localtime(&osTime);

	if ((synch - (osTime)) <= 3)
	{
		synchStatus = syncerr_le_3;
	}
	else if ((synch - (osTime)) > 3)
	{
		synchStatus = syncerr_gt_3;
	}
	else if ((synch - (osTime)) == 0)
	{
		synchStatus = syncerr_eq_0;
	}
	else
	{
		synchStatus = not_synched;
	}

	//free(osTm);
	return synchStatus;
}

/**
 * Get the current OS time
 * @param osTime - Corresponding OS time
 * @return - 0 on success
 */
int hal_dot_get_os_time(time_t* osTime)
{
	time_t ltime;
	time(&ltime);
	*osTime = ltime;
	printf("Coordinated Universal Time is %s\n", asctime(gmtime(&ltime)));
	printf("the time is %s", ctime(&ltime));
	return 0;
}

/**
 * Get the current OS time
 * @param headTime - Current second count in the VLBI header
 * @return - 0 on success
 */
int hal_dot_get_header_time(time_t* headTime)
{
	time_t ltime;
	time(&ltime);
	*headTime = ltime;
	printf("Coordinated Universal Time is %s\n", asctime(gmtime(&ltime)));
	printf("the time is %s", ctime(&ltime));
	return 0;
}

/**
 * Set the DOT clock
 * @param dotTime - unsigned long 'JJJSSSSS' value to set the time
 * @param option  - If "force", 1pps generator will be re-synced
 * @return - 0 on success
 */
int hal_dot_set(unsigned long dotTime, enum DOT_OPTIONS option)
{
	// write to the register
	printf("\nutil_write_fpga - set DOT clock: dotTime=%lu \n", dotTime);
	util_write_long_fpga(FPGA_DOT_SET_TIME_OFFSET, 1, &dotTime);
	return 0;
}

/**
 * Get the high order time from DOT clock
 * @param secTime - unsigned long 'JJJSSSSS' value to return
 * @param timeOffset - Estimated interval
 * @return - 0 on success
 */
int hal_dot_get(unsigned long* dotTime, int* timeOffset)
{
	timeOffset = 0;
	util_read_long_fpga(FPGA_DOT_SET_TIME_OFFSET, 1, dotTime);
	printf("\nutil_read_fpga - get DOT clock: dotTime=%lu \n", *dotTime);

	return 0;
}

/**
 * Set increment of DOT clock
 * @param secs - Number of seconds to increment
 * @return - 0 on success
 */
int hal_dot_inc_set(int inc)
{
  int retCode = -1;
  
  unsigned long dotTime = 0x0l;
  unsigned long secsOfDay = 0x0l;
  unsigned long dayOfYear = 0x0l;
  unsigned long bcdTimeCode = 0x0l;
  
  // read the value of control register
  // util_read_long_fpga(FPGA_DOT_CURRENT_TIME_OFFSET, 1, &dotTime);
  
  // Get current DOT running time in BCD
  retCode = fpga_get_dot(&dotTime);
#if DEBUG_VERBOSE
  printf("\nfpga_get_dot - get DOT clock: dotTime=%lu (0x%08x) \n", dotTime, (unsigned int) dotTime);
#endif
  // Word swap the BCD time code
  /* printf("\nPre-swap get DOT clock: %lu (0x%08x) \n", dotTime, (unsigned int) dotTime);
     WordSwap(&dotTime);
     printf("Post-swap get DOT clock: %lu (0x%08x) \n", dotTime, (unsigned int) dotTime); */
  
  // Extract seconds in the day and day of year in BCD 'JJJSSSSS'
  secsOfDay = (dotTime)&(0x000FFFFF); // calculate hour, minutes, seconds. . . .
  dayOfYear = (int) ((dotTime >> 20)&(0x00000FFF));
  
  // Convert BCD to long
  BcdToLong(&secsOfDay);
  BcdToLong(&dayOfYear);
#if DEBUG_VERBOSE
  printf("\nPre-increment  secsOfDay=%lu (0x%08x) dayOfYear=%lu (0x%08x) \n",
	 secsOfDay, (unsigned int) secsOfDay, dayOfYear, (unsigned int) dayOfYear);
#endif
  // Increment the seconds w/ day checker
  // dotTime += inc;
  if ((secsOfDay + inc) > 86400) // next day
    {
      ++dayOfYear;
      secsOfDay = (secsOfDay + inc) - 86400;
    }
  else if ((secsOfDay + inc) < 0) // previous day
    {
      --dayOfYear;
      secsOfDay = 86400 + (secsOfDay + inc);
    }
  else // increment the seconds
    {
      secsOfDay += inc;
    }
#if DEBUG_VERBOSE
  printf("\nPost-increment secsOfDay=%lu (0x%08x) dayOfYear=%lu (0x%08x) \n",
	 secsOfDay, (unsigned int) secsOfDay, dayOfYear, (unsigned int) dayOfYear);
  
  // populate the BCD time code ('JJJSSSSS')
  printf("\nPre-LongToBCD secsOfDay=%lu (0x%08x) \n", secsOfDay, (unsigned int) secsOfDay);
#endif 
  LongToBcd(&secsOfDay);
  
#if DEBUG_VERBOSE
  printf("Post-LongToBCD secsOfDay=%lu (0x%08x) \n", secsOfDay, (unsigned int) secsOfDay);
  
  printf("Pre-LongToBCD dayOfYear=%lu (0x%08x) \n", dayOfYear, (unsigned int) dayOfYear);
#endif
  LongToBcd(&dayOfYear);
  
#if DEBUG_VERBOSE
  printf("Post-LongToBCD dayOfYear=%lu (0x%08x) \n", dayOfYear, (unsigned int) dayOfYear);
#endif
  // create BCD time code 'JJJSSSSS' from incremented day and sec
  bcdTimeCode = (dayOfYear << 20) | (secsOfDay);
  
  // Swap BCD time code words
  /* printf("\nPre-swap BCD time code: %lu (0x%08x) \n", bcdTimeCode, (unsigned int) bcdTimeCode);
     WordSwap(&bcdTimeCode);
     printf("Post-swap BCD time code: %lu (0x%08x) \n", bcdTimeCode, (unsigned int) bcdTimeCode); */
  
  // set the DOT time and return
  // util_write_long_fpga(FPGA_DOT_SET_TIME_OFFSET, 1, &dotTime);
#if DEBUG_VERBOSE
  printf("\nfpga_set_dot - set DOT clock: dotTime=%lu (0x%08x) \n", bcdTimeCode, (unsigned int) bcdTimeCode);
#endif
  retCode = fpga_set_dot(bcdTimeCode);
  
  return 0;
}

/**
 * Get increment of DOT clock
 * @param secs - Number of seconds incremented
 * @return - 0 on success
 */
int hal_dot_inc_get(int* secs)
{
	util_read_long_fpga(FPGA_DOT_CURRENT_TIME_OFFSET, 1, secs);
	return 0;
}

/**
 * Get system status
 * @param status - Status word
 * @return - 0 on success
 */
int hal_status(short* statusWord)
{
  *statusWord = 0x0000;
  util_read_short_fpga(FPGA_DOT_BASE, 1, statusWord);
  return 0;
}

/**
 * Initialize the HAL
 * @param  - void
 * @return - 0 on success
 */
int hal_init(void)
{
/*
	unsigned short value = 0x0002;
	util_write_fpga(0x00000008, 1, &value);
	sleep(1);
	value = 0x003A;
	util_write_fpga(0x006001D4, 1, &value);
	sleep(1);
	//    value = 0x01D9;
	value = 0x81D9;
	util_write_fpga(0x00000008, 1, &value);
	sleep(1);
	value = 0xFFFF;
	util_write_fpga(0x006001C2, 1, &value);
	sleep(1);
	util_write_fpga(0x006001C4, 1, &value);
	sleep(1);
	util_write_fpga(0x006001D0, 1, &value);
	sleep(1);
	util_write_fpga(0x006001D2, 1, &value);
	sleep(1);
	util_write_fpga(0x006001CA, 1, &value);
	sleep(1);
	value = 0x0009;
	util_write_fpga(0x00A00000, 1, &value);
*/

   // Initialize the FPGA
    fpga_set_control_reg(0, 0x0100);
    sleep(1);
    fpga_set_control_reg(0, 0x0200);
    sleep(1);
    fpga_set_control_reg(0, 0xdb00);
    sleep(1);
    //fpga_qt_set_state_machine_status(0x003A);
    //sleep(1);
    //fpga_set_control_reg(0,0x81d9);
    //sleep(1);
    /* --- removed giving Bad alignment 6001c2 when executed --- COME BACK TO
       fpga_qt_set_enable_table(0xFFFFFFFF); */
    /* --- temp insertion till above is debuged - CAR */
    unsigned short value = 0xFFFF;
    util_write_short_fpga(0x006001C2, 1, &value);
    sleep(1);
    util_write_short_fpga(0x006001C4, 1, &value);
    sleep(1);
    util_write_short_fpga(0x006001d0, 1, &value);
    sleep(1);
    util_write_short_fpga(0x006001d2, 1, &value);
    /* --- temp insertion till above is debuged - CAR */
    sleep(1);
    //fpga_qt_set_comparator_enable(0xFFFFFFFF);
    sleep(1);
    fpga_qt_set_control(0xFFFF);
    sleep(1);
    fpga_ild_set_control(0x1000);
    sleep(1);
    fpga_ild_set_control(0x0000);
    sleep(1);
    fpga_ild_set_control(0x9000);
    sleep(1);
    return 0;
}
