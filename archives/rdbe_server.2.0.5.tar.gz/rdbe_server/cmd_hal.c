/*
 * cmd_hal.c
 *
 *  This module implements the "hal.h" functions as a set of VSI-S compatible commands that the command interpreter
 *  can use.
 *  Created on: Oct 15, 2009
 *      Author: mikael Taveniku XCube Communication Inc.
 *      License: GPL
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "hal.h"
#include "cmd_parser.h"


/**
 * Get the HAL SW version (this is the version of the hal library)
 * @param argc   - should be 0
 * @param argv   - pointers to the parameters
 * @param retVal - buffer with the data (allocated here)<rev_major> <rev_minor> <description>
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_hal_sw_get_version(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!hal_sw_get_version=0"; // beginning of return string
  char *retEnd   = ";\n";       // end of return string
  int major;
  int minor;
  char *desc;
  
  /* Execute the function:   */
  retCode = hal_sw_get_version(&major, &minor, &desc);
  
  if(retCode != 0) {
    sprintf(*retVal, "!hal_sw_get_version=%d:Execution Error;\n", VSIS_RET_EXECUTION_ERROR);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }
  
  /* Success get allocate return buffer and format data	 */
  sprintf(*retVal, "%s:%d:%d:%s:%s", retStart, major, minor, desc, retEnd);
  *retLen=strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}


/**
 * Insert the hal_sw_get_version into command queue.
 */
void insert_vsis_hal_sw_get_version(void)
{
  char *name = "hal_sw_get_version";
  char *usage= "hal_sw_get_version?;";
  int nParams = 0;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[1] = {CMD_PARAM_INT};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_hal_sw_get_version, cmdType);
}


/**
 * Set the value of fpga control register regNo [0..3]
 * @param argc   - should be 2
 * @param argv   - pointers to the parameters <register number><value>
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_set_control_reg(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_set_control_reg="; // beginning of return string
  char *retEnd   = ";\n";       // end of return string
  
  int paramOk;
  int regNo      = 0;
  unsigned short value = 0;
  
  // check parameters
  paramOk = 0;  // assume parameters are wrong before checking
  if(argv[0] != 0 && argv[1] != 0){
    regNo = (int)*(long*)argv[0];
    value = (unsigned short)*(unsigned long*)argv[1];
    if(regNo >=0 && regNo < 4){
      paramOk = 1;
    }
  }
  
  if(!paramOk) {
    sprintf(*retVal, "%s%d:Parameter Error;\n", retStart,VSIS_RET_PARAMETER_ERROR);
    *retLen = strlen(*retVal);
    return -VSIS_RET_PARAMETER_ERROR;
  }
  
  /* Execute the function:   */
  retCode = fpga_set_control_reg(regNo, value);
  
  /* Check for errors */
  if(retCode != 0) {
    sprintf(*retVal, "%s%d:Execution Error;\n", retStart, VSIS_RET_EXECUTION_ERROR);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }
  
  /* Success get allocate return buffer and format data	 */
  sprintf(*retVal, "%s%d%s", retStart, 0, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_set_control reg into command queue.
 */
void insert_vsis_fpga_set_control_reg(void)
{
  char *name = "fpga_set_control_reg";
  char *usage= "fpga_set_control_reg=<regNo>:<value>;";
  int nParams = 2;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[2] = {CMD_PARAM_UNSIGNED, CMD_PARAM_UNSIGNED};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_set_control_reg, cmdType);
}


/**
 * Get the value of fpga control register regNo [0..3]
 * @param argc   - should be 1
 * @param argv   - pointers to the parameters <register number>
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_get_control_reg(int argc, void **argv, void **retVal, int *retLen)
{
  /* --------------------------------------------------------------------------------------------------------
   * Bit field definitions for control register 0
   * Bit 0 – Arm – synchronizes to the external 1 pps.
   * Bit 1 – adc 3 wire reload, reloads the control data for to the ADC.
   * Bit 2 – ctrl reset, reset to the ADC board.
   * Bit 3 – Enable FIR filter 1, enable the FIR filter module
   * Bit 4 – Enable FFT, enables the FFT module
   * Bit 5 – dcm reset. Resets the DCM use to for managing the ADC clock.
   * Bit 6 – Enable Interpolator, enables the Interpolator module
   * Bit 7 – Enable Mk5BInterface,  enables the Mk5B interface module
   * --------------------------------------------------------------------------------------------------------
   */
  
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_get_control_reg?"; // beginning of return string
  char *retEnd   = ";\n";       // end of return string
  
  int paramOk;
  int regNo      = 0;
  unsigned short value = 0;
  
  // check parameters
  paramOk = 0;  // assume parameters are wrong before checking
  if(argv[0] != 0 ){
    regNo = (int)*(long*)argv[0];
    if(regNo >=0 && regNo < 4){
      paramOk = 1;
    }
  }
  
  if(!paramOk) {
    sprintf(*retVal, "%s%d:Parameter Error;\n", retStart,VSIS_RET_PARAMETER_ERROR);
    *retLen = strlen(*retVal);
    return -VSIS_RET_PARAMETER_ERROR;
  }

  /* Execute the function:   */
  retCode = fpga_get_control_reg(regNo, &value);
  
  /* Check for errors */
  if(retCode != 0) {
    sprintf(*retVal, "%s%d:Execution Error;\n", retStart, VSIS_RET_EXECUTION_ERROR);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }

  /* Success get allocate return buffer and format data	 */
  sprintf(*retVal, "%s%d:%x:%s", retStart, 0, value, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_get_control reg into command queue.
 */
void insert_vsis_fpga_get_control_reg(void)
{
  char *name = "fpga_get_control_reg";
  char *usage= "fpga_get_control_reg?<regNo>;";
  int nParams = 1;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[1] = {CMD_PARAM_UNSIGNED};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_get_control_reg, cmdType);
}



/**
 * Arm the FPGA for start at next 1PPS clock
 * @param argc   - should be 0
 * @param argv   - pointers to the parameters
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_arm(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_arm="; // beginning of return string
  char *retEnd   = ";\n";       // end of return string
  
  
  /* Execute the function: */
  retCode = fpga_arm();
  
  /* Check for errors */
  if(retCode != 0) {
    sprintf(*retVal, "%s%d:Execution Error;\n", retStart, VSIS_RET_EXECUTION_ERROR);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }

  /* Success get allocate return buffer and format data	 */
  sprintf(*retVal, "%s%d%s", retStart, 0, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_arm into command queue.
 */
void insert_vsis_fpga_arm(void)
{
  char *name = "fpga_arm";
  char *usage= "fpga_arm=;";
  int nParams = 0;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[1] = {CMD_PARAM_UNSIGNED};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_arm, cmdType);
}


/**
 * Clear the Arm flag on the FPGA for start at next 1PPS clock
 * @param argc   - should be 0
 * @param argv   - pointers to the parameters
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_arm_clear(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_arm_clear="; // beginning of return string
  char *retEnd   = ";\n";       // end of return string
  
  /* Execute the function: */
  retCode = fpga_arm_clear();
  
  /* Check for errors */
  if(retCode != 0) {
    sprintf(*retVal, "%s%d:Execution Error;\n", retStart, VSIS_RET_EXECUTION_ERROR);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }

  /* Success get allocate return buffer and format data	 */
  sprintf(*retVal, "%s%d%s", retStart, 0, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_arm into command queue.
 */
void insert_vsis_fpga_arm_clear(void)
{
  char *name = "fpga_arm_clear";
  char *usage= "fpga_arm_clear=;";
  int nParams = 0;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[1] = {CMD_PARAM_UNSIGNED};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_arm_clear, cmdType);
}

/**
 * Reload ADC registers with defaults
 * @param argc   - should be 0
 * @param argv   - pointers to the parameters
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_adc_reload(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_adc_reload="; // beginning of return string
  char *retEnd   = ";\n";       // end of return string
  
  /* Execute the function: */
  retCode = fpga_adc_reload();
  
  /* Check for errors */
  if(retCode != 0) {
    sprintf(*retVal, "%s%d:Execution Error;\n", retStart, VSIS_RET_EXECUTION_ERROR);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }
  
  /* Success get allocate return buffer and format data	 */
  sprintf(*retVal, "%s%d%s", retStart, 0, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_arm into command queue.
 */
void insert_vsis_fpga_adc_reload(void)
{
  char *name = "fpga_adc_reload";
  char *usage= "fpga_adc_reload=;";
  int nParams = 0;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[1] = {CMD_PARAM_UNSIGNED};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_adc_reload, cmdType);
}

/**
 * Clear Reload flags for ADC registers
 * @param argc   - should be 0
 * @param argv   - pointers to the parameters
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_adc_reload_clear(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_adc_reload_clear="; // beginning of return string
  char *retEnd   = ";\n";       // end of return string
  
  /* Execute the function: */
  retCode = fpga_adc_reload();
  
  /* Check for errors */
  if(retCode != 0) {   
    sprintf(*retVal, "%s%d:Execution Error;\n", retStart, VSIS_RET_EXECUTION_ERROR);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }
  
  /* Success get allocate return buffer and format data	 */
  sprintf(*retVal, "%s%d%s", retStart, 0, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_arm into command queue.
 */
void insert_vsis_fpga_adc_reload_clear(void)
{
  char *name = "fpga_adc_reload_clear";
  char *usage= "fpga_adc_reload_clear=;";
  int nParams = 0;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[1] = {CMD_PARAM_UNSIGNED};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_adc_reload_clear, cmdType);
}

/* ---------------------------------------------------------------------
 * We are going to make these commands by symbolic test instead of one command for each
 * int fpga_adc_reset(void);
 * int fpga_adc_reset_clear(void);
 * int fpga_fir_enable(void);
 * int fpga_fir_disable(void);
 * int fpga_fft_enable(void);
 * int fpga_fft_disable(void);
 * int fpga_dcm_reset(void);
 * int fpga_dcm_reset_clear(void);
 * int fpga_interpolator_enable(void);
 * int fpga_interpolator_disable(void);
 * int fpga_mk5_enable(void);
 * int fpga_mk5_disable(void);
 */


/**
 * Set the value of fpga status register regNo [0..3]
 * @param argc   - should be 1
 * @param argv   - pointers to the parameters <register number>
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_set_status_reg(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_set_status_reg="; // beginning of return string
  char *retEnd   = ";\n";                   // end of return string
  
  int paramOk;
  int regNo      = 0;
  unsigned value = 0;
  
  // check parameters
  paramOk = 0;  // assume parameters are wrong before checking
  if(argv[0] != 0 && argv[1] != 0 ){
    regNo = (int)*(long*)argv[0];
    value = (unsigned)*(unsigned long*)argv[1];
    if(regNo >=0 && regNo < 4){
      paramOk = 1;
    }
  }
  
  if(!paramOk) {    
    sprintf(*retVal, "%s%d:Parameter Error%s", retStart,VSIS_RET_PARAMETER_ERROR,retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_PARAMETER_ERROR;
  }

  /* Execute the function:   */
  retCode = fpga_set_status_reg(regNo, value);
  
  /* Check for errors */
  if(retCode != 0) {    
    sprintf(*retVal, "%s%d:Execution Error%s", retStart, VSIS_RET_EXECUTION_ERROR, retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }
  
  /* Success get allocate return buffer and format data	 */
  sprintf(*retVal, "%s%d%s", retStart, 0, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_get_control reg into command queue.
 */
void insert_vsis_fpga_set_status_reg(void)
{
  char *name = "fpga_set_status_reg";
  char *usage= "fpga_set_status_reg=<regNo>:<value>;";
  int nParams = 2;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[2] = {CMD_PARAM_UNSIGNED, CMD_PARAM_UNSIGNED};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_set_status_reg, cmdType);
}

/**
 * get the value of fpga status register regNo [0..3]
 * @param argc   - should be 1
 * @param argv   - pointers to the parameters <register number>
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_get_status_reg(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_get_status_reg?"; // beginning of return string
  char *retEnd   = ";\n";                   // end of return string
  
  int paramOk;
  int regNo      = 0;
  unsigned short value = 0;
  
  // check parameters
  paramOk = 0;  // assume parameters are wrong before checking
  if(argv[0] != 0  ){
    regNo = (int)*(long*)argv[0];
    if(regNo >=0 && regNo < 4){
      paramOk = 1;
    }
  }

  if(!paramOk) {  
    sprintf(*retVal, "%s%d:Parameter Error%s", retStart,VSIS_RET_PARAMETER_ERROR,retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_PARAMETER_ERROR;
  }
  
  /* Execute the function:   */
  retCode = fpga_get_status_reg(regNo, &value);
  
  /* Check for errors */
  if(retCode != 0) {  
    sprintf(*retVal, "%s%d:Execution Error%s", retStart, VSIS_RET_EXECUTION_ERROR, retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }
  
  /* Success get allocate return buffer and format data	 */
  sprintf(*retVal, "%s%d:%x%s", retStart, 0, value, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_get_control reg into command queue.
 */
void insert_vsis_fpga_get_status_reg(void)
{
  char *name = "fpga_get_status_reg";
  char *usage= "fpga_get_status_reg?<regNo>;";
  int nParams = 1;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[1] = {CMD_PARAM_UNSIGNED};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_get_status_reg, cmdType);
}


/**
 * get the value of fpga the board ID register
 * @param argc   - should be 0
 * @param argv   - pointers to the parameters
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_get_board_id(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_get_board_id?"; // beginning of return string
  char *retEnd   = ";\n";                   // end of return string
  
  unsigned short value = 0;
  
  /* Execute the function: get board id*/
  retCode = fpga_get_board_id( &value);
  
  /* Check for errors */
  if(retCode != 0) {    
    sprintf(*retVal, "%s%d:Execution Error%s", retStart, VSIS_RET_EXECUTION_ERROR, retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }

  /* Success get allocate return buffer and format data	 */
  sprintf(*retVal, "%s%d:%x%s", retStart, 0, value, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_get_board id into command queue.
 */
void insert_vsis_fpga_get_board_id(void)
{
  char *name = "fpga_get_board_id";
  char *usage= "fpga_get_board_id?;";
  int nParams = 0;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[1] = {CMD_PARAM_UNSIGNED};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_get_board_id, cmdType);
}

/**
 * Get the value of FPGA  board revision registers
 * @param argc   - should be 0
 * @param argv   - pointers to the parameters
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_get_board_revision(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_get_board_revision?"; // beginning of return string
  char *retEnd   = ";\n";                   // end of return string
  
  unsigned short major = 0;
  unsigned short minor = 0;
  unsigned short rcs   = 0;
  
  /* Execute the function: get board id*/
  retCode = fpga_get_board_revision( &major, &minor, &rcs);
  
  /* Check for errors */
  if(retCode != 0) {
    sprintf(*retVal, "%s%d:Execution Error%s", retStart, VSIS_RET_EXECUTION_ERROR, retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }

  /* Success get allocate return buffer and format data	 */
  sprintf(*retVal, "%s%d:%d:%d:%d%s", retStart, 0, major, minor, rcs, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_get_board id into command queue.
 */
void insert_vsis_fpga_get_board_revision(void)
{
  char *name = "fpga_get_board_revision";
  char *usage= "fpga_get_board_revision?;";
  int nParams = 0;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[1] = {CMD_PARAM_UNSIGNED};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_get_board_revision, cmdType);
}


/**
 * Get the value of FPGA  firmware id registers
 * @param argc   - should be 0
 * @param argv   - pointers to the parameters
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_get_firmware_id(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_get_firmware_id?"; // beginning of return string
  char *retEnd   = ";\n";                   // end of return string
  
  unsigned short value = 0;
  
  /* Execute the function: get board id*/
  retCode = fpga_get_firmware_id( &value);
  
  /* Check for errors */
  if(retCode != 0) {
    sprintf(*retVal, "%s%d:Execution Error%s", retStart, VSIS_RET_EXECUTION_ERROR, retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }
  
  /* Success get allocate return buffer and format data	 */
  sprintf(*retVal, "%s%d:%x%s", retStart, 0, value, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_get_firmaware_id into command queue.
 */
void insert_vsis_fpga_get_firmware_id(void)
{
  char *name = "fpga_get_firmware_id";
  char *usage= "fpga_get_firmware_id?;";
  int nParams = 0;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[1] = {CMD_PARAM_UNSIGNED};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_get_firmware_id, cmdType);
}

/**
 * Get the value of FPGA  firmware revision registers
 * @param argc   - should be 0
 * @param argv   - pointers to the parameters
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_get_firmware_revision(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_get_firmware_revision?"; // beginning of return string
  char *retEnd   = ";\n";                   // end of return string
  
  unsigned short major = 0;
  unsigned short minor = 0;
  unsigned short rcs   = 0;
  
  /* Execute the function: get board id*/
  retCode = fpga_get_firmware_revision( &major, &minor, &rcs);
  
  /* Check for errors */
  if(retCode != 0) {
    sprintf(*retVal, "%s%d:Execution Error%s", retStart, VSIS_RET_EXECUTION_ERROR, retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }
  
  /* Success get allocate return buffer and format data	 */
  sprintf(*retVal, "%s%d:%d:%d:%d%s", retStart, 0, major, minor, rcs, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_get_board id into command queue.
 */
void insert_vsis_fpga_get_firmware_revision(void)
{
  char *name = "fpga_get_firmware_revision";
  char *usage= "fpga_get_firmware_revision?;";
  int nParams = 0;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[1] = {CMD_PARAM_UNSIGNED};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_get_firmware_revision, cmdType);
}



/**
 * Get the value of fpga_qt_get_threshold_plus
 * @param argc   - should be 2
 * @param argv   - pointers to the parameters <IF [0..1]><Channel[0..15]>
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_qt_get_threshold_plus(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_qt_get_threshold_plus?"; // beginning of return string
  char *retEnd   = ";\n";                   // end of return string
  
  int paramOk;
  int ifNo      = 0;
  int channel    = 0;
  long int value = 0;
  
  // check parameters
  paramOk = 0;  // assume parameters are wrong before checking
  if(argv[0] != 0 && argv[1] != 0 ){
    ifNo    = (int)*(long*)argv[0];
    channel = (int)*(long*)argv[1];
    paramOk = 1;
  }
  
  if(!paramOk) {
    sprintf(*retVal, "%s%d:Parameter Error%s", retStart,VSIS_RET_PARAMETER_ERROR,retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_PARAMETER_ERROR;
  }
  
  /* Execute the function:   */
  retCode = fpga_qt_get_threshold_plus(ifNo, channel, &value);
  
  /* Check for errors */
  if(retCode != 0) {
    sprintf(*retVal, "%s%d:Execution Error%s", retStart, VSIS_RET_EXECUTION_ERROR, retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }
  
  /* Success get allocate return buffer and format data	 */
  sprintf(*retVal, "%s%d:%lx%s", retStart, 0, value, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_qt_get_threshold_plus into command queue.
 */
void insert_vsis_fpga_qt_get_threshold_plus(void)
{
  char *name = "fpga_qt_get_threshold_plus";
  char *usage= "fpga_qt_get_threshold_plus?<IF>:<Channel>;";
  int nParams = 2;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[2] = {CMD_PARAM_UNSIGNED, CMD_PARAM_UNSIGNED};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_qt_get_threshold_plus, cmdType);
}

/**
 * Set the value of fpga_qt_set_threshold_plus register
 * @param argc   - should be 3
 * @param argv   - pointers to the parameters <IF [0..1]><Channel[0..15]><value>
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_qt_set_threshold_plus(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_qt_set_threshold_plus="; // beginning of return string
  char *retEnd   = ";\n";                   // end of return string
  
  int paramOk;
  int ifNo      = 0;
  int channel    = 0;
  unsigned long value = 0;
  
  // check parameters
  paramOk = 0;  // assume parameters are wrong before checking
  if(argv[0] != 0 && argv[1] != 0 && argv[2] != 0 ){
    ifNo    = (int)*(long*)argv[0];
    channel = (int)*(long*)argv[1];
    value   = (unsigned long)*(unsigned long*)argv[2];
    paramOk = 1;
  }
  
  if(!paramOk) {
    sprintf(*retVal, "%s%d:Parameter Error%s", retStart,VSIS_RET_PARAMETER_ERROR,retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_PARAMETER_ERROR;
  }
  
  /* Execute the function:   */
  retCode = fpga_qt_set_threshold_plus(ifNo, channel, value);
  
  /* Check for errors */
  if(retCode != 0) {
    sprintf(*retVal, "%s%d:Execution Error%s", retStart, VSIS_RET_EXECUTION_ERROR, retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }
  
  /* Success get allocate return buffer and format data	 */
  sprintf(*retVal, "%s%d%s", retStart, 0, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_qt_get_threshold_plus into command queue.
 */
void insert_vsis_fpga_qt_set_threshold_plus(void)
{
  char *name = "fpga_qt_set_threshold_plus";
  char *usage= "fpga_qt_set_threshold_plus=<IF>:<Channel>:<Value>;";
  int nParams = 3;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[3] = {CMD_PARAM_UNSIGNED, CMD_PARAM_UNSIGNED, CMD_PARAM_UNSIGNEDLONG};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_qt_set_threshold_plus, cmdType);
}


/**
 * Get the value of fpga_qt_get_threshold_minus  register regNo [0..3]
 * @param argc   - should be 2
 * @param argv   - pointers to the parameters <IF [0..1]><Channel[0..15]>
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_qt_get_threshold_minus(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_qt_get_threshold_minus?"; // beginning of return string
  char *retEnd   = ";\n";                   // end of return string
  
  int paramOk;
  int ifNo      = 0;
  int channel    = 0;
  long int value = 0;
  
  // check parameters
  paramOk = 0;  // assume parameters are wrong before checking
  if(argv[0] != 0 && argv[1] != 0 ){
    ifNo    = (int)*(long*)argv[0];
    channel = (int)*(long*)argv[1];
    paramOk = 1;
  }
  
  if(!paramOk) {  
    sprintf(*retVal, "%s%d:Parameter Error%s", retStart,VSIS_RET_PARAMETER_ERROR,retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_PARAMETER_ERROR;
  }
  
  /* Execute the function:   */
  retCode = fpga_qt_get_threshold_minus(ifNo, channel, &value);
  
  /* Check for errors */
  if(retCode != 0) {  
    sprintf(*retVal, "%s%d:Execution Error%s", retStart, VSIS_RET_EXECUTION_ERROR, retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }

  /* Success get allocate return buffer and format data	 */
  sprintf(*retVal, "%s%d:%lx%s", retStart, 0, value, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_qt_get_threshold_minus into command queue.
 */
void insert_vsis_fpga_qt_get_threshold_minus(void)
{
  char *name = "fpga_qt_get_threshold_minus";
  char *usage= "fpga_qt_get_threshold_minus?<IF>:<Channel>;";
  int nParams = 2;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[2] = {CMD_PARAM_UNSIGNED, CMD_PARAM_UNSIGNED};
	cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_qt_get_threshold_minus, cmdType);
}

/**
 * Set the value of fpga_qt_set_threshold_minus register
 * @param argc   - should be 3
 * @param argv   - pointers to the parameters <IF [0..1]><Channel[0..15]><value>
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_qt_set_threshold_minus(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_qt_set_threshold_minus"; // beginning of return string
  char *retEnd   = ";\n";                   // end of return string
  
  int paramOk;
  int ifNo      = 0;
  int channel    = 0;
  unsigned long value = 0;
  
  // check parameters
  paramOk = 0;  // assume parameters are wrong before checking
  if(argv[0] != 0 && argv[1] != 0 && argv[2] != 0 ){
    ifNo    = (int)*(long*)argv[0];
    channel = (int)*(long*)argv[1];
    value   = (unsigned long)*(unsigned long*)argv[2];
    paramOk = 1;
  }
  
  if(!paramOk) {  
    sprintf(*retVal, "%s%d:Parameter Error%s", retStart,VSIS_RET_PARAMETER_ERROR,retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_PARAMETER_ERROR;
  }
  
  /* Execute the function:   */
  retCode = fpga_qt_set_threshold_minus(ifNo, channel, value);
  
  /* Check for errors */
  if(retCode != 0) {
    sprintf(*retVal, "%s%d:Execution Error%s", retStart, VSIS_RET_EXECUTION_ERROR, retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }
  
  /* Success get allocate return buffer and format data	 */
  sprintf(*retVal, "%s%d%s", retStart, 0, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_qt_get_threshold_minus into command queue.
 */
void insert_vsis_fpga_qt_set_threshold_minus(void)
{
  char *name = "fpga_qt_set_threshold_minus";
  char *usage= "fpga_qt_set_threshold_minus=<IF>:<Channel>:<value>;";
  int nParams = 3;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[3] = {CMD_PARAM_UNSIGNED, CMD_PARAM_UNSIGNED, CMD_PARAM_UNSIGNEDLONG};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_qt_set_threshold_minus, cmdType);
}

/**
 * Get the value of fpga_qt_get_bit_state_count register
 * @param argc   - should be 2
 * @param argv   - pointers to the parameters <IF [0..1]><Channel[0..31]>
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_qt_get_bit_state_count(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_qt_get_bit_state_count?"; // beginning of return string
  char *retEnd   = ";\n";                   // end of return string
  
  int paramOk;
  int ifNo      = 0;
  int channel    = 0;
  unsigned short value = 0;
  
  // check parameters
  paramOk = 0;  // assume parameters are wrong before checking
  if(argv[0] != 0 && argv[1] != 0 ){
    ifNo    = (int)*(long*)argv[0];
    channel = (int)*(long*)argv[1];
    paramOk = 1;
  }
  
  if(!paramOk) {
    sprintf(*retVal, "%s%d:Parameter Error%s", retStart,VSIS_RET_PARAMETER_ERROR,retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_PARAMETER_ERROR;
  }
  
  /* Execute the function:   */
  retCode = fpga_qt_get_bit_state_count(ifNo, channel, &value);
  
  /* Check for errors */
  if(retCode != 0) { 
    sprintf(*retVal, "%s%d:Execution Error%s", retStart, VSIS_RET_EXECUTION_ERROR, retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }
  
  /* Success. format data	 */
  sprintf(*retVal, "%s%d:%x%s", retStart, 0, value, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_qt_get_bit_state_count into command queue.
 */
void insert_vsis_fpga_qt_get_bit_state_count(void)
{
  char *name = "fpga_qt_get_bit_state_count";
  char *usage= "fpga_qt_get_bit_state_count?<IF>:<Channel>;";
  int nParams = 2;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[2] = {CMD_PARAM_UNSIGNED, CMD_PARAM_UNSIGNED};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_qt_get_bit_state_count, cmdType);
}

/**
 * Set the value of fpga_qt_gain register
 * @param argc   - should be 3
 * @param argv   - pointers to the parameters <IF [0..1]><Channel[0..31]><value>
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_qt_set_gain(int argc, void **argv, void **retVal, int *retLen)
{
  /*
   * Gain setting registers for each channel are 25 bits wide in the FPGA design
   * For computational purposes, When these same registers are read out by the PPC the 25 bit values are placed
   *  into two 16 bit wide registers with the zero padding on the lower 7 bits to preserve the sign of the value.
   *  This implies that the PPC must read two memory locations and shift the contents by 7 places to the right
   *  to form the correct value. .
   *  These are signed fixed point values (15,-16) as represented in a 32 bit register. Read only.
   */
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_qt_set_gain"; // beginning of return string
  char *retEnd   = ";\n";                   // end of return string
  
  int paramOk;
  int ifNo      = 0;
  int channel    = 0;
  unsigned long value = 0;
  
  // check parameters
  paramOk = 0;  // assume parameters are wrong before checking
  if(argv[0] != 0 && argv[1] != 0 && argv[2] != 0 ){
    ifNo    = (int)*(long*)argv[0];
    channel = (int)*(long*)argv[1];
    value   = (unsigned long)*(unsigned long*)argv[2];
    paramOk = 1;
  }
  
  if(!paramOk) {
    sprintf(*retVal, "%s%d:Parameter Error%s", retStart,VSIS_RET_PARAMETER_ERROR,retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_PARAMETER_ERROR;
  }
  
  /* Execute the function:   */
  retCode = fpga_qt_set_gain(ifNo, channel, value);
  
  /* Check for errors */
  if(retCode != 0) {
    sprintf(*retVal, "%s%d:Execution Error%s", retStart, VSIS_RET_EXECUTION_ERROR, retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }

  /* Success get allocate return buffer and format data	 */
  sprintf(*retVal, "%s%d%s", retStart, 0, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_qt_set_gain into command queue.
 */
void insert_vsis_fpga_qt_set_gain(void)
{
  char *name = "fpga_qt_set_gain";
  char *usage= "fpga_qt_set_gain=<IF>:<Channel>:<value>;";
  int nParams = 3;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[3] = {CMD_PARAM_UNSIGNED, CMD_PARAM_UNSIGNED, CMD_PARAM_UNSIGNEDLONG};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_qt_set_gain, cmdType);
}


/**
 * Get the value of fpga_qt_gain register
 * @param argc   - should be 2
 * @param argv   - pointers to the parameters <IF [0..1]><Channel[0..31]>
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_qt_get_gain(int argc, void **argv, void **retVal, int *retLen)
{
  /*
   * Gain setting registers for each channel are 25 bits wide in the FPGA design
   * For computational purposes, When these same registers are read out by the PPC the 25 bit values are placed
   *  into two 16 bit wide registers with the zero padding on the lower 7 bits to preserve the sign of the value.
   *  This implies that the PPC must read two memory locations and shift the contents by 7 places to the right
   *  to form the correct value. .
   *  These are signed fixed point values (15,-16) as represented in a 32 bit register. Read only.
   */
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_qt_get_gain?"; // beginning of return string
  char *retEnd   = ";\n";                   // end of return string
  
  int paramOk;
  int ifNo      = 0;
  int channel    = 0;
  long int value = 0;
  
  // check parameters
  paramOk = 0;  // assume parameters are wrong before checking
  if(argv[0] != 0 && argv[1] != 0 ){
    ifNo    = (int)*(long*)argv[0];
    channel = (int)*(long*)argv[1];
    paramOk = 1;
  }
  
  if(!paramOk) {
    sprintf(*retVal, "%s%d:Parameter Error%s", retStart,VSIS_RET_PARAMETER_ERROR,retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_PARAMETER_ERROR;
  }
  
  /* Execute the function:   */
  retCode = fpga_qt_get_gain(ifNo, channel, &value);

  /* Check for errors */
  if(retCode != 0) {
    sprintf(*retVal, "%s%d:Execution Error%s", retStart, VSIS_RET_EXECUTION_ERROR, retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }
  
  /* Success get allocate return buffer and format data	 */
  sprintf(*retVal, "%s%d:%lx%s", retStart, 0, value, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0

}

/**
 * Insert the fpga_qt_get_bit_state_count into command queue.
 */
void insert_vsis_fpga_qt_get_gain(void)
{
  char *name = "fpga_qt_get_gain";
  char *usage= "fpga_qt_get_gain?<IF>:<Channel>;";
  int nParams = 2;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[2] = {CMD_PARAM_UNSIGNED, CMD_PARAM_UNSIGNED};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_qt_get_gain, cmdType);
}

/**
 * Get the value of fpga_qt_number_samples register
 * @param argc   - should be 0
 * @param argv   - pointers to the parameters
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_qt_get_number_samples(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_qt_get_number_samples?"; // beginning of return string
  char *retEnd   = ";\n";                   // end of return string
  
  unsigned long value = 0;
  

  /* Execute the function: */
  retCode = fpga_qt_get_number_samples(&value);
  
  /* Check for errors */
  if(retCode != 0) {
    sprintf(*retVal, "%s%d:Execution Error%s", retStart, VSIS_RET_EXECUTION_ERROR, retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }
  
  /* Success get allocate return buffer and format data	 */
  sprintf(*retVal, "%s%d:%lx%s", retStart, 0, value, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_qt_get_number_samples into command queue.
 */
void insert_vsis_fpga_qt_get_number_samples(void)
{
  char *name = "fpga_qt_get_number_samples";
  char *usage= "fpga_qt_get_number_samples?;";
  int nParams = 0;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[1] = {CMD_PARAM_UNSIGNED};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_qt_get_number_samples, cmdType);
}



/**
 * Get the value of fpga_qt_enable_table register
 * @param argc   - should be 0
 * @param argv   - pointers to the parameters
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_qt_get_enable_table(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_qt_get_enable_table?"; // beginning of return string
  char *retEnd   = ";\n";                   // end of return string
  
  unsigned long value = 0;
  
  
  /* Execute the function:   */
  retCode = fpga_qt_get_enable_table(&value);
  
  /* Check for errors */
  if(retCode != 0) {
    sprintf(*retVal, "%s%d:Execution Error%s", retStart, VSIS_RET_EXECUTION_ERROR, retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }
  
  /* Success. format data	 */
  sprintf(*retVal, "%s%d:%lx%s", retStart, 0, value, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_qt_get_number_samples into command queue.
 */
void insert_vsis_fpga_qt_get_enable_table(void)
{
  char *name = "fpga_qt_get_enable_table";
  char *usage= "fpga_qt_get_enable_table?;";
  int nParams = 0;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[1] = {CMD_PARAM_UNSIGNED};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_qt_get_enable_table, cmdType);
}


/**
 * Set the value of fpga_qt_enable_table register
 * @param argc   - should be 1
 * @param argv   - pointers to the parameters <32 bit bit-field 1 for each channel>
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_qt_set_enable_table(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_qt_set_enable_table="; // beginning of return string
  char *retEnd   = ";\n";                   // end of return string
  
  int paramOk;
  unsigned long value = 0;
  
  // check parameters
  paramOk = 0;  // assume parameters are wrong before checking
  if(argv[0] != 0 ){
    value   = (unsigned long)*(unsigned long*)argv[0];
    paramOk = 1;
  }
  
  if(!paramOk) {
    sprintf(*retVal, "%s%d:Parameter Error%s", retStart,VSIS_RET_PARAMETER_ERROR,retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_PARAMETER_ERROR;
  }

  /* Execute the function:   */
  retCode = fpga_qt_set_enable_table(value);
  
  /* Check for errors */
  if(retCode != 0) {
    sprintf(*retVal, "%s%d:Execution Error%s", retStart, VSIS_RET_EXECUTION_ERROR, retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }
  
  /* Success format data	 */
  sprintf(*retVal, "%s%d%s", retStart, 0, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_qt_set_enable_table into command queue.
 */
void insert_vsis_fpga_qt_set_enable_table(void)
{
  char *name = "fpga_qt_set_enable_table";
  char *usage= "fpga_qt_set_enable_table=<value>;";
  int nParams = 1;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[1] = {CMD_PARAM_UNSIGNEDLONG};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_qt_set_enable_table, cmdType);
}


/**
 * Set the value of fpga_qt_enable_table register bit number channel
 * @param argc   - should be 2
 * @param argv   - pointers to the parameters <channel[0..31]><enable if not == 0>
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_qt_set_enable_channel(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_qt_set_enable_channel="; // beginning of return string
  char *retEnd   = ";\n";                   // end of return string
  
  int paramOk;
  unsigned short value = 0;
  int channel = 0;
  
  // check parameters
  paramOk = 0;  // assume parameters are wrong before checking
  if(argv[0] != 0 && argv[1] != 0 ){
    channel = (int)*(long*)argv[0];
    value   = (unsigned long)*(unsigned long*)argv[1];
    paramOk = 1;
  }

  if(!paramOk) {
    sprintf(*retVal, "%s%d:Parameter Error%s", retStart,VSIS_RET_PARAMETER_ERROR,retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_PARAMETER_ERROR;
  }

  /* Execute the function:   */
  if(value != 0){
    retCode = fpga_qt_enable_channel(channel);
  } else {
    retCode = fpga_qt_disable_channel(channel);
  }

  /* Check for errors */
  if(retCode != 0) {
    sprintf(*retVal, "%s%d:Execution Error%s", retStart, VSIS_RET_EXECUTION_ERROR, retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }

  /* Success. format data	 */
  sprintf(*retVal, "%s%d%s", retStart, 0, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_qt_set_enable_table into command queue.
 */
void insert_vsis_fpga_qt_set_enable_channel(void)
{
  char *name = "fpga_qt_set_enable_channel";
  char *usage= "fpga_qt_set_enable_channel=<channel>:<value>;";
  int nParams = 2;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[2] = {CMD_PARAM_UNSIGNED, CMD_PARAM_UNSIGNED};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_qt_set_enable_channel, cmdType);
}



/**
 * Get the value of fpga_qt_status register
 * @param argc   - should be 0
 * @param argv   - pointers to the parameters
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_qt_get_status(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_qt_get_status?"; // beginning of return string
  char *retEnd   = ";\n";                   // end of return string
  
  unsigned long value = 0;
  
  
  /* Execute the function:   */
  retCode = fpga_qt_get_status(&value);
  
  /* Check for errors */
  if(retCode != 0) {
    sprintf(*retVal, "%s%d:Execution Error%s", retStart, VSIS_RET_EXECUTION_ERROR, retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }

  /* Success: format data	 */
  sprintf(*retVal, "%s%d:%lx%s", retStart, 0, value, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_qt_get_number_samples into command queue.
 */
void insert_vsis_fpga_qt_get_status(void)
{
  char *name = "fpga_qt_get_status";
  char *usage= "fpga_qt_get_status?;";
  int nParams = 0;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[1] = {CMD_PARAM_UNSIGNED};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_qt_get_status, cmdType);
}

/**
 * Get the value of fpga_qt_control register
 * @param argc   - should be 0
 * @param argv   - pointers to the parameters
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_qt_get_control(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_qt_get_control?"; // beginning of return string
  char *retEnd   = ";\n";                   // end of return string
  
  unsigned short value = 0;
  
  /* Execute the function:   */
  retCode = fpga_qt_get_control(&value);
  
  /* Check for errors */
  if(retCode != 0) {
    sprintf(*retVal, "%s%d:Execution Error%s", retStart, VSIS_RET_EXECUTION_ERROR, retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }

  /* Success. format data	 */
  sprintf(*retVal, "%s%d:%x%s", retStart, 0, value, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_qt_get_number_samples into command queue.
 */
void insert_vsis_fpga_qt_get_control(void)
{
  char *name = "fpga_qt_get_control";
  char *usage= "fpga_qt_get_control?;";
  int nParams = 0;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[1] = {CMD_PARAM_UNSIGNED};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_qt_get_control, cmdType);
}



/**
 * Set the value of fpga_qt_control register
 * @param argc   - should be 1
 * @param argv   - pointers to the parameters <3value for control registerl>
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_qt_set_control(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_qt_set_control="; // beginning of return string
  char *retEnd   = ";\n";                   // end of return string
  
  int paramOk;
  unsigned long value = 0;
  
  // check parameters
  paramOk = 0;  // assume parameters are wrong before checking
  if(argv[0] != 0 ){
    value   = (unsigned short)*(unsigned long*)argv[0];
    paramOk = 1;
  }
  
  if(!paramOk) {
    sprintf(*retVal, "%s%d:Parameter Error%s", retStart,VSIS_RET_PARAMETER_ERROR,retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_PARAMETER_ERROR;
  }
  
  /* Execute the function:   */
  retCode = fpga_qt_set_control(value);
  
  /* Check for errors */
  if(retCode != 0) {
    sprintf(*retVal, "%s%d:Execution Error%s", retStart, VSIS_RET_EXECUTION_ERROR, retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }
  
  /* Success. format data	 */
  sprintf(*retVal, "%s%d%s", retStart, 0, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_qt_set_control into command queue.
 */
void insert_vsis_fpga_qt_set_control(void)
{
  char *name = "fpga_qt_set_control";
  char *usage= "fpga_qt_set_control=<value>;";
  int nParams = 1;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[1] = {CMD_PARAM_UNSIGNEDLONG};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_qt_set_control, cmdType);
}


/**
 * Get the value of fpga_qt_failure register
 * @param argc   - should be 0
 * @param argv   - pointers to the parameters
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_qt_get_failure(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_qt_get_failure?"; // beginning of return string
  char *retEnd   = ";\n";                   // end of return string
  
  unsigned long value = 0;
  
  /* Execute the function: */
  retCode = fpga_qt_get_failure(&value);
  
  /* Check for errors */
  if(retCode != 0) {
    sprintf(*retVal, "%s%d:Execution Error%s", retStart, VSIS_RET_EXECUTION_ERROR, retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }

  /* Success. format data	 */
  sprintf(*retVal, "%s%d:%lx%s", retStart, 0, value, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_qt_get_failure into command queue.
 */
void insert_vsis_fpga_qt_get_failure(void)
{
  char *name = "fpga_qt_get_failure";
  char *usage= "fpga_qt_get_failure?;";
  int nParams = 0;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[1] = {CMD_PARAM_UNSIGNED};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_qt_get_failure, cmdType);
}


/**
 * Get the value of fpga_qt_comparator_enable register
 * @param argc   - should be 0
 * @param argv   - pointers to the parameters
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_qt_get_comparator_enable(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_qt_get_comparator_enable?"; // beginning of return string
  char *retEnd   = ";\n";                   // end of return string
  
  unsigned long value = 0;
  
  /* Execute the function:   */
  retCode = fpga_qt_get_comparator_enable(&value);
  
  /* Check for errors */
  if(retCode != 0) {
    sprintf(*retVal, "%s%d:Execution Error%s", retStart, VSIS_RET_EXECUTION_ERROR, retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }
  
  /* Success.format data	 */
  sprintf(*retVal, "%s%d:%lx%s", retStart, 0, value, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_qt_get_comparator_enable into command queue.
 */
void insert_vsis_fpga_qt_get_comparator_enable(void)
{
  char *name = "fpga_qt_get_comparator_enable";
  char *usage= "fpga_qt_get_comparator_enable?;";
  int nParams = 0;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[1] = {CMD_PARAM_UNSIGNED};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_qt_get_comparator_enable, cmdType);
}


/**
 * Set the value of fpga_qt_comparator_enable register
 * @param argc   - should be 1
 * @param argv   - pointers to the parameters <value>
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_qt_set_comparator_enable(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_qt_set_comparator_enable="; // beginning of return string
  char *retEnd   = ";\n";                   // end of return string
  
  int paramOk;
  unsigned long value = 0;
  
  // check parameters
  paramOk = 0;  // assume parameters are wrong before checking
  if(argv[0] != 0 ){
    value   = (unsigned long)*(unsigned long*)argv[0];
    paramOk = 1;
  }
  
  if(!paramOk) {
    sprintf(*retVal, "%s%d:Parameter Error%s", retStart,VSIS_RET_PARAMETER_ERROR,retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_PARAMETER_ERROR;
  }
  
  /* Execute the function:   */
  retCode = fpga_qt_set_comparator_enable(value);
  
  /* Check for errors */
  if(retCode != 0) {
    sprintf(*retVal, "%s%d:Execution Error%s", retStart, VSIS_RET_EXECUTION_ERROR, retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }
  
  /* Success. Format data	 */
  sprintf(*retVal, "%s%d%s", retStart, 0, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_qt_set_comparator_enable into command queue.
 */
void insert_vsis_fpga_qt_set_comparator_enable(void)
{
  char *name = "fpga_qt_set_comparator_enable";
  char *usage= "fpga_qt_set_comparator_enable=<value>;";
  int nParams = 1;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[1] = {CMD_PARAM_UNSIGNEDLONG};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_qt_set_comparator_enable, cmdType);
}

/**
 * Get the value of fpga_qt_state_machine_status register
 * @param argc   - should be 0
 * @param argv   - pointers to the parameters
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_qt_get_state_machine_status(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_qt_get_state_machine_status?"; // beginning of return string
  char *retEnd   = ";\n";                   // end of return string
  
  unsigned short value = 0;
  
  /* Execute the function:   */
  retCode = fpga_qt_get_state_machine_status(&value);
  
  /* Check for errors */
  if(retCode != 0) {
    sprintf(*retVal, "%s%d:Execution Error%s", retStart, VSIS_RET_EXECUTION_ERROR, retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }

  /* Success. format data	 */
  sprintf(*retVal, "%s%d:%x%s", retStart, 0, value, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_qt_get_state_machine_status into command queue.
 */
void insert_vsis_fpga_qt_get_state_machine_status(void)
{
  char *name = "fpga_qt_get_state_machine_status";
  char *usage= "fpga_qt_get_state_machine_status?;";
  int nParams = 0;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[1] = {CMD_PARAM_UNSIGNED};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_qt_get_state_machine_status, cmdType);
}

/* ----------------------------------------------------------------------------------------------------------
 * Mark V B Interface
 *----------------------------------------------------------------------------------------------------------
 */


/**
 * Get the value of fpga_mk5__sync_word register
 * @param argc   - should be 0
 * @param argv   - pointers to the parameters
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_mk5_get_sync_word(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_mk5_get_sync_word?"; // beginning of return string
  char *retEnd   = ";\n";                   // end of return string
  
  unsigned long value = 0;
  
  /* Execute the function:   */
  retCode = fpga_mk5_get_sync_word(&value);
  
  /* Check for errors */
  if(retCode != 0) {
    sprintf(*retVal, "%s%d:Execution Error%s", retStart, VSIS_RET_EXECUTION_ERROR, retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }

  /* Success. Format data	 */
  sprintf(*retVal, "%s%d:%lx%s", retStart, 0, value, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_mk5_get_sync_word into command queue.
 */
void insert_vsis_fpga_mk5_get_sync_word(void)
{
  char *name = "fpga_mk5_get_sync_word";
  char *usage= "fpga_mk5_get_sync_word?;";
  int nParams = 0;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[1] = {CMD_PARAM_UNSIGNED};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_mk5_get_sync_word, cmdType);
}

/**
 * Set the value of fpga_mk5_sync_word register
 * @param argc   - should be 1
 * @param argv   - pointers to the parameters <value>
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_mk5_set_sync_word(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_mk5_set_sync_word="; // beginning of return string
  char *retEnd   = ";\n";                   // end of return string
  
  int paramOk;
  unsigned long value = 0;
  
  // check parameters
  paramOk = 0;  // assume parameters are wrong before checking
  if(argv[0] != 0 ){
    value   = (unsigned long)*(unsigned long*)argv[0];
    paramOk = 1;
  }
  
  if(!paramOk) {
    sprintf(*retVal, "%s%d:Parameter Error%s", retStart,VSIS_RET_PARAMETER_ERROR,retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_PARAMETER_ERROR;
  }
  
  /* Execute the function:   */
  retCode = fpga_mk5_set_sync_word(value);
  
  /* Check for errors */
  if(retCode != 0) {
    sprintf(*retVal, "%s%d:Execution Error%s", retStart, VSIS_RET_EXECUTION_ERROR, retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }
  
  /* Success. format data	 */
  sprintf(*retVal, "%s%d%s", retStart, 0, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_mk5_set_sync_word into command queue.
 */
void insert_vsis_fpga_mk5_set_sync_word(void)
{
  char *name = "fpga_mk5_set_sync_word";
  char *usage= "fpga_mk5_set_sync_word=<value>;";
  int nParams = 1;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[1] = {CMD_PARAM_UNSIGNEDLONG};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_mk5_set_sync_word, cmdType);
}


/**
 * Get the value of fpga_mk5_years register
 * @param argc   - should be 0
 * @param argv   - pointers to the parameters
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_mk5_get_years(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_mk5_get_years?"; // beginning of return string
  char *retEnd   = ";\n";                   // end of return string
  
  unsigned short value = 0;
  
  /* Execute the function:   */
  retCode = fpga_mk5_get_years(&value);
  
  /* Check for errors */
  if(retCode != 0) {
    sprintf(*retVal, "%s%d:Execution Error%s", retStart, VSIS_RET_EXECUTION_ERROR, retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }

  /* Success. Format data	 */
  sprintf(*retVal, "%s%d:%x%s", retStart, 0, value, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_mk5_get_years into command queue.
 */
void insert_vsis_fpga_mk5_get_years(void)
{
  char *name = "fpga_mk5_get_years";
  char *usage= "fpga_mk5_get_years?;";
  int nParams = 0;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[1] = {CMD_PARAM_UNSIGNED};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_mk5_get_years, cmdType);
}

/**
 * Set the value of fpga_mk5_years register
 * @param argc   - should be 1
 * @param argv   - pointers to the parameters <value>
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_mk5_set_years(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_mk5_set_years"; // beginning of return string
  char *retEnd   = ";\n";                   // end of return string
  
  int paramOk;
  unsigned short value = 0;
  
  // check parameters
  paramOk = 0;  // assume parameters are wrong before checking
  if(argv[0] != 0 ){
    value   = (unsigned short)*(unsigned long*)argv[0];
    paramOk = 1;
  }
  
  if(!paramOk) {
    sprintf(*retVal, "%s%d:Parameter Error%s", retStart,VSIS_RET_PARAMETER_ERROR,retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_PARAMETER_ERROR;
  }
  
  /* Execute the function:   */
  retCode = fpga_mk5_set_years(value);

  /* Check for errors */
  if(retCode != 0) {
    sprintf(*retVal, "%s%d:Execution Error%s", retStart, VSIS_RET_EXECUTION_ERROR, retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }

  /* Success. format data	 */
  sprintf(*retVal, "%s%d%s", retStart, 0, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_mk5_set_years into command queue.
 */
void insert_vsis_fpga_mk5_set_years(void)
{
  char *name = "fpga_mk5_set_years";
  char *usage= "fpga_mk5_set_years=<value>;";
  int nParams = 1;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[1] = {CMD_PARAM_UNSIGNED};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_mk5_set_years, cmdType);
}



/**
 * Get the value of fpga_mk5_t_bit register
 * @param argc   - should be 0
 * @param argv   - pointers to the parameters
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_mk5_get_t_bit(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_mk5_get_t_bit?"; // beginning of return string
  char *retEnd   = ";\n";                   // end of return string
  
  unsigned short value = 0;
  
  /* Execute the function:   */
  retCode = fpga_mk5_get_t_bit(&value);
  
  /* Check for errors */
  if(retCode != 0) {
    sprintf(*retVal, "%s%d:Execution Error%s", retStart, VSIS_RET_EXECUTION_ERROR, retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }
  
  /* Success. Format data	 */
  sprintf(*retVal, "%s%d:%x%s", retStart, 0, value, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_mk5_get_t_bit into command queue.
 */
void insert_vsis_fpga_mk5_get_t_bit(void)
{
  char *name = "fpga_mk5_get_t_bit";
  char *usage= "fpga_mk5_get_t_bit?;";
  int nParams = 0;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[1] = {CMD_PARAM_UNSIGNED};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_mk5_get_t_bit, cmdType);
}

/**
 * Set the value of fpga_mk5_t_bit register
 * @param argc   - should be 1
 * @param argv   - pointers to the parameters <value>
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_mk5_set_t_bit(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_mk5_set_t_bit="; // beginning of return string
  char *retEnd   = ";\n";                   // end of return string
  
  int paramOk;
  unsigned short value = 0;
  
  // check parameters
  paramOk = 0;  // assume parameters are wrong before checking
  if(argv[0] != 0 ){
    value   = (unsigned short)*(unsigned long*)argv[0];
    paramOk = 1;
  }
  
  if(!paramOk) {
    sprintf(*retVal, "%s%d:Parameter Error%s", retStart,VSIS_RET_PARAMETER_ERROR,retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_PARAMETER_ERROR;
  }
  
  /* Execute the function:   */
  retCode = fpga_mk5_set_t_bit(value);
  
  /* Check for errors */
  if(retCode != 0) {
    sprintf(*retVal, "%s%d:Execution Error%s", retStart, VSIS_RET_EXECUTION_ERROR, retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }

  /* Success. Format data	 */
  sprintf(*retVal, "%s%d%s", retStart, 0, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_mk5_set_t_bit into command queue.
 */
void insert_vsis_fpga_mk5_set_t_bit(void)
{
  char *name = "fpga_mk5_set_t_bit";
  char *usage= "fpga_mk5_set_t_bit=<value>;";
  int nParams = 1;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[1] = {CMD_PARAM_UNSIGNED};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_mk5_set_t_bit, cmdType);
}

/**
 * Get the value of fpga_mk5_user_reg register
 * @param argc   - should be 0
 * @param argv   - pointers to the parameters
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_mk5_get_user_reg(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_mk5_get_user_reg?"; // beginning of return string
  char *retEnd   = ";\n";                   // end of return string
  
  unsigned short value = 0;
  
  /* Execute the function:   */
  retCode = fpga_mk5_get_user_reg(&value);
  
  /* Check for errors */
  if(retCode != 0) {
    sprintf(*retVal, "%s%d:Execution Error%s", retStart, VSIS_RET_EXECUTION_ERROR, retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }

  /* Success. format data	 */
  sprintf(*retVal, "%s%d:%x%s", retStart, 0, value, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_mk5_get_user_reg into command queue.
 */
void insert_vsis_fpga_mk5_get_user_reg(void)
{
  char *name = "fpga_mk5_get_user_reg";
  char *usage= "fpga_mk5_get_user_reg?;";
  int nParams = 0;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[1] = {CMD_PARAM_UNSIGNED};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_mk5_get_user_reg, cmdType);
}

/**
 * Set the value of fpga_mk5_user_reg register
 * @param argc   - should be 1
 * @param argv   - pointers to the parameters <value>
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_mk5_set_user_reg(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_mk5_set_user_reg="; // beginning of return string
  char *retEnd   = ";\n";                   // end of return string
  
  int paramOk;
  unsigned short value = 0;
  
  // check parameters
  paramOk = 0;  // assume parameters are wrong before checking
  if(argv[0] != 0 ){
    value   = (unsigned short)*(unsigned long*)argv[0];
    paramOk = 1;
  }
  
  if(!paramOk) {
    sprintf(*retVal, "%s%d:Parameter Error%s", retStart,VSIS_RET_PARAMETER_ERROR,retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_PARAMETER_ERROR;
  }
  
  /* Execute the function:   */
  retCode = fpga_mk5_set_user_reg(value);
  
  /* Check for errors */
  if(retCode != 0) {
    sprintf(*retVal, "%s%d:Execution Error%s", retStart, VSIS_RET_EXECUTION_ERROR, retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }
  
  /* Success. format data	 */
  sprintf(*retVal, "%s%d%s", retStart, 0, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_mk5_set_user_reg into command queue.
 */
void insert_vsis_fpga_mk5_set_user_reg(void)
{
  char *name = "fpga_mk5_set_user_reg";
  char *usage= "fpga_mk5_set_user_reg=<value>;";
  int nParams = 1;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[1] = {CMD_PARAM_UNSIGNED};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_mk5_set_user_reg, cmdType);
}


/**
 * Get the value of fpga_mk5_unassigned_reg register
 * @param argc   - should be 0
 * @param argv   - pointers to the parameters
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_mk5_get_unassigned_reg(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_mk5_get_unassigned_reg?"; // beginning of return string
  char *retEnd   = ";\n";                   // end of return string
  
  unsigned long value = 0;
  
  /* Execute the function:   */
  retCode = fpga_mk5_get_unassigned_reg(&value);
  
  /* Check for errors */
  if(retCode != 0) {
    sprintf(*retVal, "%s%d:Execution Error%s", retStart, VSIS_RET_EXECUTION_ERROR, retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }

  /* Success. format data	 */
  sprintf(*retVal, "%s%d:%lx%s", retStart, 0, value, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_mk5_get_unassigned_reg into command queue.
 */
void insert_vsis_fpga_mk5_get_unassigned_reg(void)
{
  char *name = "fpga_mk5_get_unassigned_reg";
  char *usage= "fpga_mk5_get_unassigned_reg?;";
  int nParams = 0;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[1] = {CMD_PARAM_UNSIGNED};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_mk5_get_unassigned_reg, cmdType);
}

/**
 * Set the value of fpga_mk5_unassigned_reg register
 * @param argc   - should be 1
 * @param argv   - pointers to the parameters <value>
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_mk5_set_unassigned_reg(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_mk5_set_unassigned_reg"; // beginning of return string
  char *retEnd   = ";\n";                   // end of return string
  
  int paramOk;
  unsigned short value = 0;
  
  // check parameters
  paramOk = 0;  // assume parameters are wrong before checking
  if(argv[0] != 0 ){
    value   = (unsigned short)*(unsigned long*)argv[0];
    paramOk = 1;
  }
  
  if(!paramOk) {
    sprintf(*retVal, "%s%d:Parameter Error%s", retStart,VSIS_RET_PARAMETER_ERROR,retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_PARAMETER_ERROR;
  }
  
  /* Execute the function:   */
  retCode = fpga_mk5_set_unassigned_reg(value);
  
  /* Check for errors */
  if(retCode != 0) {
    sprintf(*retVal, "%s%d:Execution Error%s", retStart, VSIS_RET_EXECUTION_ERROR, retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }
  
  /* Success get allocate return buffer and format data	 */
  sprintf(*retVal, "%s%d%s", retStart, 0, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_mk5_set_unassigned_reg into command queue.
 */
void insert_vsis_fpga_mk5_set_unassigned_reg(void)
{
  char *name = "fpga_mk5_set_unassigned_reg";
  char *usage= "fpga_mk5_set_unassigned_reg=<value>;";
  int nParams = 1;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[1] = {CMD_PARAM_UNSIGNED};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_mk5_set_unassigned_reg, cmdType);
}


/**
 * Get the value of fpga_mk5_statemachine_status register
 * @param argc   - should be 0
 * @param argv   - pointers to the parameters
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_mk5_get_statemachine_status(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_mk5_get_statemachine_status?"; // beginning of return string
  char *retEnd   = ";\n";                   // end of return string
  
  unsigned short value = 0;
  
  /* Execute the function:   */
  retCode = fpga_mk5_get_state_machine_status(&value);
  
  /* Check for errors */
  if(retCode != 0) {
    sprintf(*retVal, "%s%d:Execution Error%s", retStart, VSIS_RET_EXECUTION_ERROR, retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }

  /* Success get allocate return buffer and format data	 */
  sprintf(*retVal, "%s%d:%x%s", retStart, 0, value, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_mk5_get_statemachine_status into command queue.
 */
void insert_vsis_fpga_mk5_get_statemachine_status(void)
{
  char *name = "fpga_mk5_get_statemachine_status";
  char *usage= "fpga_mk5_get_statemachine_status?;";
  int nParams = 0;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[1] = {CMD_PARAM_UNSIGNED};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_mk5_get_statemachine_status, cmdType);
}

/* ----------------------------------------------------------------------------------------------------------
 * Output Channel Selector Registers
 * The Channel Selection Registers permits a user to select 1 of 32 frequency channels for each output channel
 * slot. This is a 5 bit binary code (lower 5 bits of the 16 bit register). In the VLBI2010 design there are 16
 * available slots, each slot can select any one of the different frequency channels from either IF0 or IF1.
 *
 * Each "output slot" is coded so that the 4 lowest bits select an input channel 0..15, and bit 4 selects IF0 or 1
 */

/**
 * Get the value of fpga_mk5_channel [0..15] select register [0..31] where upper bit designates IF [0..1] lower bits channel [0..15]
 * @param argc   - should be 1
 * @param argv   - pointers to the parameters (channel 0..15)
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_get_channel_select(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_channel_select?"; // beginning of return string
  char *retEnd   = ";\n";                   // end of return string
  int  paramOk;
  unsigned short outputChannel;
  unsigned short value = 0;

  // check parameters
  paramOk = 0;  // assume parameters are wrong before checking
  if(argv[0] != 0 ){
    outputChannel   = (unsigned short)*(unsigned long*)argv[0];
    paramOk = 1;
  }

  if(!paramOk) {
    sprintf(*retVal, "%s%d:Parameter Error%s", retStart,VSIS_RET_PARAMETER_ERROR,retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_PARAMETER_ERROR;
  }
// TODO:
  /* Execute the function:   */
  retCode = fpga_get_channel_select(outputChannel, &value);

  /* Check for errors */
  if(retCode != 0) {
    sprintf(*retVal, "%s%d:Execution Error%s", retStart, VSIS_RET_EXECUTION_ERROR, retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }

  /* Success get allocate return buffer and format data	 */
  sprintf(*retVal, "%s%d:%x%s", retStart, 0, value, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_get_channel_select into command queue.
 */
void insert_vsis_fpga_get_channel_select(void)
{
  char *name = "fpga_get_channel_select";
  char *usage= "fpga_get_channel_select?<channel 0..15>;";
  int nParams = 1;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[1] = {CMD_PARAM_UNSIGNED};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_get_channel_select, cmdType);
}

/**
 * Set the input channel [0..31] associated with output channel [0..15]
 * @param argc   - should be 2 <outputChannel 0..15> <inputChannel 0..31>
 * @param argv   - pointers to the parameters <value>
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_set_channel_select(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_set_channel_select"; // beginning of return string
  char *retEnd   = ";\n";                   // end of return string

  int paramOk;
  unsigned short outputChannel = 0;
  unsigned short inputChannel = 0;

  // check parameters
  paramOk = 0;  // assume parameters are wrong before checking
  if(argc >=2) {
	  if(argv[0] != 0 ){
		  outputChannel   = (unsigned short)*(unsigned long*)argv[0];
		  paramOk = 1;
	  }
	  if(argv[1] != 0 ){
		  inputChannel   = (unsigned short)*(unsigned long*)argv[1];
		  paramOk = 1;
	  }
  }
  if(!paramOk) {
    sprintf(*retVal, "%s%d:Parameter Error%s", retStart,VSIS_RET_PARAMETER_ERROR,retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_PARAMETER_ERROR;
  }

  /* Execute the function:   */
  retCode = fpga_set_channel_select(outputChannel, inputChannel);

  /* Check for errors */
  if(retCode != 0) {
    sprintf(*retVal, "%s%d:Execution Error%s", retStart, VSIS_RET_EXECUTION_ERROR, retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }

  /* Success get allocate return buffer and format data	 */
  sprintf(*retVal, "%s%d%s", retStart, 0, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_set_channel_select into command queue.
 */
void insert_vsis_fpga_set_channel_select(void)
{
  char *name = "fpga_set_channel_select";
  char *usage= "fpga_set_channel_select=<ouptutChannel 0..15>:<inputChannel 0..31>;";
  int nParams = 2;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[2] = {CMD_PARAM_UNSIGNED, CMD_PARAM_UNSIGNED};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_set_channel_select, cmdType);
}



/* ----------------------------------------------------------------------------------------------------------
 *  Optimal Input Level Detector Registers
 * ----------------------------------------------------------------------------------------------------------
 */


/**
 * Get the value of fpga_mk5_unassigned_reg register
 * @param argc   - should be 0
 * @param argv   - pointers to the parameters
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_ild_get_control(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_ild_get_control?"; // beginning of return string
  char *retEnd   = ";\n";                   // end of return string
  
  unsigned short value = 0;
  
  /* Execute the function:   */
  retCode = fpga_ild_get_control(&value);
  
  /* Check for errors */
  if(retCode != 0) {
    sprintf(*retVal, "%s%d:Execution Error%s", retStart, VSIS_RET_EXECUTION_ERROR, retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }
  
  /* Success get allocate return buffer and format data	 */
  sprintf(*retVal, "%s%d:%x%s", retStart, 0, value, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_ild_get_control into command queue.
 */
void insert_vsis_fpga_ild_get_control(void)
{
  char *name = "fpga_ild_get_control";
  char *usage= "fpga_ild_get_control?;";
  int nParams = 0;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[1] = {CMD_PARAM_UNSIGNED};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_ild_get_control, cmdType);
}

/**
 * Set the value of fpga_ild_control register
 * @param argc   - should be 1
 * @param argv   - pointers to the parameters <value>
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_ild_set_control(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_ild_set_control"; // beginning of return string
  char *retEnd   = ";\n";                   // end of return string
  
  int paramOk;
  unsigned short value = 0;
  
  // check parameters
  paramOk = 0;  // assume parameters are wrong before checking
  if(argv[0] != 0 ){
    value   = (unsigned short)*(unsigned long*)argv[0];
    paramOk = 1;
  }
  
  if(!paramOk) {
    sprintf(*retVal, "%s%d:Parameter Error%s", retStart,VSIS_RET_PARAMETER_ERROR,retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_PARAMETER_ERROR;
  }
  
  /* Execute the function:   */
  retCode = fpga_ild_set_control(value);
  
  /* Check for errors */
  if(retCode != 0) {
    sprintf(*retVal, "%s%d:Execution Error%s", retStart, VSIS_RET_EXECUTION_ERROR, retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }
  
  /* Success get allocate return buffer and format data	 */
  sprintf(*retVal, "%s%d%s", retStart, 0, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_ild_set_control into command queue.
 */
void insert_vsis_fpga_ild_set_control(void)
{
  char *name = "fpga_ild_set_control";
  char *usage= "fpga_ild_set_control=<value>;";
  int nParams = 1;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[1] = {CMD_PARAM_UNSIGNED};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_ild_set_control, cmdType);
}


/**
 * Get the value of input level detector status register
 * @param argc   - should be 0
 * @param argv   - pointers to the parameters
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_ild_get_status(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_ild_get_status?"; // beginning of return string
  char *retEnd   = ";\n";                   // end of return string
  
  unsigned short value = 0;
  
  /* Execute the function:   */
  retCode = fpga_ild_get_status(&value);
  
  /* Check for errors */
  if(retCode != 0) {
    sprintf(*retVal, "%s%d:Execution Error%s", retStart, VSIS_RET_EXECUTION_ERROR, retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }

  /* Success get allocate return buffer and format data	 */
  sprintf(*retVal, "%s%d:%x%s", retStart, 0, value, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_ild_get_status into command queue.
 */
void insert_vsis_fpga_ild_get_status(void)
{
  char *name = "fpga_ild_get_status";
  char *usage= "fpga_ild_get_status?;";
  int nParams = 0;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[1] = {CMD_PARAM_UNSIGNED};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_ild_get_status, cmdType);
}


/**
 * Get the value of input level detector low_state_count register
 * @param argc   - should be 0
 * @param argv   - pointers to the parameters
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_ild_get_low_state_count(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_ild_get_low_state_count?"; // beginning of return string
  char *retEnd   = ";\n";                   // end of return string
  
  unsigned short value = 0;
  
  /* Execute the function:   */
  retCode = fpga_ild_get_low_state_count(&value);
  
  /* Check for errors */
  if(retCode != 0) {
    sprintf(*retVal, "%s%d:Execution Error%s", retStart, VSIS_RET_EXECUTION_ERROR, retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }
  
  /* Success get allocate return buffer and format data	 */
  sprintf(*retVal, "%s%d:%x%s", retStart, 0, value, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_ild_get_low_state_count into command queue.
 */
void insert_vsis_fpga_ild_get_low_state_count(void)
{
  char *name = "fpga_ild_get_low_state_count";
  char *usage= "fpga_ild_get_low_state_count?;";
  int nParams = 0;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[1] = {CMD_PARAM_UNSIGNED};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_ild_get_low_state_count, cmdType);
}


/**
 * Get the value of input level detector mid_state_count register
 * @param argc   - should be 0
 * @param argv   - pointers to the parameters
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_ild_get_mid_state_count(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_ild_get_mid_state_count?"; // beginning of return string
  char *retEnd   = ";\n";                   // end of return string
  
  unsigned short value = 0;
  
  /* Execute the function:   */
  retCode = fpga_ild_get_mid_state_count(&value);
  
  /* Check for errors */
  if(retCode != 0) {
    sprintf(*retVal, "%s%d:Execution Error%s", retStart, VSIS_RET_EXECUTION_ERROR, retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }

  /* Success get allocate return buffer and format data	 */
  sprintf(*retVal, "%s%d:%x%s", retStart, 0, value, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_ild_get_mid_state_count into command queue.
 */
void insert_vsis_fpga_ild_get_mid_state_count(void)
{
  char *name = "fpga_ild_get_mid_state_count";
  char *usage= "fpga_ild_get_mid_state_count?;";
  int nParams = 0;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[1] = {CMD_PARAM_UNSIGNED};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_ild_get_mid_state_count, cmdType);
}


/**
 * Get the value of input level detector high_state_count register
 * @param argc   - should be 0
 * @param argv   - pointers to the parameters
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_ild_get_high_state_count(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_ild_get_high_state_count?"; // beginning of return string
  char *retEnd   = ";\n";                   // end of return string
  
  unsigned short value = 0;
  
  /* Execute the function:   */
  retCode = fpga_ild_get_high_state_count(&value);
  
  /* Check for errors */
  if(retCode != 0) {
    sprintf(*retVal, "%s%d:Execution Error%s", retStart, VSIS_RET_EXECUTION_ERROR, retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }

  /* Success get allocate return buffer and format data	 */
  sprintf(*retVal, "%s%d:%x%s", retStart, 0, value, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_ild_get_high_state_count into command queue.
 */
void insert_vsis_fpga_ild_get_high_state_count(void)
{
  char *name = "fpga_ild_get_high_state_count";
  char *usage= "fpga_ild_get_high_state_count?;";
  int nParams = 0;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[1] = {CMD_PARAM_UNSIGNED};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_ild_get_high_state_count, cmdType);
}


/**
 * Get the value of input level detector num_samples register
 * @param argc   - should be 0
 * @param argv   - pointers to the parameters
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_ild_get_num_samples(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_ild_get_num_samples?"; // beginning of return string
  char *retEnd   = ";\n";                   // end of return string
  
  unsigned short value = 0;
  
  /* Execute the function:   */
  retCode = fpga_ild_get_num_samples(&value);
  
  /* Check for errors */
  if(retCode != 0) {
    sprintf(*retVal, "%s%d:Execution Error%s", retStart, VSIS_RET_EXECUTION_ERROR, retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }

  /* Success get allocate return buffer and format data	 */  
  sprintf(*retVal, "%s%d:%x%s", retStart, 0, value, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_ild_get_num_samples into command queue.
 */
void insert_vsis_fpga_ild_get_num_samples(void)
{
  char *name = "fpga_ild_get_num_samples";
  char *usage= "fpga_ild_get_num_samples?;";
  int nParams = 0;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[1] = {CMD_PARAM_UNSIGNED};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_ild_get_num_samples, cmdType);
}


/**
 * Get the value of input level detector statemachine_status register
 * @param argc   - should be 0
 * @param argv   - pointers to the parameters
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_ild_get_statemachine_status(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_ild_get_statemachine_status?"; // beginning of return string
  char *retEnd   = ";\n";                   // end of return string
  
  unsigned short value = 0;
  
  /* Execute the function:   */
  retCode = fpga_ild_get_state_machine_status(&value);
  
  /* Check for errors */
  if(retCode != 0) {
    sprintf(*retVal, "%s%d:Execution Error%s", retStart, VSIS_RET_EXECUTION_ERROR, retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }

  /* Success get allocate return buffer and format data	 */
  sprintf(*retVal, "%s%d:%x%s", retStart, 0, value, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_ild_get_statemachine_status into command queue.
 */
void insert_vsis_fpga_ild_get_statemachine_status(void)
{
  char *name = "fpga_ild_get_statemachine_status";
  char *usage= "fpga_ild_get_statemachine_status?;";
  int nParams = 0;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[1] = {CMD_PARAM_UNSIGNED};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_ild_get_statemachine_status, cmdType);
}


/* --------------------------------------------------------------------------------------------- */
/* 10Gigabit Ethernet functions                                                                  */
/* --------------------------------------------------------------------------------------------- */


/**
 * Get the value of 10GE local_mac register
 * @param argc   - should be 1
 * @param argv   - pointers to the parameters <physical port number [0..3]>
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_10ge_get_local_mac(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_10ge_get_local_mac?"; // beginning of return string
  char *retEnd   = ";\n";                   // end of return string
  
  int paramOk;
  unsigned char value[6];
  int channel = 0;
  
  // check parameters
  paramOk = 0;  // assume parameters are wrong before checking
  if(argv[0]  != 0 ){
    channel  = (int)*(long*)argv[0];
    paramOk  = 1;
  }
  
  if(!paramOk) {
    sprintf(*retVal, "%s%d:Parameter Error%s", retStart,VSIS_RET_PARAMETER_ERROR,retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_PARAMETER_ERROR;
  }
  
  
  /* Execute the function:   */
  retCode = fpga_10ge_get_local_mac(channel, value);
  
  /* Check for errors */
  if(retCode != 0) {
    sprintf(*retVal, "%s%d:Execution Error%s", retStart, VSIS_RET_EXECUTION_ERROR, retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }

  /* Success get allocate return buffer and format data	 */
  sprintf(*retVal, "%s%d:%x:%x:%x:%x:%x:%x%s", retStart, 0, value[0],value[1],value[2],value[3],value[4],value[5], retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_10ge_get_local_mac into command queue.
 */
void insert_vsis_fpga_10ge_get_local_mac(void)
{
  char *name = "fpga_10ge_get_local_mac";
  char *usage= "fpga_10ge_get_local_mac?<port>;";
  int nParams = 1;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[1] = {CMD_PARAM_UNSIGNED};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_10ge_get_local_mac, cmdType);
}


/**
 * Set the value of 10GE local_mac register
 * @param argc   - should be 1
 * @param argv   - pointers to the parameters <physical port number [0..3]>
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_10ge_set_local_mac(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_10ge_set_local_mac="; // beginning of return string
  char *retEnd   = ";\n";                   // end of return string
  
  int paramOk;
  unsigned char value[6];
  int channel = 0;
  int i;
  // check parameters
  paramOk = 0;  // assume parameters are wrong before checking
  if(argv[0]!= 0 && argv[1]!= 0 && argv[2]!= 0 && argv[3]!= 0 && argv[4]!= 0 && argv[5]!= 0 && argv[6]!= 0 ){
    channel  = (int)*(long*)argv[0];
    for(i=0;i<6;i++){
      value[i] = (unsigned char)*(unsigned long*)argv[i+1];
    }
    paramOk  = 1;
  }
  
  if(!paramOk) {
    sprintf(*retVal, "%s%d:Parameter Error%s", retStart,VSIS_RET_PARAMETER_ERROR,retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_PARAMETER_ERROR;
  }
  
  
  /* Execute the function:   */
  retCode = fpga_10ge_set_local_mac(channel, value);
  
  /* Check for errors */
  if(retCode != 0) {
    sprintf(*retVal, "%s%d:Execution Error%s", retStart, VSIS_RET_EXECUTION_ERROR, retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }

  /* Success get allocate return buffer and format data	 */
  sprintf(*retVal, "%s%d%s", retStart, 0, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_10ge_set_local_mac into command queue.
 */
void insert_vsis_fpga_10ge_set_local_mac(void)
{
  char *name = "fpga_10ge_set_local_mac";
  char *usage= "fpga_10ge_set_local_mac=<port>:mac0:mac1:mac2:mac3:mac4:mac5;";
  int nParams = 7;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[7] = {CMD_PARAM_UNSIGNED,CMD_PARAM_UNSIGNED,CMD_PARAM_UNSIGNED,CMD_PARAM_UNSIGNED,CMD_PARAM_UNSIGNED,CMD_PARAM_UNSIGNED,CMD_PARAM_UNSIGNED};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_10ge_set_local_mac, cmdType);
}


/**
 * Get the value of 10GE local_gw register
 * @param argc   - should be 1
 * @param argv   - pointers to the parameters <physical port number [0..3]>
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_10ge_get_local_gw(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_10ge_get_local_gw?"; // beginning of return string
  char *retEnd   = ";\n";                   // end of return string
  
  int paramOk;
  unsigned char value;
  int channel = 0;
  
  // check parameters
  paramOk = 0;  // assume parameters are wrong before checking
  if(argv[0]  != 0 ){
    channel  = (int)*(long*)argv[0];
    paramOk  = 1;
  }
  
  if(!paramOk) {
    sprintf(*retVal, "%s%d:Parameter Error%s", retStart,VSIS_RET_PARAMETER_ERROR,retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_PARAMETER_ERROR;
  }
  
  /* Execute the function:   */
  retCode = fpga_10ge_get_local_gw(channel, &value);
  
  /* Check for errors */
  if(retCode != 0) {
    sprintf(*retVal, "%s%d:Execution Error%s", retStart, VSIS_RET_EXECUTION_ERROR, retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }
  
  /* Success get allocate return buffer and format data	 */
  sprintf(*retVal, "%s%d:%x%s", retStart, 0, value, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_10ge_get_local_gw into command queue.
 */
void insert_vsis_fpga_10ge_get_local_gw(void)
{
  char *name = "fpga_10ge_get_local_gw";
  char *usage= "fpga_10ge_get_local_gw?;";
  int nParams = 1;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[1] = {CMD_PARAM_UNSIGNED};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_10ge_get_local_gw, cmdType);
}


/**
 * Get the value of 10GE local_gw register
 * @param argc   - should be 2
 * @param argv   - pointers to the parameters <physical port number [0..3]> <ip>
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_10ge_set_local_gw(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_10ge_set_local_gw?"; // beginning of return string
  char *retEnd   = ";\n";                   // end of return string
  
  int paramOk;
  unsigned char value;
  int channel = 0;
  
  // check parameters
  paramOk = 0;  // assume parameters are wrong before checking
  if(argv[0]!= 0 && argv[1]!= 0 ){
    channel  = (int)*(long*)argv[0];
    value = (unsigned char)*(unsigned long*)argv[1];
    paramOk  = 1;
  }
  
  if(!paramOk) {
    sprintf(*retVal, "%s%d:Parameter Error%s", retStart,VSIS_RET_PARAMETER_ERROR,retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_PARAMETER_ERROR;
  }
  
  
  /* Execute the function:   */
  retCode = fpga_10ge_set_local_gw(channel, value);
  
  /* Check for errors */
  if(retCode != 0) {       
    sprintf(*retVal, "%s%d:Execution Error%s", retStart, VSIS_RET_EXECUTION_ERROR, retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }
  
  /* Success get allocate return buffer and format data	 */
  sprintf(*retVal, "%s%d%s", retStart, 0, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_10ge_set_local_gw into command queue.
 */
void insert_vsis_fpga_10ge_set_local_gw(void)
{
  char *name = "fpga_10ge_set_local_gw";
  char *usage= "fpga_10ge_set_local_gw=<port>:<end of ip>;";
  int nParams = 2;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[2] = {CMD_PARAM_UNSIGNED,CMD_PARAM_UNSIGNED};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_10ge_set_local_gw, cmdType);
}



/**
 * Get the value of 10GE local_ip register
 * @param argc   - should be 1
 * @param argv   - pointers to the parameters <physical port number [0..3]>
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_10ge_get_local_ip(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_10ge_get_local_ip?"; // beginning of return string
  char *retEnd   = ";\n";                   // end of return string
  
  int paramOk;
  unsigned char value[4];
  int channel = 0;
  
  // check parameters
  paramOk = 0;  // assume parameters are wrong before checking
  if(argv[0]  != 0 ){
    channel  = (int)*(long*)argv[0];
    paramOk  = 1;
  }
  
  if(!paramOk) {
    sprintf(*retVal, "%s%d:Parameter Error%s", retStart,VSIS_RET_PARAMETER_ERROR,retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_PARAMETER_ERROR;
  }

  /* Execute the function:  */
  retCode = fpga_10ge_get_local_ip(channel, value);
  
  /* Check for errors */
  if(retCode != 0) {
    sprintf(*retVal, "%s%d:Execution Error%s", retStart, VSIS_RET_EXECUTION_ERROR, retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }
  
  /* Success get allocate return buffer and format data	 */
  sprintf(*retVal, "%s%d:%x:%x:%x:%x%s", retStart, 0, value[0],value[1],value[2],value[3], retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_10ge_get_local_ip into command queue.
 */
void insert_vsis_fpga_10ge_get_local_ip(void)
{
  char *name = "fpga_10ge_get_local_ip";
  char *usage= "fpga_10ge_get_local_ip?<port>;";
  int nParams = 1;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[1] = {CMD_PARAM_UNSIGNED};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_10ge_get_local_ip, cmdType);
}


/**
 * Set the value of 10GE local_ip register
 * @param argc   - should be 5
 * @param argv   - pointers to the parameters <physical port number [0..3]>
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_10ge_set_local_ip(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_10ge_set_local_ip="; // beginning of return string
  char *retEnd   = ";\n";                   // end of return string
  
  int paramOk;
  unsigned char value[4];
  int channel = 0;
  int i;
  // check parameters
  paramOk = 0;  // assume parameters are wrong before checking
  if(argv[0]!= 0 && argv[1]!= 0 && argv[2]!= 0 && argv[3]!= 0 && argv[4]!= 0 ){
    channel  = (int)*(long*)argv[0];
    for(i=0;i<4;i++){
      value[i] = (unsigned char)*(unsigned long*)argv[i+1];
    }
    paramOk  = 1;
  }
  
  if(!paramOk) {
    sprintf(*retVal, "%s%d:Parameter Error%s", retStart,VSIS_RET_PARAMETER_ERROR,retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_PARAMETER_ERROR;
  }
  

  /* Execute the function: */
  retCode = fpga_10ge_set_local_ip(channel, value);
  
  /* Check for errors */
  if(retCode != 0) {
    sprintf(*retVal, "%s%d:Execution Error%s", retStart, VSIS_RET_EXECUTION_ERROR, retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }
  
  /* Success get allocate return buffer and format data	 */
  sprintf(*retVal, "%s%d%s", retStart, 0, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_10ge_set_local_ip into command queue.
 */
void insert_vsis_fpga_10ge_set_local_ip(void)
{
  char *name = "fpga_10ge_set_local_ip";
  char *usage= "fpga_10ge_set_local_ip=<port>:ip0:ip1:ip2:ip3;";
  int nParams = 5;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[7] = {CMD_PARAM_UNSIGNED,CMD_PARAM_UNSIGNED,CMD_PARAM_UNSIGNED,CMD_PARAM_UNSIGNED,CMD_PARAM_UNSIGNED,CMD_PARAM_UNSIGNED,CMD_PARAM_UNSIGNED};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_10ge_set_local_ip, cmdType);
}




/**
 * Get the value of 10GE buffer_sizes register
 * @param argc   - should be 1
 * @param argv   - pointers to the parameters <physical port number [0..3]>
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_10ge_get_buffer_sizes(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_10ge_get_buffer_sizes?"; // beginning of return string
  char *retEnd   = ";\n";                   // end of return string
  
  int paramOk;
  unsigned short value;
  int channel = 0;
  
  // check parameters
  paramOk = 0;  // assume parameters are wrong before checking
  if(argv[0]  != 0 ){
    channel  = (int)*(long*)argv[0];
    paramOk  = 1;
  }
  
  if(!paramOk) {
    sprintf(*retVal, "%s%d:Parameter Error%s", retStart,VSIS_RET_PARAMETER_ERROR,retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_PARAMETER_ERROR;
  }
  
  
  /* Execute the function:   */
  retCode = fpga_10ge_get_buffer_sizes(channel, &value);
  
  /* Check for errors */
  if(retCode != 0) {
    sprintf(*retVal, "%s%d:Execution Error%s", retStart, VSIS_RET_EXECUTION_ERROR, retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }
  
  /* Success get allocate return buffer and format data	 */
  sprintf(*retVal, "%s%d:%x%s", retStart, 0, value, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_10ge_get_buffer_sizes into command queue.
 */
void insert_vsis_fpga_10ge_get_buffer_sizes(void)
{
  char *name = "fpga_10ge_get_buffer_sizes";
  char *usage= "fpga_10ge_get_buffer_sizes?;";
  int nParams = 1;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[1] = {CMD_PARAM_UNSIGNED};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_10ge_get_buffer_sizes, cmdType);
}


/**
 * Get the value of 10GE buffer_sizes register
 * @param argc   - should be 2
 * @param argv   - pointers to the parameters <physical port number [0..3]> <ip>
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_10ge_set_buffer_sizes(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_10ge_set_buffer_sizes?"; // beginning of return string
  char *retEnd   = ";\n";                   // end of return string
  
  int paramOk;
  unsigned short value;
  int channel = 0;
  
  // check parameters
  paramOk = 0;  // assume parameters are wrong before checking
  if(argv[0]!= 0 && argv[1]!= 0 ){
    channel  = (int)*(long*)argv[0];
    value = (unsigned short)*(unsigned long*)argv[1];
    paramOk  = 1;
  }
  
  if(!paramOk) { 
    sprintf(*retVal, "%s%d:Parameter Error%s", retStart,VSIS_RET_PARAMETER_ERROR,retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_PARAMETER_ERROR;
  }
  
  /* Execute the function:   */
  retCode = fpga_10ge_set_buffer_sizes(channel, value);

  /* Check for errors */
  if(retCode != 0) {
    sprintf(*retVal, "%s%d:Execution Error%s", retStart, VSIS_RET_EXECUTION_ERROR, retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }
  
  /* Success get allocate return buffer and format data	 */
  sprintf(*retVal, "%s%d%s", retStart, 0, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_10ge_set_buffer_sizes into command queue.
 */
void insert_vsis_fpga_10ge_set_buffer_sizes(void)
{
  char *name = "fpga_10ge_set_buffer_sizes";
  char *usage= "fpga_10ge_set_buffer_sizes=<port>:<vlue>;";
  int nParams = 2;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[2] = {CMD_PARAM_UNSIGNED,CMD_PARAM_UNSIGNED};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_10ge_set_buffer_sizes, cmdType);
}

/**
 * Get the value of 10GE valid_ports register
 * @param argc   - should be 1
 * @param argv   - pointers to the parameters <physical port number [0..3]>
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_10ge_get_valid_ports(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_10ge_get_valid_ports?"; // beginning of return string
  char *retEnd   = ";\n";                   // end of return string
  
  int paramOk;
  unsigned short value;
  int channel = 0;
  
  // check parameters
  paramOk = 0;  // assume parameters are wrong before checking
  if(argv[0]  != 0 ){
    channel  = (int)*(long*)argv[0];
    paramOk  = 1;
  }
  
  if(!paramOk) {
    sprintf(*retVal, "%s%d:Parameter Error%s", retStart,VSIS_RET_PARAMETER_ERROR,retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_PARAMETER_ERROR;
  }
  
  /* Execute the function:   */
  retCode = fpga_10ge_get_valid_ports(channel, &value);
  
  /* Check for errors */
  if(retCode != 0) {
    sprintf(*retVal, "%s%d:Execution Error%s", retStart, VSIS_RET_EXECUTION_ERROR, retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }

  /* Success get allocate return buffer and format data	 */
  sprintf(*retVal, "%s%d:%x%s", retStart, 0, value, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_10ge_get_valid_ports into command queue.
 */
void insert_vsis_fpga_10ge_get_valid_ports(void)
{
  char *name = "fpga_10ge_get_valid_ports";
  char *usage= "fpga_10ge_get_valid_ports?<port>;";
  int nParams = 1;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[1] = {CMD_PARAM_UNSIGNED};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_10ge_get_valid_ports, cmdType);
}


/**
 * Get the value of 10GE valid_ports register
 * @param argc   - should be 2
 * @param argv   - pointers to the parameters <physical port number [0..3]> <ip>
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_10ge_set_valid_ports(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_10ge_set_valid_ports"; // beginning of return string
  char *retEnd   = ";\n";                   // end of return string
  
  int paramOk;
  unsigned short value;
  int channel = 0;
  
  // check parameters
  paramOk = 0;  // assume parameters are wrong before checking
  if(argv[0]!= 0 && argv[1]!= 0 ){
    channel  = (int)*(long*)argv[0];
    value = (unsigned short)*(unsigned long*)argv[1];
    paramOk  = 1;
  }
  
  if(!paramOk) {
    sprintf(*retVal, "%s%d:Parameter Error%s", retStart,VSIS_RET_PARAMETER_ERROR,retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_PARAMETER_ERROR;
  }
  
  /* Execute the function:   */
  retCode = fpga_10ge_set_valid_ports(channel, value);
  
  /* Check for errors */
  if(retCode != 0) {
    sprintf(*retVal, "%s%d:Execution Error%s", retStart, VSIS_RET_EXECUTION_ERROR, retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }
  
  /* Success get allocate return buffer and format data	 */
  sprintf(*retVal, "%s%d%s", retStart, 0, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_10ge_set_valid_ports into command queue.
 */
void insert_vsis_fpga_10ge_set_valid_ports(void)
{
  char *name = "fpga_10ge_set_valid_ports";
  char *usage= "fpga_10ge_set_valid_ports=<ports>;";
  int nParams = 2;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[2] = {CMD_PARAM_UNSIGNED,CMD_PARAM_UNSIGNED};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_10ge_set_valid_ports, cmdType);
}



/**
 * Get the value of 10GE xaui_status register
 * @param argc   - should be 1
 * @param argv   - pointers to the parameters <physical port number [0..3]>
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_10ge_get_xaui_status(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_10ge_get_xaui_status?"; // beginning of return string
  char *retEnd   = ";\n";                   // end of return string
  
  int paramOk;
  unsigned short value;
  int channel = 0;
  
  // check parameters
  paramOk = 0;  // assume parameters are wrong before checking
  if(argv[0]  != 0 ){
    channel  = (int)*(long*)argv[0];
    paramOk  = 1;
  }
  
  if(!paramOk) {
    sprintf(*retVal, "%s%d:Parameter Error%s", retStart,VSIS_RET_PARAMETER_ERROR,retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_PARAMETER_ERROR;
  }
  
  /* Execute the function:   */
  retCode = fpga_10ge_get_xaui_status(channel, &value);
  
  /* Check for errors */
  if(retCode != 0) {  
    sprintf(*retVal, "%s%d:Execution Error%s", retStart, VSIS_RET_EXECUTION_ERROR, retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }
  
  /* Success get allocate return buffer and format data	 */
  sprintf(*retVal, "%s%d:%x%s", retStart, 0, value, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_10ge_get_xaui_status into command queue.
 */
void insert_vsis_fpga_10ge_get_xaui_status(void)
{
  char *name = "fpga_10ge_get_xaui_status";
  char *usage= "fpga_10ge_get_xaui_status?<port>;";
  int nParams = 1;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[1] = {CMD_PARAM_UNSIGNED};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_10ge_get_xaui_status, cmdType);
}


/**
 * Get the value of 10GE phy_config register
 * @param argc   - should be 1
 * @param argv   - pointers to the parameters <physical port number [0..3]>
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_10ge_get_phy_config(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_10ge_get_phy_config?"; // beginning of return string
  char *retEnd   = ";\n";                   // end of return string
  
  int paramOk;
  unsigned short value;
  int channel = 0;
  
  // check parameters
  paramOk = 0;  // assume parameters are wrong before checking
  if(argv[0]  != 0 ){
    channel  = (int)*(long*)argv[0];
    paramOk  = 1;
  }
  
  if(!paramOk) {
    sprintf(*retVal, "%s%d:Parameter Error%s", retStart,VSIS_RET_PARAMETER_ERROR,retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_PARAMETER_ERROR;
  }

  /* Execute the function:   */
  retCode = fpga_10ge_get_phy_config(channel, &value);
  
  /* Check for errors */
  if(retCode != 0) {
    sprintf(*retVal, "%s%d:Execution Error%s", retStart, VSIS_RET_EXECUTION_ERROR, retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }
  
  /* Success get allocate return buffer and format data	 */
  sprintf(*retVal, "%s%d:%x%s", retStart, 0, value, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_10ge_get_phy_config into command queue.
 */
void insert_vsis_fpga_10ge_get_phy_config(void)
{
  char *name = "fpga_10ge_get_phy_config";
  char *usage= "fpga_10ge_get_phy_config?<port>;";
  int nParams = 1;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[1] = {CMD_PARAM_UNSIGNED};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_10ge_get_phy_config, cmdType);
}


/**
 * Get the value of 10GE phy_config register
 * @param argc   - should be 2
 * @param argv   - pointers to the parameters <physical port number [0..3]> <ip>
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_10ge_set_phy_config(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_10ge_set_phy_config?"; // beginning of return string
  char *retEnd   = ";\n";                   // end of return string
  
  int paramOk;
  unsigned short value;
  int channel = 0;
  
  // check parameters
  paramOk = 0;  // assume parameters are wrong before checking
  if(argv[0]!= 0 && argv[1]!= 0 ){
    channel  = (int)*(long*)argv[0];
    value = (unsigned short)*(unsigned long*)argv[1];
    paramOk  = 1;
  }
  
  if(!paramOk) {  
    sprintf(*retVal, "%s%d:Parameter Error%s", retStart,VSIS_RET_PARAMETER_ERROR,retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_PARAMETER_ERROR;
  }
  
  /* Execute the function:   */
  retCode = fpga_10ge_set_phy_config(channel, value);
  
  /* Check for errors */
  if(retCode != 0) {  
    sprintf(*retVal, "%s%d:Execution Error%s", retStart, VSIS_RET_EXECUTION_ERROR, retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }
  
  /* Success get allocate return buffer and format data	 */
  sprintf(*retVal, "%s%d%s", retStart, 0, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_10ge_set_phy_config into command queue.
 */
void insert_vsis_fpga_10ge_set_phy_config(void)
{
  char *name = "fpga_10ge_set_phy_config";
  char *usage= "fpga_10ge_set_phy_config=<port>:<value>;";
  int nParams = 2;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[2] = {CMD_PARAM_UNSIGNED,CMD_PARAM_UNSIGNED};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_10ge_set_phy_config, cmdType);
}

///////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////


/**
 * Write bytes to the TX buffer on port
 * @param port - the port to write to
 * @param buf - array of bytes to write (2k always)
 * @return - 0 on success
 */
//int fpga_10ge_set_tx_buffer(unsigned port, unsigned char *buf);

/**
 * Read data from TX buffer on port
 * @param port - the port to read from
 * @param buf - return array of bytes from buffer (user must allocate 2k)
 * @return - 0 on success
 */
//int fpga_10ge_get_tx_buffer(unsigned port, unsigned char *buf);

/**
 * Write bytes to the RX buffer on port
 * @param port - the port to write to (2k always)
 * @param buf - array of bytes to write
 * @return - 0 on success
 */
//int fpga_10ge_set_rx_buffer(unsigned port, unsigned char *buf);

/**
 * Write bytes to the TX buffer on port
 * @param port - the port to write to
 * @param buf - return - array of bytes to write 2k user must allocate
 * @return - 0 on success
 */
//int fpga_10ge_get_rx_buffer(unsigned port, unsigned char *buf);

/**
 * Write a full APR cache table to FPGA port
 * @param port - the port [0..3]
 * @param arp_table - 128 entries of 6 bytes each in LE format
 * @return - 0 on success
 */
//int fpga_10ge_set_arp_cache(unsigned port, unsigned char *arp_table);

/**
 * Write a full APR cahce table to FPGA port
 * User must allocate return buffer
 * @param port - the port [0..3]
 * @param arp_table - (return value) 128 entries of 6 bytes each in LE format
 * @return - 0 on success
 */
//int fpga_10ge_get_arp_cache(unsigned port, unsigned char *arp_table);

/**
 * Set the value of 10GE arp cache entry for IP
 * @param argc   - should be 8
 * @param argv   - pointers to the parameters <port No[0..3]><last byte of IPv4><MAC[6]>
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_10ge_set_arp_value(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_10ge_set_arp_value="; // beginning of return string
  char *retEnd   = ";\n";                   // end of return string
  
  int paramOk;
  unsigned char value[6];
  unsigned channel = 0;
  unsigned char endIP;
  int i;
  // check parameters
  paramOk = 0;  // assume parameters are wrong before checking
  if(argv[0]!= 0 && argv[1]!= 0 && argv[2]!= 0 && argv[3]!= 0 && argv[4]!= 0 && argv[5]!= 0 && argv[6]!= 0 && argv[7]!= 0 ){
    channel = (unsigned)*(unsigned long*)argv[0];
    endIP   = (unsigned char)*(unsigned long*)argv[1];
    for(i=0;i<6;i++){
      value[i] = (unsigned char)*(unsigned long*)argv[i+2];
    }
    paramOk  = 1;
  }
  
  if(!paramOk) {
    sprintf(*retVal, "%s%d:Parameter Error%s", retStart,VSIS_RET_PARAMETER_ERROR,retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_PARAMETER_ERROR;
  }


  /* Execute the function:   */
  retCode = fpga_10ge_set_arp_value(channel, endIP, value);
  
  /* Check for errors */
  if(retCode != 0) {  
    sprintf(*retVal, "%s%d:Execution Error%s", retStart, VSIS_RET_EXECUTION_ERROR, retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }
  
  /* Success get allocate return buffer and format data	 */
  sprintf(*retVal, "%s%d%s", retStart, 0, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_10ge_set_local_mac into command queue.
 */
void insert_vsis_fpga_10ge_set_arp_value(void)
{
  char *name = "fpga_10ge_set_arp_value";
  char *usage= "fpga_10ge_set_arp_value=<port>:<endIP>:mac0:mac1:mac2:mac3:mac4:mac5;";
  int nParams = 8;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[8] = {CMD_PARAM_UNSIGNED,CMD_PARAM_UNSIGNED,CMD_PARAM_UNSIGNED,CMD_PARAM_UNSIGNED,CMD_PARAM_UNSIGNED,CMD_PARAM_UNSIGNED,CMD_PARAM_UNSIGNED,CMD_PARAM_UNSIGNED};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_10ge_set_arp_value, cmdType);
}



/**
 * Get the value of 10GE ARP cache at location endIP
 * @param argc   - should be 2
 * @param argv   - pointers to the parameters <portNo[0..3]><endIP>
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_10ge_get_arp_value(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_10ge_get_arp_value?"; // beginning of return string
  char *retEnd   = ";\n";                   // end of return string
  
  int paramOk;
  unsigned char value[6];
  unsigned channel = 0;
  unsigned char endIP;
  
  // check parameters
  paramOk = 0;  // assume parameters are wrong before checking
  if(argv[0]  != 0 && argv[1] != 0){
    channel = (unsigned)*(unsigned long*)argv[0];
    endIP   = (unsigned char)*(unsigned long*)argv[1];
    paramOk  = 1;
  }
  
  if(!paramOk) {
    sprintf(*retVal, "%s%d:Parameter Error%s", retStart,VSIS_RET_PARAMETER_ERROR,retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_PARAMETER_ERROR;
  }

  
  /* Execute the function:  */
  retCode = fpga_10ge_get_arp_value(channel, endIP, value);
  
  /* Check for errors */
  if(retCode != 0) {
    sprintf(*retVal, "%s%d:Execution Error%s", retStart, VSIS_RET_EXECUTION_ERROR, retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }
  
  /* Success get allocate return buffer and format data	 */
  sprintf(*retVal, "%s%d:%x:%x:%x:%x:%x:%x%s", retStart, 0, value[0],value[1],value[2],value[3],value[4],value[5], retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_10ge_get_arp_value into command queue.
 */
void insert_vsis_fpga_10ge_get_arp_value(void)
{
  char *name = "fpga_10ge_get_arp_value";
  char *usage= "fpga_10ge_get_arp_value?<port>:<end IP>;";
  int nParams = 2;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[2] = {CMD_PARAM_UNSIGNED, CMD_PARAM_UNSIGNED};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_10ge_get_arp_value, cmdType);
}



/**
 * Set the value of fpga julian time register
 * @param argc   - should be 1
 * @param argv   - pointers to the parameters
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_set_dot(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_set_dot="; // beginning of return string
  char *retEnd   = ";\n";                   // end of return string
  
  int paramOk;
  unsigned long value = 0;
  
  // check parameters
  paramOk = 0;  // assume parameters are wrong before checking
  if(argv[0] != 0 ){
    value = (unsigned long)*(unsigned long*)argv[0];
    paramOk = 1;
  }
  
  if(!paramOk) {  
    sprintf(*retVal, "%s%d:Parameter Error%s", retStart,VSIS_RET_PARAMETER_ERROR,retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_PARAMETER_ERROR;
  }

  /* Execute the function:  */
  retCode = fpga_set_dot(value);
  
  /* Check for errors */
  if(retCode != 0) {
    sprintf(*retVal, "%s%d:Execution Error%s", retStart, VSIS_RET_EXECUTION_ERROR, retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }

  /* Success get allocate return buffer and format data	 */
  sprintf(*retVal, "%s%d%s", retStart, 0, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_set_julian time into command queue.
 */
void insert_vsis_fpga_set_dot(void)
{
  char *name = "fpga_set_dot";
  char *usage= "fpga_set_dot=<JJJSSSSS>;";
  int nParams = 1;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[1] = {CMD_PARAM_UNSIGNED};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_set_dot, cmdType);
}


/**
 * Get the value of Julian time register
 * @param argc   - should be 0
 * @param argv   - pointers to the parameters
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_get_dot(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_get_dot?"; // beginning of return string
  char *retEnd   = ";\n";                   // end of return string
  
  unsigned long value;
  
  /* Execute the function: */
  retCode = fpga_get_dot(&value);
  
  /* Check for errors */
  if(retCode != 0) {
    sprintf(*retVal, "%s%d:Execution Error%s", retStart, VSIS_RET_EXECUTION_ERROR, retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }

  /* Success get allocate return buffer and format data	 */
  sprintf(*retVal, "%s%d:%lx%s", retStart, 0, value, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_get_julian_time into command queue.
 */
void insert_vsis_fpga_get_dot(void)
{
  char *name = "fpga_get_dot";
  char *usage= "fpga_get_dot?;";
  int nParams = 0;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[1] = {CMD_PARAM_UNSIGNED};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_get_dot, cmdType);
}


/* ---------------------------------------------------------------------------------------
 *    Data Transfer module
 * ---------------------------------------------------------------------------------------
 */

/**
 * Set the start and stop time value for data transfer TON/TOFF in slot X
 * @param argc   - should be 3
 * @param argv   - pointers to the parameters
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_dtm_set_timeslot(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_dtm_set_timeslot="; // beginning of return string
  char *retEnd   = ";\n";                   // end of return string
  
  int paramOk;
  unsigned char slotNo = 0;
  unsigned long tOn    = 0;
  unsigned long tOff   = 0;
  
  // check parameters
  paramOk = 0;  // assume parameters are wrong before checking
  if(argv[0] != 0 ){
    slotNo = (unsigned char)*(unsigned long*)argv[0];
    paramOk = 1;
  }
  
  if(argv[1] != 0 ){
    tOn = (unsigned)*(unsigned long*)argv[1];
    paramOk = 1;
  }
  
  if(argv[2] != 0 ){
    tOff = (unsigned)*(unsigned long*)argv[2];
    paramOk = 1;
  }
  if(!paramOk) {
    sprintf(*retVal, "%s%d:Parameter Error%s", retStart,VSIS_RET_PARAMETER_ERROR,retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_PARAMETER_ERROR;
  }
  
  /* Execute the function:  */
  retCode = fpga_dtm_set_timeslot(slotNo, tOn, tOff);
  
  /* Check for errors */
  if(retCode != 0) {
    sprintf(*retVal, "%s%d:Execution Error%s", retStart, VSIS_RET_EXECUTION_ERROR, retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }

  /* Success get allocate return buffer and format data	 */
  sprintf(*retVal, "%s%d%s", retStart, 0, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_dtm_set_timeslot time into command queue.
 */
void insert_vsis_fpga_dtm_set_timeslot(void)
{
  char *name = "fpga_dtm_set_timeslot";
  char *usage= "fpga_dtm_set_timeslot=<slotNo>:<JJJSSSSS>:<JJJSSSSS>;";
  int nParams = 3;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[3] = {CMD_PARAM_UNSIGNED,CMD_PARAM_UNSIGNED,CMD_PARAM_UNSIGNED};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_dtm_set_timeslot, cmdType);
}

/**
 * Get the value of DTM time slot register SlotNo
 * @param argc   - should be 1
 * @param argv   - pointers to the parameters <slotNo>
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_dtm_get_timeslot(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_dtm_get_timeslot?"; // beginning of return string
  char *retEnd   = ";\n";                   // end of return string
  
  int paramOk;
  unsigned char slotNo;
  unsigned long tOn;
  unsigned long tOff;
  
  // check parameters
  paramOk = 0;  // assume parameters are wrong before checking
  if(argv[0] != 0 ){
    slotNo = (unsigned char)*(unsigned long*)argv[0];
    paramOk = 1;
  }
  
  if(!paramOk) {
    sprintf(*retVal, "%s%d:Parameter Error%s", retStart,VSIS_RET_PARAMETER_ERROR,retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_PARAMETER_ERROR;
  }

  /* Execute the function: */
  retCode = fpga_dtm_get_timeslot(slotNo, &tOn, &tOff);
  
  /* Check for errors */
  if(retCode != 0) {
    sprintf(*retVal, "%s%d:Execution Error%s", retStart, VSIS_RET_EXECUTION_ERROR, retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }

  /* Success get allocate return buffer and format data	 */
  sprintf(*retVal, "%s%d:%lx:%lx%s", retStart, 0, tOn, tOff, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_dtm_get_timeslot into command queue.
 */
void insert_vsis_fpga_dtm_get_timselot(void)
{
  char *name = "fpga_dtm_get_timeslot";
  char *usage= "fpga_dtm_get_timeslot?=<slotNo>;";
  int nParams = 1;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[1] = {CMD_PARAM_UNSIGNED};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_dtm_get_timeslot, cmdType);
}


/**
 * Set the start and stop time value for data transfer TOFF in slot X
 * @param argc   - should be 2
 * @param argv   - pointers to the parameters
 * @param retVal - buffer with return values
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_dtm_set_timeslot_end(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode; //tmp holder of return code
  char *retStart = "!fpga_dtm_set_timeslot_end="; // beginning of return string
  char *retEnd   = ";\n";                   // end of return string
  
  int paramOk;
  unsigned char slotNo = 0;
  unsigned long tOff   = 0;
  
  // check parameters
  paramOk = 0;  // assume parameters are wrong before checking
  if(argv[0] != 0 ){
    slotNo = (unsigned char)*(unsigned long*)argv[0];
    paramOk = 1;
  }
  
  if(argv[1] != 0 ){
    tOff = (unsigned)*(unsigned long*)argv[1];
    paramOk = 1;
  }
  
  if(!paramOk) {
    sprintf(*retVal, "%s%d:Parameter Error%s", retStart,VSIS_RET_PARAMETER_ERROR,retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_PARAMETER_ERROR;
  }

  /* Execute the function:  */
  retCode = fpga_dtm_set_timeslot_end(slotNo, tOff);
  
  /* Check for errors */
  if(retCode != 0) {
    sprintf(*retVal, "%s%d:Execution Error%s", retStart, VSIS_RET_EXECUTION_ERROR, retEnd);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }

  /* Success get allocate return buffer and format data	 */
  sprintf(*retVal, "%s%d%s", retStart, 0, retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS; // 0
}

/**
 * Insert the fpga_dtm_set_timeslot_end time into command queue.
 */
void insert_vsis_fpga_dtm_set_timeslot_end(void)
{
  char *name = "fpga_dtm_set_timeslot_end";
  char *usage= "fpga_dtm_set_timeslot_end=<slotNo>:<JJJSSSSS>;";
  int nParams = 2;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[3] = {CMD_PARAM_UNSIGNED,CMD_PARAM_UNSIGNED};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_dtm_set_timeslot_end, cmdType);
}


/**
 * Initializes command lists with HAL command set
 */
void cmd_hal_initialize(void)
{
  insert_vsis_hal_sw_get_version();
  insert_vsis_fpga_set_control_reg();
  insert_vsis_fpga_get_control_reg();
  insert_vsis_fpga_arm();
  insert_vsis_fpga_arm_clear();
  insert_vsis_fpga_adc_reload();
  insert_vsis_fpga_adc_reload_clear();
  insert_vsis_fpga_set_status_reg();
  insert_vsis_fpga_get_status_reg();
  insert_vsis_fpga_get_board_id();
  insert_vsis_fpga_get_board_revision();
  insert_vsis_fpga_get_firmware_id();
  insert_vsis_fpga_get_firmware_revision();
  insert_vsis_fpga_qt_get_threshold_plus();
  insert_vsis_fpga_qt_set_threshold_plus();
  insert_vsis_fpga_qt_get_threshold_minus();
  insert_vsis_fpga_qt_set_threshold_minus();
  insert_vsis_fpga_qt_get_bit_state_count();
  insert_vsis_fpga_qt_set_gain();
  insert_vsis_fpga_qt_get_gain();
  insert_vsis_fpga_qt_get_number_samples();
  insert_vsis_fpga_qt_get_enable_table();
  insert_vsis_fpga_qt_set_enable_table();
  insert_vsis_fpga_qt_set_enable_channel();
  insert_vsis_fpga_qt_get_status();
  insert_vsis_fpga_qt_get_control();
  insert_vsis_fpga_qt_set_control();
  insert_vsis_fpga_qt_get_failure();
  insert_vsis_fpga_qt_get_comparator_enable();
  insert_vsis_fpga_qt_set_comparator_enable();
  insert_vsis_fpga_qt_get_state_machine_status();
  insert_vsis_fpga_mk5_get_sync_word();
  insert_vsis_fpga_mk5_set_sync_word();
  insert_vsis_fpga_mk5_get_years();
  insert_vsis_fpga_mk5_set_years();
  insert_vsis_fpga_mk5_get_t_bit();
  insert_vsis_fpga_mk5_set_t_bit();
  insert_vsis_fpga_mk5_get_user_reg();
  insert_vsis_fpga_mk5_set_user_reg();
  insert_vsis_fpga_mk5_get_unassigned_reg();
  insert_vsis_fpga_mk5_set_unassigned_reg();
  insert_vsis_fpga_mk5_get_statemachine_status();
  insert_vsis_fpga_get_channel_select();
  insert_vsis_fpga_set_channel_select();
  insert_vsis_fpga_ild_get_control();
  insert_vsis_fpga_ild_set_control();
  insert_vsis_fpga_ild_get_status();
  insert_vsis_fpga_ild_get_low_state_count();
  insert_vsis_fpga_ild_get_mid_state_count();
  insert_vsis_fpga_ild_get_high_state_count();
  insert_vsis_fpga_ild_get_num_samples();
  insert_vsis_fpga_ild_get_statemachine_status();
  insert_vsis_fpga_10ge_get_local_mac();
  insert_vsis_fpga_10ge_set_local_mac();
  insert_vsis_fpga_10ge_get_local_gw();
  insert_vsis_fpga_10ge_set_local_gw();
  insert_vsis_fpga_10ge_get_local_ip();
  insert_vsis_fpga_10ge_set_local_ip();
  insert_vsis_fpga_10ge_get_buffer_sizes();
  insert_vsis_fpga_10ge_set_buffer_sizes();
  insert_vsis_fpga_10ge_get_valid_ports();
  insert_vsis_fpga_10ge_set_valid_ports();
  insert_vsis_fpga_10ge_get_xaui_status();
  insert_vsis_fpga_10ge_get_phy_config();
  insert_vsis_fpga_10ge_set_phy_config();
  insert_vsis_fpga_set_dot();
  insert_vsis_fpga_get_dot();
}
