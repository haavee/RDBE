/*
 * cmd_parser.h
 *
 *  Created on: Jul 26, 2009
 *      Author: Mikael Taveniku XCube Communication Inc.
 *      License: GPL
 */

#ifndef CMD_PARSER_H_
#define CMD_PARSER_H_


/** Define type definitions for arguments */
#define CMD_PARAM_INT 0
#define CMD_PARAM_UNSIGNED 1
#define CMD_PARAM_LONG 2
#define CMD_PARAM_UNSIGNEDLONG 3
#define CMD_PARAM_STRING 4
#define CMD_PARAM_ACCESSTYPE 5
#define CMD_PARAM_LITERAL 6
#define CMD_PARAM_REAL 7
#define CMD_PARAM_HEX 8
#define CMD_PARAM_INTEGER 9
#define CMD_PARAM_ASCII 10
#define CMD_PARAM_TIME 11

/** Command packet type containing an executable command */
typedef struct cmd_pkt cmd_pkt_t;

/** Command descriptor type describing a command */
typedef struct cmd_desc cmd_desc_t;


/**
 * Internal function to tokenize a string.  This function does not allocate any memory
 * It returns an array of pointers to substrings in the string buffer buf (delimiters removed)
 * Remember to nod deallocate buf, before tokens are used
 * @param buf - null terminated string to tokenize
 * @param tokPtr - the array of tokens to be returned
 * @param maxTokens - maximum number of tokens
 * @return - number of tokens in string or -1 on error
 */
int tokenize_cmd_line(char *buf, char **tokPtr, int maxTokens);

/**
 * Take a command line and match it with a command - if possible
 * @param buf
 * @param bufLen
 * @return - a command package ready to execute or null if error
 */
cmd_pkt_t *parser_get_cmd(char *buf, int bufLen);


/**
 * returns the number of known commands in our command list
 * @return - the number of registered commands
 */
unsigned cmd_get_num_cmd(void);

/**
 * Returns a string containing the usage of the command cmd.
 * @param cmd
 * @return
 */
const char *cmd_get_usage(cmd_desc_t *cmd);

/**
 * Find a command in the command list with name cmdName
 * @param cmdName - the command to search for
 * @return - the command or 0 if not found
 */
cmd_desc_t *cmd_find_cmdName(char *cmdName);

/**
 * Finds (and returns) the command with command number cmdNo.
 * If it doesn't exist return 0
 * @param cmdNo - the command number
 * @return - pointer to the command or 0 if not found
 */
cmd_desc_t *cmd_find_cmdNo(int cmdNo);


/**
 * Execute a given command, this command will allocate memory for the return values
 * The return values will be contained in the retBuf buffer and retLen is the length
 * Caller must deallocate the memory when done.
 * @param cmd
 * @param retBuf - will contain a pointer to the return values
 * @param retLen - will contain the number of bytes in buffer
 * @return - 0 on success
 */
int cmd_execute_cmd(cmd_pkt_t *cmd, void **retBuf, int *retLen);


/**
 * Insert a new command into the list of available commands
 * @param name - string name of the command
 * @param usage - string describing the usage of this command
 * @param nParams - number of parameters for the command
 * @param paramTypes - parameter typed definition
 * @param fun - function to execute command " int fun(int argc, void**argv, void **retBuf, int *retLen);"
 * @return - 0 if successful, negative otherwise
 */
int cmd_insert_cmd_desc(char *name, char *usage, int nParams, int *paramTypes, int (*fun)(int, void**, void **, int*), int cmdType);


/**
 * Return command packet after use
 * @param cmd - pointer to packet to return
 * @return 0 if successful
 */
int parser_free_cmd(cmd_pkt_t *cmd);


/**
 * Internal debug command for command list display
 */
void cmd_print_cmd_list(void);


/** These are the command type parameters for the monitor commands */
#define CMD_MONITOR      0
#define CMD_VSIS_QUERY   1
#define CMD_VSIS_COMMAND 2
#define CMD_VSIS_OTHER   3

/**
 * VSIS get command takes a command line as input and produces a command packet
 * if possible, based on the input line. It assumes the following:
 * the buffer contains one line of input.
 * Input format <keyword><?|=>[parameter list];
 * parameter_list ::= parameter [: parameter_list]
 * parameter ::= <STRING> <INTEGER> <LITERAL> <REAL>
 * notes: white space is removed unless they are in a string.
 * strings are market by " or ' and can have escaped \" or \' in them
 * @param cmdPkt - if parsing is successful this will point to a filled in command structure
 * @param buf - assumes that we have a command in the buffer
 * @param bufLen - length of the "valid" characters in the buffer.
 * @return an error code
 */
int vsis_get_command(cmd_pkt_t **cmd, char *buf, int bufLen);



/**
 * Defines for VSIS Return Codes
 * Returned from command or parser execution
 */
#define VSIS_RET_SUCCESS 0
#define VSIS_RET_INITIATED 1
#define VSIS_RET_NOT_IMPLEMENTED 2
#define VSIS_RET_SYNTAX_ERROR 3
#define VSIS_RET_EXECUTION_ERROR 4
#define VSIS_RET_UNABLE 5
#define VSIS_RET_INCONSISTENT 6
#define VSIS_RET_UNKNOWN 7
#define VSIS_RET_PARAMETER_ERROR 8
#define VSIS_RET_UNDEFINED_STATE 9

/**
 * Get a string representation of a VSIS return code
 */
char *vsis_ret_code_2_str(int retCode);


#endif /* CMD_PARSER_H_ */
