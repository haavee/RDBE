/*
 * rdbe_emulate.h
 *
 *  Created on: Jul 29, 2009
 *      Author: micke
 */

#ifndef RDBE_EMULATE_H_
#define RDBE_EMULATE_H_

/**
 * Create a emulated rdbe device for testing.
 * This function replaces ioctl for rdbe_dev
 * @param devNo
 * @param cmdNo
 * @param arg
 * @return
 */
int rdbe_emulate_ioctl(int devNo, int cmdNo, char *arg);



#endif /* RDBE_EMULATE_H_ */
