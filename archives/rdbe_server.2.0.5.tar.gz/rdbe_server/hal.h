/*
 * hal.h
 * Simple abstraction of FPGA processing layer
 *  Created on: Sep 24, 2009
 *      Author: Mikael Taveniku XCube Communication Inc.
 */

#ifndef HAL_H_
#define HAL_H_

#define HAL_VERSION_MAJOR 0
#define HAL_VERSION_MINOR 1
#define HAL_DESCRIPTION "HAL version 1.0 PFB"
#define HAL_RDBE_HOME   "/home/roach/personalities/"

/**
 * Utility functions
 */


/**
 * Convert a double floating point number to a decimal number with nBits significant bits
 * and with the decimal point in bit-position dotPos.
 * The output number will be padded with 0 in the LSB part of the number
 * The routine will do best effort to convert the double to a valid fractional representation
 * and will convert it to maximum allowed value if the input is out of bounds.
 * @param num - return value 0 on errors, otherwise a 32-bit integer representing the double
 * @param nBits - Number of valid bits in the Number [1..32]
 * @param dotPos - Position of the decimal point [0..31]
 * @param dbl - the number to convert
 * @return - 0 on success
 */
int lsb_pad_dbl2frac(long *num, unsigned nBits, unsigned dotPos, double dbl );


/**
 * Convert a fractional number, represented in a 32 bit word to a double precision floating point
 * the input number is padded with 0 at the LSB portion of the number
 * The routine returns 0 on success or an error code otherwise
 * @param dbl - the return value
 * @param num - the input fractional
 * @param nBits - the number of significant bits (0 .. 32)
 * @param dotPos - the position of the decimal point 0 .. 31
 * @return 0 on success
 */
int lsb_pad_frac2dbl(double *dbl, long num, unsigned nBits, unsigned dotPos );

/**
 * Convert a double floating point number to a decimal number with nBits significant bits
 * and with the decimal point in bit-position dotPos.
 * The routine will do best effort to convert the double to a valid fractional representation
 * and will convert it to maximum allowed value if the input is out of bounds.
 * @param num - return value 0 on errors, otherwise a 32-bit integer representing the double
 * @param nBits - Number of valid bits in the Number [1..32]
 * @param dotPos - Position of the decimal point [0..31]
 * @param dbl - the number to convert
 * @return - 0 on success
 */
int dbl2frac(long *num, unsigned nBits, unsigned dotPos, double dbl );


/**
 * Convert a fractional number, represented in a 32 bit word to a double precision floating point
 * The routine returns 0 on success or an error code otherwise
 * @param dbl - the return value
 * @param num - the input fractional
 * @param nBits - the number of significant bits (0 .. 32)
 * @param dotPos - the position of the decimal point 0 .. 31
 * @return 0 on success
 */
int frac2dbl(double *dbl, long num, unsigned nBits, unsigned dotPos );


/**
 * Get the HAL software version and description
 * @param major - return parameter
 * @param minor - return parameter
 * @param description - textual version of version
 * @return - 0 on success
 */
int hal_sw_get_version(int *major, int *minor, char **description);

/*
 * FPGA hardware access functions based on Interface Command Document for VLBI Roach design
 */

/*
 * Top Level Control  Registers
 */
/**
 * Set the value of fpga control register regNo [0..3]
 * @param regNo - the register to access
 * @param value - the value to set
 * @return - 0 if successful
 */
int fpga_set_control_reg( int regNo, unsigned short value);

/**
 * Read the value of a specific control register, return it in value
 * @param regNo - the register to read [0..3]
 * @param value - return value of the function
 * @return - 0 if success
 */
int fpga_get_control_reg( int regNo, unsigned short *value);

/* --------------------------------------------------------------------------------------------------------
 * Bit field definitions for control register 0
 * Bit 0 – Arm – synchronizes to the external 1 pps.
 * Bit 1 – adc 3 wire reload, reloads the control data for to the ADC.
 * Bit 2 – ctrl reset, reset to the ADC board.
 * Bit 3 – Enable FIR filter 1, enable the FIR filter module
 * Bit 4 – Enable FFT, enables the FFT module
 * Bit 5 – dcm reset. Resets the DCM use to for managing the ADC clock.
 * Bit 6 – Enable Interpolator, enables the Interpolator module
 * Bit 7 – Enable Mk5BInterface,  enables the Mk5B interface module
 * --------------------------------------------------------------------------------------------------------
 */

/**
 * Arm the fpga, -- synchronize on next 1pps
 * @return - 0
 */
int fpga_arm(void);

/**
 * clear fpga arm flag
 * @return - 0 on success
 */
int fpga_arm_clear(void);

/**
 * reload ADC control registers
 * @return
 */
int fpga_adc_reload(void);


/**
 * Clear ADC reload flag
 * @return - 0 on success
 */
int fpga_adc_reload_clear(void);

/**
 * Reset the ADC block
 * @return - 0 on success
 */
int fpga_adc_reset(void);

/**
 * Clear ADC reset flag
 * @return
 */
int fpga_adc_reset_clear(void);

/**
 * Enable the FIR filter block
 * @return - 0 on success
 */
int fpga_fir_enable(void);

/**
 * Disable FIR filter block
 * @return - 0 on success
 */
int fpga_fir_disable(void);

/**
 * Enable the FFT block
 * @return - 0 on success
 */
int fpga_fft_enable(void);

/**
 * Disable FFT block
 * @return
 */
int fpga_fft_disable(void);

/**
 * Reset the DCM
 * @return
 */
int fpga_dcm_reset(void);

/**
 * Clear reset flag for DCM
 * @return
 */
int fpga_dcm_reset_clear(void);

/**
 * Enable the Interpolator block
 * @return
 */
int fpga_interpolator_enable(void);

/**
 * Disable interpolator block
 * @return
 */
int fpga_interpolator_disable(void);
/**
 * Enable the MK5 Interface
 * @return - 0 on success
 */
int fpga_mk5_enable(void);

/**
 * Disable MK5 Interface
 * @return - 0 on success
 */
int fpga_mk5_disable(void);

/**
 * Write the value to the status register regNo [0..3] (most of the time this will fail)
 * @param regNo - the status register to set
 * @param value - the value to write
 * @return - 0 if successful
 */
int fpga_set_status_reg( int regNo, unsigned short value);

/**
 * Read the status register defined by regNo [0..3], and return it in value
 * @param regNo - the register to read
 * @param value - a place to put the returned value in
 * @return - 0 if successful
 */
int fpga_get_status_reg( int regNo, unsigned short *value);

/* ----------------------------------------------------------------------------------------------------
 *  System Registers starting at address 0x0000 in the FPGA
 * ---------------------------------------------------------------------------------------------------
 */

/**
 * Read the board id, return it in the value
 * @param value - return value
 * @return 0 if successful
 */
int fpga_get_board_id(unsigned short *value);

/**
 * set the board id to value (will always fail)
 * @param value - the board id to set
 * @return 0 if successful
 */
int fpga_set_board_id(unsigned short value);

/**
 * read the board revision id's
 * @param rev_major - return parameter
 * @param rev_minor - return parameter
 * @param rev_rcs - return parameter
 * @return - 0 if successful
 */
int fpga_get_board_revision(unsigned short *rev_major, unsigned short *rev_minor, unsigned short *rev_rcs);

/**
 * Set the board revision ID -- will always fail
 * @param rev_major
 * @param rev_minor
 * @param rev_rcs
 * @return - 0 if successful
 */
int fpga_set_board_revision( unsigned short rev_major, unsigned short rev_minor, unsigned short rev_rcs);

/**
 * Get the firmware id
 * @param id - return parameter
 * @return - 0 if successful
 */
int fpga_get_firmware_id( unsigned short *id);

/**
 * Set the firmware register to id, will always fail
 * @param id - the id to set
 * @return - 0 if successful
 */
int fpga_set_firmware_id( unsigned short id);

/**
 * Read the firmware version information
 * @param rev_major - return value
 * @param rev_minor - return value
 * @param rev_rcs - return value
 * @return - 0 if successful
 */
int fpga_get_firmware_revision(unsigned short *rev_major, unsigned short *rev_minor, unsigned short *rev_rcs);

/**
 * Set the firmware version numbers -- will always fail
 * @param rev_major
 * @param rev_minor
 * @param rev_rcs
 * @return - 0 if successful
 */
int fpga_set_firmware_revision(unsigned short rev_major, unsigned short rev_minor, unsigned short rev_rcs);


/* ---------------------------------------------------------------------------------------------------------
 *
 * Interrupt control registers and utility functions for them
 *
 * ---------------------------------------------------------------------------------------------------------
 */


/**
 * Enable a specific interrupt 0 .. 7
 * @param irqN - interrupt number 0 .. 7
 * @return 0 on success, or negative error code
 */
int fpga_isr_enable(unsigned short irqN);

/**
 * Enable all Interrupts (FPGA)
 * @return 0 on success, else negative error code
 */
int fpga_isr_enable_all(void);

/**
 * Disable a FPGA interrupt
 * @param irqN - the interrupt 0..7 to disable
 */
int fpga_isr_disable(unsigned short irqN);
/**
 * Disable all FPGA interrupts
 * @return 0 on success, negative error code
 */
int fpga_isr_disable_all(void);

/**
 * Calls the FPGA IOCTL routine to wait for an interrupt
 * @return 0 on success
 */
int fpga_isr_rd(void);



/* ----------------------------------------------------------------------------------------------------------
 * Quantizer Block and Registers
 *
 *
 * Threshold setting registers for each channel are 25 bits wide in the FPGA design
 * For computational purposes, When these same registers are read out by the PPC the 25 bit values are placed
 * into two 16 bit wide registers with the zero padding on the lower 7 bits to preserve the sign of the value.
 * This implies that the PPC must read two memory locations and shift the contents by 7 places to the right to
 * form the correct value. These are signed fixed point values (15,-16) as represented in a 32 bit register.
 * Read only for now. But should implement the routines to do the writes also.
 * ----------------------------------------------------------------------------------------------------------
 */

/**
 * Get Quantizer threshold value as 25bit integer sign extended to 32 bits
 * The value is a "real" with the lower 20 bits as fraction
 * @param intFreq - IF [0 or 1]
 * @param channel - Channel [0 .. 15]
 * @param value - the return value
 * @return - 0 on success
 */
int fpga_qt_get_threshold_plus(int intFreq, int channel, long int *value);

/**
 * Set Quantizer threshold value as 25bit integer sign extended to 32 bits
 * The value is a "real" with the lower 20 bits as fraction
 * @param intFreq - IF [0 or 1]
 * @param channel - Channel [0 .. 15]
 * @param value - the value to set (only low 25 bits are valid
 * @return - 0 on success
 */
int fpga_qt_set_threshold_plus(int intFreq, int channel, long int value);


/**
 * Get Quantizer threshold MINUS value as 25bit integer sign extended to 32 bits
 * The value is a "real" with the lower 20 bits as fraction
 * @param intFreq - IF [0 or 1]
 * @param channel - Channel [0 .. 15]
 * @param value - the return value
 * @return - 0 on success
 */
int fpga_qt_get_threshold_minus(int intFreq, int channel, long int *value);

/**
 * Set Quantizer threshold MINUS value as 25bit integer sign extended to 32 bits
 * The value is a "real" with the lower 20 bits as fraction
 * @param intFreq - IF [0 or 1]
 * @param channel - Channel [0 .. 15]
 * @param value - the value to set (only low 25 bits are valid
 * @return - 0 on success
 */
int fpga_qt_set_threshold_minus(int intFreq, int channel, long int value);


/*
 * In order to re-quantize the data some state statistics need to be collected for each channel.
 * These are the number of states counts (high/low) over a given period of time.
 * Only the low bit count is provided since the high count can be calculated by knowing the number of samples
 * and low bit count. . These are unsigned 16 bit values. Read only.
 */

/**
 * Get the bit state count for IF and Channel
 * unsigned 16 bit number
 * @param intFreq - IF [0..1]
 * @param channel - Channel [0..15]
 * @param value - return value
 * @return - 0 on success
 */
int fpga_qt_get_bit_state_count(int intFreq, int channel, unsigned short *value);

/**
 * Set the bit state count for IF and Channel
 * unsigned 16 bit number
 * @param intFreq - IF [0..1]
 * @param channel - Channel [0..15]
 * @param value - return value
 * @return - 0 on success
 */
int fpga_qt_set_bit_state_count(int intFreq, int channel, unsigned short value);

/*
 * Gain setting registers for each channel are 25 bits wide in the FPGA design
 * For computational purposes, When these same registers are read out by the PPC the 25 bit values are placed
 *  into two 16 bit wide registers with the zero padding on the lower 7 bits to preserve the sign of the value.
 *  This implies that the PPC must read two memory locations and shift the contents by 7 places to the right
 *  to form the correct value. .
 *  These are signed fixed point values (15,-16) as represented in a 32 bit register. Read only.
 */

/**
 * Get the quantizer gain value
 * This is an signed fractional int with first 20 bits as fraction
 * @param intFreq - IF [0..1]
 * @param channel - Channel [0..31]
 * @param value - return value
 * @return - 0 on success
 */
int fpga_qt_get_gain(int intFreq, int channel, long int *value);

/**
 * Set the quantizer gain value
 * This is an signed fractional int with first 20 bits as fraction
 * @param intFreq - IF [0..1]
 * @param channel - Channel [0..31]
 * @param value - Gain setting, only first 25 bits are valid
 * @return - 0 on success
 */
int fpga_qt_set_gain(int intFreq, int channel, long int value);

/* Added for the DDC quantizer */

int fpga_ddc_qt_set_hold(short value);
int fpga_ddc_qt_get_hold(short *value);

int fpga_ddc_qt_get_threshold_plus(int channel, short *value);
int fpga_ddc_qt_set_threshold_plus(int channel, short value);
int fpga_ddc_qt_get_threshold_minus(int channel, short *value);
int fpga_ddc_qt_set_threshold_minus(int channel, short value);

int fpga_ddc_qt_set_threshold_zero(int channel, short value);
int fpga_ddc_qt_get_threshold_zero(int channel, short *value);

int fpga_ddc_qt_get_count_lo_state00(int channel, unsigned short * count);
int fpga_ddc_qt_get_count_lo_state01(int channel, unsigned short * count);
int fpga_ddc_qt_get_count_lo_state10(int channel, unsigned short * count);
int fpga_ddc_qt_get_count_lo_state11(int channel, unsigned short * count);

int fpga_ddc_qt_get_count_hi_state00(int channel, unsigned short * count);
int fpga_ddc_qt_get_count_hi_state01(int channel, unsigned short * count);
int fpga_ddc_qt_get_count_hi_state10(int channel, unsigned short * count);
int fpga_ddc_qt_get_count_hi_state11(int channel, unsigned short * count);
/* ---------------------------------------------------------------------------------------------------------
 * These are the other registers.
 * ----------------------------------------------------------------------------------------------------------
 */

/**
 * Get the total number of samples collected for state count statistics
 * @param value - number of samples collected
 * @return - 0 on success
 */
int fpga_qt_get_number_samples(unsigned long *value);

/**
 * Write the bit mask 32 bits to enable(1) or disable(0) each quantizer channel
 * @param channels - [0..31 bits]
 * @return - 0 on success
 */
int fpga_qt_set_enable_table(unsigned long channels);

/**
 * Get the current value of which channels are enabled
 * @param channels - bit-field with 0..31 bits
 * @return - 0 on success
 */
int fpga_qt_get_enable_table(unsigned long *channels);

/**
 * Disable a specific quantizer channel
 * @param channel - [0..31]
 * @return - 0 on success
 */
int fpga_qt_disable_channel(int channel);

/**
 * Enable a specific quantizer channel
 * @param channel - [0..31]
 * @return - 0 on success
 */
int fpga_qt_enable_channel(int channel);

/**
 * Get the quantizer status register value
 * (1)indicates that the corresponding channel quantization levels have been calculated.
 * @param status - the returned status value
 * @return - 0 on success
 */
int fpga_qt_get_status(unsigned long *status);

/**
 * Write value to quantizer status register -- will always fail
 * (1)indicates that the corresponding channel quantization levels have been calculated.
 * @param status - the value to write
 * @return - 0 on success
 */
int fpga_qt_set_status(unsigned long status);

/**
 * Write the value to quantizer control register
 * @param value - the value to set [0 disable, 1 enable]
 * @return - 0 on success
 */
int fpga_qt_set_control(unsigned short value);

/**
 * Get the quantizer control register value
 * @param value - return parameter [0 disabled, 1 enabled]
 * @return - 0 on success
 */
int fpga_qt_get_control(unsigned short *value);

/**
 * Get the quantizer failure register values
 * Quantizer Failure Resister indicates that the corresponding channel quantization levels have
 * been calculated and did not meet the set criteria.
 * @param value - the value bit-field 0..31
 * @return - 0 on success
 */
int fpga_qt_get_failure(unsigned long *value);

/**
 * Write a failure pattern to the quantizer failure register
 * Quantizer Failure Resister indicates that the corresponding channel quantization levels have
 * been calculated and did not meet the set criteria.
 * @param value - bit-field 0..31
 * @return - 0 on success
 */
int fpga_qt_set_failure(unsigned long value);

/**
 * Comparator Enable Table Register is a 32 bit register. When a bit is set the corresponding
 * channels comparators are enabled.
 * @param value - the value bit-field 0..31
 * @return - 0 on success
 */
int fpga_qt_get_comparator_enable(unsigned long *value);

/**
 * Comparator Enable Table Register is a 32 bit register. When a bit is set the corresponding
 * channels comparators are enabled.
 * @param value - bit-field 0..31
 * @return - 0 on success
 */
int fpga_qt_set_comparator_enable(unsigned long value);

/**
 * Get the quantizer state machine status
 * @param value -
 * @return - 0 on success
 */
int fpga_qt_get_state_machine_status(unsigned short *value);

/**
 * Set the quantizer state machine status
 * @param value -
 * @return - 0 on success
 */
int fpga_qt_set_initial(void);


/**
 * Set the quantizer state machine status
 * @param value -
 * @return - 0 on success
 */
int fpga_qt_set_requantize(void);


/* ----------------------------------------------------------------------------------------------------------
 * Mark V B Interface
 *----------------------------------------------------------------------------------------------------------
 */

/**
 * Get the sync word from MKV
 * @param value - return value
 * @return 0 on success
 */
int fpga_mk5_get_sync_word(unsigned long *value);

/**
 * Set the MKV sync word
 * @param value - value to write
 * @return - 0 on success
 */
int fpga_mk5_set_sync_word(unsigned long value);

/**
 * Get the number of years from 2000
 * @param value - return value
 * @return - 0 on success
 */
int fpga_mk5_get_years(unsigned short *value);

/**
 * Set the number of years from 2000
 * @param value - return value
 * @return - 0 on success
 */
int fpga_mk5_set_years(unsigned short value);

/**
 * Set the T-Bit (only bit 0 is valid)
 * @param value - [0..1]
 * @return - 0 on success
 */
int fpga_mk5_set_t_bit(unsigned short value);

/**
 * Get the T-Bit (only bit 0 is valid)
 * @param value - [0..1]
 * @return - 0 on success
 */
int fpga_mk5_get_t_bit(unsigned short *value);

/**
 * Set the user specified register value (12 bit)
 * @param value - the value to set
 * @return - 0 on success
 */
int fpga_mk5_set_user_reg(unsigned short value);

/**
 * Get the current user register value
 * @param value - return parameter (12 bit)
 * @return - 0 on success
 */
int fpga_mk5_get_user_reg(unsigned short *value);

/**
 * Set the 32 bits of the unassigned register value
 * @param value - the value bits 0..31
 * @return - 0 on success
 */
int fpga_mk5_set_unassigned_reg(unsigned long value);


/**
 * Get the 32 bits of the unassigned register value
 * @param value - the returned value bits 0..31
 * @return - 0 on success
 */
int fpga_mk5_get_unassigned_reg(unsigned long *value);

/**
 * Get mark5 state machine status
 * @param value -
 * @return - 0 on success
 */
int fpga_mk5_get_state_machine_status(unsigned short *value);

/**
 * Set the output channel [0..15] to take input from inputChannel [0..31]
 * Coded with IF0 = [0..15] and IF1 [16..31]
 * @param ouputChannel - the output channel 0 .. 15
 * @param inputChannel - the input channel 0..31
 * @return - 0 on success
 */
int fpga_set_channel_select(unsigned short outputChannel, unsigned short inputChannel);

/**
 * Get the input channel [0..31] that the output channel [0..15] to take input from
 * Coded with IF0 = [0..15] and IF1 [16..31]/
 * @param ouputChannel - the output channel 0 .. 15
 * @param inputChannel - the input channel 0..31
 * @return - 0 on success
 */
int fpga_get_channel_select(unsigned short outputChannel, unsigned short *inputChannel);


/* ----------------------------------------------------------------------------------------------------------
 *  Optimal Input Level Detector Registers
 */

/**
 * Get input level detector control value
 * @param value - the control register value
 * @return - 0 on success
 */
int fpga_ild_get_control(unsigned short *value);


/**
 * Set the input level control register to value
 * @param value - the value to write
 * @return - 0 on success
 */
int fpga_ild_set_control(unsigned short value);


/**
 * Get the input level detector status
 * @param status - returned value
 * @return - 0 on success
 */
int fpga_ild_get_status(unsigned short *status);

/**
 * Set the input level detector status
 * @param status - status to set
 * @return - 0 on success
 */
int fpga_ild_set_status(unsigned short status);


/**
 * Get the state count
 * @param cnt - returned value
 * @return - 0 on success
 */
int fpga_ild_get_low_state_count(unsigned short *cnt);

/**
 * Set the state count
 * @param cnt - value to set
 * @return - 0 on success
 */
int fpga_ild_set_low_state_count(unsigned short cnt);

/**
 * Get the state count
 * @param cnt - returned value
 * @return - 0 on success
 */
int fpga_ild_get_mid_state_count(unsigned short *cnt);

/**
 * Set the state count
 * @param cnt - value to set
 * @return - 0 on success
 */
int fpga_ild_set_mid_state_count(unsigned short cnt);

/**
 * Get the state count
 * @param cnt - returned value
 * @return - 0 on success
 */
int fpga_ild_get_high_state_count(unsigned short *cnt);

/**
 * Set the state count
 * @param cnt - value to set
 * @return - 0 on success
 */
int fpga_ild_set_high_state_count(unsigned short cnt);

/**
 * Get the Input Level Detector number of samples
 * @param cnt - returned value
 * @return - 0 on success
 */
int fpga_ild_get_num_samples(unsigned short *cnt);

/**
 * Set the Input Level Detector number of samples
 * @param cnt - number of samples
 * @return - 0 on success
 */
int fpga_ild_set_num_samples(unsigned short cnt);

/**
 * Get the Input Level Detector state machine status
 * @param status - returned value
 * @return - 0 on success
 */
int fpga_ild_get_state_machine_status(unsigned short *status);

/* --------------------------------------------------------------------------------------------- */
/* 10Gigabit Ethernet functions                                                                  */
/* --------------------------------------------------------------------------------------------- */

/**
 * Set the local MAC address for the 10GE port
 * @param port - Ethernet port [0..3]
 * @param mac - array of 6 bytes LE format [00:01:02:03:...] = 00:02:02 ..
 * @return - 0 on success
 */
int fpga_10ge_set_local_mac(unsigned port, unsigned char *mac);

/**
 * Get the local MAC address for the 10GE port
 * @param port - Ethernet port [0..3]
 * @param mac - return value - array of 6 bytes LE format [00:01:02:03:...] = 00:02:02 ..
 * @return - 0 on success
 */
int fpga_10ge_get_local_mac(unsigned port, unsigned char *mac);

/**
 * Set the local IP address for the 10GE port
 * @param port - Ethernet port [0..3]
 * @param ip - 1 byte LE format [192, 168, 0,1] = 1
 * @return - 0 on success
 */
int fpga_10ge_set_local_gw(unsigned port, unsigned char ip);

/**
 * Get the local Gateway address for the 10GE port
 * @param port - Ethernet port [0..3]
 * @param ip - return value - 1 byte with end of ip 192.168.0.1 returns "1"
 * @return - 0 on success
 */
int fpga_10ge_get_local_gw(unsigned port, unsigned char *ip);

/**
 * Set the local Gateway address for the 10GE port
 * @param port - Ethernet port [0..3]
 * @param ip - 1 bytes 192.168.0.1 then ip should be [192,168,0,1]
 * @return - 0 on success
 */
int fpga_10ge_set_local_ip(unsigned port, unsigned long *ip);

/**
 * Get the local IP address for the 10GE port
 * @param port - Ethernet port [0..3]
 * @param ip - return value - array of 4 bytes LE format [192, 168, 0,1] = 192.168.0.1
 * @return - 0 on success
 */
int fpga_10ge_get_local_ip(unsigned port, unsigned long *ip);

/**
 * Set the buffer size value for the RX/TX buffer
 * @param port - Ethernet port
 * @param sz - size of buffer (valid data in the buffer)
 * @return - 0 on success
 */
int fpga_10ge_set_buffer_sizes(unsigned port, unsigned short sz);

/**
 * Read the value of valid data in receive buffer
 * @param port - Ethernet port
 * @param sz - valid number of bytes
 * @return - 0 on success
 */
int fpga_10ge_get_buffer_sizes(unsigned port, unsigned short *sz);

/**
 * TODO:
 * @param port
 * @param ports
 * @return
 */
int fpga_10ge_set_valid_ports(unsigned port, unsigned short ports);

/**
 * TODO:
 * @param port
 * @param ports
 * @return
 */
int fpga_10ge_get_valid_ports(unsigned port, unsigned short *ports);

/**
 * Read the status register of the XILINX XAUI
 * @param port - the port to read
 * @param status - see XILINX documentation
 * @return - 0 n success
 */
int fpga_10ge_get_xaui_status(unsigned port, unsigned short *status);

/**
 * TODO:
 * @param port
 * @param config
 * @return
 */
int fpga_10ge_set_phy_config(unsigned port, unsigned short config);

/**
 * TODO:
 * @param port
 * @param config
 * @return
 */
int fpga_10ge_get_phy_config(unsigned port, unsigned short *config);

/**
 * Write bytes to the TX buffer on port
 * @param port - the port to write to
 * @param buf - array of bytes to write (2k always)
 * @return - 0 on success
 */
int fpga_10ge_set_tx_buffer(unsigned port, unsigned char *buf);

/**
 * Read data from TX buffer on port
 * @param port - the port to read from
 * @param buf - return array of bytes from buffer (user must allocate 2k)
 * @return - 0 on success
 */
int fpga_10ge_get_tx_buffer(unsigned port, unsigned char *buf);

/**
 * Write bytes to the RX buffer on port
 * @param port - the port to write to (2k always)
 * @param buf - array of bytes to write
 * @return - 0 on success
 */
int fpga_10ge_set_rx_buffer(unsigned port, unsigned char *buf);

/**
 * Write bytes to the TX buffer on port
 * @param port - the port to write to
 * @param buf - return - array of bytes to write 2k user must allocate
 * @return - 0 on success
 */
int fpga_10ge_get_rx_buffer(unsigned port, unsigned char *buf);

/**
 * Write a full APR cahce table to FPGA port
 * @param port - the port [0..3]
 * @param arp_table - 128 entries of 6 bytes each in LE format
 * @return - 0 on success
 */
int fpga_10ge_set_arp_cache(unsigned port, unsigned char *arp_table);

/**
 * Write a full APR cahce table to FPGA port
 * User must allocate return buffer
 * @param port - the port [0..3]
 * @param arp_table - (return value) 128 entries of 6 bytes each in LE format
 * @return - 0 on success
 */
int fpga_10ge_get_arp_cache(unsigned port, unsigned char *arp_table);

/**
 * Get the arp table entry for port, and ip with ending number pos
 * User must allocate return value
 * @param port - Ethernet port [0..3]
 * @param pos - Ending IP address [0..127]
 * @param mac - return value - 6 bytes LE array of byte
 * @return - 0 on success
 */
int fpga_10ge_get_arp_value(unsigned port, unsigned char pos, unsigned char *mac);

/**
 * Set the arp table entry for port, and ip with ending number pos
 * @param port - Ethernet port [0..3]
 * @param pos - Ending IP address [0..127]
 * @param mac - 6 bytes LE array of byte
 * @return - 0 on success
 */
int fpga_10ge_set_arp_value(unsigned port, unsigned char pos, unsigned char *mac);

/**
 * Set the Maximum MTU size for the port
 * @param port 0 .. 3
 * @param mtu - only 90000 allowed
 * @return - 0 on success
 */
int fpga_10ge_set_if_mtu(unsigned port, unsigned short mtu);

/**
 * Get the current Max MTU size for port
 * @param port 0..3
 * @param mtu -- return value MTU
 * @return 0 on success
 */
int fpga_10ge_get_if_mtu(unsigned port, unsigned short *mtu);

/**
 * Set the interface mode to
 * @param port interface 0 .. 3
 * @param mode (2 or 4)
 * @return 0 on success
 */
int fpga_10ge_set_if_mode(unsigned port, unsigned char mode);

/**
 * Get the interface mode
 * @param port Interface 0 .. 3
 * @param mode - return value [2|4]
 * @return 0 always success
 */
int fpga_10ge_get_if_mode(unsigned port, unsigned char *mode);

/**
 * Set the Julian time value in the FPGA
 * @param dot the Julian time
 * @return 0
 */
int fpga_set_dot(unsigned long dot);

/**
 * Read the Julian time value from the FPGA
 * @param dot the Julian time as read from the FPGA
 * @return 0
 */
int fpga_get_dot(unsigned long *dot);


/* ****************************************************************************
 *
 *            Data Transfer Module Registers
 *
 * ****************************************************************************
 */


/**
 * Set the Data Transfer Module Control register bits
 * @param ctl : control data to write
 * @return 0 - on success
 */
int fpga_dtm_set_control(unsigned short ctl);

/**
 * Read the Data Transfer Module control register
 * @param ctl : the control register value
 * @return 0 on success
 */
int fpga_dtm_get_control(unsigned short *ctl);

/**
 * Get the Data Transfer Module Status register bits
 * @param status : the status register contents
 * @return 0 - on success
 */
int fpga_dtm_get_status(unsigned short *status);

/**
 * Set the time to start and time to stop capture in the DTM module
 * @param slotNo - position in the DTM shall be 1 .. 16 (currently only 1 allowed)
 * @param tOn - 32 bit Julian time
 * @param tOff - 32 bit Julian time
 * @return - 0 on success
 */
int fpga_dtm_set_timeslot(unsigned slotNo, unsigned long tOn, unsigned long tOff);

/**
 * Get the time to start and time to stop capture in the DTM module
 * @param slotNo - position in the DTM shall be 1 .. 16 (currelnty only 1 allowed)
 * @param tOn - 32 bit Julian time
 * @param tOff - 32 bit Julian time
 * @return - 0 on success
 */
int fpga_dtm_get_timeslot(unsigned slotNo, unsigned long *tOn, unsigned long *tOff);

/**
 * Set the time to stop capture in the DTM module
 * @param slotNo - position in the DTM shall be 1 .. 16(currently only 1 slot)
 * @param tOff - 32 bit Julian time
 * @return - 0 on success
 */
int fpga_dtm_set_timeslot_end(unsigned slotNo, unsigned long tOff);

/* ****************************************************************************
 *
 *            ALC/Frequency Synthesizer Module
 *
 * ****************************************************************************
 */

/**
 * Set the ALC Control register bits
 * @param ctl : control data to write
 * @return 0 - on success
 */
int fpga_alc_set_control(unsigned short ctl);


int fpga_fs_set_control(unsigned short ctl);

/**
 * Read  the ALC Control register bits
 * @param ctl : control data to read
 * @return 0 - on success
 */
int fpga_alc_get_control(unsigned short *ctl);


/**
 * Read the ALC FPGA version register
 * @param ver : the ALC FPGA version value
 * @return 0 on success
 */
int fpga_alc_get_ver(unsigned short *ver);


/**
 * Read the ALC PPS Status Register
 * @param status: the ALC PPS Status.
 * @return 0 on success
 */
int fpga_alc_get_pps_status(unsigned short *status);

/**
 * Read the ALC PPS Status Register
 * @param status: the ALC PPS Sync Status.
 * @return 0 on success
 */
int fpga_alc_get_sync_status(unsigned int *status);


/**
 * used to read data  for ALC capture and other.
 */

int fpga_alc_capture(unsigned long offset, unsigned short *data);

/**
 * Handshaking with the ALC to exchange log data.
 * @param offset - the offset for capture
 * @param cmd - the command to send
 * @return always 0
 */
int fpga_alc_capture_cmd(unsigned long offset, unsigned short cmd);

int fpga_xbar_set(short cmd[]);
int fpga_xbar_get(short cmd[]);

int fpga_ddc_rate_set(short rate[]);
int fpga_ddc_rate_get(short rate[]);

int fpga_ddc_lo_set(short dc, short rate, unsigned long lofreq);
int fpga_ddc_lo_get(short rate[], unsigned long lofreq[], unsigned long tOn[]);

int fpga_ddc_lo_set_stime(short dc, unsigned long tOn);
int fpga_ddc_lo_get_stime(short dc, unsigned long * tOn);

int fpga_ddc_set_sideband_select(short dc, short stat);
int fpga_ddc_get_sideband_select(short * stat);


/**
 * Set the destination IP address
 * @param ip - unsigned long representation of IP address
 * @return - 0 on success
 */
int fpga_10ge_set_dest_ip(unsigned short *upper, unsigned short *lower);

/**
 * Get the destination IP address
 * @return ip - return value - unsigned long representation of IP
 * @return - 0 on success
 */
int fpga_10ge_get_dest_ip(unsigned short *upper, unsigned short *lower);

/**
 * Set the port control register.
 * @param ctrl -  control word for the destination control register
 * @return - 0 on success
 */
int fpga_10ge_set_local_port_ctrl(unsigned short ctrl);

/**
 * Get the port control register.
 * @return ctrl -  control word for the destination control register
 * @return - 0 on success
 */
int fpga_10ge_get_local_port_ctrl(unsigned short *ctrl);


int fpga_get_tsys_on(int intFreq, int channel, unsigned long *val_low, unsigned long *val_high);
int fpga_get_tsys_off(int intFreq, int channel, unsigned long *val_low, unsigned long *val_high);

int fpga_tsys_diode_set_blanking(unsigned short bt);
int fpga_tsys_diode_set_period(unsigned short dp);
int fpga_tsys_diode_set_control(unsigned short dp, unsigned short bt);
int fpga_tsys_diode_get_control(unsigned short *da, unsigned short *db, 
				unsigned short *bt, unsigned long *accum_on, 
				unsigned long *accum_off);


int fpga_ddc_tsys_get_power_tsys_off(short chan, unsigned long long * val);
int fpga_ddc_tsys_get_power_tsys_on(short chan, unsigned long long * val);
int fpga_ddc_tsys_get_voltage_tsys_off(short chan, long long * val);
int fpga_ddc_tsys_get_voltage_tsys_on(short chan, long long * val);

int fpga_ddc_tsys_get_on_count(unsigned int * count);
int fpga_ddc_tsys_get_off_count(unsigned int * count);

int fpga_ddc_tsys_get_scale(short chan, short *val);
int fpga_ddc_tsys_set_scale(short chan, short val);


int fpga_get_fpga_status(unsigned short * stat);

#define MAX_FILE_NAME_LEN     255
#define PERSONALITY_TYPE_LEN  5

typedef struct
{
  int ifstate; /* 0: down. 1: up */
  int personality_load_status; /* indicates if a personality was successfully loaded into the FPGA */
  char personality_file_name[MAX_FILE_NAME_LEN];
  char personality_type[PERSONALITY_TYPE_LEN];
} rdbe_settings_t;

typedef struct
{
  unsigned char target_board;
  unsigned char c_id;
  unsigned char rev_major_int;
  unsigned char rev_major_frac;
  unsigned char rev_minor;
  unsigned char unused;
  unsigned char p_type;
  unsigned char o_format;
} FPGA_BIN_INFO;

int fpga_get_fpga_binary_info(FPGA_BIN_INFO * fpga_info);

int fpga_ddc_get_vdif_epoch(short * ref_epoch, unsigned long * seconds_from_ref_epoch);
int fpga_ddc_set_vdif_epoch(short * ref_epoch, unsigned long * seconds_from_ref_epoch);
int fpga_ddc_set_vdif_Log2NumChan(short * count);
int fpga_ddc_set_vdif_StationID(short * id);
int fpga_ddc_set_vdif_DBEnum(short * num);

int fpga_ddc_set_vdif_Bits_Per_Sample(short sample[]);

int fpga_ddc_set_vdif_thread_ids(short thids[]);

int fpga_set_1pps_status(unsigned short stat);
int fpga_get_1pps_status(unsigned short * sync_en, unsigned short *stat, unsigned int * delta);

int fpga_write_Adc_reload(unsigned short stat);

#endif /* HAL_H_ */
