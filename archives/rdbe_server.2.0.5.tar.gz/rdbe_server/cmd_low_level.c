/*
 * cmd_low_level.c
 *
 *  Created on: Jul 29, 2009
 *      Author: Mikael Taveniku XCube Communication Inc.
 *      License: GPL
 *      Description: Common VSIS compatible low level commands for the rdbe server understands.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <linux/mman.h> // memory management things
#include <sys/mman.h>   //mmap



#include "rdbe_exports.h"     // device driver information access functions and types
#include "cmd_parser.h"
#include "serv_storage.h"
#include "ioctl_util.h"
#include "hal.h"

extern int serv_rdbe_ioctl(int funNo, char*arg); // defined in server main for now
extern int serv_get_data(int bufNo, unsigned long length);



/**  *****************************************************************************************************
 *   Building VSIS compatible commands
 *
 *   Command format <keyword>[<portNumber]=<param>:<param> ... ;
 *   Parameters can be optional (all listed at the end of the list;
 *   Parameters can be omitted, but then represented as a null pointer in the parameter list
 *   Parameters are position dependent.
 *   It is implementation (of the command) specific in what to do with omitted parameters or defaults
 *
 *   When a command gets called, the parser has made certain that the parameters given are of the correct type (or null)
 *   for the command. The command may return a cmd_parameter_error if the parameters are incorrect
 *
 *   The function shall have a type specifier CMD_VSIS_QUERY, CMD_VSIS_COMMAND, CMD_VSIS_OTHER, CMD_MONITOR
 */




/**
 * Device read command that interface to the IOCTL command of the RDBE driver.
 * This is a function that is intended to be used by the commands that need r/w access to hardware
 * on the device.
 * @param ioctlCmd -
 * @param argc - number of arguments in argv.
 * @param argv - [0]=accessType, [1]=offset, [2]=length
 * @param retVal - buffer containing returned data
 * @param retLen - length of returned data
 * @return - 0 on success
 */
int vsis_dev_rd_cmd(int ioctlCmd, unsigned long accessType, unsigned long offset, unsigned long numWords, void *retBuf)
{
	rdbe_rdwr_cmd_t cmd; // command to send

	cmd.access_type = accessType;
	cmd.len         = numWords;
	cmd.ofs         = offset;
	cmd.buf         = retBuf;

	//printf("\nCalling ioctl with DEV=%d CMD=%d ParPtr=%p, BUFPtr=%p Length=%lu \n", 0, ioctlCmd, &cmd, cmd.buf, cmd.len);
	/* printf("\nCalling ioctl with ofs=%lu, buf=%s len=%lu \n", cmd.ofs, (char*)cmd.buf, cmd.len); */
	serv_rdbe_ioctl(ioctlCmd, (char *)&cmd);

	return VSIS_RET_SUCCESS; // all went well
}

/**
 * swap endiannes on a 16 bit entity
 * @param ptr - pointer to the start of the word
 */
void change_endian_short(void *ptr)
{
	unsigned char tmp;
	tmp = *(unsigned char*)ptr;
	*(unsigned char*)ptr = *(unsigned char*)(ptr+1);
	*(unsigned char*)(ptr+1) = tmp;
}

/**
 * byte reverse a long
 * @param ptr
 */
void change_endian_long(void *ptr)
{
	unsigned char tmp;
	tmp = *(unsigned char*)ptr;
	*(unsigned char*) ptr    = *(unsigned char*)(ptr+3);
	*(unsigned char*)(ptr+3) = tmp;
	tmp = *(unsigned char*)(ptr+1);
	*(unsigned char*)(ptr+1) = *(unsigned char*)(ptr+2);
	*(unsigned char*)(ptr+2) = tmp;
}

/**
 * Read a number of bytes from the FPGA device Maximum 2048 words.
 * @param argc   - should be 3 <access_type> <offset> <number of words of access type>
 * @param argv   - pointers to the parameters
 * @param retVal - buffer with the data (allocated here)
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_fpga_rd_cmd(int argc, void **argv, void **retVal, int *retLen)
{
  int   i;
  int   retCode; //tmp holder of return code
  char dataBuf[8192]; // buffer for our binary data
  char *wrPtr;   // pointer to next end of return buffer while writing to it;

  char *retStart = "!fpga_rd=0"; // beginning of return string
  char *retEnd   = ";\n";       // end of return string

  unsigned long accessType = 2;  // word access
  unsigned long numWords   = 1;  // default number of words
  unsigned long offset     = 0;  // default offset

  /*
   * check the parameters and fill in values from the list if we have any
   * we know here that the list is complete, but may have null entries that
   * shall be filled in with default values
   * or return errors
   */

  // Access type parameter
  if(argv[0] != 0 ) accessType = *(unsigned long*)argv[0];
  /*
   * Example on how we can handle an error with unspecified required parameter
   * this is the offset parameter
   */
  if(argv[1] == 0) {
    sprintf(*retVal, "!fpga_rd=%d:Parameter Error;\n", VSIS_RET_PARAMETER_ERROR);
    *retLen = strlen(*retVal);
    return -VSIS_RET_PARAMETER_ERROR;
  } else {
    offset = *(unsigned long*)argv[1];
  }

  // number of words parameter
  if(argv[2] != 0) numWords = *(unsigned long*)argv[2];
  // check that we dont have buffer overflow
  if(accessType * numWords > 8192) {
	    sprintf(*retVal, "!fpga_rd=%d:Parameter Error too many bytes to read;\n", VSIS_RET_PARAMETER_ERROR);
	    *retLen = strlen(*retVal);
	    return -VSIS_RET_PARAMETER_ERROR;
  }

  /*
   * Execute the function: Get data from FPGA
   */

  // Read data from the FPGA device
  //	retCode = vsis_dev_rd_cmd(RDBE_FPGA_READ, accessType, offset, numWords, dataBuf);
  retCode = util_read_fpga(accessType, offset, numWords, dataBuf);


  if(retCode != 0) {
    sprintf(*retVal, "!fpga_rd=%d:Execution Error;\n", VSIS_RET_EXECUTION_ERROR);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }

  /*
   * Format the return data from a successful return
   */

  // allocate memory for the return data. -- all strings plus the null character
  *retLen = strlen(retStart) + numWords * (2 * accessType + 1) + strlen(retEnd) + 1;

  // write to the buffer
  wrPtr = (char*)*retVal; // get us the start of buffer pointer

  sprintf(wrPtr, "%s", retStart);
  wrPtr += strlen(retStart);
  switch(accessType){
  case 1:
    for(i=0; i<numWords; i++) {
      sprintf(wrPtr,":%02x", (unsigned char)dataBuf[i]);
      wrPtr += 3;
    }
    break;
  case 2:
    for(i=0; i<numWords; i++){
      //			change_endian_short(dataBuf+2*i);
      sprintf(wrPtr,":%04x", *(unsigned short *)(dataBuf + 2*i));
      wrPtr +=5;
    }
    break;
  case 4:
    for(i=0; i<numWords; i++){
      //			change_endian_long(dataBuf+4*i);
      sprintf(wrPtr,":%08lx ", *(unsigned long*)(dataBuf + 4*i));
      wrPtr += 9;
    }
    break;
  default:
    break;
  }
  sprintf(wrPtr, "%s", retEnd);
  wrPtr +=strlen(retEnd);

  return VSIS_RET_SUCCESS; // 0
}


/**
 * Insert the fpga read command into command queue.
 */
void insert_vsis_fpga_rd(void)
{
	char *name = "fpga_rd";
	char *usage= "fpga_rd=<access type>:<offset>:<length>;";
	int nParams = 3;
	int cmdType = CMD_VSIS_COMMAND;
	int paramTypes[3] = {CMD_PARAM_ACCESSTYPE, CMD_PARAM_UNSIGNEDLONG, CMD_PARAM_UNSIGNEDLONG};
	cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_rd_cmd, cmdType);
}



/**
 * Read a number of bytes from the SMAP device
 * @param argc   - should be 3 <access_type> <offset> <number of word of access type>
 * @param argv   - pointers to the parameters
 * @param retVal - buffer with the data (allocated here)
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_smap_rd_cmd(int argc, void **argv, void **retVal, int *retLen)
{
  int   i;
  int   retCode; //tmp holder of return code
  char dataBuf[8196]; // buffer for our binary data
  char *wrPtr;   // pointer to next end of return buffer while writing to it;

  char *retStart = "!smap_rd=0"; // beginning of return string
  char *retEnd   = ";\n";       // end of return string

  unsigned long accessType = 2;  // word access
  unsigned long numWords   = 1;  // default number of words
  unsigned long offset     = 0;  // default offset

  // Access type parameter from input
  if(argv[0] != 0 ) accessType = *(unsigned long*)argv[0];
  // offset parameter
  if(argv[1] == 0) offset = *(unsigned long*)argv[1];
  // number of words parameter
  if(argv[2] != 0) numWords = *(unsigned long*)argv[2];

  if(numWords * accessType > 8196){
	    sprintf(*retVal, "!fpga_rd=%d:Parameter Error too many bytes to read;\n", VSIS_RET_PARAMETER_ERROR);
	    *retLen = strlen(*retVal);
	    return -VSIS_RET_PARAMETER_ERROR;
  }

  // Read data from the device device
  retCode = vsis_dev_rd_cmd(RDBE_SMAP_READ, accessType, offset, numWords, dataBuf);
  if(retCode != 0) {
    sprintf(*retVal, "!smap_rd=%d:Execution Error;\n", VSIS_RET_EXECUTION_ERROR);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }

  /* Format the return data from a successful read  */

  // allocate memory for the return data. -- all strings plus the null character
  *retLen = strlen(retStart) + numWords * (2 * accessType + 1) + strlen(retEnd) + 1;

  // write to the buffer
  wrPtr = (char*)*retVal; // get us the start of buffer pointer

  sprintf(wrPtr, "%s", retStart);
  wrPtr += strlen(retStart);
  switch(accessType){
  case 1:
    for(i=0; i<numWords; i++) {
      sprintf(wrPtr,":%02x", (unsigned char)dataBuf[i]);
      wrPtr += 3;
    }
    break;
  case 2:
    for(i=0; i<numWords; i++){
      sprintf(wrPtr,":%04x", *(unsigned short *)(dataBuf + 2*i));
      wrPtr +=5;
    }
    break;
  case 4:
    for(i=0; i<numWords; i++){
      sprintf(wrPtr,":%08lx ", *(unsigned long*)(dataBuf + 4*i));
      wrPtr += 9;
    }
    break;
  default:
    break;
  }
  sprintf(wrPtr, "%s", retEnd);
  wrPtr +=strlen(retEnd);

  return VSIS_RET_SUCCESS; // 0
}


/**
 * Insert the smap read command into command queue.
 */
void insert_vsis_smap_rd(void)
{
	char *name = "smap_rd";
	char *usage= "smap_rd=<access type>:<offset>:<length>;";
	int nParams = 3;
	int cmdType = CMD_VSIS_COMMAND;
	int paramTypes[3] = {CMD_PARAM_ACCESSTYPE, CMD_PARAM_UNSIGNEDLONG, CMD_PARAM_UNSIGNEDLONG};
	cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_smap_rd_cmd, cmdType);
}

/**
 * Read a number of words from the CPLD device
 * @param argc   - should be 3 <access_type> <offset> <number of byte>
 * @param argv   - pointers to the parameters
 * @param retVal - buffer with the data (allocated here)
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int vsis_cpld_rd_cmd(int argc, void **argv, void **retVal, int *retLen)
{
	int   i;
	int   retCode; //tmp holder of return code
	char  dataBuf[8192]; // buffer for our binary data
	char *wrPtr;   // pointer to next end of return buffer while writing to it;

	char *retStart = "!cpld_rd=0"; // beginning of return string
	char *retEnd   = ";\n";       // end of return string

	unsigned long accessType = 1;  // byte access
	unsigned long numWords   = 1;  // default number of words
	unsigned long offset     = 0;  // default offset

	// Access type parameter
	if(argv[0] != 0 ) accessType = *(unsigned long*)argv[0];
	// offset parameter
	if(argv[1] == 0) offset = *(unsigned long*)argv[1];
	// number of words parameter
	if(argv[2] != 0) numWords = *(unsigned long*)argv[2];

	if(numWords * accessType > 8196){
	    sprintf(*retVal, "!fpga_rd=%d:Parameter Error too many bytes to read;\n", VSIS_RET_PARAMETER_ERROR);
	    *retLen = strlen(*retVal);
	    return -VSIS_RET_PARAMETER_ERROR;
	}

	// Read data from the device device
	retCode = vsis_dev_rd_cmd(RDBE_CPLD_READ, accessType, offset, numWords, dataBuf);
	if(retCode != 0) {
		sprintf(*retVal, "!cpld_rd=%d:Execution Error;\n", VSIS_RET_EXECUTION_ERROR);
		*retLen = strlen(*retVal);
		return -VSIS_RET_EXECUTION_ERROR;
	}

	/* Format the return data from a successful read  */

	// allocate memory for the return data. -- all strings plus the null character
	*retLen = strlen(retStart) + numWords * (2 * accessType + 1) + strlen(retEnd) + 1;

	// write to the buffer
	wrPtr = (char*)*retVal; // get us the start of buffer pointer

	sprintf(wrPtr, "%s", retStart);
	wrPtr += strlen(retStart);
	switch(accessType){
	case 1:
		for(i=0; i<numWords; i++) {
			sprintf(wrPtr,":%02x", (unsigned char)dataBuf[i]);
			wrPtr += 3;
		}
		break;
	case 2:
		for(i=0; i<numWords; i++){
			sprintf(wrPtr,":%04x", *(unsigned short *)(dataBuf + 2*i));
			wrPtr +=5;
		}
		break;
	case 4:
		for(i=0; i<numWords; i++){
			sprintf(wrPtr,":%08lx ", *(unsigned long*)(dataBuf + 4*i));
			wrPtr += 9;
		}
		break;
	default:
		break;
	}
	sprintf(wrPtr, "%s", retEnd);
	wrPtr +=strlen(retEnd);

	return VSIS_RET_SUCCESS; // 0
}


/**
 * Insert the smap read command into command queue.
 */
void insert_vsis_cpld_rd(void)
{
	char *name = "cpld_rd";
	char *usage= "cpld_rd=<access type>:<offset>:<length>;";
	int nParams = 3;
	int cmdType = CMD_VSIS_COMMAND;
	int paramTypes[3] = {CMD_PARAM_ACCESSTYPE, CMD_PARAM_UNSIGNEDLONG, CMD_PARAM_UNSIGNEDLONG};
	cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_cpld_rd_cmd, cmdType);
}


/**
 * Programs the FPGA given a filename pointing to a FPGA bit file
 * @param argc
 * @param argv
 * @param retVal
 * @param retLen
 * @return
 */
int vsis_fpga_prg_cmd(int argc, void **argv, void **retVal, int *retLen)
{
  int inFile;
  int funRet;
  void *bitFilePtr;
  struct stat fileStat;
  rdbe_configure_cmd_t cmdPar;

  funRet = 0; // all ok

  printf("fpga_prg called with %s\n", (char*)argv[0]);

  // open file
  if ((inFile = open((char*)argv[0], O_RDWR))) {
    // get length and map file to virtual memory
    if (fstat(inFile, &fileStat) >= 0) {
      bitFilePtr = mmap(0, fileStat.st_size, (PROT_READ|PROT_WRITE), MAP_SHARED, inFile, 0);
      printf("mapped file %d with length %lu to %p \n", inFile,(unsigned long)fileStat.st_size, bitFilePtr );
      if (bitFilePtr) {
	cmdPar.buf = bitFilePtr;
	cmdPar.len = fileStat.st_size;

	printf(	"\nCall serv_rdbe_ioctl CMD=%d ParPtr=%p, BufPtr=%p Length=%lu \n",RDBE_DEV_CONFIGURE, (void*) &cmdPar, cmdPar.buf, cmdPar.len);
	funRet = serv_rdbe_ioctl(RDBE_DEV_CONFIGURE, (char *) &cmdPar);
      } else {
	printf("Error - could not MMAP file desc %d\n", inFile );
	sprintf(*retVal, "!fpga_prg=%d:Error - could not MMAP file desc %d;\n", VSIS_RET_EXECUTION_ERROR, inFile);
	*retLen = strlen(*retVal);
	return -VSIS_RET_EXECUTION_ERROR;
      }
    } else {
      printf("Could not get file status on %s error\n", (char*)argv[0]);
      sprintf(*retVal, "!fpga_prg=%d:Could not get file status on %s error;\n", VSIS_RET_EXECUTION_ERROR, (char*)argv[0]);
      *retLen = strlen(*retVal);
      return -VSIS_RET_EXECUTION_ERROR;
    }
  } else {
    printf("Failed to open \" %s \" for reading", (char*)argv[0]);
    sprintf(*retVal, "!fpga_prg=%d:Failed to open \"%s\" for reading;\n", VSIS_RET_EXECUTION_ERROR, (char*)argv[0]);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }
  sprintf(*retVal, "!fpga_prg=%d:Programmed with %s ;\n", VSIS_RET_SUCCESS, (char*)argv[0]);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS;
}


void insert_vsis_fpga_prg(void)
{
	char *name = "fpga_prg";
	char *usage= "fpga_prg=<file_name>";
	int cmdType = CMD_VSIS_COMMAND;
	int nParams = 1;
	int paramTypes[1] = {CMD_PARAM_STRING};
	cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_prg_cmd, cmdType);
}


/*  ***************************************************************************************
 *  VSIS WRITE COMMANDS
 *  ***************************************************************************************
 */

/**
 * Packages a device write command to the Roach IOCTL
 * @param ioctlCmd - where to write to
 * @param accessType - Byte(1) Word(2) Long(4)
 * @param offset - offset from device start
 * @param data - a pointer to the data item to write
 * @return - 0 on success errors are negative
 */
int vsis_dev_wr1_cmd(int ioctlCmd, int accessType, unsigned long offset, void *data)
{
	rdbe_rdwr_cmd_t cmd; // command to send

	cmd.access_type = accessType;
	cmd.ofs         = offset;
	cmd.len         = 1;
	cmd.buf         = data;

	// cludge for endianness problems
	switch(accessType){
	case 1:
		cmd.buf = (data+3);
		printf("Write value is %x \n", *(unsigned char*)cmd.buf);
		break;
	case 2:
		cmd.buf=(data+2);
		printf("Write value is %x \n", *(unsigned short*)cmd.buf);
		break;
	case 4:
		cmd.buf= data;
		printf("Write value is %lx \n", *(unsigned long*)cmd.buf);
		break;
	}
	/* printf("\nCalling ioctl with CMD=%d ParPtr=%p, BUFPtr=%p Length=%lu \n", ioctlCmd, &cmd, cmd.buf, cmd.len); */
	return serv_rdbe_ioctl(ioctlCmd, (char *)&cmd);
}

/**
 * Write a word of access type to the device at offset
 * @param argc   - should be 3 <access_type> <offset> <word to write>
 * @param argv   - pointers to the parameters
 * @param retVal - buffer with the data (none today)
 * @param retLen - length of buffer in BYTES (0 today)
 * @return       - 0 on success
 */
int vsis_fpga_wr1_cmd(int argc, void **argv, void **retVal, int *retLen)
{
  int tmpRet;
  unsigned long accessType = 2;
  unsigned long offset     = 0;
  unsigned long data       = 0; // this is a required parameter
  //	void *dPtr;
  unsigned char chBuf;
  unsigned short shBuf;

  *retLen = 0;

  // Check for null parameters
  if(argv[0] == 0 || argv[1]==0 || argv[2] == 0){
    sprintf(*retVal, "!fpga_wr=%d:Parameter Error;\n", VSIS_RET_PARAMETER_ERROR);
    *retLen = strlen(*retVal);
    return -VSIS_RET_PARAMETER_ERROR;
  }
  // assign local variables
  accessType = *(unsigned long*)argv[0]; 	// Access type parameter
  offset     = *(unsigned long*)argv[1];     // offset parameter
  data       = *(unsigned long *)argv[2];    // data parameter

  switch (accessType){
  case 1:
    chBuf = (unsigned char) data;
    tmpRet = util_write_byte_fpga(offset, 1, &chBuf);
    break;
  case 2:
    shBuf = (unsigned short) data; //type conversion endian safe
    tmpRet = util_write_short_fpga(offset, 1, &shBuf);
    break;
  case 4:
    tmpRet = util_write_long_fpga(offset, 1, &data);
    break;
  default:
    sprintf(*retVal, "!fpga_wr=%d:Parameter Error;\n", VSIS_RET_PARAMETER_ERROR);
    *retLen = strlen(*retVal);
    return -VSIS_RET_PARAMETER_ERROR;
  }
  //	// Fix endian issue FPGA is Little Endian
  //	dPtr = &data;
  //	switch(accessType){
  //	case 2:
  //		printf("data before change = %lx ", data);
  //		change_endian_short(dPtr+2);
  //		printf("and after = %lx \n", data);
  //		break;
  //	case 4:
  //		printf("data before change = %lx ", data);
  //		change_endian_long(&data);
  //		printf("and after = %lx \n", data);
  //		break;
  //	default:
  //		break;
  //	}
  //
  //	tmpRet = vsis_dev_wr1_cmd(RDBE_FPGA_WRITE, accessType, offset, &data);
  //

  if(tmpRet == 0) {
    sprintf(*retVal,"!fpga_wr=%d;\n", VSIS_RET_SUCCESS);
    *retLen = strlen(*retVal);
  } else {
    sprintf(*retVal,"!fpga_wr=%d:Execution Error;\n", VSIS_RET_EXECUTION_ERROR);
    *retLen = strlen(*retVal);
  }
  return tmpRet;
}


/**
 * Insert the fpgawr command into command queue.
 */
void insert_vsis_fpga_wr(void)
{
	char *name = "fpga_wr";
	char *usage= "fpga_wr=<access type>:<offset>:<datum>";
	int nParams = 3;
	int cmdType = CMD_VSIS_COMMAND;
	int paramTypes[3] = {CMD_PARAM_ACCESSTYPE, CMD_PARAM_UNSIGNEDLONG, CMD_PARAM_UNSIGNEDLONG};
	cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_wr1_cmd, cmdType);
}

/**
 * Write a word of access type to the device at offset
 * @param argc   - should be 3 <access_type> <offset> <word to write>
 * @param argv   - pointers to the parameters
 * @param retVal - buffer with the data (none today)
 * @param retLen - length of buffer in BYTES (0 today)
 * @return       - 0 on success
 */
int vsis_cpld_wr1_cmd(int argc, void **argv, void **retVal, int *retLen)
{
  int tmpRet;
  unsigned long accessType = 2;
  unsigned long offset     = 0;
  unsigned long data       = 0; // this is a required parameter

  *retLen = 0;

  // Access type parameter
  if(argv[0] != 0 ) accessType = *(unsigned long*)argv[0];
  // offset parameter
  if(argv[1] != 0) offset = *(unsigned long*)argv[1];
  // the data parameter //TODO: HERE
  if(argv[2] == 0){
    sprintf(*retVal, "!cpld_wr=%d:Parameter Error;\n", VSIS_RET_PARAMETER_ERROR);
    *retLen = strlen(*retVal);
    return -VSIS_RET_PARAMETER_ERROR;
  } else {
    data = *(unsigned long *)argv[2];
  }
  tmpRet = vsis_dev_wr1_cmd(RDBE_CPLD_WRITE, accessType, offset, &data);
  if(tmpRet == 0) {
    sprintf(*retVal,"!cpld_wr=%d;\n", VSIS_RET_SUCCESS);
    *retLen = strlen(*retVal);
  } else {
    sprintf(*retVal,"!cpld_wr=%d:Execution Error;\n", VSIS_RET_EXECUTION_ERROR);
		*retLen = strlen(*retVal);
  }
  return tmpRet;
}


/**
 * Insert the cpld_wr command into command queue.
 */
void insert_vsis_cpld_wr(void)
{
	char *name = "cpld_wr";
	char *usage= "cpld_wr=<access type>:<offset>:<datum>";
	int nParams = 3;
	int cmdType = CMD_VSIS_COMMAND;
	int paramTypes[3] = {CMD_PARAM_ACCESSTYPE, CMD_PARAM_UNSIGNEDLONG, CMD_PARAM_UNSIGNEDLONG};
	cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_cpld_wr1_cmd, cmdType);
}

/**
 * Write a word of access type to the device at offset
 * @param argc   - should be 3 <access_type> <offset> <word to write>
 * @param argv   - pointers to the parameters
 * @param retVal - buffer with the data (none today)
 * @param retLen - length of buffer in BYTES (0 today)
 * @return       - 0 on success
 */
int vsis_smap_wr1_cmd(int argc, void **argv, void **retVal, int *retLen)
{
  int tmpRet;
  unsigned long accessType = 2;
  unsigned long offset     = 0;
  unsigned long data       = 0; // this is a required parameter

  *retLen = 0;

  // Access type parameter
  if(argv[0] != 0 ) accessType = *(unsigned long*)argv[0];
  // offset parameter
  if(argv[1] != 0) offset = *(unsigned long*)argv[1];
  // the data parameter
  if(argv[2] == 0){
    sprintf(*retVal, "!smap_wr=%d:Parameter Error;\n", VSIS_RET_PARAMETER_ERROR);
    *retLen = strlen(*retVal);
    return -VSIS_RET_PARAMETER_ERROR;
  } else {
    data = *(unsigned long *)argv[2];
  }
  tmpRet = vsis_dev_wr1_cmd(RDBE_CPLD_WRITE, accessType, offset, &data);
  if(tmpRet == 0) {
    sprintf(*retVal,"!smap_wr=%d;\n", VSIS_RET_SUCCESS);
    *retLen = strlen(*retVal);
  } else {
    sprintf(*retVal,"!smap_wr=%d:Execution Error;\n", VSIS_RET_EXECUTION_ERROR);
    *retLen = strlen(*retVal);
  }
  return tmpRet;
}


/**
 * Insert the smap_wr1 command into command queue.
 */
void insert_vsis_smap_wr(void)
{
  char *name = "smap_wr";
  char *usage= "smap_wr=<access type>:<offset>:<datum>";
  int nParams = 3;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[3] = {CMD_PARAM_ACCESSTYPE, CMD_PARAM_UNSIGNEDLONG, CMD_PARAM_UNSIGNEDLONG};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_smap_wr1_cmd, cmdType);
}

/**
 * Upload data from the client to the server and put it in a specific buffer.
 * @param argc
 * @param argv
 * @param retVal
 * @param retLen
 * @return - 0 on success.
 */
int vsis_data_upload(int argc, void **argv, void **retVal, int *retLen)
{
  char *bufName;
  unsigned long  bufNo;
  unsigned long  dataLen;
  int funRet;

  // initialize variables
  *retLen = 0;
  funRet = 0;
  // check input variables
  if(argv[0] == 0) {
    sprintf(*retVal,"!upload=%d:Parameter Error;\n", VSIS_RET_PARAMETER_ERROR);
    *retLen = strlen(*retVal);
    return -VSIS_RET_PARAMETER_ERROR;
  } else {
    bufName = (char*)argv[0];
  }
  if(((strlen(bufName) <= 0)) || (strcmp(bufName,"BUF") != 0)){
    sprintf(*retVal,"!upload=%d:Parameter BUFNAME Error;\n", VSIS_RET_PARAMETER_ERROR);
    *retLen = strlen(*retVal);
    return -VSIS_RET_PARAMETER_ERROR;
  }

  if(argv[1] == 0){
    bufNo = 0;
  } else {
    bufNo = *(unsigned long*)argv[1];
  }

  if(bufNo >9 ) {
    sprintf(*retVal,"!upload=%d:Parameter buf number Error;\n", VSIS_RET_PARAMETER_ERROR);
    *retLen = strlen(*retVal);
    return -VSIS_RET_PARAMETER_ERROR;
  }

  if(argv[2] == 0){
    sprintf(*retVal,"!upload=%d:Parameter buf number Error;\n", VSIS_RET_PARAMETER_ERROR);
    *retLen = strlen(*retVal);
    return -VSIS_RET_PARAMETER_ERROR;
  }

  dataLen = *(unsigned long*)argv[2];
  if(dataLen > 0x01600000){
    sprintf(*retVal,"!upload=%d:Parameter length too large Error;\n", VSIS_RET_PARAMETER_ERROR);
    *retLen = strlen(*retVal);
    return -VSIS_RET_PARAMETER_ERROR;
  }
  printf("Uploading data to buffer %lu with %lu bytes\n", bufNo, dataLen);
  // store the next set of data in memory buffer x
  funRet = serv_get_data(bufNo, dataLen); // this calls the server and awaits a stream of hex coded bytes!

  if(funRet == 0){
    sprintf(*retVal,"!upload=%d;\n", VSIS_RET_SUCCESS);
    *retLen = strlen(*retVal);
  } else {
    sprintf(*retVal,"!upload=%d;\n", VSIS_RET_EXECUTION_ERROR);
    *retLen = strlen(*retVal);
  }
  return funRet;
}


void insert_vsis_data_upload(void)
{
  char *name = "upload"; // usage upload <BUF 0 | BUF 1> <num bytes>
  char *usage= "upload= BUF:<0..9>:<number_of_bytes>;";
  int nParams = 3;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[3] = {CMD_PARAM_STRING, CMD_PARAM_UNSIGNEDLONG, CMD_PARAM_UNSIGNEDLONG};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_data_upload, cmdType);
}

/**
 * Programs the FPGA given a memory buffer
 * @param argc
 * @param argv
 * @param retVal
 * @param retLen
 * @return
 */
int vsis_fpga_prg_buf_cmd(int argc, void **argv, void **retVal, int *retLen)
{
  int funRet;
  unsigned long bufNo;
  rdbe_configure_cmd_t cmdPar;

  *retLen = 0 ;
  funRet = 0; // all ok
  if(argv[0] == 0 || argv[1] == 0 ) {
    sprintf(*retVal,"!fpga_prg_buf=%d:Parameter Error;\n", VSIS_RET_PARAMETER_ERROR);
    *retLen = strlen(*retVal);
    return -VSIS_RET_PARAMETER_ERROR;
  }
  bufNo = *(unsigned long*)argv[1];

  printf("fpga_prg_buf called with %s = %lu \n", (char*)argv[0], bufNo);
  cmdPar.buf = ss_get_buf(pthread_self(), bufNo);
  cmdPar.len = ss_get_buf_len(pthread_self(), bufNo);
  if(cmdPar.len <= 0 && cmdPar.buf == 0) {
    printf("Error - FPGA PRG BUF with Buf %p and len %lu\n", cmdPar.buf, cmdPar.len);
    sprintf(*retVal,"!fpga_prg_buf=%d:Execution Error;\n", VSIS_RET_EXECUTION_ERROR);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }
  printf(	"\nrdbe_ioctl CONFIGURE ParPtr=%p, BufPtr=%p Length=%lu \n", (void*) &cmdPar, cmdPar.buf, cmdPar.len);
  funRet = serv_rdbe_ioctl(RDBE_DEV_CONFIGURE, (char *) &cmdPar);
  if(funRet != 0){
    printf("Error - FPGA_PRG_BUF with Buf %p and len %lu\n", cmdPar.buf, cmdPar.len);
    sprintf(*retVal,"!fpga_prg_buf=%d:Execution Error;\n", VSIS_RET_EXECUTION_ERROR);
    *retLen = strlen(*retVal);
    return -VSIS_RET_EXECUTION_ERROR;
  }
  sprintf(*retVal,"!fpga_prg_buf=%d;\n", VSIS_RET_SUCCESS);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS;
}


void insert_vsis_fpga_prg_buf(void)
{
  char *name = "fpga_prg_buf";
  char *usage= "fpga_prg_buf=BUF:<0..9>:<num bytes>";
  int nParams = 3;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[3] = {CMD_PARAM_STRING, CMD_PARAM_UNSIGNEDLONG, CMD_PARAM_UNSIGNEDLONG};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_fpga_prg_buf_cmd, cmdType);
}

/**
 * Testing the RDBE ISR routine
 * @param argc   - should be 0
 * @param argv   - pointers to the parameters
 * @param retVal - buffer with the data (none today)
 * @param retLen - length of buffer in BYTES (0 today)
 * @return       - 0 on success
 */
int vsis_isr_rd_cmd(int argc, void **argv, void **retVal, int *retLen)
{
  int tmpRet;

  *retLen = 0;

  tmpRet = fpga_isr_rd();
  if(tmpRet == 0) {
    sprintf(*retVal,"!isr_read=%d;\n", VSIS_RET_SUCCESS);
    *retLen = strlen(*retVal);
  } else {
    sprintf(*retVal,"!isr_read=%d:Execution Error;\n", VSIS_RET_EXECUTION_ERROR);
    *retLen = strlen(*retVal);
  }
  return tmpRet;
}


/**
 * Insert the isr_rd command into command queue.
 */
void insert_vsis_isr_rd(void)
{
  char *name = "isr_rd";
  char *usage= "isr_rd=";
  int nParams = 0;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[1] = {CMD_PARAM_UNSIGNEDLONG};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_isr_rd_cmd, cmdType);
}



/**
 * Write a
 * @param argc   - should be 1
 * @param argv   - pointers to the parameters
 * @param retVal - buffer with the data (none today)
 * @param retLen - length of buffer in BYTES (0 today)
 * @return       - 0 on success
 */
int vsis_isr_enable_cmd(int argc, void **argv, void **retVal, int *retLen)
{
  int tmpRet;
  unsigned long tmp; // jsut to make type conversion more readable
  unsigned short irqNo; // the bits to write to the ISR_ENABLE register.

  *retLen = 0;
  // Get the interrupt number to enable
  if(argv[0] != 0 ) {
	  tmp = *(unsigned long*)argv[0];
	  irqNo = (unsigned short) tmp;
	  tmpRet = fpga_isr_enable(irqNo);
  } else {
	  tmpRet = -1;
  }

  if(tmpRet == 0) {
    sprintf(*retVal,"!isr_enable=%d;\n", VSIS_RET_SUCCESS);
    *retLen = strlen(*retVal);
  } else {
    sprintf(*retVal,"!isr_enable=%d:Execution Error;\n", VSIS_RET_EXECUTION_ERROR);
    *retLen = strlen(*retVal);
  }
  return tmpRet;
}

/**
 * Insert the isr_enable command into command queue.
 */
void insert_vsis_isr_enable(void)
{
  char *name = "isr_enable";
  char *usage= "isr_enable=<irqNo>";
  int nParams = 0;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[1] = {CMD_PARAM_UNSIGNEDLONG};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_isr_enable_cmd, cmdType);
}


/**
 * Disable a specific FPGA IRQ
 * @param argc   - should be 1
 * @param argv   - pointers to the parameters
 * @param retVal - buffer with the data (none today)
 * @param retLen - length of buffer in BYTES (0 today)
 * @return       - 0 on success
 */
int vsis_isr_disable_cmd(int argc, void **argv, void **retVal, int *retLen)
{
  int tmpRet;
  unsigned long tmp; // jsut to make type conversion more readable
  unsigned short irqNo; // the bits to write to the ISR_ENABLE register.

  *retLen = 0;
  // Get the interrupt number to enable
  if(argv[0] != 0 ) {
	  tmp = *(unsigned long*)argv[0];
	  irqNo = (unsigned short) tmp;
	  tmpRet = fpga_isr_disable(irqNo);
  } else {
	  tmpRet = -1;
  }

  if(tmpRet == 0) {
    sprintf(*retVal,"!isr_disable=%d;\n", VSIS_RET_SUCCESS);
    *retLen = strlen(*retVal);
  } else {
    sprintf(*retVal,"!isr_disable=%d:Execution Error;\n", VSIS_RET_EXECUTION_ERROR);
    *retLen = strlen(*retVal);
  }
  return tmpRet;
}

/**
 * Insert the isr_disable command into command queue.
 */
void insert_vsis_isr_disable(void)
{
  char *name = "isr_disable";
  char *usage= "isr_disable=<irqNo>";
  int nParams = 0;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[1] = {CMD_PARAM_UNSIGNEDLONG};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, vsis_isr_disable_cmd, cmdType);
}




/**
 * Initializes command lists with basic command set
 */
void cmd_low_level_initialize(void)
{
  insert_vsis_fpga_rd();
  insert_vsis_smap_rd();
  insert_vsis_cpld_rd();
  insert_vsis_fpga_prg();
  insert_vsis_fpga_wr();
  insert_vsis_cpld_wr();
  insert_vsis_smap_wr();
  insert_vsis_data_upload();
  insert_vsis_fpga_prg_buf();
  insert_vsis_isr_rd();
  insert_vsis_isr_enable();
  insert_vsis_isr_disable();
};
