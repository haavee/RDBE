/*
 * cmd_parser.c
 *
 *  Created on: Jul 26, 2009
 *      Author: Mikael Taveniku XCube Communication Inc.
 *      License: GPL
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "cmd_parser.h"
#include "server_error.h"

const char *cmd_parser_delims = " ,\t\n";

// #define DEBUG_VERBOSE

/**
 * Internal function to tokenize a string.  This function does not allocate any memory
 * It returns an array of pointers to substrings in the string buffer buf (delimiters removed)
 * Remember to not deallocate buf, before tokens are used
 * @param buf - null terminated string to tokenize
 * @param tokPtr - the array of tokens to be returned
 * @param maxTokens - maximum number of tokens
 * @return - number of tokens in string or -1 on error
 */
int tokenize_cmd_line(char *buf, char **tokPtr, int maxTokens)
{
  char *savePtr; // tmp ptr used by reentrant version of strtok
  int nToken; // number of tokens in this string
  
  // Sanity check
  if(buf == 0 || strlen(buf) == 0 || tokPtr==0 || maxTokens == 0) return -ERR_PARSER_0;
  // Try to tokenize
  nToken = 0;
  tokPtr[nToken] = strtok_r(buf,cmd_parser_delims, &savePtr);
  while (tokPtr[nToken] != NULL && nToken < maxTokens)
    {
      nToken++;
      tokPtr[nToken] = strtok_r (NULL, cmd_parser_delims, &savePtr );
    }
  
  return nToken;
}


/* ***************************************************************************
 *   Parser functions
 * ***************************************************************************
 */

/**
 * Takes a null terminated string and tries to interpret it as an access type specifier
 * b,w,l, (q not implemented)
 * @param str - {b,w,l}
 * @return - 0 if error, nr of byte per access request 1,2,4 otherwise
 */
int cmd_parse_access_type(char *str)
{
  if(str == 0) return 0;
  if(strlen(str) != 1) return 0;
  switch(str[0]){
  case 'b':
  case 'B': return 1;
  case 'w':
  case 'W': return 2;
  case 'l':
  case 'L': return 4;
  default : return 0;
  }
}


/**
 * Parse a string as a hexadecimal number, call always succeeds.
 * it returns the value of the first set of charcters that it can parse as a number.
 * @param str -{0..9, a..f, A..F}
 * @return - the number, or 0 if unsuccessful,
 */
unsigned long cmd_parse_hex(char *str)
{
  int i, len;
  unsigned long val = 0;
  
  if(str == 0 ) return 0;
  len = strlen(str);
  for(i=0; i<len; i++){
    switch(str[i]){
    case '0': val = (val<<4) + 0; break;
    case '1': val = (val<<4) + 1; break;
    case '2': val = (val<<4) + 2; break;
    case '3': val = (val<<4) + 3; break;
    case '4': val = (val<<4) + 4; break;
    case '5': val = (val<<4) + 5; break;
    case '6': val = (val<<4) + 6; break;
    case '7': val = (val<<4) + 7; break;
    case '8': val = (val<<4) + 8; break;
    case '9': val = (val<<4) + 9; break;
    case 'a': val = (val<<4) + 10; break;
    case 'A': val = (val<<4) + 10; break;
    case 'b': val = (val<<4) + 11; break;
    case 'B': val = (val<<4) + 11; break;
    case 'c': val = (val<<4) + 12; break;
    case 'C': val = (val<<4) + 12; break;
    case 'd': val = (val<<4) + 13; break;
    case 'D': val = (val<<4) + 13; break;
    case 'e': val = (val<<4) + 14; break;
    case 'E': val = (val<<4) + 14; break;
    case 'f': val = (val<<4) + 15; break;
    case 'F': val = (val<<4) + 15; break;
    default : printf("Hex: bad character in string");
    }
  }
  return val;
}

/**
 * Parse a string as an octal number
 * @param str - the string to be converted
 * @return - the number
 */
unsigned long cmd_parse_octal(char *str)
{
  int i, len;
  unsigned long val = 0;
  
  if(str == 0 ) return 0;
  len = strlen(str);
  for(i=0; i<len; i++){
    switch(str[i]){
    case '0': val = (val<<3) + 0; break;
    case '1': val = (val<<3) + 1; break;
    case '2': val = (val<<3) + 2; break;
    case '3': val = (val<<3) + 3; break;
    case '4': val = (val<<3) + 4; break;
    case '5': val = (val<<3) + 5; break;
    case '6': val = (val<<3) + 6; break;
    case '7': val = (val<<3) + 7; break;
    default : printf("Octal: bad character in string %c at index %d in string %s\n", str[i], i, str);
    }
  }
  return val;
}


/**
 * Parse the string as a binary number
 * @param str - the string {0,1}*
 * @return - the number
 */
unsigned long cmd_parse_binary(char *str)
{
  int i, len;
  unsigned long val = 0;
  
  if(str == 0 ) return 0;
  len = strlen(str);
  len = len == 0 ? 0 : len - 1;
  
  for(i=0; i<len; i++){
    switch(str[i]){
    case '0': val = (val<<1) + 0; break;
    case '1': val = (val<<1) + 1; break;
    default : printf("Binary: bad character in string %c at index %d in string %s\n", str[i], i, str);
    }
  }
  return val;
}

/**
 * Parse the a string as an unsigned decimal number {0..9}*.
 * @param str
 * @return
 */
unsigned long cmd_parse_decimal(char *str)
{
  int i, len;
  unsigned long val = 0;
  
  if(str == 0 ) return 0;
  len = strlen(str);
  for(i=0; i<len; i++){
    switch(str[i]){
    case '0': val = (val*10) + 0; break;
    case '1': val = (val*10) + 1; break;
    case '2': val = (val*10) + 2; break;
    case '3': val = (val*10) + 3; break;
    case '4': val = (val*10) + 4; break;
    case '5': val = (val*10) + 5; break;
    case '6': val = (val*10) + 6; break;
    case '7': val = (val*10) + 7; break;
    case '8': val = (val*10) + 8; break;
    case '9': val = (val*10) + 9; break;
    default : printf("Decimal: bad character in string %c at index %d in string %s\n", str[i], i, str);
    }
  }
  return val;
}

/**
 * Parses a string in binary, octal, decimal and hex format and returns the value of it.
 * @param str - {0|1}*b || o{0..7}* || {0..9}* || 0x{0..f)*
 * @return - the number parsed with best effort
 */
unsigned long cmd_parse_ul(char *str)
{
  int len;
  
  if(str == 0) return 0;
  len = strlen(str);
  if( (len >= 2) && str[0]=='0' && (str[1]=='x' || str[1]=='X')) return cmd_parse_hex(&str[2]);
  if( (len >= 1) && (str[0]=='o' || str[0]=='O')) return cmd_parse_octal(&str[1]);
  if( (len >= 1) && (str[len-1]=='b' || str[len-1]=='B')) return cmd_parse_binary(str);
  return cmd_parse_decimal(str);
}

/**
 * Parses a string in binary, octal, decimal and hex format and returns the value of it.
 * @param str - {0|1}*b || o{0..7}* || {0..9}* || 0x{0..f)*
 * @return - the number parsed with best effort
 */
long cmd_parse_l(char *str)
{
  int len;
  
  if(str == 0) return 0;
  len = strlen(str);
  if((len>=2) && (str[0] == '-')) {
    return -(long)cmd_parse_ul(&str[1]);
  } else {
    return cmd_parse_ul(str);
  }
}

/**
 * Parse a double out of the string str
 * returns 0.0 if it can't convert it.
 * @param str
 * @return - the double representation of the string str
 */
double cmd_parse_double(char *str)
{
  // TODO: Check errno for errors
  // TODO: if value is 0.0 we had an error but it is silent
  if(str == 0) return 0.0;
  return strtod(str,NULL);
}

/* ***************************************************************************
 *  End Parser Functions
 * ***************************************************************************
 */


/* ****************************************************************************
 *  Command Interpreter functions
 * ****************************************************************************
 */




/**
 * Command type descriptor
 */
struct cmd_desc {
  int cmdNo;         // internal command number
  int (*fun)(int,void **, void**, int *); // function to execute command
  char *cmdStr;      // string representation of command
  int  cmdType;      // CMD_TYPE_UNDEFINED, CMD_TYPE_COMMAND, CMD_TYPE_QUERY
  char *usageStr;    // String defining the command usage of this command
  int nParams;       // number of parameters
  int *paramTypes;   // list of parameter types for the command
  cmd_desc_t *next;  // PTR to next CMD in list
};




/**
 * Executable command structure, highly type unsafe so be careful
 */
struct cmd_pkt{
  int (*fun)(int, void**, void **, int *); // function to execute
  int argc;                // number of arguments
  void **arg;              // the pointers to our arguments
};



/** head of the list of valid commands */
cmd_desc_t *cmd_list_hd = 0;  // head of command list, initialize to NULL

/**
 * Insert a new command into the list of available commands, if a command is inserted twice, it is
 * appended to the head of the list and the latest inserted command definition will be used.
 * @param name - string name of the command
 * @param usage - string describing the usage of this command
 * @param nParams - number of parameters for the command
 * @param paramTypes - parameter typed definition
 * @param fun - function to execute command " int fun(int argc, void**argv, void **retBuf, int *retLen);"
 * @return - 0 if successful, negative otherwise
 */
int cmd_insert_cmd_desc(char *name, char *usage, int nParams, int *paramTypes, int (*fun)(int, void**, void **, int*), int cmdType)
{
  cmd_desc_t *cmd;   // the new command to insert in the list
  
  cmd = (cmd_desc_t*) malloc(sizeof(cmd_desc_t));
  cmd->cmdNo = 0;          // not implemented yet
  cmd->cmdType = cmdType;
  cmd->cmdStr = strdup(name);
  cmd->usageStr = strdup(usage);
  cmd->nParams = nParams;
  cmd->paramTypes = (int*) malloc(nParams * sizeof(int*));
  memcpy(cmd->paramTypes, paramTypes, nParams * sizeof(int*));
  cmd->fun = fun;
  
  // insert the new command first in the list of commands
  // increment cmd number for the inserted command..
  if(cmd_list_hd != 0){
    // if we are not the first command then increment command number by 1
    cmd->cmdNo = 1 + cmd_list_hd->cmdNo;
  }
  cmd->next = cmd_list_hd;
  cmd_list_hd = cmd;
  return 0;
}

/**
 * Finds (and returns) the command with command number cmdNo.
 * If it doesn't exist return 0
 * @param cmdNo - the command number
 * @return - pointer to the command or 0 if not found
 */
cmd_desc_t *cmd_find_cmdNo(int cmdNo)
{
  cmd_desc_t *tmpDesc = cmd_list_hd;
  while(tmpDesc != 0 && tmpDesc->cmdNo != cmdNo){
    tmpDesc = tmpDesc->next;
  }
  return tmpDesc;
}

/**
 * Find a command in the command list with name cmdName
 * @param cmdName - the command to search for
 * @return - the command or 0 if not found
 */
cmd_desc_t *cmd_find_cmdName(char *cmdName)
{
  cmd_desc_t *tmpDesc = cmd_list_hd;
  
  if(cmdName == 0) return 0; // safety if we get called with null string
  
  while(tmpDesc != 0) {
    if(tmpDesc->cmdStr != 0) {
      //printf("comparing cmd %s with %s\n", tmpDesc->cmdStr, cmdName);
      if(strcmp(tmpDesc->cmdStr, cmdName) == 0){
	return tmpDesc;
      }
    }
    tmpDesc = tmpDesc->next;
  }
  return tmpDesc;
}

/**
 * returns the number of known commands in our command list
 * @return - the number of registered commands
 */
unsigned cmd_get_num_cmd(void)
{
  cmd_desc_t *tmpDesc = cmd_list_hd;
  unsigned cnt = 0;
  while(tmpDesc != 0){
    tmpDesc = tmpDesc->next;
    cnt++;
  }
  return cnt;
}


/**
 * Returns a string containing the usage of the command cmd.
 * @param cmd
 * @return
 */
const char *cmd_get_usage(cmd_desc_t *cmd)
{
  if(cmd == 0) return 0;
  return cmd->usageStr;
}

/**
 * Find a command with the name cmdName that takes the nParam Number of parameters
 * @param cmdName
 * @param nParam
 * @return - the command
 */
cmd_desc_t *cmd_find(char *cmdName, int nParam){
  cmd_desc_t *tmpDesc;
  int done;
  //printf("cmd find with cmd=%s and param=%d\n", cmdName, nParam);
  //find the command that correspond to the parameter list and the name
  tmpDesc = cmd_list_hd;
  done = 0;
  while(!done){
    // debug
    if(tmpDesc != 0 && tmpDesc->cmdStr != 0) {
      //printf("comparing with cmd %s with nparam=%d\n", tmpDesc->cmdStr, tmpDesc->nParams);
    }
    if(tmpDesc == 0 ||
       (tmpDesc->cmdStr != 0 && strcmp(tmpDesc->cmdStr, cmdName) == 0 && nParam == tmpDesc->nParams)
       ) {
      done=1;
    } else {
      tmpDesc = tmpDesc->next;
    }
  }
  return tmpDesc;
}

/**
 * Execute a given command, this command will allocate memory for the return values
 * The return values will be contained in the retBuf buffer and retLen is the length
 * Caller must deallocate the memory when done.
 * @param cmd
 * @param retBuf - will contain a pointer to the return values
 * @param retLen - will contain the number of bytes in buffer
 * @return - 0 on success
 */
int cmd_execute_cmd(cmd_pkt_t *cmd, void **retBuf, int *retLen)
{
#ifdef DEBUG_VERBOSE
  printf("Execute cmd");
#endif
  if(cmd != 0){
#ifdef DEBUG_VERBOSE
    printf("Cmd fun=%p, argc=%d, argv=%p\n",cmd->fun, cmd->argc, cmd->arg );
#endif
    if(cmd->fun !=0) {
      return cmd->fun(cmd->argc, cmd->arg, retBuf, retLen);
    }
  }
  return 0;
}


/**
 * builds a command based on parameters given in the command structure
 * @param tokPtr
 * @param cmd
 * @return a command packet
 */
cmd_pkt_t *cmd_build_cmd(char **tokPtr, cmd_desc_t *cmd)
{
	int i;
	unsigned long *num;
	long *sNum;
	char *str;
	double *rNum;

	cmd_pkt_t *cmdPkt;

	//printf("cmd build called with cmd_desc=%s nparam=%d\n", cmd->cmdStr, cmd->nParams);

	cmdPkt = (cmd_pkt_t *) malloc(sizeof(cmd_pkt_t));
	cmdPkt->arg = (void **) malloc(cmd->nParams * sizeof(void**));

	cmdPkt->fun = cmd->fun;     //make sure we have a function to execute
	cmdPkt->argc= cmd->nParams; // the correct number of arguments

	for(i=1; i<= cmd->nParams; i++){  // remember token 0 is the name of the function so we start at 1
		switch(cmd->paramTypes[i-1]){
		case CMD_PARAM_UNSIGNED:
		case CMD_PARAM_UNSIGNEDLONG:
			num = (unsigned long *) malloc(sizeof(unsigned long));
			*num = cmd_parse_ul(tokPtr[i]);
			cmdPkt->arg[i-1] = num;
			printf("UL assigned cmdPkt[%d]=%p which is %lu\n", i-1, num, *num);
			break;
		case CMD_PARAM_INT:
		case CMD_PARAM_LONG:
			sNum = (long *) malloc(sizeof(long));
			*sNum = cmd_parse_l(tokPtr[i]);
			cmdPkt->arg[i-1] = sNum;
			printf("L assigned cmdPkt[%d]=%p which is %ld\n", i-1, sNum, *sNum);
			break;
		case CMD_PARAM_STRING:
			str = malloc(strlen(tokPtr[i]));
			strcpy(str, tokPtr[i]);
			cmdPkt->arg[i-1] = (void*)str;
			printf("STR assigned cmdPkt[%d]=%p which is %s\n", i-1, str, str);
			break;
		case CMD_PARAM_ACCESSTYPE:
			num = (unsigned long *) malloc(sizeof(unsigned long));
			*num = (unsigned long) cmd_parse_access_type(tokPtr[i]);
			cmdPkt->arg[i-1] = num;
			printf("AT assigned cmdPkt[%d]=%p which is %lu\n", i-1, num, *num);
			break;
		case CMD_PARAM_REAL:
			// create
			rNum = (double *) malloc(sizeof(double));
			//TODO: Need to fix this one to handle errors... check string before passing it in
			*rNum = cmd_parse_double(tokPtr[i]);
			cmdPkt->arg[i-1] = rNum;
			break;
		}
	}
	return cmdPkt;
}


/**
 * Try to match a command with the given set of tokens
 * @param tokPtr - pointer to token array
 * @param nTok - number of items in the array
 * @return - the command if successful, negative on error
 */
cmd_pkt_t *find_cmd(char **tokPtr, int nTok)
{
  cmd_desc_t *cmdDesc; // the command we think it is
  cmd_pkt_t  *cmdPkt;
  
  // assume first token is the command, next tokens are the parameter list
  if(tokPtr == 0 || nTok <= 0 ) return 0 ;//-ERR_PARSER_1;
  //printf("calling cmd_find with %s and %d\n", tokPtr[0], nTok);
  cmdDesc = cmd_find(tokPtr[0], nTok-1); // arguments are one less than total number of tokens
  // found a potential command
  if(cmdDesc > 0) {
    //printf("found a cmd description, %p trying to build a command\n", cmdDesc);
    cmdPkt = cmd_build_cmd(tokPtr, cmdDesc);  // parse parameters for this particular command
    return cmdPkt; // cmdPkt will contain error code if not successful
  }
  return 0; //-ERR_PARSER_2;
}


/**
 * Take a command line and match it with a command - if possible
 * @param buf
 * @param bufLen
 * @return - a command package ready to execute or null if error
 */
cmd_pkt_t *parser_get_cmd(char *buf, int bufLen)
{
  char *savePtr; // tmp ptr used by reentrant version of strtok
  char *tokens[256];    //array to hold tokens from the command line
  int  nToken;          //number of tokens in the command line
  int  maxTokens = 256;
  
  // Sanity check
  if(buf == 0 || strlen(buf) == 0 ) return 0;//-ERR_PARSER_0;
  // Try to tokenize
  nToken = 0;
  tokens[nToken] = strtok_r(buf,cmd_parser_delims, &savePtr);
  while (tokens[nToken] != NULL && nToken < maxTokens)
    {
      nToken++;
      tokens[nToken] = strtok_r (NULL, cmd_parser_delims, &savePtr );
    }
  
  return find_cmd(tokens, nToken);
}



/**
 * Return command packet after use
 * @param cmd - pointer to packet to return
 * @return 0 if successful
 */
int parser_free_cmd(cmd_pkt_t *cmd)
{
  int i;
  if (cmd) 
    {
      for(i=0; i< cmd->argc; i++)
	{
	  if (cmd->arg[i]) 
	    free(cmd->arg[i]);
	}
      free(cmd->arg);
      free(cmd);
    }
  return 0;
}

/**
 * Internal debug command for command list display
 */
void cmd_print_cmd_list(void)
{
  int i;
  int cmdNo;
  cmdNo = 0;
  cmd_desc_t *tmpCmd;
  tmpCmd = cmd_list_hd;
  printf("current command list: \n");
  while(tmpCmd != 0){
    if(tmpCmd->cmdStr != 0){
      printf("CmdNo %d Command=%s, NumParam=%d Function Ptr=%p\n", cmdNo, tmpCmd->cmdStr, tmpCmd->nParams, tmpCmd->fun);
    } else {
      printf("ERROR: CmdNo %d Command=NULL, NumParam=%d Function=%p\n", cmdNo, tmpCmd->nParams, tmpCmd->fun);
    }
    if(tmpCmd->usageStr != 0){
      printf("Usage %s \n", tmpCmd->usageStr);
    }
    printf("Parameter Types: ");
    for(i=0;i<tmpCmd->nParams;i++){
      if(tmpCmd->paramTypes != 0){
	switch(tmpCmd->paramTypes[i]){
	case CMD_PARAM_INT:
	  printf(" <int> ");
	  break;
	case CMD_PARAM_LONG:
	  printf(" <long> ");
	  break;
	case CMD_PARAM_UNSIGNEDLONG:
	  printf(" <unsigned long> ");
	  break;
	case CMD_PARAM_STRING:
	  printf(" <string> ");
	  break;
	case CMD_PARAM_ACCESSTYPE:
	  printf(" <access type> ");
	  break;
	default:
	  printf(" <error> ");
	}
      }
    }
    printf("\n");
    cmdNo++;
    tmpCmd = tmpCmd->next;
  }
  printf("Total of %d Commands in list\n", cmdNo);
}


/**  *********************************************************************************************************************
 *
 *   VSI-S Parser
 *
 *   *********************************************************************************************************************
 */


char *vsis_ret_str[] = {"success", "operation initiated", "not implemented", "syntax error", "execution error", "unable to perform command",
		"inconsistent state", "unknown command", "parameter error", "undefined state" };


/**
 * Get a string representation of a VSIS return code
 */
char *vsis_ret_code_2_str(int retCode)
{
  if(retCode < 10 && retCode >= 0)
    return vsis_ret_str[retCode];
  return "undefined return code";
}



#define VSIS_NULL_BUFFER 1
#define VSIS_EMPTY_BUFFER 2
#define VSIS_NO_KEYWORD_FOUND 3
#define VSIS_NO_CMD_SPEC 4
#define VSIS_ILLEGAL_CHARACTER 5
#define VSIS_PARSE_ERROR  6
#define VSIS_UNTERMINATED_STRING 7
#define VSIS_UNKNOWN_KEYWORD   8
#define VSIS_PARAMETER_ERROR 9


#define VSIS_MAX_KEYWORD_SZ 255

/**
 * Read a string and try to interpret it as a VSIS keyword
 * @param keyword - return parameter
 * @param keyLen - length of the returned string
 * @param srcBuf - source buffer
 * @param srcLen - length of buffer
 * @return - number of characters consumed in operation, negative on error
 */
int vsis_get_keyword(char *keyword, int *keyLen, char *srcBuf, int srcLen)
{
	int i;       // srcBuf index
	int j;       // keyword index
	int leading; // boolean for leading space
	char ch;

	leading = 1;
	j = 0;
	keyword[0] = 0; // terminate string to make strlen happy
	*keyLen    = 0;

	for(i=0; i< VSIS_MAX_KEYWORD_SZ && i<srcLen; i++){
		ch = srcBuf[i];
		if(leading && (ch==' ' || ch=='\t')) {
			//discard if in beginning
		} else {
			leading = 0; //we have discarded all leading space characters
			if(ch==' ' || ch=='\t' || ch=='=' || ch=='?'){
				// we are done with the keyword (it may still have a trailing number)
				keyword[j++] = 0; // terminate string
				*keyLen = j;
				return i;
			} else {
				keyword[j++] = ch;
			}
		}
	}
	return -1; // no keyword found!!
}

/**
 * Try to extract a command type item from the front of the input buffer
 * @param cmdQuery - return value
 * @param srcBuf - source buffer
 * @param srcLen - maximum length of buffer
 * @return - number of characters consumer, or negative on error
 */
int vsis_get_command_type(int *cmdQuery, char *srcBuf, int srcLen)
{
	int i;       // srcBuf index
	int leading; // boolean for leading space
	char ch;
	leading = 1;

	for(i=0; i<srcLen; i++){
		ch = srcBuf[i];
		if(leading && (ch==' ' || ch=='\t')) {
			//discard if in beginning
		} else {
			leading = 0; //we have discarded all leading space characters
			if(ch=='=') {
				*cmdQuery = CMD_VSIS_COMMAND;
				return i+1;
			}
			if(ch=='?'){
				*cmdQuery = CMD_VSIS_QUERY;
				return i+1;
			}
			return -1; // no command found
		}
	}
	return -1; // no keyword found!!
}

/**
 * Extract a VSIS formatted string from the input stream. All characters are contained intact
 * including the leading and trailing string markers.
 * @param param - return value
 * @param paramLen - length of the returned string
 * @param srcBuf - source buffer
 * @param srcLen - length of buffer
 * @return - number of characters consumed, or negative on error
 */
int vsis_get_string(char *param, int *paramLen, char *srcBuf, int srcLen)
{
	int i;   //src index
	char ch; // character we read

	int done; // break the loop when done
	char startCh; //initial " or ' always first in string
	int nextLitteral; // if we should discard the next version of the start character

	nextLitteral = 0;
	startCh  = srcBuf[0]; // this is our starting character
	param[0] = srcBuf[0];
	done     = 0;
	i        = 1;

	while(i<srcLen && !done){
		ch = srcBuf[i];
		*paramLen  += 1;
		param[i]   = ch;
		param[i+1] = 0;
		if(ch==startCh && !nextLitteral) {
			done = 1;
		}
		if(ch == '\\') { // see if next character is escaped
			nextLitteral = 1;
		} else {
			nextLitteral = 0;
		}
		i++;
	}
	if(done) {
		return i;
	}
	return - VSIS_UNTERMINATED_STRING;

}

/**
 * Extract a parameter from the input buffer.
 * A parameter can be EMPTY
 * @param param - the returned parameter as a string
 * @param paramLen - length of the returned string
 * @param srcBuf - source buffer
 * @param srcLen - length of buffer
 * @return - number of characters consumed, or negative on error
 */
int vsis_get_parameter(char *param, int *paramLen, char *srcBuf, int srcLen)
{
	int i;       // srcBuf index
	int j;       // parameter index
	int chRead;  // number of characters read for string parameter
	char ch;
	int  done;   // terminator for while loops

	j         = 0;
	param[0]  = 0; // terminate string to make strlen happy
	*paramLen = 0;
	i         = 0;

	//printf("Get Parameter called with %s", srcBuf);

	// remove any leading white space characters
	while(i<srcLen && isspace(srcBuf[i]))	i++;

	if(i >= srcLen) return -VSIS_PARSE_ERROR; // empty string without termination
	// Check what type of parameter we have
	if(srcBuf[i] == ';') return 0; //this is a "no parameter" or end of parameter list parameter..
	if((srcBuf[i] == '\'' || srcBuf[i] == '\"')) {
		// This is a string parameter need extra processing
		chRead = vsis_get_string(param, paramLen, &srcBuf[i], srcLen-i);
		if (chRead <= 0) return -VSIS_UNTERMINATED_STRING;
		i += chRead;
	} else {
		// this is a general variable literal or number
		done = 0;
		j    = 0;
		while(!done && i < srcLen) {
			ch = srcBuf[i];
			if(ch== '\'')   return -VSIS_ILLEGAL_CHARACTER;
			if(ch== '"')    return -VSIS_ILLEGAL_CHARACTER;

			if(isspace(ch) || (ch==':') || (ch==';'))
				done=1;  // found end of parameter
			else {
				i++;
				param[j++] = ch;
				param[j]   = 0;
				*paramLen  = j;
			}
		}
	}
	// remove any trailing characters
	while ( i < srcLen && isspace(srcBuf[i])) i++;
	// now we should have a ":" or a ";"
	if(i >= srcLen)       return -VSIS_PARSE_ERROR; // no trailing : or ;
	if(srcBuf[i] == ';' ) return i;     // do not consume the ";" we need it to check for valid cmd line
	if(srcBuf[i] == ':')  return i + 1; // consume the : so we can go on with the next potentially empty param
	return -VSIS_PARSE_ERROR; // no parameter found!!
}





/**
 * Builds a command based on the input parameters argc and argv, legal commands are defined by the VSIS
 * command specification.
 * @param argc - number of parameters in argv, may be different than in the command spec
 * @param argPtr - pointer to argument array - strings at this point
 * @param cmd - the command descriptor we thing it is
 * @param cmdRet - return value, (this needs to point to an allocated cmd_pkt structure) a filled out command packet
 * @return - 0 if successful error code otherwise
 */
int vsis_build_cmd(cmd_pkt_t **cmdRet, int argc, char **argPtr, cmd_desc_t *cmd)
{
	int i;
	unsigned long *num;
	long *sNum;
	char *str;
	double *realNum;

	cmd_pkt_t *cmdPkt;

	//printf("VSI-S build cmd called with cmd_desc=%s nParam=%d\n", cmd->cmdStr, cmd->nParams);

	cmdPkt = (cmd_pkt_t *) malloc(sizeof(cmd_pkt_t));
	cmdPkt->arg = (void **) malloc(cmd->nParams * sizeof(void**));

	cmdPkt->fun = cmd->fun;     //make sure we have a function to execute
	cmdPkt->argc= cmd->nParams; // the correct number of arguments

	for(i=0; i< cmd->nParams; i++){
		if(i < argc && argPtr[i] != 0 && strlen(argPtr[i]) > 0) {
			switch(cmd->paramTypes[i]){
			case CMD_PARAM_UNSIGNED:  // still will allocate a full unsigned long for tis one
			case CMD_PARAM_UNSIGNEDLONG:
			case CMD_PARAM_HEX:
				num = (unsigned long *) malloc(sizeof(unsigned long));
				*num = cmd_parse_ul(argPtr[i]);
				cmdPkt->arg[i] = num;
#ifdef DEBUG_VERBOSE
				printf("UL assigned cmdPkt[%d]=%p which is %lu\n", i, num, *num);
#endif
				break;
			case CMD_PARAM_LONG:
			case CMD_PARAM_INTEGER:
				sNum = (long *) malloc(sizeof(long));
				*sNum = cmd_parse_l(argPtr[i]);
				cmdPkt->arg[i] = sNum;
#ifdef DEBUG_VERBOSE
				printf("L assigned cmdPkt[%d]=%p which is %ld\n", i, sNum, *sNum);
#endif
				break;
			case CMD_PARAM_STRING:
			case CMD_PARAM_LITERAL:  //Pass these up just as they are to the command
				str = malloc(strlen(argPtr[i]));
				strcpy(str, argPtr[i]);
				cmdPkt->arg[i] = (void*)str;
#ifdef DEBUG_VERBOSE
				printf("STR assigned cmdPkt[%d]=%p which is %s\n", i, str, str);
#endif
				break;
			case CMD_PARAM_ACCESSTYPE:
				num = (unsigned long *) malloc(sizeof(unsigned long));
				*num = (unsigned long) cmd_parse_access_type(argPtr[i]);
				cmdPkt->arg[i] = num;
#ifdef DEBUG_VERBOSE
				printf("AT assigned cmdPkt[%d]=%p which is %lu\n", i, num, *num);
#endif
				break;
			case CMD_PARAM_TIME:
				// format .y..d..h..m..s
				// example: 2000y212d19h03m | 2003y91d9h23m13.093s
				// for now let's just make it a string
				str = malloc(strlen(argPtr[i]));
				strcpy(str, argPtr[i]);
				cmdPkt->arg[i] = (void*)str;
#ifdef DEBUG_VERBOSE
				printf("TIME assigned cmdPkt[%d]=%p which is %s\n", i, str, str);
#endif
				break;
			case CMD_PARAM_REAL:
				realNum = (double *) malloc(sizeof(double));
				*realNum = cmd_parse_double(argPtr[i]);
				cmdPkt->arg[i] = realNum;
#ifdef DEBUG_VERBOSE
				printf("REAL assigned cmdPkt[%d]=%p which is %f\n", i, realNum, *realNum);
#endif
				break;
			default:
				cmdPkt->arg[i] = 0;
				printf("Warning unknown format for argument %d is of type %d\n", i, *(cmd->paramTypes));
			}
		} else {
			cmdPkt->arg[i] = 0;
			//printf("default parameter value == null for param %d\n", i);
		}
	}
	*cmdRet = cmdPkt;
	return 0;
}


/**
 * VSIS Command Format
 * <keyword['['<n>'] '=' <param> [:<param>];
 * Response: !<keyword> '=' <return code> [:<response param>];
 * Fields can be optional, but all fields are position dependent.
 * From the command parser, the commands will always have the following format
 * Arg[0] channel number
 * Arg[1] ... Arg[n] parameters may be null
 */


/**
 * Find a command with the name cmdName and is of the right type CMD or QUERY
 * @param cmdName
 * @param nParam
 * @return - the command
 */
cmd_desc_t *vsis_cmd_find(char *cmdName, int cmdType){
	cmd_desc_t *tmpDesc;
	int done;
#ifdef DEBUG_VERBOSE
	printf("cmd find with cmd=%s and cmdType=%d\n", cmdName, cmdType);
#endif
	//find the command that correspond to the parameter list and the name
	tmpDesc = cmd_list_hd;
	done = 0;
	while(!done){
		// debug
		if(tmpDesc != 0 && tmpDesc->cmdStr != 0) {
			//printf("comparing with cmd %s with cmdType=%d\n", tmpDesc->cmdStr, tmpDesc->cmdType);
		}
		if(tmpDesc == 0 ||(tmpDesc->cmdStr != 0 && strcmp(tmpDesc->cmdStr, cmdName) == 0 && cmdType == tmpDesc->cmdType)) {
			done=1;
		} else {
			//printf("- not this one \n");
			tmpDesc = tmpDesc->next;
		}
	}
	return tmpDesc;
}



/**
 * VSIS_get_command takes a command line as input and produces a command packet
 * if possible, based on the input line. It assumes the following:
 * the buffer contains one line of input.
 * Input format <keyword><?|=>[parameter list];
 * parameter_list ::= parameter [: parameter_list]
 * parameter ::= <STRING> <INTEGER> <LITERAL> <REAL>
 * notes: white space is removed unless they are in a string.
 * strings are marked by " or ' and can have escaped \" or \' in them
 * @param cmdPkt - if parsing is successful this will point to a filled in command structure
 * @param buf - assumes that we have a command in the buffer
 * @param bufLen - length of the "valid" characters in the buffer.
 * @return an error code
 */
int vsis_get_command(cmd_pkt_t **cmd, char *buf, int bufLen)
{
	int chRead;
	char keyword[VSIS_MAX_KEYWORD_SZ+1]; // big enough for any keyword
	int keyLen;                          // length of our keyword
	int bufIdx = 0;

	int done;
	int parNo;
	int maxPar;
	char *param[50];
	char  parBuf[50*255]; // space for our parameters;
	int paramLen[50];
	int cmdType;
	int numParams;     // the actual number of parameters in the call
	char *channelNo;
	int j;
#ifdef DEBUG_VERBOSE
	int k; // debug only
#endif
	cmd_desc_t *cmdDesc;
	cmd_pkt_t *cmdPkt;
	int buildRet; // return value from the build command

	// initialize variables
	keyword[0]  = 0; // make sure string is empty
	channelNo   = 0; // make sure it is null

	// make sure return value is set to null in case we need to abort
	*cmd = 0;

	// sanity check
	if(buf == 0)    return -VSIS_RET_UNKNOWN;
	if(bufLen == 0) return -VSIS_RET_UNKNOWN;

	// find the keyword
	chRead = vsis_get_keyword(keyword, &keyLen, buf, bufLen);
	if(chRead <=0 || keyLen <=0) return  -VSIS_RET_UNKNOWN;
	bufIdx = chRead;

	// Find the Command Type
	chRead = vsis_get_command_type(&cmdType, &buf[bufIdx], bufLen-bufIdx);
	if(chRead <=0) return -VSIS_RET_UNKNOWN;
	bufIdx += chRead; // increase index

	// find parameters
	parNo = 0;
	done  = 0;
	maxPar= 50;

	// need to make this a little nicer
	while(!done && parNo < maxPar) {
		param[parNo] = &(parBuf[parNo*255]); //Pointer to our buffer TODO: clean this up
		chRead = vsis_get_parameter( param[parNo], &paramLen[parNo], &buf[bufIdx], bufLen-bufIdx);
		if(chRead == 0) done=1;         // this is our valid command line return point;
		if(chRead < 0 ) return -VSIS_RET_SYNTAX_ERROR; //propagate the error upward
		if(chRead > 0 ) {              // we got a parameter
			bufIdx += chRead; // increase index
			parNo++;
		}
	}
	numParams = parNo;
	// Find our semicolon... this is implied by the end of the parameter parsing, so we will not need to look again

	// Now we have parameters ... see if we have some "channel" information as ending of the keyword
	j = strlen(keyword);
	while(j > 0 && isdigit(keyword[j-1])){
		j -= 1;
	}
	if(strlen(keyword) > j){
		// we have a number -- and it is valid
		channelNo = strdup(&keyword[j]); // copy string to a numeric string
		// remember to null terminate keyword with the shorter length
		keyword[j] = 0;
	}
#ifdef DEBUG_VERBOSE
	/*
	 * ***************************************************************************************
	 * Debug stuff
	 * ***************************************************************************************
	 */
	printf("Original String: %s \n", buf);
	printf("VSIS Parser Found:\n");
	printf("Keyword        = %s\n", keyword);
	printf("Command/Query  = %d\n", cmdType);
	if(channelNo) printf("Channel Number = %s\n", channelNo);
	printf("Num Param      = %d\n", parNo);
	for(k=0; k<parNo;k++){
		if(param[k]) printf("Param %2d      = %s\n", k, param[k]);
	}

	/*
	 * ***************************************************************************************
	 * END Debug stuff
	 * ***************************************************************************************
	 */
#endif

	// We have a Valid command line, see if we can find a command for it
	cmdDesc = vsis_cmd_find(keyword, cmdType);
#ifdef DEBUG_VERBOSE
	printf("cmd desc is %p, which is %lx\n", cmdDesc, (unsigned long)cmdDesc);
#endif
	if(cmdDesc == 0){
		printf("no command found for %s with type %d\n", keyword, cmdType);
		return -VSIS_RET_UNKNOWN;
	}
	// we found a command... let's see if we can parse the parameters for it
	buildRet = vsis_build_cmd(&cmdPkt, numParams, param, cmdDesc);
	if(buildRet != 0) {
		printf("Invalid parameters for command %s, usage: %s", keyword, cmdDesc->usageStr);
		return -VSIS_RET_PARAMETER_ERROR;
	}
	// at this point we have a command packet we can execute!!
	*cmd = cmdPkt; // assign our return value
	return 0;
}


/**
 * Command can be with fixed number of parameters "easiest format"
 * <command> [parameter list]
 * <name> <num parameters> [parameter type]
 * Macro can replace a parameter, but not a command
 * Command macro provide a list of commands
 *
 * Commands ALWAYS return a data buffer and a length
 *
 */
