/*
 * ioctl_util.h
 *
 *  Created on: Sep 25, 2009
 *      Author: mtaveniku @ XCube Communication Inc.
 *      License: GPL
 */

#ifndef IOCTL_UTIL_H_
#define IOCTL_UTIL_H_

/**
 * Device read command that interface to the IOCTL command of the RDBE driver.
 * This is a function that is intended to be used by the commands that need r/w access to hardware
 * on the device.
 * @param ioctlCmd -
 * @param access_type - data type 1, 2, or 4 bytes.
 * @param offset - starting offset of read - same alignment as datatype required
 * @param numWords - number of words to read
 * @param retBuf - buffer containing returned data
 * @return - 0 on success
 */
int util_dev_rd_cmd(int ioctlCmd, unsigned long accessType, unsigned long offset, unsigned long numWords, void *retBuf);

/**
 * Read number of access type words from FPGA at offset offset
 * @param offset - start address - must be aligned with the data type
 * @param accessType - 1, 2, or 4 byte WORDS
 * @param numWords - number of words of data type
 * @param retBuf - return data from operation
 * @return - 0 on success
 */
int util_read_fpga(unsigned accessType, unsigned long offset, unsigned long numWords, void *retBuf);

/**
 * Write number of access type words from FPGA at offset offset
 * @param offset - start address - must be aligned with the data type
 * @param accessType - 1, 2, or 4 byte WORDS
 * @param numWords - number of words of data type
 * @param retBuf - return data from operation
 * @return - 0 on success
 */
int util_write_fpga(unsigned long offset, unsigned accessType, unsigned long numWords, void *retBuf);

/**
 * Read number of words 16 bit from FPGA at offset offset
 * @param offset - address in FPGA
 * @param numWords
 * @param retBuf - returned buffer allocated by caller
 * @return - 0 on success
 */
int util_read_byte_fpga(unsigned long offset, unsigned long numWords, void *retBuf);

/**
 * Write number of words 8 bit to FPGA at offset offset
 * @param offset - address in FPGA
 * @param numWords
 * @param retBuf
 * @return - 0 on success
 */
int util_write_byte_fpga(unsigned long offset, unsigned long numWords, void *retBuf);

/**
 * Read number of words 16 bit words from FPGA at offset offset
 * @param offset - address in FPGA
 * @param numWords
 * @param retBuf
 * @return - 0 on success
 */
int util_read_short_fpga(unsigned long offset, unsigned long numWords, void *retBuf);

/**
 * Write number of words 16 bit to FPGA at offset offset
 * @param offset - address in FPGA
 * @param numWords
 * @param retBuf
 * @return - 0 on success
 */
int util_write_short_fpga(unsigned long offset, unsigned long numWords, void *retBuf);

/**
 * Read number of words 32 bit words from FPGA at offset offset
 * @param offset - address in FPGA
 * @param numWords
 * @param retBuf
 * @return - 0 on success
 */
int util_read_long_fpga(unsigned long offset, unsigned long numWords, void *retBuf);

/**
 * Write number of words 32 bit to FPGA at offset offset
 * @param offset - address in FPGA
 * @param numWords
 * @param retBuf
 * @return - 0 on success
 */
int util_write_long_fpga(unsigned long offset, unsigned long numWords, void *retBuf);

/**
 * Calls the RDBE driver for a ISR read
 * this routine hangs until an interrupt occurs in the FPGA
 * @return 0 on success
 */
int util_isr_rd(void);

#endif /* IOCTL_UTIL_H_ */
