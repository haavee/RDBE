/*
 * cmd_common.c
 *
 *  Created on: Jul 29, 2009
 *      Author: Mikael Taveniku XCube Communication Inc.
 *      License: GPL
 *      Description: Common commands that the rdbe_server understands.
 *      Note: These commands are currently not used (!!)
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
#include <linux/mman.h> // memory management things
#include <sys/mman.h>   //mmap
#include <dirent.h>  //To read directory entries



#include "rdbe_exports.h"     // device driver information access functions and types
#include "cmd_parser.h"
#include "serv_storage.h"

extern int serv_rdbe_ioctl(int funNo, char*arg); // defined in server main for now
extern int serv_get_data(int bufNo, unsigned long length); // defined in server_main

/**
 * Internal routines
 */



/* *******************************************************************************************************
 * Read and Write functions to the devices
 * *******************************************************************************************************
 */


/*
 *  description of fpga_read command
 *  Reads a set number of words from the FPGA device
 *  Name = fpga_rd
 *  Parameters:
 *  access_type access;
 *  unsigned long offset;
 *  unsigned long number_words;
 *  function fpga_rd_cmd; // in cmd_common
 */


/**
 * Struct to that hold parameters for the device read commands.
 */
typedef struct dev_rd_cmd {
	unsigned long *access_type; // 1, 2, or 4 bytes per word
	unsigned long *offset;   // start address from start of device memory
	unsigned long *numWords; // number of access type words to read
} dev_rd_cmd_t;


/**
 * Device read command that interface to the IOCTL command of the RDBE driver.
 * This is a function that is intended to be used by the commands that need r/w access to hardware
 * on the device.
 * @param ioctlCmd -
 * @param argc - number of arguments in argv.
 * @param argv - [0]=accessType, [1]=offset, [2]=length
 * @param retVal - buffer containing returned data
 * @param retLen - length of returned data
 * @return - 0 on success
 */
int dev_rd_cmd(int ioctlCmd, int argc, void **argv, void **retVal, int *retLen)
{
  int i;
  char *retBuf, *tmpBuf;
  
  rdbe_rdwr_cmd_t cmd; // command to send
  dev_rd_cmd_t *devCmd;

  printf("dev_rd called with argc=%d, argv=%p Device=%d \n", argc, argv, ioctlCmd);
  printf("argv  0=%p, 1=%p, 2=%p\n", argv[0],argv[1], argv[2]);
  printf("Deref 0=%lu, 1=%lu, 2=%lu\n", *(unsigned long*)argv[0],*(unsigned long*)argv[1], *(unsigned long*)argv[2]);
  
  devCmd = (dev_rd_cmd_t*)argv;  // we know the parser has done its job right -- or we are SOL
  
  cmd.access_type = *devCmd->access_type;
  cmd.len = *devCmd->numWords;
  cmd.ofs = *devCmd->offset;
  cmd.buf = (void *) malloc(cmd.len * cmd.access_type);
  
  printf("\nCalling ioctl with DEV=%d CMD=%d ParPtr=%p, BUFPtr=%p Length=%lu \n", 0, ioctlCmd, &cmd, cmd.buf, cmd.len);
  serv_rdbe_ioctl(ioctlCmd, (char *)&cmd);
  // temporary for debug purposes, we are returning readable words instead of the actual data
  retBuf = (char*) malloc(cmd.len * ((cmd.access_type * 2) +1));
  tmpBuf = (char*)cmd.buf;
  
  switch(cmd.access_type){
  case 1:
    for(i=0; i<cmd.len; i++){
      sprintf(&retBuf[3*i],"%02x ", (unsigned char)tmpBuf[i]);
    }
    break;
  case 2:
    for(i=0; i<cmd.len; i++){
      sprintf(&retBuf[5*i],"%04x ", *(unsigned short *)(tmpBuf + 2*i));
    }
    break;
  case 4:
    for(i=0; i<cmd.len; i++){
      sprintf(&retBuf[9*i],"%08lx ", *(unsigned long*)(tmpBuf + 4*i));
    }
    break;
  default:
    printf("ERROR");
  }
  *retVal = retBuf;
  *retLen = cmd.len * ((cmd.access_type * 2) +1); //number of bytes in return packet
  
  //	*retVal = cmd.buf;
  //	*retLen = cmd.len * cmd.access_type; //number of bytes in return packet
  if (cmd.buf)
    free(cmd.buf);
  return 0; // all went well
}

/**
 * Structure used for the write one data command.
 * here for convenience
 */
typedef struct dev_wr1_cmd {
	unsigned long *access_type; // 1, 2, or 4 bytes per word
	unsigned long *offset;      // start address from start of device memory
	unsigned long *theWord;     // the word to write
} dev_wr1_cmd_t;


/**
 * Write one word of access type data to the address specified by ioctlCmd and offset
 * @param ioctlCmd - where to write the datum
 * @param argc - number of arguments in argv (3)
 * @param argv - [0] accessType, [1] offset, [2] data
 * @param retVal - null
 * @param retLen - 0
 * @return - 0 on success
 */
int dev_wr1_cmd(int ioctlCmd, int argc, void **argv, void **retVal, int *retLen)
{
	rdbe_rdwr_cmd_t cmd; // command to send
	dev_wr1_cmd_t *devCmd;
	unsigned long val; // value to write to the device

	printf("dev_wr1 called with argc=%d, argv=%p Device=%d \n", argc, argv, ioctlCmd);
	printf("argv  0=%p, 1=%p, 2=%p\n", argv[0],argv[1], argv[2]);
	printf("Deref 0=%lu, 1=%lu, 2=%lu\n", *(unsigned long*)argv[0],*(unsigned long*)argv[1], *(unsigned long*)argv[2]);

	devCmd = (dev_wr1_cmd_t*)argv;  // we know the parser has done its job right -- or we are SOL

	cmd.access_type = *devCmd->access_type;
	cmd.ofs  = *devCmd->offset;
	cmd.len  = 1;
	cmd.buf  = &val;

	switch(cmd.access_type){
	case 1:
		val = (unsigned char)*devCmd->theWord;
		break;
	case 2:
		val = (unsigned short)*devCmd->theWord;
		break;
	case 4:
		val = (unsigned long)*devCmd->theWord;
		break;
	default:
		val = 0;
	}

	printf("\nCalling ioctl with DEV=%d CMD=%d ParPtr=%p, BUFPtr=%p Length=%lu \n", 0, ioctlCmd, &cmd, cmd.buf, cmd.len);
	serv_rdbe_ioctl(ioctlCmd, (char *)&cmd);

	*retVal = 0;
	*retLen = 0; //number of bytes in return packet
	return 0; // all went well
}


/**
 * Read a number of bytes from the FPGA device
 * @param argc   - should be 3 <access_type> <offset> <number of byte>
 * @param argv   - pointers to the parameters
 * @param retVal - buffer with the data
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int fpga_rd_cmd(int argc, void **argv, void **retVal, int *retLen)
{
	return dev_rd_cmd(RDBE_FPGA_READ, argc, argv, retVal, retLen);
}


/**
 * Insert the fpga read command into command queue.
 */
void insert_fpga_rd(void)
{
	char *name = "fpga_rd";
	char *usage= "fpga_rd <access type> offset length";
	int nParams = 3;
	int cmdType = CMD_MONITOR;
	int paramTypes[3] = {CMD_PARAM_ACCESSTYPE, CMD_PARAM_UNSIGNEDLONG, CMD_PARAM_UNSIGNEDLONG};
	cmd_insert_cmd_desc(name, usage, nParams, paramTypes, fpga_rd_cmd, cmdType);
}

/**
 * Read a number of bytes from the smap device
 * @param argc   - should be 3 <access_type> <offset> <number of byte>
 * @param argv   - pointers to the parameters
 * @param retVal - buffer with the data
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int smap_rd_cmd(int argc, void **argv, void **retVal, int *retLen)
{
	return dev_rd_cmd(RDBE_SMAP_READ, argc, argv, retVal, retLen);
}

/**
 * Insert the smap read command into command queue.
 */
void insert_smap_rd(void)
{
	char *name = "smap_rd";
	char *usage= "smap_rd <access type> offset length";
	int nParams = 3;
	int cmdType = CMD_MONITOR;
	int paramTypes[3] = {CMD_PARAM_ACCESSTYPE, CMD_PARAM_UNSIGNEDLONG, CMD_PARAM_UNSIGNEDLONG};
	cmd_insert_cmd_desc(name, usage, nParams, paramTypes, smap_rd_cmd, cmdType);
}

/**
 * Read a number of bytes from the CPLD device
 * @param argc   - should be 3 <access_type> <offset> <number of byte>
 * @param argv   - pointers to the parameters
 * @param retVal - buffer with the data
 * @param retLen - length of buffer in BYTES
 * @return       - 0 on success
 */
int cpld_rd_cmd(int argc, void **argv, void **retVal, int *retLen)
{
	return dev_rd_cmd(RDBE_CPLD_READ, argc, argv, retVal, retLen);
}

/**
 * Insert the smap read command into command queue.
 */
void insert_cpld_rd(void)
{
	char *name = "cpld_rd";
	char *usage= "cpld_rd <access type> offset length";
	int nParams = 3;
	int cmdType = CMD_MONITOR;
	int paramTypes[3] = {CMD_PARAM_ACCESSTYPE, CMD_PARAM_UNSIGNEDLONG, CMD_PARAM_UNSIGNEDLONG};
	cmd_insert_cmd_desc(name, usage, nParams, paramTypes, cpld_rd_cmd, cmdType);
}


/*  ***************************************************************************************
 *  WRITE COMMANDS
 *  ***************************************************************************************
 */

/**
 * Write a word of access type to the device at offset
 * @param argc   - should be 3 <access_type> <offset> <word to write>
 * @param argv   - pointers to the parameters
 * @param retVal - buffer with the data (none today)
 * @param retLen - length of buffer in BYTES (0 today)
 * @return       - 0 on success
 */
int fpga_wr1_cmd(int argc, void **argv, void **retVal, int *retLen)
{
	return dev_wr1_cmd(RDBE_FPGA_WRITE, argc, argv, retVal, retLen);
}

/**
 * Insert the smap read command into command queue.
 */
void insert_fpga_wr1(void)
{
	char *name = "fpga_wr";
	char *usage= "fpga_wr <access type> offset datum";
	int nParams = 3;
	int cmdType = CMD_MONITOR;
	int paramTypes[3] = {CMD_PARAM_ACCESSTYPE, CMD_PARAM_UNSIGNEDLONG, CMD_PARAM_UNSIGNEDLONG};
	cmd_insert_cmd_desc(name, usage, nParams, paramTypes, fpga_wr1_cmd, cmdType);
}

/**
 * Write a word of access type to the device at offset
 * @param argc   - should be 3 <access_type> <offset> <word to write>
 * @param argv   - pointers to the parameters
 * @param retVal - buffer with the data (none today)
 * @param retLen - length of buffer in BYTES (0 today)
 * @return       - 0 on success
 */
int cpld_wr1_cmd(int argc, void **argv, void **retVal, int *retLen)
{
	return dev_wr1_cmd(RDBE_CPLD_WRITE, argc, argv, retVal, retLen);
}

/**
 * Insert the smap read command into command queue.
 */
void insert_cpld_wr1(void)
{
	char *name = "cpld_wr";
	char *usage= "cpld_wr <access type> offset datum";
	int nParams = 3;
	int cmdType = CMD_MONITOR;
	int paramTypes[3] = {CMD_PARAM_ACCESSTYPE, CMD_PARAM_UNSIGNEDLONG, CMD_PARAM_UNSIGNEDLONG};
	cmd_insert_cmd_desc(name, usage, nParams, paramTypes, cpld_wr1_cmd, cmdType);
}
/**
 * Write a word of access type to the device at offset
 * @param argc   - should be 3 <access_type> <offset> <word to write>
 * @param argv   - pointers to the parameters
 * @param retVal - buffer with the data (none today)
 * @param retLen - length of buffer in BYTES (0 today)
 * @return       - 0 on success
 */
int smap_wr1_cmd(int argc, void **argv, void **retVal, int *retLen)
{
	return dev_wr1_cmd(RDBE_SMAP_WRITE, argc, argv, retVal, retLen);
}

/**
 * Insert the smap write command into command queue.
 */
void insert_smap_wr1(void)
{
	char *name = "smap_wr";
	char *usage= "smap_wr <access type> offset datum";
	int nParams = 3;
	int cmdType = CMD_MONITOR;
	int paramTypes[3] = {CMD_PARAM_ACCESSTYPE, CMD_PARAM_UNSIGNEDLONG, CMD_PARAM_UNSIGNEDLONG};
	cmd_insert_cmd_desc(name, usage, nParams, paramTypes, smap_wr1_cmd, cmdType);
}


/**
 * Programs the FPGA given a filename pointing to a FPGA bit file
 * @param argc 1
 * @param argv - argv[0] "full or relative path to the bin file to load"
 * @param retVal - return buffer in VSIS format
 * @param retLen  - length of return buffer
 * @return 0 on success
 */
int fpga_prg_cmd(int argc, void **argv, void **retVal, int *retLen)
{
	int inFile;
	int funRet;
	void *bitFilePtr;
	struct stat fileStat;
	rdbe_configure_cmd_t cmdPar;

	funRet = 0; // all ok

	// open file
	if ((inFile = open((char*)argv[0], O_RDWR))) {
		// get length and map file to virtual memory
		if (fstat(inFile, &fileStat) >= 0) {
			bitFilePtr = mmap(0, fileStat.st_size, (PROT_READ|PROT_WRITE), MAP_SHARED, inFile, 0);
			if (bitFilePtr) {
				cmdPar.buf = bitFilePtr;
				cmdPar.len = fileStat.st_size;
				funRet = serv_rdbe_ioctl(RDBE_DEV_CONFIGURE, (char *) &cmdPar);
			} else {
				printf("Error - could not MMAP file desc %d\n", inFile );
				funRet = -1;
			}
		} else {
			printf("Could not get file status on %s error\n", (char*)argv[0]);
			funRet = -1;
		}
	} else {
		printf("Failed to open \" %s \" for reading", (char*)argv[0]);
		funRet = -1;
	}
	if(inFile) close(inFile); // close file and cleanup
	*retLen = strlen( (char*)retVal );
	return funRet;
}


void insert_fpga_prg(void)
{
	char *name = "fpga_prg";
	char *usage= "fpgarg file_name";
	int nParams = 1;
	int cmdType = CMD_MONITOR;
	int paramTypes[1] = {CMD_PARAM_STRING};
	cmd_insert_cmd_desc(name, usage, nParams, paramTypes, fpga_prg_cmd, cmdType);
}

/**
 * Upload data from the client to the server and put it in a specific buffer.
 * @param argc
 * @param argv
 * @param retVal
 * @param retLen
 * @return
 */
int data_upload(int argc, void **argv, void **retVal, int *retLen)
{
	char *bufName;
	unsigned long  bufNo;
	unsigned long  dataLen;
	int funRet;

	funRet = 0;
	bufName = (char*)argv[0];
	if(((strlen(bufName) > 0)) && (strcmp(bufName,"BUF") == 0)){
		bufNo = *(unsigned long*)argv[1];
		if(bufNo <2 ) {
			dataLen = *(unsigned long*)argv[2];
			if(dataLen < 0x01600000){  //TODO: fix this
				printf("Uploading data to buffer %lu with %lu bytes\n", bufNo, dataLen);
				// store the next set of data in memory buffer x
				funRet = serv_get_data(bufNo, dataLen);
			}
		}
	}
	return funRet;
}


void insert_data_upload(void)
{
	char *name = "upload"; // usage upload <BUF 0 | BUF 1> <num bytes>
	char *usage= "upload BUF <0..9> <number_of_bytes>";
	int nParams = 3;
	int cmdType = CMD_MONITOR;
	int paramTypes[3] = {CMD_PARAM_STRING, CMD_PARAM_UNSIGNEDLONG, CMD_PARAM_UNSIGNEDLONG};
	cmd_insert_cmd_desc(name, usage, nParams, paramTypes, data_upload, cmdType);
}

/**
 * Programs the FPGA given a memory buffer
 * @param argc
 * @param argv
 * @param retVal
 * @param retLen
 * @return
 */
int fpga_prg_buf_cmd(int argc, void **argv, void **retVal, int *retLen)
{
	int funRet;
	unsigned long bufNo;
	rdbe_configure_cmd_t cmdPar;

	funRet = 0; // all ok
	bufNo = *(unsigned long*)argv[1];
	printf("fpga_prg called with %s = %lu \n", (char*)argv[0], bufNo);
	cmdPar.buf = ss_get_buf(pthread_self(), bufNo);
	cmdPar.len = ss_get_buf_len(pthread_self(), bufNo);
	if(cmdPar.len > 0 && cmdPar.buf > 0) {
		printf(	"\nrdbe_ioctl CONFIGURE ParPtr=%p, BufPtr=%p Length=%lu \n", (void*) &cmdPar, cmdPar.buf, cmdPar.len);
		funRet = serv_rdbe_ioctl(RDBE_DEV_CONFIGURE, (char *) &cmdPar);
	} else {
		funRet = -1;
		printf("Error - fpga_prg BUF with Buf %p and len %lu\n", cmdPar.buf, cmdPar.len);
	}
	*retLen = 0;
	*retVal = 0;
	return funRet;
}


void insert_fpga_prg_buf(void)
{
	char *name = "fpga_prg";
	char *usage= "fpga_prg  BUF <0..9> <num bytes>";
	int nParams = 3;
	int cmdType = CMD_MONITOR;
	int paramTypes[3] = {CMD_PARAM_STRING, CMD_PARAM_UNSIGNEDLONG, CMD_PARAM_UNSIGNEDLONG};
	cmd_insert_cmd_desc(name, usage, nParams, paramTypes, fpga_prg_buf_cmd, cmdType);
}



/**
 * Initializes command lists with basic command set
 */
void cmd_common_initialize_cmd(void)
{
	insert_fpga_rd();
	insert_smap_rd();
	insert_cpld_rd();
	insert_fpga_wr1();
	insert_fpga_prg();
	insert_data_upload();
	insert_fpga_prg_buf();
};
