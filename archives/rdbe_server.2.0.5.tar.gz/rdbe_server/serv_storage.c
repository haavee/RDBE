/*
 * serv_storage.c
 *
 *  Created on: Aug 1, 2009
 *      Author: Mikael Taveniku XCube Communication Inc.
 *      License: GPL
 *      Description: Provides a per thread storage facility for RDBE server.
 */

#include <stdlib.h>

#include "serv_storage.h"


#define SERV_STORAGE_MAX_SZ 0x01600000l
#define SERV_STORAGE_MAX_TID 255
#define SERV_STORAGE_MAX_BUF 1024

typedef struct ss_storage {
	pthread_t tId; //id of thread who owns this buffer 0 if free
	unsigned char *bPtr; // pointer to data buffer 0 if free
	unsigned long len;   // length of buffer 0 if free or invalid
	unsigned long bufNo; // buffer number for the thread
} ss_storage_t;

/** internal storage buffers for all threads */
ss_storage_t serv_storage[SERV_STORAGE_MAX_BUF];

/**
 * Allocates a buffer of size X at storage position bufNo
 * No check is made for multiple allocations of the same storage!
 * @param tId
 * @param bufNo
 * @param len
 * @return
 */
unsigned char *ss_allocate_buf(pthread_t tId, unsigned long bufNo, unsigned long len)
{
	int i;
	for(i=0; i<SERV_STORAGE_MAX_BUF; i++){
		if(serv_storage[i].tId == 0 ){
			serv_storage[i].bPtr = (unsigned char*) malloc(len);

			if(serv_storage[i].bPtr) {
				serv_storage[i].len   = len;
				serv_storage[i].bufNo = bufNo;
				serv_storage[i].tId   = tId;
				return serv_storage[i].bPtr;   // return the buffer we found
			} else {
				serv_storage[i].bPtr  = 0;
				serv_storage[i].len   = 0;
				serv_storage[i].bufNo = 0;
				serv_storage[i].tId   = 0;
			}
		}
	}
	return 0;
}

/**
 * Get the buffer allocated for thread tId and position bufNo
 * @param tId - thread id
 * @param bufNo - buffer number
 * @return the buffer or 0 if not found
 */
unsigned char *ss_get_buf(pthread_t tId, unsigned long bufNo)
{
	int i;
	for(i=0; i<SERV_STORAGE_MAX_BUF; i++){
		if(serv_storage[i].tId == tId && (serv_storage[i].bufNo == bufNo)){
			return serv_storage[i].bPtr;
		}
	}
	return 0;

}

/**
 * Get the length of a the buffer for tId at position bufNo
 * @param tId - thread id
 * @param bufNo - buffer number
 * @return - length of buffer or 0 on error
 */
unsigned long ss_get_buf_len(pthread_t tId, unsigned long bufNo)
{
	int i;
	for(i=0; i<SERV_STORAGE_MAX_BUF; i++){
		if(serv_storage[i].tId == tId && (serv_storage[i].bufNo == bufNo)){
			return serv_storage[i].len;
		}
	}
	return 0;
}

/**
 * Initialize server storage structures must be the first call to the module
 * @return 0 if successful
 */
int ss_init(void)
{
	int i;
	for(i=0; i<SERV_STORAGE_MAX_BUF; i++){
		serv_storage[i].bPtr  = 0;
		serv_storage[i].len   = 0;
		serv_storage[i].bufNo = 0;
		serv_storage[i].tId   = 0;
	}
	return 0;
}

/**
 * Free a specific memory buffer (return it to the system)
 * @param tId - thread id
 * @param bufNo - buffer number
 * @return - 0 on success
 */
int ss_free_buf(pthread_t tId, unsigned long bufNo)
{
	int i;
	for(i=0; i<SERV_STORAGE_MAX_BUF; i++){
		if(serv_storage[i].tId == tId && (serv_storage[i].bufNo == bufNo)){
			if(serv_storage[i].bPtr) free(serv_storage[i].bPtr); // return memory to system
			serv_storage[i].bPtr  = 0;
			serv_storage[i].len   = 0;
			serv_storage[i].bufNo = 0;
			serv_storage[i].tId   = 0;
			return 0;
		}
	}
	return 0;
}

/**
 * Return all allocated memory to the system
 * @return 0 on success
 */
int ss_free_all(void)
{
	int i;
	for(i=0; i<SERV_STORAGE_MAX_BUF; i++){
		if(serv_storage[i].bPtr) free(serv_storage[i].bPtr); // return memory to system
		serv_storage[i].bPtr  = 0;
		serv_storage[i].len   = 0;
		serv_storage[i].bufNo = 0;
		serv_storage[i].tId   = 0;
	}
	return 0;
}
