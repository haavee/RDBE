/*
 * hal.c
 *
 *  Created on: Sep 24, 2009
 *      Author: Mikael Taveniku XCube Communication inc.
 *
 *  Hichem Ben Frej: changes in supoort of PFBG & DDC.
 */

#include "hal.h"
#include "ioctl_util.h"  // read and write functions for devices
#include <stdio.h>
#include <stdlib.h>
#include <math.h>


#define VDIF_START_ADDR                  0x0800000
#define VDIF_SYNC_WORD_1_OFFSET          0x0
#define VDIF_SYNC_WORD_2_OFFSET          0x2

#define VDIF_REF_EPOCH_OFFSET            0x4
#define VDIF_EPOCH_SECS_OFFSET           0x210

#define VDIF_EPOCH_SECS_READ_OFFSET      0x208

#define VDIF_LEGACY_OFFSET               0x6
#define VDIF_STATION_ID_OFFSET           0x8
#define VDIF_DBE_NUM_OFFSET              0xA
#define VDIF_DEBUG_OFFSET                0xC
#define VDIF_DEBUG_STAT_OFFSET           0xE
#define VDIF_DTM_STATUS_OFFSET           0x12
#define VDIF_TIME_SLOT_ON_LSB_OFFSET     0x14
#define VDIF_TIME_SLOT_ON_MSB_OFFSET     0x16
#define VDIF_TIME_SLOT_OFF_LSB_OFFSET    0x18
#define VDIF_TIME_SLOT_OFF_MSB_OFFSET    0x1A
#define VDIF_TIME_ALIGN_OFFSET           0x1C

#define VDIF_SELECT_INPUT_OFFSET         0x214
#define VDIF_LOG_2_NUM_CHAN_OFFSET       0x216

/* LOIF Frequency Tuning word */

#define VDIF_LOIF_DC0_LSB_OFFSET         0x100
#define VDIF_LOIF_DC0_MSB_OFFSET         0x102
#define VDIF_LOIF_DC1_LSB_OFFSET         0x104
#define VDIF_LOIF_DC1_MSB_OFFSET         0x106
#define VDIF_LOIF_DC2_LSB_OFFSET         0x108
#define VDIF_LOIF_DC2_MSB_OFFSET         0x10A
#define VDIF_LOIF_DC3_LSB_OFFSET         0x10C
#define VDIF_LOIF_DC3_MSB_OFFSET         0x10E

#define VDIF_SAMPLE_0_RATE_UNIT_OFFSET   0x120
#define VDIF_SAMPLE_0_RATE_OFFSET        0x122
#define VDIF_SAMPLE_1_RATE_UNIT_OFFSET   0x124
#define VDIF_SAMPLE_1_RATE_OFFSET        0x126
#define VDIF_SAMPLE_2_RATE_UNIT_OFFSET   0x128
#define VDIF_SAMPLE_2_RATE_OFFSET        0x12A
#define VDIF_SAMPLE_3_RATE_UNIT_OFFSET   0x12C
#define VDIF_SAMPLE_3_RATE_OFFSET        0x12E

#define VDIF_SAMPLE_0_1_OFFSET           0x140
#define VDIF_SAMPLE_2_3_OFFSET           0x142
#define VDIF_SAMPLE_4_5_OFFSET           0x144
#define VDIF_SAMPLE_6_7_OFFSET           0x146


#define VDIF_IF0_3_OFFSET                0x148 /* IF3(15..12), IF2(11..8), IF1(7..4), IF0(3..0) */
#define VDIF_IF4_7_OFFSET                0x14A /* IF7(15..12), IF6(11..8), IF5(7..4), IF4(3..0) */

#define VDIF_SB0_3_OFFSET                0x14C /* SB3(15..12), SB2(11..8), SB1(7..4), SB0(3..0) */
#define VDIF_SB4_7_OFFSET                0x14E /* SB7(15..12), SB6(11..8), SB5(7..4), SB4(3..0) */

#define VDIF_THREAD_ID_0_OFFSET          0x160
#define VDIF_THREAD_ID_1_OFFSET          0x162
#define VDIF_THREAD_ID_2_OFFSET          0x164
#define VDIF_THREAD_ID_3_OFFSET          0x166
#define VDIF_THREAD_ID_4_OFFSET          0x168
#define VDIF_THREAD_ID_5_OFFSET          0x16A
#define VDIF_THREAD_ID_6_OFFSET          0x16C
#define VDIF_THREAD_ID_7_OFFSET          0x16E

#define VDIF_COMPLEX_FLAG_OFFSET         0x200
#define VDIF_ESIDE_BAND_OFFSET           0x202



/**
 * Convert a fractional number, represented in a 32 bit word with 0 padded at the end to a double precision floating point
 * The routine returns 0 on success or an error code otherwise
 * @param dbl - the return value
 * @param num - the input fractional
 * @param nBits - the number of significant bits (0 .. 32)
 * @param dotPos - the position of the decimal point 0 .. 31
 * @return 0 on success
 */
int lsb_pad_frac2dbl(double *dbl, long num, unsigned nBits, unsigned dotPos )
{
	long mask = -1;  // 0xFFFF FFFF

	// check parameters
	if(nBits > 32 || nBits < dotPos || nBits < 1) {
		*dbl=0.0;
		return -1; // parameter error
	}
	num = num >> (32 - nBits); // get rid of the padding at the LSB
	//	num = num & (~(mask << nBits));  // clear the top bits from garbage
	if(num & (1<<(nBits-1))) {
		// negative number so we need to sign extend
		num = num | (mask << nBits);
	}
	*dbl = (double) num;
	// take care of the fraction
	*dbl = *dbl / (double)((unsigned long)1 << dotPos);
	return 0;
}

/**
 * Convert a double floating point number to a decimal number with nBits significant bits
 * and with the decimal point in bit-position dotPos.
 * The routine will do best effort to convert the double to a valid fractional representation
 * and will convert it to maximum allowed value if the input is out of bounds.
 * @param num - return value 0 on errors, otherwise a 32-bit integer representing the double
 * @param nBits - Number of valid bits in the Number [1..32]
 * @param dotPos - Position of the decimal point [0..31]
 * @param dbl - the number to convert
 * @return - 0 on success
 */
int lsb_pad_dbl2frac(long *num, unsigned nBits, unsigned dotPos, double dbl )
{
	double maxNum, maxNeg;
	// check parameters
	if(nBits > 32 || nBits < dotPos || nBits < 1) {
		*num=0;
		return -1; // parameter error
	}
	dbl = dbl * (1<<dotPos); // adjust for the decimal point position multiply with 2^(decimal position)
	maxNum = (double)(1 << (nBits-1)) - 1 ;  // 2^(n-1)-1 - two's complement
	maxNeg = (double) -(1 << (nBits-1));     // (-)2^(n-1)
	if(dbl >= maxNum) dbl=maxNum;
	if(dbl <= maxNeg) dbl=maxNeg;
	//We now know we can convert the thing to our internal format
	*num = (long)(dbl + 0.5); // round it to nearest number
	*num = *num << (32-nBits);
	return 0;
}



/**
 * Convert a fractional number, represented in a 32 bit word to a double precision floating point
 * The routine returns 0 on success or an error code otherwise
 * @param dbl - the return value
 * @param num - the input fractional
 * @param nBits - the number of significant bits (0 .. 32)
 * @param dotPos - the position of the decimal point 0 .. 31
 * @return 0 on success
 */
int frac2dbl(double *dbl, long num, unsigned nBits, unsigned dotPos )
{
	long mask = -1;  // 0xFFFF FFFF
	// check parameters
	if(nBits > 32 || nBits < dotPos || nBits < 1) {
		*dbl=0.0;
		return -1; // parameter error
	}
	num = num & (~(mask << nBits));  // clear the top bits from garbage
	if(num & (1<<(nBits-1))) {
		// negative number so we need to sign extend
		num = num | (mask << nBits);
	}
	*dbl = (double) num;
	// take care of the fraction
	*dbl = *dbl / (double)((unsigned long)1 << dotPos);
	return 0;
}

/**
 * Convert a double floating point number to a decimal number with nBits significant bits
 * and with the decimal point in bit-position dotPos.
 * The routine will do best effort to convert the double to a valid fractional representation
 * and will convert it to maximum allowed value if the input is out of bounds.
 * @param num - return value 0 on errors, otherwise a 32-bit integer representing the double
 * @param nBits - Number of valid bits in the Number [1..32]
 * @param dotPos - Position of the decimal point [0..31]
 * @param dbl - the number to convert
 * @return - 0 on success
 */
int dbl2frac(long *num, unsigned nBits, unsigned dotPos, double dbl )
{
	double maxNum, maxNeg;
	// check parameters
	if(nBits > 32 || nBits < dotPos || nBits < 1) {
		*num=0;
		return -1; // parameter error
	}
	dbl = dbl * (1<<dotPos); // adjust for the decimal point position multiply with 2^(decimal position)
	maxNum = (double)(1 << (nBits-1)) - 1 ;  // 2^(n-1)-1 - two's complement
	maxNeg = (double) -(1 << (nBits-1));     // (-)2^(n-1)
	if(dbl >= maxNum) dbl=maxNum;
	if(dbl <= maxNeg) dbl=maxNeg;
	//We now know we can convert the thing to our internal format
	*num = (long)(dbl + 0.5); // round it to nearest number
	return 0;
}



/**
 * Get the HAL software version and description
 * @param major - return parameter
 * @param minor - return parameter
 * @param description - textual version of version
 * @return - 0 on success
 */
int hal_sw_get_version(int *major, int *minor, char **description)
{
	*major = HAL_VERSION_MAJOR;
	*minor = HAL_VERSION_MINOR;
	*description = HAL_DESCRIPTION;
	return 0;
}

/*
 * FPGA hardware access functions based on Interface Command Document for VLBI Roach design
 */
#define FPGA_CONTROL_REG_BASE 0x08  /* --- CAR - diff from working version is write_fpga(0x8,1,&val) */
#define FPGA_STATUS_REG_BASE  0x0E
/*
 * Top Level Control  Registers
 */
/**
 * Set the value of fpga control register regNo [0..3]
 * @param regNo - the register to access
 * @param value - the value to set
 * @return - 0 if successful
 */
int fpga_set_control_reg( int regNo, unsigned short value)
{
	util_write_short_fpga(FPGA_CONTROL_REG_BASE + 2 * regNo, 1, &value);
	return 0;
}

/**
 * Read the value of a specific control register, return it in value
 * @param regNo - the register to read [0..3]
 * @param value - return value of the function
 * @return - 0 if success
 */
int fpga_get_control_reg( int regNo, unsigned short *value)
{
	util_read_short_fpga(FPGA_CONTROL_REG_BASE + 2 * regNo, 1, value);
	return 0;
}

// --------------------------------------------------------------------------------------------------------
//
//                  Helper functions for setting functions in the fpga
//
// Bit field definitions
//
// Control Reg
// Bit 0 – Arm – synchronizes to the external 1 pps.
// Bit 1 – adc 3 wire reload, reloads the control data for to the ADC.
// Bit 2 – ctrl reset, reset to the ADC board.
// Bit 3 – Enable FIR filter 1, enable the FIR filter module
// Bit 4 – Enable FFT, enables the FFT module
// Bit 5 – dcm reset. Resets the DCM use to for managing the ADC clock.
// Bit 6 – Enable Interpolator, enables the Interpolator module
// Bit 7 – Enable Mk5BInterface,  enables the Mk5B interface module
// --------------------------------------------------------------------------------------------------------

/**
 * Arm the fpga, -- synchronize on next 1pps
 * @return - 0
 */
int fpga_arm(void)
{
	unsigned short value;
	// read the value of control register
	util_read_short_fpga(FPGA_CONTROL_REG_BASE, 1, &value);
	value |= 0x01; // set bit 0 in the word
	// write it back to the register
	util_write_short_fpga(FPGA_CONTROL_REG_BASE, 1, &value);
	return 0;
}

/**
 * clear fpga arm flag
 * @return - 0 on success
 */
int fpga_arm_clear(void)
{
	unsigned short value;
	// read the value of control register
	util_read_short_fpga(FPGA_CONTROL_REG_BASE, 1, &value);
	value &= 0xFFFE; // clear bit 0 in the word
	// write it back to the register
	util_write_short_fpga(FPGA_CONTROL_REG_BASE, 1, &value);
	return 0;
}
/**
 * reload ADC control registers
 * @return
 */
int fpga_adc_reload(void)
{
	unsigned short value;
	// read the value of control register
	util_read_short_fpga(FPGA_CONTROL_REG_BASE, 1, &value);
	value |= 0x02; // set bit 1 in the word
	// write it back to the register
	util_write_short_fpga(FPGA_CONTROL_REG_BASE, 1, &value);
	return 0;
}

/**
 * Clear ADC reload flag
 * @return - 0 on success
 */
int fpga_adc_reload_clear(void)
{
	unsigned short value;
	// read the value of control register
	util_read_short_fpga(FPGA_CONTROL_REG_BASE, 1, &value);
	value &= ~0x02; // clear bit 1 in the word
	// write it back to the register
	util_write_short_fpga(FPGA_CONTROL_REG_BASE, 1, &value);
	return 0;
}
/**
 * Reset the ADC block
 * @return - 0 on success
 */
int fpga_adc_reset(void)
{
	unsigned short value;
	// read the value of control register
	util_read_short_fpga(FPGA_CONTROL_REG_BASE, 1, &value);
	value |= 0x04; // set bit 2 in the word
	// write it back to the register
	util_write_short_fpga(FPGA_CONTROL_REG_BASE, 1, &value);
	return 0;
}

/**
 * Clear ADC reset flag
 * @return
 */
int fpga_adc_reset_clear(void)
{
	unsigned short value;
	// read the value of control register
	util_read_short_fpga(FPGA_CONTROL_REG_BASE, 1, &value);
	value &= ~0x04; // clear bit 2 in the word
	// write it back to the register
	util_write_short_fpga(FPGA_CONTROL_REG_BASE, 1, &value);
	return 0;
}
/**
 * Enable the FIR filter block
 * @return - 0 on success
 */
int fpga_fir_enable(void)
{
	unsigned short value;
	// read the value of control register
	util_read_short_fpga(FPGA_CONTROL_REG_BASE, 1, &value);
	value |= 0x08; // set bit 3 in the word
	// write it back to the register
	util_write_short_fpga(FPGA_CONTROL_REG_BASE, 1, &value);
	return 0;
}

/**
 * Disable FIR filter block
 * @return - 0 on success
 */
int fpga_fir_disable(void)
{
	unsigned short value;
	// read the value of control register
	util_read_short_fpga(FPGA_CONTROL_REG_BASE, 1, &value);
	value &= ~0x08; // clear bit 3 in the word
	// write it back to the register
	util_write_short_fpga(FPGA_CONTROL_REG_BASE, 1, &value);
	return 0;
}
/**
 * Enable the FFT block
 * @return - 0 on success
 */
int fpga_fft_enable(void)
{
	unsigned short value;
	// read the value of control register
	util_read_short_fpga(FPGA_CONTROL_REG_BASE, 1, &value);
	value |= 0x10; // set bit 4 in the word
	// write it back to the register
	util_write_short_fpga(FPGA_CONTROL_REG_BASE, 1, &value);
	return 0;
}

/**
 * Disable FFT block
 * @return
 */
int fpga_fft_disable(void)
{
	unsigned short value;
	// read the value of control register
	util_read_short_fpga(FPGA_CONTROL_REG_BASE, 1, &value);
	value &= ~0x10; // clear bit 4 in the word
	// write it back to the register
	util_write_short_fpga(FPGA_CONTROL_REG_BASE, 1, &value);
	return 0;
}

/**
 * Reset the DCM
 * @return
 */
int fpga_dcm_reset(void)
{
	unsigned short value;
	// read the value of control register
	util_read_short_fpga(FPGA_CONTROL_REG_BASE, 1, &value);
	value |= 0x20; // set bit 5 in the word
	// write it back to the register
	util_write_short_fpga(FPGA_CONTROL_REG_BASE, 1, &value);
	return 0;
}

/**
 * Clear reset flag for DCM
 * @return
 */
int fpga_dcm_reset_clear(void)
{
	unsigned short value;
	// read the value of control register
	util_read_short_fpga(FPGA_CONTROL_REG_BASE, 1, &value);
	value &= ~0x20; // clear bit 5 in the word
	// write it back to the register
	util_write_short_fpga(FPGA_CONTROL_REG_BASE, 1, &value);
	return 0;
}
/**
 * Enable the Interpolator block
 * @return
 */
int fpga_interpolator_enable(void)
{
	unsigned short value;
	// read the value of control register
	util_read_short_fpga(FPGA_CONTROL_REG_BASE, 1, &value);
	value |= 0x40; // set bit 6 in the word
	// write it back to the register
	util_write_short_fpga(FPGA_CONTROL_REG_BASE, 1, &value);
	return 0;
}

/**
 * Disable interpolator block
 * @return
 */
int fpga_interpolator_disable(void)
{
	unsigned short value;
	// read the value of control register
	util_read_short_fpga(FPGA_CONTROL_REG_BASE, 1, &value);
	value &= ~0x40; // clear bit 6 in the word
	// write it back to the register
	util_write_short_fpga(FPGA_CONTROL_REG_BASE, 1, &value);
	return 0;
}
/**
 * Enable the MK5 Interface
 * @return - 0 on success
 */
int fpga_mk5_enable(void)
{
	unsigned short value;
	// read the value of control register
	util_read_short_fpga(FPGA_CONTROL_REG_BASE, 1, &value);
	value |= 0x80; // set bit 7 in the word
	// write it back to the register
	util_write_short_fpga(FPGA_CONTROL_REG_BASE, 1, &value);
	return 0;
}

/**
 * Disable MK5 Interface
 * @return - 0 on success
 */
int fpga_mk5_disable(void)
{
	unsigned short value;
	// read the value of control register
	util_read_short_fpga(FPGA_CONTROL_REG_BASE, 1, &value);
	value &= ~0x80; // clear bit 7 in the word
	// write it back to the register
	util_write_short_fpga(FPGA_CONTROL_REG_BASE, 1, &value);
	return 0;
}

/* -------------------------------------------------------------------------- *
 * FPGA Status registers:
 * First Register Definition:
 * Bit 0: Instrument armed
 * Bit 3: FIR filter signal enabled
 * Bit 4: FFT signal enabled
 * Bit 6: Interpolator signal enabled
 * Bit 7: Mk5B Interface signal Enabled
 * -------------------------------------------------------------------------- *
 */


/**
 * Write the value to the status register regNo [0..3] (most of the time this will fail)
 * @param regNo - the status register to set
 * @param value - the value to write
 * @return - 0 if successful
 */
int fpga_set_status_reg( int regNo, unsigned short value)
{
	if(regNo >= 0 && regNo < 4 ) {
		util_write_short_fpga(FPGA_STATUS_REG_BASE + 2 * regNo, 1, &value);
		return 0;
	}
	return -1;
}

/**
 * Read the status register defined by regNo [0..3], and return it in value
 * @param regNo - the register to read
 * @param value - a place to put the returned value in
 * @return - 0 if successful
 */
int fpga_get_status_reg( int regNo, unsigned short *value)
{
	if(regNo >=0 && regNo < 4){
		util_read_short_fpga(FPGA_STATUS_REG_BASE + 2 * regNo, 1, value);
		return 0;
	}
	return -1;
}


/* ----------------------------------------------------------------------------------------------------
 *  System Registers starting at address 0x0000 in the FPGA
 *  Sysblock from FPGA code
 * Name  			Address		Definitions
 *
 * Board_ID   			0x0
 * Board_REV_MAJOR 		0x2
 * Board_REV_MINOR 		0x4
 * Board_REV_RCS 		0x6
 *
 * FirmWare_ID 			0x8
 * Firmware_REV_MAJOR 	0xA
 * Firmaware_REV_MINOR 	0xC
 * Firmware_RCS 		0xE
 * ---------------------------------------------------------------------------------------------------
 */

#define FPGA_SYSBLOCK_BASE 0
/**
 * Read the board id, return it in the value
 * @param value - return value
 * @return 0 if successful
 */
int fpga_get_board_id(unsigned short *value)
{
	util_read_short_fpga(FPGA_SYSBLOCK_BASE, 1, value);
	return 0;
}

/**
 * set the board id to value (will always fail)
 * @param value - the board id to set
 * @return 0 if successful
 */
int fpga_set_board_id(unsigned short value)
{
	util_write_short_fpga(FPGA_SYSBLOCK_BASE, 1, &value);
	return 0;
}

/**
 * read the board revision id's
 * @param rev_major - return parameter
 * @param rev_minor - return parameter
 * @param rev_rcs - return parameter
 * @return - 0 if successful
 */
int fpga_get_board_revision(unsigned short *rev_major, unsigned short *rev_minor, unsigned short *rev_rcs)
{
	util_read_short_fpga(FPGA_SYSBLOCK_BASE + 2, 1, rev_major);
	util_read_short_fpga(FPGA_SYSBLOCK_BASE + 4, 1, rev_minor);
	util_read_short_fpga(FPGA_SYSBLOCK_BASE + 6, 1, rev_rcs);
	return 0;
}

/**
 * Set the board revision ID -- will always fail
 * @param rev_major
 * @param rev_minor
 * @param rev_rcs
 * @return - 0 if successful
 */
int fpga_set_board_revision( unsigned short rev_major, unsigned short rev_minor, unsigned short rev_rcs)
{
	util_write_short_fpga(FPGA_SYSBLOCK_BASE + 2, 1, &rev_major);
	util_write_short_fpga(FPGA_SYSBLOCK_BASE + 4, 1, &rev_minor);
	util_write_short_fpga(FPGA_SYSBLOCK_BASE + 6, 1, &rev_rcs);
	return 0;
}

/**
 * Get the firmware id
 * @param id - return parameter
 * @return - 0 if successful
 */
int fpga_get_firmware_id( unsigned short *id)
{
	util_read_short_fpga(FPGA_SYSBLOCK_BASE + 8, 1, id);
	return 0;
}

/**
 * Set the firmware register to id, will always fail
 * @param id - the id to set
 * @return - 0 if successful
 */
int fpga_set_firmware_id( unsigned short id)
{
	util_read_short_fpga(FPGA_SYSBLOCK_BASE + 8, 1, &id);
	return 0;
}

/**
 * Read the firmware version information
 * @param rev_major - return value
 * @param rev_minor - return value
 * @param rev_rcs - return value
 * @return - 0 if successful
 */
int fpga_get_firmware_revision(unsigned short *rev_major, unsigned short *rev_minor, unsigned short *rev_rcs)
{
	util_read_short_fpga(FPGA_SYSBLOCK_BASE + 10, 1, rev_major);
	util_read_short_fpga(FPGA_SYSBLOCK_BASE + 12, 1, rev_minor);
	util_read_short_fpga(FPGA_SYSBLOCK_BASE + 14, 1, rev_rcs);
	return 0;
}

/**
 * Set the firmware version numbers -- will always fail
 * @param rev_major
 * @param rev_minor
 * @param rev_rcs
 * @return - 0 if successful
 */
int fpga_set_firmware_revision(unsigned short rev_major, unsigned short rev_minor, unsigned short rev_rcs)
{
	util_write_short_fpga(FPGA_SYSBLOCK_BASE + 10, 1, &rev_major);
	util_write_short_fpga(FPGA_SYSBLOCK_BASE + 12, 1, &rev_minor);
	util_write_short_fpga(FPGA_SYSBLOCK_BASE + 14, 1, &rev_rcs);
	return 0;
}

int fpga_get_fpga_binary_info(FPGA_BIN_INFO * fpga_info)
{
  unsigned short val;

  util_read_short_fpga(FPGA_SYSBLOCK_BASE, 1, &val);
  fpga_info->target_board = (val & 0xFF);
  fpga_info->c_id = ((val & 0xFF00) >> 8);

  util_read_short_fpga(FPGA_SYSBLOCK_BASE + 2, 1, &val);
  fpga_info->rev_major_frac = (val & 0xFF);
  fpga_info->rev_major_int = ((val & 0xFF00) >> 8);

  util_read_short_fpga(FPGA_SYSBLOCK_BASE + 4, 1, &val);
  fpga_info->unused = (val & 0xFF);
  fpga_info->rev_minor = ((val & 0xFF00) >> 8);

  util_read_short_fpga(FPGA_SYSBLOCK_BASE + 6, 1, &val);
  fpga_info->o_format = (val & 0xFF);
  fpga_info->p_type = ((val & 0xFF00) >> 8);

  return 0;
}


/* ---------------------------------------------------------------------------------------------------------
 *
 * Interrupt control registers and utility functions for them
 *
 */

#define FPGA_ISR_ENABLE 0x18
#define FPGA_ISR_CLEAR  0x1A
#define FPGA_ISR_ACK    0x1C
#define FPGA_ISR_STATUS 0x1E



/**
 * Enable a specific interrupt 0 .. 7
 * @param irqN - interrupt number 0 .. 7
 * @return 0 on success, or negative error code
 */
int fpga_isr_enable(unsigned short irqN)
{
	unsigned short value;
	unsigned short irqBit;
	if(irqN >= 8) return -1; // isr out of range
	irqBit = 1 << irqN; // shift in a one to the right position
	util_read_short_fpga(FPGA_ISR_ENABLE, 1, &value);
	value = value | irqBit;
	util_write_short_fpga(FPGA_ISR_ENABLE, 1, &value);
	return 0;
}

/**
 * Enable all Interrupts (FPGA)
 * @return 0 on success, else negative error code
 */
int fpga_isr_enable_all(void)
{
	unsigned short value = 0xFFFF;
	util_write_short_fpga(FPGA_ISR_ENABLE, 1, &value);
	return 0;
}
/**
 * Disable a FPGA interrupt
 * @param irqN - the interrupt 0..7 to disable
 */
int fpga_isr_disable(unsigned short irqN)
{
	unsigned short value;
	unsigned short irqBit;
	if(irqN >= 8) return -1; // isr out of range
	irqBit = ~(1 << irqN); // shift in a 0 to the right position
	util_read_short_fpga(FPGA_ISR_ENABLE, 1, &value);
	value = value & irqBit;
	util_write_short_fpga(FPGA_ISR_ENABLE, 1, &value);
	return 0;
}

/**
 * Disable all FPGA interrupts
 * @return 0 on success, negative error code
 */
int fpga_isr_disable_all(void)
{
  unsigned short value = 0x0000;
  util_write_short_fpga(FPGA_ISR_ENABLE, 1, &value);
  return 0;
}

/**
 * Calls the FPGA IOCTL routine to wait for an interrupt
 * @return 0 on success
 */
int fpga_isr_rd(void)
{

#if 0
  sleep(1);
  return 1;
#endif

#if 1 /* RESTORE ME remove the sleep */
  return util_isr_rd();
#endif
}

/* ----------------------------------------------------------------------------------------------------------
 * Quantizer Block and Registers
 *
 *
 * Threshold setting registers for each channel are 25 bits wide in the FPGA design
 * For computational purposes, When these same registers are read out by the PPC the 25 bit values are placed
 * into two 16 bit wide registers with the zero padding on the lower 7 bits to preserve the sign of the value.
 * This implies that the PPC must read two memory locations and shift the contents by 7 places to the right to
 * form the correct value. These are signed fixed point values (15,-16) as represented in a 32 bit register.
 * Read only for now. But should implement the routines to do the writes also.
 *
 * PPC addr 0xD060_0000 FPGA addr  0x300000 – Lower 16 bits of channel 0 IF0 Threshold Plus value
 * PPC addr 0xD060_0002  FPGA addr 0x300001 – Upper 16 bits of channel 0 IF0 Threshold Plus value
 * PPC addr 0xD060_0004  FPGA addr 0x300002 – Lower 16 bits of channel 0 IF0 Threshold Minus value
 * PPC addr 0xD060_0006  FPGA addr 0x300003 – Upper 16 bits of channel 0 IF0 Threshold Minus value
 *
 * PPC addr 0xD060_0008 FPGA addr  0x300004 – Lower 16 bits of channel 1 IF0 Threshold Plus value
 * PPC addr 0xD060_000A  FPGA addr 0x300005 – Upper 16 bits of channel 1 IF0 Threshold Plus value
 * PPC addr 0xD060_000C FPGA addr 0x300006 – Lower 16 bits of channel 1 IF0 Threshold Minus value
 * PPC addr 0xD060_000E FPGA addr 0x300007 – Upper 16 bits of channel 1 IF0 Threshold Minus value
 *

 * PPC addr 0xD060_0010 FPGA addr  0x300008 – Lower 16 bits of channel 2 IF0 Threshold Plus value
 * PPC addr 0xD060_0012  FPGA addr 0x300009 – Upper 16 bits of channel 2 IF0 Threshold Plus value
 * PPC addr 0xD060_0014  FPGA addr 0x30000A – Lower 16 bits of channel 2 IF0 Threshold Minus value
 * PPC addr 0xD060_0016  FPGA addr 0x30000B – Upper 16 bits of channel 2 IF0 Threshold Minus value
 *
 * PPC addr 0xD060_0018 FPGA addr  0x30000C – Lower 16 bits of channel 3 IF0 Threshold Plus value
 * PPC addr 0xD060_001A  FPGA addr 0x30000D – Upper 16 bits of channel 3 IF0 Threshold Plus value
 * PPC addr 0xD060_001C FPGA addr 0x30000E – Lower 16 bits of channel 3 IF0 Threshold Minus value
 * PPC addr 0xD060_001E  FPGA addr 0x30000F – Upper 16 bits of channel 3 IF0 Threshold Minus value
 *
 * PPC addr 0xD060_0020 FPGA addr  0x300010 – Lower 16 bits of channel 4 IF0 Threshold Plus value
 * PPC addr 0xD060_0022 FPGA addr 0x300011 – Upper 16 bits of channel 4 IF0 Threshold Plus value
 * PPC addr 0xD060_0024 FPGA addr 0x300012 – Lower 16 bits of channel 4 IF0 Threshold Minus value
 * PPC addr 0xD060_0026 FPGA addr 0x300013 – Upper 16 bits of channel 4 IF0 Threshold Minus value
 *
 * PPC addr 0xD060_0028 FPGA addr  0x300014 – Lower 16 bits of channel 5 IF0 Threshold Plus value
 * PPC addr 0xD060_002A FPGA addr 0x300015 – Upper 16 bits of channel 5 IF0 Threshold Plus value
 * PPC addr 0xD060_002C FPGA addr 0x300016 – Lower 16 bits of channel 5 IF0 Threshold Minus value
 * PPC addr 0xD060_002E FPGA addr 0x300017 – Upper 16 bits of channel 5 IF0 Threshold Minus value
 *
 * PPC addr 0xD060_0030 FPGA addr 0x300018 – Lower 16 bits of channel 6 IF0 Threshold Plus value
 * PPC addr 0xD060_0032  FPGA addr 0x300019 – Upper 16 bits of channel 6 IF0 Threshold Plus value
 * PPC addr 0xD060_0034  FPGA addr 0x30001A – Lower 16 bits of channel 6 IF0 Threshold Minus value
 * PPC addr 0xD060_0036  FPGA addr 0x30001B – Upper 16 bits of channel 6 IF0 Threshold Minus value
 *
 *
 * PPC addr 0xD060_0038 FPGA addr 0x30001C – Lower 16 bits of channel 7 IF0 Threshold Plus value
 * PPC addr 0xD060_003A FPGA addr 0x30001D – Upper 16 bits of channel 7 IF0 Threshold Plus value
 * PPC addr 0xD060_003C FPGA addr 0x30001E – Lower 16 bits of channel 7 IF0 Threshold Minus value
 * PPC addr 0xD060_003E FPGA addr 0x30001F – Upper 16 bits of channel 7 IF0 Threshold Minus value
 *
 * PPC addr 0xD060_0040 FPGA addr 0x300020 – Lower 16 bits of channel 8 IF0 Threshold Plus value
 * PPC addr 0xD060_0042 FPGA addr 0x300021 – Upper 16 bits of channel 8 IF0 Threshold Plus value
 * PPC addr 0xD060_0044 FPGA addr 0x300022 – Lower 16 bits of channel 8 IF0 Threshold Minus value
 * PPC addr 0xD060_0046 FPGA addr 0x300023 – Upper 16 bits of channel 8 IF0 Threshold Minus value
 *
 * PPC addr 0xD060_0048 FPGA addr 0x300024 – Lower 16 bits of channel 9 IF0 Threshold Plus value
 * PPC addr 0xD060_004A FPGA addr 0x300025 – Upper 16 bits of channel 9 IF0 Threshold Plus value
 * PPC addr 0xD060_004C FPGA addr 0x300026 – Lower 16 bits of channel 9 IF0 Threshold Minus value
 * PPC addr 0xD060_004E FPGA addr 0x300027 – Upper 16 bits of channel 9 IF0 Threshold Minus value
 *
 * PPC addr 0xD060_0050 FPGA addr 0x300028 – Lower 16 bits of channel 10 IF0 Threshold Plus value
 * PPC addr 0xD060_0052 FPGA addr 0x300029 – Upper 16 bits of channel 10 IF0 Threshold Plus value
 * PPC addr 0xD060_0054 FPGA addr 0x30002A – Lower 16 bits of channel 10 IF0 Threshold Minus value
 * PPC addr 0xD060_0056 FPGA addr 0x30002B – Upper 16 bits of channel 10 IF0 Threshold Minus value
 *
 * PPC addr 0xD060_0058 FPGA addr 0x30002C – Lower 16 bits of channel 11 IF0 Threshold Plus value
 * PPC addr 0xD060_005A FPGA addr 0x30002D – Upper 16 bits of channel 11 IF0 Threshold Plus value
 * PPC addr 0xD060_005C FPGA addr 0x30002E – Lower 16 bits of channel 11 IF0 Threshold Minus value
 * PPC addr 0xD060_005E FPGA addr 0x30002F – Upper 16 bits of channel 11 IF0 Threshold Minus value
 *
 * PPC addr 0xD060_0060 FPGA addr 0x300030 – Lower 16 bits of channel 12 IF0 Threshold Plus value
 * PPC addr 0xD060_0062 FPGA addr 0x300031 – Upper 16 bits of channel 12 IF0 Threshold Plus value
 * PPC addr 0xD060_0064 FPGA addr 0x300032 – Lower 16 bits of channel 12 IF0 Threshold Minus value
 * PPC addr 0xD060_0066 FPGA addr 0x300033 – Upper 16 bits of channel 12 IF0 Threshold Minus value
 *
 * PPC addr 0xD060_0068 FPGA addr 0x300034 – Lower 16 bits of channel 13 IF0 Threshold Plus value
 * PPC addr 0xD060_006A FPGA addr 0x300035 – Upper 16 bits of channel 13 IF0 Threshold Plus value
 * PPC addr 0xD060_006C FPGA addr 0x300036 – Lower 16 bits of channel 13 IF0 Threshold Minus value
 * PPC addr 0xD060_006E FPGA addr 0x300037 – Upper 16 bits of channel 13 IF0 Threshold Minus value
 *
 * PPC addr 0xD060_0070 FPGA addr 0x300038 – Lower 16 bits of channel 14 IF0 Threshold Plus value
 * PPC addr 0xD060_0072 FPGA addr 0x300039 – Upper 16 bits of channel 14 IF0 Threshold Plus value
 * PPC addr 0xD060_0074 FPGA addr 0x30003A – Lower 16 bits of channel 14 IF0 Threshold Minus value
 * PPC addr 0xD060_0076 FPGA addr 0x30003B – Upper 16 bits of channel 14 IF0 Threshold Minus value
 *
 * PPC addr 0xD060_0078 FPGA addr 0x30003C – Lower 16 bits of channel 15 IF0 Threshold Plus value
 * PPC addr 0xD060_007A FPGA addr 0x30003D – Upper 16 bits of channel 15 IF0 Threshold Plus value
 * PPC addr 0xD060_007C FPGA addr 0x30003E – Lower 16 bits of channel 15 IF0 Threshold Minus value
 * PPC addr 0xD060_007E FPGA addr 0x30003F – Upper 16 bits of channel 15 IF0 Threshold Minus value
 * PPC addr 0xD060_0080 FPGA addr 0x300040 – Lower 16 bits of channel 0 IF1 Threshold Plus value
 * PPC addr 0xD060_0082 FPGA addr 0x300041 – Upper 16 bits of channel 0 IF1 Threshold Plus value
 * PPC addr 0xD060_0084 FPGA addr 0x300042 – Lower 16 bits of channel 0 IF1 Threshold Minus value
 * PPC addr 0xD060_0086 FPGA addr 0x300043 – Upper 16 bits of channel 0 IF1 Threshold Minus value
 *
 * PPC addr 0xD060_0088 FPGA addr 0x300044 – Lower 16 bits of channel 1 IF1 Threshold Plus value
 * PPC addr 0xD060_008A FPGA addr 0x300045 – Upper 16 bits of channel 1 IF1 Threshold Plus value
 * PPC addr 0xD060_008C FPGA addr 0x300046 – Lower 16 bits of channel 1 IF1 Threshold Minus value
 * PPC addr 0xD060_008E FPGA addr 0x300047 – Upper 16 bits of channel 1 IF1 Threshold Minus value
 *
 *
 * PPC addr 0xD060_0090 FPGA addr 0x300048 – Lower 16 bits of channel 2 IF1 Threshold Plus value
 * PPC addr 0xD060_0092 FPGA addr 0x300049 – Upper 16 bits of channel 2 IF1 Threshold Plus value
 * PPC addr 0xD060_0094 FPGA addr 0x30004A – Lower 16 bits of channel 2 IF1 Threshold Minus value
 * PPC addr 0xD060_0096 FPGA addr 0x30004B – Upper 16 bits of channel 2 IF1 Threshold Minus value
 *
 * PPC addr 0xD060_0098 FPGA addr 0x30004C – Lower 16 bits of channel 3 IF1 Threshold Plus value
 * PPC addr 0xD060_009A FPGA addr 0x30004D – Upper 16 bits of channel 3 IF1 Threshold Plus value
 * PPC addr 0xD060_009C FPGA addr 0x30004E – Lower 16 bits of channel 3 IF1 Threshold Minus value
 * PPC addr 0xD060_009E FPGA addr 0x30004F – Upper 16 bits of channel 3 IF1 Threshold Minus value
 *
 * PPC addr 0xD060_00A0 FPGA addr 0x300050 – Lower 16 bits of channel 4 IF1 Threshold Plus value
 * PPC addr 0xD060_00A2 FPGA addr 0x300051 – Upper 16 bits of channel 4 IF1 Threshold Plus value
 * PPC addr 0xD060_00A4 FPGA addr 0x300052 – Lower 16 bits of channel 4 IF1 Threshold Minus value
 * PPC addr 0xD060_00A6 FPGA addr 0x300053 – Upper 16 bits of channel 4 IF1 Threshold Minus value
 *
 * PPC addr 0xD060_00A8 FPGA addr 0x300054 – Lower 16 bits of channel 5 IF1 Threshold Plus value
 * PPC addr 0xD060_00AA FPGA addr 0x300055 – Upper 16 bits of channel 5 IF1 Threshold Plus value
 * PPC addr 0xD060_00AC FPGA addr 0x300056 – Lower 16 bits of channel 5 IF1 Threshold Minus value
 * PPC addr 0xD060_00AE FPGA addr 0x300057 – Upper 16 bits of channel 5 IF1 Threshold Minus value
 *
 *
 * PPC addr 0xD060_00B0 FPGA addr 0x300058 – Lower 16 bits of channel 6 IF1 Threshold Plus value
 * PPC addr 0xD060_00B2 FPGA addr 0x300059 – Upper 16 bits of channel 6 IF1 Threshold Plus value
 * PPC addr 0xD060_00B4 FPGA addr 0x30005A – Lower 16 bits of channel 6 IF1 Threshold Minus value
 * PPC addr 0xD060_00B6 FPGA addr 0x30005B – Upper 16 bits of channel 6 IF1 Threshold Minus value
 *
 * PPC addr 0xD060_00B8 FPGA addr 0x30005C – Lower 16 bits of channel 7 IF1 Threshold Plus value
 * PPC addr 0xD060_00BA FPGA addr 0x30005D – Upper 16 bits of channel 7 IF1 Threshold Plus value
 * PPC addr 0xD060_00BC FPGA addr 0x30005E – Lower 16 bits of channel 7 IF1 Threshold Minus value
 * PPC addr 0xD060_00BE FPGA addr 0x30005F – Upper 16 bits of channel 7 IF1 Threshold Minus value
 *
 * PPC addr 0xD060_00C0 FPGA addr 0x300060 – Lower 16 bits of channel 8 IF1 Threshold Plus value
 * PPC addr 0xD060_00C2 FPGA addr 0x300061 – Upper 16 bits of channel 8 IF1 Threshold Plus value
 * PPC addr 0xD060_00C4 FPGA addr 0x300062 – Lower 16 bits of channel 8 IF1 Threshold Minus value
 * PPC addr 0xD060_00C6 FPGA addr 0x300063 – Upper 16 bits of channel 8 IF1 Threshold Minus value
 *
 * PPC addr 0xD060_00C8 FPGA addr 0x300064 – Lower 16 bits of channel 9 IF1 Threshold Plus value
 * PPC addr 0xD060_00CA FPGA addr 0x300065 – Upper 16 bits of channel 9 IF1 Threshold Plus value
 * PPC addr 0xD060_00CC FPGA addr 0x300066 – Lower 16 bits of channel 9 IF1 Threshold Minus value
 * PPC addr 0xD060_00CE FPGA addr 0x300067 – Upper 16 bits of channel 9 IF1 Threshold Minus value
 *
 *
 * PPC addr 0xD060_00D0 FPGA addr 0x300068 – Lower 16 bits of channel 10 IF1 Threshold Plus value
 * PPC addr 0xD060_00D2 FPGA addr 0x300069 – Upper 16 bits of channel 10 IF1 Threshold Plus value
 * PPC addr 0xD060_00D4 FPGA addr 0x30006A – Lower 16 bits of channel 10 IF1 Threshold Minus value
 * PPC addr 0xD060_00D6 FPGA addr 0x30006B – Upper 16 bits of channel 10 IF1 Threshold Minus value
 *
 * PPC addr 0xD060_00D8 FPGA addr 0x30006C – Lower 16 bits of channel 11 IF1 Threshold Plus value
 * PPC addr 0xD060_00DA FPGA addr 0x30006D – Upper 16 bits of channel 11 IF1 Threshold Plus value
 * PPC addr 0xD060_00DC FPGA addr 0x30006E – Lower 16 bits of channel 11 IF1 Threshold Minus value
 * PPC addr 0xD060_00DE FPGA addr 0x30006F – Upper 16 bits of channel 11 IF1 Threshold Minus value
 *
 * PPC addr 0xD060_00E0 FPGA addr 0x300070 – Lower 16 bits of channel 12 IF1 Threshold Plus value
 * PPC addr 0xD060_00E2 FPGA addr 0x300071 – Upper 16 bits of channel 12 IF1 Threshold Plus value
 * PPC addr 0xD060_00E4 FPGA addr 0x300072 – Lower 16 bits of channel 12 IF1 Threshold Minus value
 * PPC addr 0xD060_00E6 FPGA addr 0x300073 – Upper 16 bits of channel 12 IF1 Threshold Minus value
 *
 *
 *
 * PPC addr 0xD060_00E8 FPGA addr 0x300074 – Lower 16 bits of channel 13 IF1 Threshold Plus value
 * PPC addr 0xD060_00EA FPGA addr 0x300075 – Upper 16 bits of channel 13 IF1 Threshold Plus value
 * PPC addr 0xD060_00EC FPGA addr 0x300076 – Lower 16 bits of channel 13 IF1 Threshold Minus value
 * PPC addr 0xD060_00EE FPGA addr 0x300077 – Upper 16 bits of channel 13 IF1 Threshold Minus value
 *
 *
 * PPC addr 0xD060_00F0 FPGA addr 0x300078 – Lower 16 bits of channel 14 IF1 Threshold Plus value
 * PPC addr 0xD060_00F2 FPGA addr 0x300079 – Upper 16 bits of channel 14 IF1 Threshold Plus value
 * PPC addr 0xD060_00F4 FPGA addr 0x30007A – Lower 16 bits of channel 14 IF1 Threshold Minus value
 * PPC addr 0xD060_00F6 FPGA addr 0x30007B – Upper 16 bits of channel 14 IF1 Threshold Minus value
 *
 * PPC addr 0xD060_00F8 FPGA addr 0x30007C – Lower 16 bits of channel 15 IF1 Threshold Plus value
 * PPC addr 0xD060_00FA FPGA addr 0x30007D – Upper 16 bits of channel 15 IF1 Threshold Plus value
 * PPC addr 0xD060_00FC FPGA addr 0x30007E – Lower 16 bits of channel 15 IF1 Threshold Minus value
 * PPC addr 0xD060_00FE FPGA addr 0x30007F – Upper 16 bits of channel 15 IF1 Threshold Minus value
 *
 */

#define FPGA_fpga_qt_BASE 0x0600000

#define QT_CH_OFFSET 8
#define QT_IF_OFFSET (16 * QT_CH_OFFSET)

#define DDC_QT_CH_OFFSET 32
#define DDC_QT_IF_OFFSET (8 * DDC_QT_CH_OFFSET)
/**
 * Get Quantizer threshold value as 25bit integer sign extended to 32 bits
 * The value is a "real" with the lower 20 bits as fraction
 * @param intFreq - IF [0 or 1]
 * @param channel - Channel [0 .. 15]
 * @param value - the return value
 * @return - 0 on success
 */
int fpga_qt_get_threshold_plus(int intFreq, int channel, long int *value)
{
  if(intFreq >= 0 && intFreq < 2 && channel >=0 && channel < 16) 
    {
      util_read_long_fpga(FPGA_fpga_qt_BASE + (intFreq * QT_IF_OFFSET) + (QT_CH_OFFSET * channel), 1, value);
      return 0;
    }
  return -1;
}

/**
 * Set Quantizer threshold value as 25bit integer sign extended to 32 bits
 * The value is a "real" with the lower 20 bits as fraction
 * @param intFreq - IF [0 or 1]
 * @param channel - Channel [0 .. 15]
 * @param value - the value to set (only low 25 bits are valid
 * @return - 0 on success
 */
int fpga_qt_set_threshold_plus(int intFreq, int channel, long int value)
{
  if(intFreq >= 0 && intFreq < 2 && channel >=0 && channel < 16) {
    util_write_long_fpga(FPGA_fpga_qt_BASE + (intFreq * QT_IF_OFFSET) + (QT_CH_OFFSET * channel), 1, &value);
    return 0;
  }
  return -1;
}

/**
 * Get Quantizer threshold MINUS value as 25bit integer sign extended to 32 bits
 * The value is a "real" with the lower 20 bits as fraction
 * @param intFreq - IF [0 or 1]
 * @param channel - Channel [0 .. 15]
 * @param value - the return value
 * @return - 0 on success
 */
int fpga_qt_get_threshold_minus(int intFreq, int channel, long int *value)
{
  if(intFreq >= 0 && intFreq < 2 && channel >=0 && channel < 16) 
    {
      util_read_long_fpga(FPGA_fpga_qt_BASE + (intFreq * QT_IF_OFFSET) + (QT_CH_OFFSET * channel) + 4, 1, value);
    return 0;
  }
  return -1;
}

/**
 * Set Quantizer threshold MINUS value as 25bit integer sign extended to 32 bits
 * The value is a "real" with the lower 20 bits as fraction
 * @param intFreq - IF [0 or 1]
 * @param channel - Channel [0 .. 15]
 * @param value - the value to set (only low 25 bits are valid
 * @return - 0 on success
 */
int fpga_qt_set_threshold_minus(int intFreq, int channel, long int value)
{
  if (intFreq >= 0 && intFreq < 2 && channel >=0 && channel < 16) 
    {
      util_write_long_fpga(FPGA_fpga_qt_BASE + (intFreq * QT_IF_OFFSET) + (QT_CH_OFFSET * channel) + 4, 1, &value);
      return 0;
    }
  return -1;
}


/**
 * Get DDC Quantizer threshold plus value
 * @param channel - Channel [0 .. 7]
 * @param value - the return value
 * @return - 0 on success
 */
int fpga_ddc_qt_get_threshold_plus(int channel, short *value)
{
  if(channel >=0 && channel < 8) 
    {
      util_read_short_fpga(FPGA_fpga_qt_BASE + (DDC_QT_CH_OFFSET * channel) + 16, 
			  1, 
			  value);
      return 0;
    }
  return -1;
}

/**
 * Set DDC Quantizer threshold plus value as hosrt
 * @param channel - Channel [0 .. 7]
 * @param value - the value to set
 * @return - 0 on success
 */
int fpga_ddc_qt_set_threshold_plus(int channel, short value)
{
  if(channel >=0 && channel < 8) 
    {
      util_write_short_fpga(FPGA_fpga_qt_BASE + (DDC_QT_CH_OFFSET * channel) + 16,
			   1, 
			   &value);
      return 0;
  }
  return -1;
}

/**
 * Set DDC Quantizer threshold zero value as hosrt
 * @param channel - Channel [0 .. 7]
 * @param value - the value to set
 * @return - 0 on success
 */
int fpga_ddc_qt_set_threshold_zero(int channel, short value)
{
  if(channel >=0 && channel < 8) 
    {
      util_write_short_fpga(FPGA_fpga_qt_BASE + (DDC_QT_CH_OFFSET * channel) + 18, 
			   1, 
			   &value);
      return 0;
  }
  return -1;
}

/**
 * Get DDC Quantizer threshold zero value as hosrt
 * @param channel - Channel [0 .. 7]
 * @param value - the value to set
 * @return - 0 on success
 */
int fpga_ddc_qt_get_threshold_zero(int channel, short *value)
{
  if(channel >=0 && channel < 8) 
    {
      util_read_short_fpga(FPGA_fpga_qt_BASE + (DDC_QT_CH_OFFSET * channel) + 18, 
			   1, 
			   value);
      return 0;
  }
  return -1;
}

/**
 * Set Quantizer hold status
 * @param value - the value to set the hold register to.
 * @return - 0 on success
 */
int fpga_ddc_qt_set_hold(short value)
{
  util_write_short_fpga(0x0600010, 1, &value);
  return 0;
}

/**
 * Get Quantizer hold status
 * @param value - the value to read the hold register to.
 * @return - 0 on success
 */
int fpga_ddc_qt_get_hold(short *value)
{
  util_read_short_fpga(0x0600010, 1, value);
  return 0;
}

/**
 * Get DDC Quantizer threshold MINUS value
 * @param channel - Channel [0 .. 7]
 * @param value - the return value
 * @return - 0 on success
 */
int fpga_ddc_qt_get_threshold_minus(int channel, short *value)
{
  if (channel >=0 && channel < 8) 
    {
      util_read_short_fpga(FPGA_fpga_qt_BASE + (DDC_QT_CH_OFFSET * channel) + 20, 
			   1, 
			  value);
    return 0;
  }
  return -1;
}

/**
 * Set DDC Quantizer threshold MINUS value
 * @param channel - Channel [0 .. 7]
 * @param value - the value to set 
 * @return - 0 on success
 */
int fpga_ddc_qt_set_threshold_minus(int channel, short value)
{
  if(channel >=0 && channel < 8) 
    {
      util_write_short_fpga(FPGA_fpga_qt_BASE + (DDC_QT_CH_OFFSET * channel) + 20, 
			   1, 
			   &value);
      return 0;
    }
  return -1;
}

/**
 * Get DDC Quantizer Counts for state 00
 * @param channel - Channel [0 .. 7]
 * @param value - the return value
 * @return - 0 on success
 */
int fpga_ddc_qt_get_count_lo_state00 (int channel, unsigned short * count)
{
  if (channel >=0 && channel < 8) 
    {
      util_read_short_fpga(FPGA_fpga_qt_BASE + (DDC_QT_CH_OFFSET * channel), 
			  1, 
			  count);
      return 0;
    }
  return -1;
}

int fpga_ddc_qt_get_count_hi_state00 (int channel, unsigned short * count)
{
  if (channel >=0 && channel < 8) 
    {
      util_read_short_fpga(FPGA_fpga_qt_BASE + (DDC_QT_CH_OFFSET * channel) + 2, 
			  1, 
			  count);
      return 0;
    }
  return -1;
}

/**
 * Get DDC Quantizer Counts for state 01
 * @param channel - Channel [0 .. 7]
 * @param value - the return value
 * @return - 0 on success
 */
int fpga_ddc_qt_get_count_lo_state01(int channel, unsigned short * count)
{
  if (channel >=0 && channel < 8) 
    {
      util_read_short_fpga(FPGA_fpga_qt_BASE + (DDC_QT_CH_OFFSET * channel) + 4, 
			   1, 
			  count);
      return 0;
    }
  return -1;
}

int fpga_ddc_qt_get_count_hi_state01(int channel, unsigned short * count)
{
  if (channel >=0 && channel < 8) 
    {
      util_read_short_fpga(FPGA_fpga_qt_BASE + (DDC_QT_CH_OFFSET * channel) + 6, 
			   1, 
			  count);
      return 0;
    }
  return -1;
}

/**
 * Get DDC Quantizer Counts for state 10
 * @param channel - Channel [0 .. 7]
 * @param value - the return value
 * @return - 0 on success
 */
int fpga_ddc_qt_get_count_lo_state10(int channel, unsigned short * count)
{
  if(channel >=0 && channel < 8) 
    {
      util_read_short_fpga(FPGA_fpga_qt_BASE + (DDC_QT_CH_OFFSET * channel) + 8, 
			  1, 
			  count);
      return 0;
    }
  return -1;
}

int fpga_ddc_qt_get_count_hi_state10(int channel, unsigned short * count)
{
  if(channel >=0 && channel < 8) 
    {
      util_read_short_fpga(FPGA_fpga_qt_BASE + (DDC_QT_CH_OFFSET * channel) + 10, 
			  1, 
			  count);
      return 0;
    }
  return -1;
}

/**
 * Get DDC Quantizer Counts for state 11
 * @param channel - Channel [0 .. 7]
 * @param value - the return value
 * @return - 0 on success
 */
int fpga_ddc_qt_get_count_lo_state11(int channel, unsigned short * count)
{
  if(channel >=0 && channel < 8) 
    {
      util_read_short_fpga(FPGA_fpga_qt_BASE + (DDC_QT_CH_OFFSET * channel) + 12,
			  1,
			  count);
      return 0;
    }
  return -1;
}

int fpga_ddc_qt_get_count_hi_state11(int channel, unsigned short * count)
{
  if(channel >=0 && channel < 8) 
    {
      util_read_short_fpga(FPGA_fpga_qt_BASE + (DDC_QT_CH_OFFSET * channel) + 14,
			  1,
			  count);
      return 0;
    }
  return -1;
}

/*
 * In order to re-quantize the data some state statistics need to be collected for each channel.
 * These are the number of states counts (high/low) over a given period of time.
 * Only the low bit count is provided since the high count can be calculated by knowing the number of samples
 * and low bit count. . These are unsigned 16 bit values. Read only.
 *
 *
 * PPC addr 0xD060_0100 FPGA addr 0x300080 – Channel 00 IF0 Low Bit State Count
 * PPC addr 0xD060_0102 FPGA addr 0x300081 – Channel 01 IF0 Low Bit State Count
 * PPC addr 0xD060_0104 FPGA addr 0x300082 – Channel 02 IF0 Low Bit State Count
 * PPC addr 0xD060_0106 FPGA addr 0x300083 – Channel 03 IF0 Low Bit State Count
 * PPC addr 0xD060_0108 FPGA addr 0x300084 – Channel 04 IF0 Low Bit State Count
 * PPC addr 0xD060_010A FPGA addr 0x300085 – Channel 05 IF0 Low Bit State Count
 * PPC addr 0xD060_010C FPGA addr 0x300086 – Channel 06 IF0 Low Bit State Count
 * PPC addr 0xD060_010E FPGA addr 0x300087 – Channel 07 IF0 Low Bit State Count
 * PPC addr 0xD060_0110 FPGA addr 0x300088 – Channel 08 IF0 Low Bit State Count
 * PPC addr 0xD060_0112 FPGA addr 0x300089 – Channel 09 IF0 Low Bit State Count
 * PPC addr 0xD060_0114 FPGA addr 0x30008A – Channel 10 IF0 Low Bit State Count
 * PPC addr 0xD060_0116 FPGA addr 0x30008B – Channel 11 IF0 Low Bit State Count
 * PPC addr 0xD060_0118 FPGA addr 0x30008C – Channel 12 IF0 Low Bit State Count
 * PPC addr 0xD060_011A FPGA addr 0x30008D – Channel 13 IF0 Low Bit State Count
 * PPC addr 0xD060_011C FPGA addr 0x30008E – Channel 14 IF0 Low Bit State Count
 * PPC addr 0xD060_011E FPGA addr 0x30008F – Channel 15 IF0 Low Bit State Count
 * PPC addr 0xD060_0120 FPGA addr 0x300090 – Channel 00 IF1 Low Bit State Count
 * PPC addr 0xD060_0122 FPGA addr 0x300091 – Channel 01 IF1 Low Bit State Count
 * PPC addr 0xD060_0124 FPGA addr 0x300092 – Channel 02 IF1 Low Bit State Count
 * PPC addr 0xD060_0126 FPGA addr 0x300093 – Channel 02 IF1 Low Bit State Count
 * PPC addr 0xD060_0128 FPGA addr 0x300094 – Channel 04 IF1 Low Bit State Count
 * PPC addr 0xD060_012A FPGA addr 0x300095 – Channel 05 IF1 Low Bit State Count
 * PPC addr 0xD060_012C FPGA addr 0x300096 – Channel 06 IF1 Low Bit State Count
 * PPC addr 0xD060_012E FPGA addr 0x300097 – Channel 07 IF1 Low Bit State Count
 * PPC addr 0xD060_0130 FPGA addr 0x300098 – Channel 08 IF1 Low Bit State Count
 * PPC addr 0xD060_0132 FPGA addr 0x300099 – Channel 09 IF1 Low Bit State Count
 * PPC addr 0xD060_0134 FPGA addr 0x30009A – Channel 10 IF1 Low Bit State Count
 * PPC addr 0xD060_0136 FPGA addr 0x30009B – Channel 11 IF1 Low Bit State Count
 * PPC addr 0xD060_0138 FPGA addr 0x30009C – Channel 12 IF1 Low Bit State Count
 * PPC addr 0xD060_013A FPGA addr 0x30009D – Channel 13 IF1 Low Bit State Count
 * PPC addr 0xD060_013C FPGA addr 0x30009E – Channel 14 IF1 Low Bit State Count
 * PPC addr 0xD060_013E FPGA addr 0x30009F – Channel 15 IF1 Low Bit State Count
 *
 */

#define QT_STATE_COUNT_BASE (FPGA_fpga_qt_BASE + 0x100)
#define QT_ST_IF_OFFSET 0x20
#define QT_ST_CH_OFFSET 2
/**
 * Get the bit state count for IF and Channel
 * unsigned 16 bit number
 * @param intFreq - IF [0..1]
 * @param channel - Channel [0..15]
 * @param value - return value
 * @return - 0 on success
 */
int fpga_qt_get_bit_state_count(int intFreq, int channel, unsigned short *value)
{
  if(intFreq >= 0 && intFreq < 2 && channel >=0 && channel < 32) {
    util_read_short_fpga(QT_STATE_COUNT_BASE + intFreq * QT_ST_IF_OFFSET + (QT_ST_CH_OFFSET * channel), 1, value);
    return 0;
  }
  return -1;
}

/**
 * Set the bit state count for IF and Channel (write will always fail)
 * unsigned 16 bit number
 * @param intFreq - IF [0..1]
 * @param channel - Channel [0..15]
 * @param value - return value
 * @return - 0 on success
 */
int fpga_qt_set_bit_state_count(int intFreq, int channel, unsigned short value)
{
  if(intFreq >= 0 && intFreq < 1 && channel >=0 && channel < 32) {
    util_write_short_fpga(QT_STATE_COUNT_BASE + (intFreq * QT_ST_IF_OFFSET) + (QT_ST_CH_OFFSET * channel), 1, &value);
    return 0;
  }
  return -1;
}

/*
 * Gain setting registers for each channel are 25 bits wide in the FPGA design
 * For computational purposes, When these same registers are read out by the PPC the 25 bit values are placed
 *  into two 16 bit wide registers with the zero padding on the lower 7 bits to preserve the sign of the value.
 *  This implies that the PPC must read two memory locations and shift the contents by 7 places to the right
 *  to form the correct value. .
 *  These are signed fixed point values (15,-16) as represented in a 32 bit register. Read only.
 *
 * PPC addr 0xD060_0140 FPGA addr 0x3000A0 – Lower 16 bits of channel 0 IF0 gain setting
 * PPC addr 0xD060_0142 FPGA addr 0x3000A1 – Upper 16 bits of channel 0 IF0 gain setting
 * PPC addr 0xD060_0144 FPGA addr 0x3000A2 – Lower 16 bits of channel 1 IF0 gain setting
 * PPC addr 0xD060_0146 FPGA addr 0x3000A3 – Upper 16 bits of channel 1 IF0 gain setting
 * PPC addr 0xD060_0148 FPGA addr 0x3000A4 – Lower 16 bits of channel 2 IF0 gain setting
 * PPC addr 0xD060_014A FPGA addr 0x3000A5 – Upper 16 bits of channel 2 IF0 gain setting
 * PPC addr 0xD060_014C FPGA addr 0x3000A6 – Lower 16 bits of channel 3 IF0 gain setting
 * PPC addr 0xD060_014E FPGA addr 0x3000A7 – Upper 16 bits of channel 3 IF0 gain setting
 *
 * PPC addr 0xD060_0150 FPGA addr 0x3000A8 – Lower 16 bits of channel 4 IF0 gain setting
 * PPC addr 0xD060_0152 FPGA addr 0x3000A9 – Upper 16 bits of channel 4 IF0 gain setting
 * PPC addr 0xD060_0154 FPGA addr 0x3000AA – Lower 16 bits of channel 5 IF0 gain setting
 * PPC addr 0xD060_0156 FPGA addr 0x3000AB – Upper 16 bits of channel 5 IF0 gain setting
 *
 * PPC addr 0xD060_0158 FPGA addr 0x3000AC – Lower 16 bits of channel 6 IF0 gain setting
 * PPC addr 0xD060_015A FPGA addr 0x3000AD – Upper 16 bits of channel 6 IF0 gain setting
 * PPC addr 0xD060_015C FPGA addr 0x3000AE – Lower 16 bits of channel 7 IF0 gain setting
 * PPC addr 0xD060_015E FPGA addr 0x3000AF – Upper 16 bits of channel 7 IF0 gain setting
 *
 * PPC addr 0xD060_0160 FPGA addr 0x3000B0 – Lower 16 bits of channel 8 IF0 gain setting
 * PPC addr 0xD060_0162 FPGA addr 0x3000B1 – Upper 16 bits of channel 8 IF0 gain setting
 * PPC addr 0xD060_0164 FPGA addr 0x3000B2 – Lower 16 bits of channel 9 IF0 gain setting
 * PPC addr 0xD060_0166 FPGA addr 0x3000B3 – Upper 16 bits of channel 9 IF0 gain setting
 *
 * PPC addr 0xD060_0168 FPGA addr 0x3000B4 – Lower 16 bits of channel 10 IF0 gain setting
 * PPC addr 0xD060_016A FPGA addr 0x3000B5 – Upper 16 bits of channel 10 IF0 gain setting
 * PPC addr 0xD060_016C FPGA addr 0x3000B6 – Lower 16 bits of channel 11 IF0 gain setting
 * PPC addr 0xD060_016E FPGA addr 0x3000B7 – Upper 16 bits of channel 11 IF0 gain setting
 *
 * PPC addr 0xD060_0170 FPGA addr 0x3000B8 – Lower 16 bits of channel 12 IF0 gain setting
 * PPC addr 0xD060_0172 FPGA addr 0x3000B9 – Upper 16 bits of channel 12 IF0 gain setting
 * PPC addr 0xD060_0174 FPGA addr 0x3000BA – Lower 16 bits of channel 13 IF0 gain setting
 * PPC addr 0xD060_0176 FPGA addr 0x3000BB – Upper 16 bits of channel 13 IF0 gain setting
 *
 * PPC addr 0xD060_0178 FPGA addr 0x3000BC – Lower 16 bits of channel 14 IF0 gain setting
 * PPC addr 0xD060_017A FPGA addr 0x3000BD – Upper 16 bits of channel 14 IF0 gain setting
 * PPC addr 0xD060_017C FPGA addr 0x3000BE – Lower 16 bits of channel 15 IF0 gain setting
 * PPC addr 0xD060_017E FPGA addr 0x3000BF – Upper 16 bits of channel 15 IF0 gain setting
 *
 * PPC addr 0xD060_0180 FPGA addr 0x3000C0 – Lower 16 bits of channel 16 IF0 gain setting
 * PPC addr 0xD060_0182 FPGA addr 0x3000C1 – Upper 16 bits of channel 16 IF0 gain setting
 * PPC addr 0xD060_0184 FPGA addr 0x3000C2 – Lower 16 bits of channel 17 IF0 gain setting
 * PPC addr 0xD060_0186 FPGA addr 0x3000C3 – Upper 16 bits of channel 17 IF0 gain setting
 *
 * PPC addr 0xD060_0188 FPGA addr 0x3000C4 – Lower 16 bits of channel 18 IF0 gain setting
 * PPC addr 0xD060_018A FPGA addr 0x3000C5 – Upper 16 bits of channel 18 IF0 gain setting
 * PPC addr 0xD060_018C FPGA addr 0x3000C6 – Lower 16 bits of channel 19 IF0 gain setting
 * PPC addr 0xD060_018E FPGA addr 0x3000C7 – Upper 16 bits of channel 19 IF0 gain setting
 *
 * PPC addr 0xD060_0190 FPGA addr 0x3000C8 – Lower 16 bits of channel 20 IF0 gain setting
 * PPC addr 0xD060_0192 FPGA addr 0x3000C9 – Upper 16 bits of channel 20 IF0 gain setting
 * PPC addr 0xD060_0194 FPGA addr 0x3000CA – Lower 16 bits of channel 21 IF0 gain setting
 * PPC addr 0xD060_0196 FPGA addr 0x3000CB – Upper 16 bits of channel 21 IF0 gain setting
 *
 * PPC addr 0xD060_0198 FPGA addr 0x3000CC – Lower 16 bits of channel 22 IF0 gain setting
 * PPC addr 0xD060_019A FPGA addr 0x3000CD – Upper 16 bits of channel 22 IF0 gain setting
 * PPC addr 0xD060_019C FPGA addr 0x3000CE – Lower 16 bits of channel 23 IF0 gain setting
 * PPC addr 0xD060_019E FPGA addr 0x3000CF – Upper 16 bits of channel 23 IF0 gain setting
 *
 * PPC addr 0xD060_01A0 FPGA addr 0x3000D0 – Lower 16 bits of channel 24 IF0 gain setting
 * PPC addr 0xD060_01A2 FPGA addr 0x3000D1 – Upper 16 bits of channel 24 IF0 gain setting
 * PPC addr 0xD060_01A4 FPGA addr 0x3000D2 – Lower 16 bits of channel 25 IF0 gain setting
 * PPC addr 0xD060_01A6 FPGA addr 0x3000D3 – Upper 16 bits of channel 25 IF0 gain setting
 *
 * PPC addr 0xD060_01A8 FPGA addr 0x3000D4 – Lower 16 bits of channel 26 IF0 gain setting
 * PPC addr 0xD060_01AA FPGA addr 0x3000D5 – Upper 16 bits of channel 26 IF0 gain setting
 * PPC addr 0xD060_01AC FPGA addr 0x3000D6 – Lower 16 bits of channel 27 IF0 gain setting
 * PPC addr 0xD060_01AE FPGA addr 0x3000D7 – Upper 16 bits of channel 27 IF0 gain setting
 *
 * PPC addr 0xD060_01B0 FPGA addr 0x3000D8 – Lower 16 bits of channel 28 IF0 gain setting
 * PPC addr 0xD060_01B2 FPGA addr 0x3000D9 – Upper 16 bits of channel 28 IF0 gain setting
 * PPC addr 0xD060_01B4 FPGA addr 0x3000DA – Lower 16 bits of channel 29 IF0 gain setting
 * PPC addr 0xD060_01B6 FPGA addr 0x3000DB – Upper 16 bits of channel 29 IF0 gain setting
 *
 * PPC addr 0xD060_01B8 FPGA addr 0x3000DC – Lower 16 bits of channel 30 IF0 gain setting
 * PPC addr 0xD060_01BA FPGA addr 0x3000DD – Upper 16 bits of channel 30 IF0 gain setting
 * PPC addr 0xD060_01BC FPGA addr 0x3000DE – Lower 16 bits of channel 31 IF0 gain setting
 * PPC addr 0xD060_01BE FPGA addr 0x3000DF – Upper 16 bits of channel 31 IF0 gain setting
 */

#define FPGA_QT_GAIN_BASE 0x600140
#define QT_GAIN_IF_OFFSET 0
#define QT_GAIN_CH_OFFSET 4
/**
 * Get the quantizer gain value
 * This is an signed fractional int with first 20 bits as fraction
 * @param intFreq - IF [0..1]
 * @param channel - Channel [0..31]
 * @param value - return value
 * @return - 0 on success
 */
int fpga_qt_get_gain(int intFreq, int channel, long int *value)
{
  //TODO: SHIFT return value to 32 bit value
  if(intFreq >= 0 && intFreq < 2 && channel >=0 && channel < 32) {
    util_read_long_fpga(FPGA_QT_GAIN_BASE + (intFreq * QT_GAIN_IF_OFFSET) + (QT_GAIN_CH_OFFSET * channel), 1, value);
    return 0;
  }
  return -1;
}

/**
 * Set the quantizer gain value
 * This is an signed fractional integer with first 20 bits as fraction
 * @param intFreq - IF [0..1]
 * @param channel - Channel [0..31]
 * @param value - Gain setting, only first 25 bits are valid
 * @return - 0 on success
 */
int fpga_qt_set_gain(int intFreq, int channel, long int value)
{
  if(intFreq >= 0 && intFreq < 2 && channel >=0 && channel < 32) {
    util_write_long_fpga(FPGA_QT_GAIN_BASE + (intFreq * QT_GAIN_IF_OFFSET) + (QT_GAIN_CH_OFFSET * channel), 1, &value);
    return 0;
  }
  return -1;
}

/* ---------------------------------------------------------------------------------------------------------
 * These are the other registers.
 *
 * PPC addr 0xD060_01C0 FPGA addr 0x3000E0  -The number of samples collected for state count statistics (N). Read only
 * PPC addr 0xD060_01C2 FPGA addr 0x3000E1 – Quantizer Enable Table Register lower 16 bits. W
 * PPC addr 0xD060_01C4 FPGA addr 0x3000E2 – Quantizer Enable Table Register upper 16 bits.  W
 * PPC addr 0xD060_01C6 FPGA addr 0x3000E3 – Quantizer Status Register lower 16 bits. R
 * PPC addr 0xD060_01C8 FPGA addr 0x3000E4 – Quantizer Status Register upper 16 bits.  R
 * PPC addr 0xD060_01CA FPGA addr 0x3000E5 – Quantizer Control Register, 16 bits. W
 * PPC addr 0xD060_01CC FPGA addr 0x3000E6 – Quantizer Failure Register lower 16 bits. R
 * PPC addr 0xD060_01CE FPGA addr 0x3000E7 – Quantizer Failure Register lower 16 bits.  R
 * PPC addr 0xD060_01D0 FPGA addr 0x3000E8 – Comparator Enable Table Register lower 16 bits. R
 * PPC addr 0xD060_01D2 FPGA addr 0x3000E9 – Comparator Enable Table Register lower 16 bits.  R
 * PPC addr 0xD060_01D4 FPGA addr 0x3000EA – State Machine 2 State Status.  R
 *
 * ----------------------------------------------------------------------------------------------------------
 */

#define FPGA_QT_MISC_BASE 0x6001C0

/**
 * Get the total number of samples collected for state count statistics
 * @param value - number of samples collected
 * @return - 0 on success
 */
int fpga_qt_get_number_samples(unsigned long *value)
{
  util_read_short_fpga(FPGA_QT_MISC_BASE + 0, 1, value);
  return 0;
}

/**
 * Write the bit mask 32 bits to enable(1) or disable(0) each quantizer channel
 * @param channels - [0..31 bits]
 * @return - 0 on success
 */
int fpga_qt_set_enable_table(unsigned long channels)
{
  util_write_long_fpga(FPGA_QT_MISC_BASE + 2, 2, &channels);
  return 0;
}

/**
 * Get the current value of which channels are enabled
 * @param channels - bit-field with 0..31 bits
 * @return - 0 on success
 */
int fpga_qt_get_enable_table(unsigned long *channels)
{
  util_read_long_fpga(FPGA_QT_MISC_BASE + 2, 1, channels);
  return 0;
}

/**
 * Disable a specific quantizer channel
 * @param channel - [0..31]
 * @return - 0 on success
 */
int fpga_qt_disable_channel(int channel)
{
  unsigned long value;
  unsigned long mask = 0;
  if(channel >= 0 && channel < 32){
    mask = ~(1 << channel);
    util_read_long_fpga(FPGA_QT_MISC_BASE + 2, 1, &value);
    value = value & mask; // set bit n to 0
    util_write_long_fpga(FPGA_QT_MISC_BASE + 2, 1, &value);
    return 0;
  }
  return -1;
}

/**
 * Enable a specific quantizer channel
 * @param channel - [0..31]
 * @return - 0 on success
 */
int fpga_qt_enable_channel(int channel)
{
  unsigned long value;
  unsigned long mask = 0;
  if(channel >= 0 && channel < 32){
    mask = (1 << channel);
    util_read_long_fpga(FPGA_QT_MISC_BASE + 2, 1, &value);
    value = value | mask; // set bit n to 1
    util_write_long_fpga(FPGA_QT_MISC_BASE + 2, 1, &value);
    return 0;
  }
  return -1;
}

/**
 * Get the quantizer status register value
 * (1)indicates that the corresponding channel quantization levels have been calculated.
 * @param status - the returned status value
 * @return - 0 on success
 */
int fpga_qt_get_status(unsigned long *status)
{
	util_read_long_fpga(FPGA_QT_MISC_BASE + 6, 1, status);
	return 0;
}

/**
 * Write value to quantizer status register -- will always fail
 * (1)indicates that the corresponding channel quantization levels have been calculated.
 * @param status - the value to write
 * @return - 0 on success
 */
int fpga_qt_set_status(unsigned long status)
{
  util_write_long_fpga(FPGA_QT_MISC_BASE + 6, 1, &status);
  return 0;
}

/**
 * Write the value to quantizer control register
 * Bit 0: Enable the Time Division Multiplexer
 * Bit 1: Enable the Quantization Level Calculator
 * @param value - the value to set [0 disable, 1 enable]
 * @return - 0 on success
 */
int fpga_qt_set_control(unsigned short value)
{
  util_write_short_fpga(FPGA_QT_MISC_BASE + 10, 1, &value);
  return 0;
}

/**
 * Get the quantizer control register value
 * @param value - return parameter [0 disable, 1 enable]
 * @return - 0 on success
 */
int fpga_qt_get_control(unsigned short *value)
{
  util_read_short_fpga(FPGA_QT_MISC_BASE + 10, 1, value);
  return 0;
}

/**
 * Get the quantizer failure register values
 * Quantizer Failure Resister indicates that the corresponding channel quantization levels have
 * been calculated and did not meet the set criteria.
 * @param value - the value bit-field 0..31
 * @return - 0 on success
 */
int fpga_qt_get_failure(unsigned long *value)
{
  util_read_long_fpga(FPGA_QT_MISC_BASE + 12, 1, value);
  return 0;
}

/**
 * Write a failure pattern to the quantizer failure register
 * Quantizer Failure Resister indicates that the corresponding channel quantization levels have
 * been calculated and did not meet the set criteria.
 * @param value - bit-field 0..31
 * @return - 0 on success
 */
int fpga_qt_set_failure(unsigned long value)
{
  util_write_long_fpga(FPGA_QT_MISC_BASE + 12, 1, &value);
  return 0;
}


/**
 * Comparator Enable Table Register is a 32 bit register. When a bit is set the corresponding
 * channels comparators are enabled.
 * @param value - the value bit-field 0..31
 * @return - 0 on success
 */
int fpga_qt_get_comparator_enable(unsigned long *value)
{
  util_read_long_fpga(FPGA_QT_MISC_BASE + 16, 1, value);
  return 0;
}

/**
 * Comparator Enable Table Register is a 32 bit register. When a bit is set the corresponding
 * channels comparators are enabled.
 * @param value - bit-field 0..31
 * @return - 0 on success
 */
int fpga_qt_set_comparator_enable(unsigned long value)
{
  util_write_long_fpga(FPGA_QT_MISC_BASE + 16, 1, &value);
  return 0;
}

/**
 * Get the quantizer state machine status
 * @param value -
 * @return - 0 on success
 */
int fpga_qt_get_state_machine_status(unsigned short *value)
{
  util_read_short_fpga(FPGA_QT_MISC_BASE + 20, 1, value);
  return 0;
}

/**
 * Set the quantizer state machine status
 * @param value -
 * @return - 0 on success
 */
int fpga_qt_set_state_machine_status(unsigned short value)
{
  util_write_short_fpga(FPGA_QT_MISC_BASE + 20, 1, &value);
  return 0;
}

int fpga_qt_set_initial()
{
  short value = 1;
  /* --- reset the enable bit */
  util_write_short_fpga(FPGA_QT_MISC_BASE + 0xA, 1, &value);
  /* --- set the enable bit and restart bit */
  value = 3;
  util_write_short_fpga(FPGA_QT_MISC_BASE + 0xA, 1, &value);
  return 0;
}
int fpga_qt_set_requantize()
{
  short value = 5;
  /* --- reset the enable bit */
  util_write_short_fpga(FPGA_QT_MISC_BASE + 0xA, 1, &value);
  /* --- set the enable bit */
  value = 7;
  util_write_short_fpga(FPGA_QT_MISC_BASE + 0xA, 1, &value);
  return 0;
}

/* ----------------------------------------------------------------------------------------------------------
 * Mark V B Interface
 *
 * PPC addr 0xD080_0000 FPGA addr 0x400000 – Sync Word Register lower 16 bits. R/W
 * PPC addr 0xD080_0002 FPGA addr 0x400001 – Sync Word Register upper 16 bits.  R/W
 * PPC addr 0xD080_0004 FPGA addr 0x400002 – Years From 2000Quantizer (lower 4 bits) R/W -- ?
 * PPC addr 0xD080_0006 FPGA addr 0x400003 – T (bit 0)  R/W
 * PPC addr 0xD080_0008 FPGA addr 0x400004 – User Specified Register (lower 12 bits) R/W
 * PPC addr 0xD080_000A FPGA addr 0x400005 – Unassigned Register lower 16 bits R/W
 * PPC addr 0xD080_000C FPGA addr 0x400006 – Unassigned  Register upper 16 bits.  R/W
 * PPC addr 0xD080_000E FPGA addr 0x400007 – State Machine 2 State Status.  R
 * ----------------------------------------------------------------------------------------------------------
 */

#define FPGA_MK5_BASE 0x800000

/**
 * Get the sync word from MKV
 * @param value - return value
 * @return 0 on success
 */
int fpga_mk5_get_sync_word(unsigned long *value)
{
	util_read_long_fpga(FPGA_MK5_BASE + 0, 1, value);
	return 0;
}

/**
 * Set the MKV sync word
 * @param value - value to write
 * @return - 0 on success
 */
int fpga_mk5_set_sync_word(unsigned long value)
{
	util_write_long_fpga(FPGA_MK5_BASE + 0, 1, &value);
	return 0;
}

/**
 * Get the number of years from 2000
 * @param value - return value
 * @return - 0 on success
 */
int fpga_mk5_get_years(unsigned short *value)
{
	util_read_short_fpga(FPGA_MK5_BASE + 4, 1, value);
	return 0;
}

/**
 * Set the number of years from 2000
 * @param value - return value
 * @return - 0 on success
 */
int fpga_mk5_set_years(unsigned short value)
{
	util_write_short_fpga(FPGA_MK5_BASE + 4, 1, &value);
	return 0;
}

/**
 * Set the T-Bit (only bit 0 is valid)
 * @param value - [0..1]
 * @return - 0 on success
 */
int fpga_mk5_set_t_bit(unsigned short value)
{
	util_write_short_fpga(FPGA_MK5_BASE + 6, 1, &value);
	return 0;
}

/**
 * Get the T-Bit (only bit 0 is valid)
 * @param value - [0..1]
 * @return - 0 on success
 */
int fpga_mk5_get_t_bit(unsigned short *value)
{
	util_read_short_fpga(FPGA_MK5_BASE + 6, 1, value);
	return 0;
}

/**
 * Set the user specified register value (12 bit)
 * @param value - the value to set
 * @return - 0 on success
 */
int fpga_mk5_set_user_reg(unsigned short value)
{
	util_write_short_fpga(FPGA_MK5_BASE + 8, 1, &value);
	return 0;
}

/**
 * Get the current user register value
 * @param value - return parameter (12 bit)
 * @return - 0 on success
 */
int fpga_mk5_get_user_reg(unsigned short *value)
{
	util_read_short_fpga(FPGA_MK5_BASE + 8, 1, value);
	return 0;
}

/**
 * Set the 32 bits of the un-assigned register value
 * @param value - the value bits 0..31
 * @return - 0 on success
 */
int fpga_mk5_set_unassigned_reg(unsigned long value)
{
	util_write_long_fpga(FPGA_MK5_BASE + 10, 1, &value);
	return 0;
}

/**
 * Get the 32 bits of the un-assigned register value
 * @param value - the returned value bits 0..31
 * @return - 0 on success
 */
int fpga_mk5_get_unassigned_reg(unsigned long *value)
{
	util_read_long_fpga(FPGA_MK5_BASE + 10, 1, value);
	return 0;
}

/**
 * Get mark5 state machine status
 * @param value -
 * @return - 0 on success
 */
int fpga_mk5_get_state_machine_status(unsigned short *value)
{
	util_read_short_fpga(FPGA_MK5_BASE + 14, 1, value);
	return 0;
}

/* ----------------------------------------------------------------------------------------------------------
 * Output Channel Selector Registers
 * The Channel Selection Registers permits a user to select 1 of 32 frequency channels for each output channel
 * slot. This is a 5 bit binary code (lower 5 bits of the 16 bit register). In the VLBI2010 design there are 16
 * available slots, each slot can select any one of the different frequency channels from either IF0 or IF1.
 *
 * Each "output slot" is coded so that the 4 lowest bits select an input channel 0..15, and bit 4 selects IF0 or 1
 *
 * PPC addr 0xD080_001E FPGA addr 0x40000F – Channel Selection Slot 0 R/W
 * PPC addr 0xD080_0020 FPGA addr 0x400010 – Channel Selection Slot 1 R/W
 * PPC addr 0xD080_0022 FPGA addr 0x400011 – Channel Selection Slot 2 R/W
 * PPC addr 0xD080_0024 FPGA addr 0x400012 – Channel Selection Slot 3 R/W
 * PPC addr 0xD080_0026 FPGA addr 0x400013 – Channel Selection Slot 4 R/W
 * PPC addr 0xD080_0028 FPGA addr 0x400014 – Channel Selection Slot 5 R/W
 * PPC addr 0xD080_002A FPGA addr 0x400015 – Channel Selection Slot 6 R/W
 * PPC addr 0xD080_002C FPGA addr 0x400016 – Channel Selection Slot 7 R/W
 * PPC addr 0xD080_002E FPGA addr 0x400017 – Channel Selection Slot 8 R/W
 * PPC addr 0xD080_0030 FPGA addr 0x400018 – Channel Selection Slot 9 R/W
 * PPC addr 0xD080_0032 FPGA addr 0x400019 – Channel Selection Slot 10 R/W
 * PPC addr 0xD080_0034 FPGA addr 0x40001A – Channel Selection Slot 11 R/W
 * PPC addr 0xD080_0036 FPGA addr 0x40001B – Channel Selection Slot 12 R/W
 * PPC addr 0xD080_0038 FPGA addr 0x40001C – Channel Selection Slot 13 R/W
 * PPC addr 0xD080_003A FPGA addr 0x40001D – Channel Selection Slot 14 R/W
 * PPC addr 0xD080_003C FPGA addr 0x40001E – Channel Selection Slot 15 R/W
 *
 */

#define FPGA_MK5_OUTPUT_SELECT_BASE 0x0080001E

/**
 * Set the output channel [0..15] to take input from inputChannel [0..31]
 * Coded with IF0 = [0..15] and IF1 [16..31]
 * @param ouputChannel - the output channel 0 .. 15
 * @param inputChannel - the input channel 0..31
 * @return - 0 on success
 */
int fpga_set_channel_select(unsigned short outputChannel, unsigned short inputChannel)
{
	if(inputChannel < 32 && outputChannel < 16) {
		util_write_short_fpga(FPGA_MK5_OUTPUT_SELECT_BASE + (2 * outputChannel), 1, &inputChannel);
		return 0;
	}
	return -1;
}

/**
 * Get the input channel [0..31] that the output channel [0..15] to take input from
 * Coded with IF0 = [0..15] and IF1 [16..31]/
 * @param ouputChannel - the output channel 0 .. 15
 * @param inputChannel - the input channel 0..31
 * @return - 0 on success
 */
int fpga_get_channel_select(unsigned short outputChannel, unsigned short *inputChannel)
{
	if(outputChannel < 16) {
		util_read_short_fpga(FPGA_MK5_OUTPUT_SELECT_BASE + (2 * outputChannel), 1, inputChannel);
		return 0;
	}
	return -1;
}


/* ----------------------------------------------------------------------------------------------------------
 *  Optimal Input Level Detector Registers
 *
 * Addresses (FPGA)
 * PPC addr 0xD0A0_0000  FPGA addr 0x300000 – Control
 * PPC addr 0xD0A0_0002  FPGA addr 0x300001 – Status
 * PPC addr 0xD0A0_0004  FPGA addr 0x300002 – Low State Count
 * PPC addr 0xD0A0_0006  FPGA addr 0x300003 – Mid State Count
 * PPC addr 0xD0A0_0008  FPGA addr 0x300004 – High State Count
 * PPC addr 0xD0A0_0010  FPGA addr 0x300008– Number of  Samples  40k for now
 * PPC addr 0xD0A0_0012 FPGA addr 0x300009 – State Machine Status
 *
 * -----------------------------------------------------------------------------------------------------------
 */

#define FPGA_ILD_BASE 0xa00000

/**
 * Get input level detector control value
 * @param value - the control register value
 * @return - 0 on success
 */
int fpga_ild_get_control(unsigned short *value)
{
	util_read_short_fpga(FPGA_ILD_BASE + 0, 1, value);
	return 0;
}

/**
 * Set the input level control register to value
 * @param value - the value to write
 * @return - 0 on success
 */
int fpga_ild_set_control(unsigned short value)
{
	util_write_short_fpga(FPGA_ILD_BASE + 0, 1, &value);
	return 0;
}

/**
 * Get the input level detector status
 * @param status - returned value
 * @return - 0 on success
 */
int fpga_ild_get_status(unsigned short *status)
{
	util_read_short_fpga(FPGA_ILD_BASE + 2, 1, status);
	return 0;
}

/**
 * Set the input level detector status
 * @param status - status to set
 * @return - 0 on success
 */
int fpga_ild_set_status(unsigned short status)
{
	util_write_short_fpga(FPGA_ILD_BASE + 2, 1, &status);
	return 0;
}

/**
 * Get the state count
 * @param cnt - returned value
 * @return - 0 on success
 */
int fpga_ild_get_low_state_count(unsigned short *cnt)
{
	util_read_short_fpga(FPGA_ILD_BASE + 4, 1, cnt);
	return 0;
}

/**
 * Set the state count
 * @param cnt - value to set
 * @return - 0 on success
 */
int fpga_ild_set_low_state_count(unsigned short cnt)
{
	util_write_short_fpga(FPGA_ILD_BASE + 4, 1, &cnt);
	return 0;
}
/**
 * Get the state count
 * @param cnt - returned value
 * @return - 0 on success
 */
int fpga_ild_get_mid_state_count(unsigned short *cnt)
{
	util_read_short_fpga(FPGA_ILD_BASE + 6, 1, cnt);
	return 0;
}

/**
 * Set the state count
 * @param cnt - value to set
 * @return - 0 on success
 */
int fpga_ild_set_mid_state_count(unsigned short cnt)
{
	util_write_short_fpga(FPGA_ILD_BASE + 6, 1, &cnt);
	return 0;
}

/**
 * Get the state count
 * @param cnt - returned value
 * @return - 0 on success
 */
int fpga_ild_get_high_state_count(unsigned short *cnt)
{
	util_read_short_fpga(FPGA_ILD_BASE + 8, 1, cnt);
	return 0;
}

/**
 * Set the state count
 * @param cnt - value to set
 * @return - 0 on success
 */
int fpga_ild_set_high_state_count(unsigned short cnt)
{
	util_write_short_fpga(FPGA_ILD_BASE + 8, 1, &cnt);
	return 0;
}


/**
 * Get the Input Level Detector number of samples
 * @param cnt - returned value
 * @return - 0 on success
 */
int fpga_ild_get_num_samples(unsigned short *cnt)
{
	util_read_short_fpga(FPGA_ILD_BASE + 10, 1, cnt);
	return 0;
}

/**
 * Set the Input Level Detector number of samples
 * @param cnt - number of samples
 * @return - 0 on success
 */
int fpga_ild_set_num_samples(unsigned short cnt)
{
	util_write_short_fpga(FPGA_ILD_BASE + 10, 1, &cnt);
	return 0;
}

/**
 * Get the Input Level Detector state machine status
 * @param status - returned value
 * @return - 0 on success
 */
int fpga_ild_get_state_machine_status(unsigned short *status)
{
	util_read_short_fpga(FPGA_ILD_BASE + 12, 1, status);
	return 0;
}


/* ------------------------------------------------------------------------------------------------
 * 10 Gigabit Ethernet functions
 *
 * Default register values from Verilog definition file
 * kat_ten_gb_eth_0 : kat_ten_gb_eth
 *  generic map (
 *
 *    C_BASEADDR     => x"01000000",
 *    C_HIGHADDR     => x"01003FFF",
 *    C_OPB_AWIDTH   => 32,
 *    C_OPB_DWIDTH   => 32,
 *    FABRIC_MAC     => x"123456789abc",
 *    FABRIC_IP      => x"30405060",
 *    FABRIC_PORT    => x"2468",
 *    FABRIC_GATEWAY => x"fb",
 *    FABRIC_ENABLE  => 1,
 *    SWING          => 800,
 *    PREEMPHASYS    => 3,
 *    CPU_TX_ENABLE  => 1,
 *    CPU_RX_ENABLE  => 1,
 *    RX_DIST_RAM    => 0
 *
 * The register definitions are in archive_remote_sources/kat_ten_gb_eth/hdl/verilog/opb_attach.v
 * relative to the base address.
 */

#define FPGA_10GE_BASE              0x0400000
#define FPGA_10GE_CX4_OFFSET        0x10000
#define FPGA_10GE_REGISTERS_OFFSET  0x0000
#define FPGA_10GE_REGISTERS_HIGH    0x07FF
#define FPGA_10GE_TX_BUFFER_OFFSET  0x2000
#define FPGA_10GE_TX_BUFFER_HIGH    0x17FF
#define FPGA_10GE_RX_BUFFER_OFFSET  0x4000
#define FPGA_10GE_RX_BUFFER_HIGH    0x27FF
#define FPGA_10GE_ARP_CACHE_OFFSET  0x6000
#define FPGA_10GE_ARP_CACHE_HIGH    0x37FF

// TODO: verify local mac address byte order for correct operation
#define FPGA_10GE_LOCAL_MAC       0x00
#define FPGA_10GE_LOCAL_GATEWAY   0x06
#define FPGA_10GE_LOCAL_IP        0x08
#define FPGA_10GE_BUFFER_SIZES    0x0C
#define FPGA_10GE_VALID_PORTS     0x0E
#define FPGA_10GE_LOCAL_PORT_CTRL 0x10
#define FPGA_10GE_XAUI_STATUS     0x12
#define FPGA_10GE_PHY_CONFIG      0x14
#define FPGA_10GE_DEST_IP         0x16

//#define FPGA_10GE_PHY_CONFIG     (0x08<<2)

/*
 * -------------------------------------------------------------------------------------------------
 * TODO: Add register offsets for all Ethernet ports... today all queries go to port 0
 */

/**
 * Set the local MAC address for the 10GE port
 * @param port - Ethernet port [0..4]
 * @param MAC - array of 6 bytes LE format [00:01:02:03:...] = 00:02:02 ..
 * @return - 0 on success
 */
int fpga_10ge_set_local_mac(unsigned port, unsigned char *mac)
{
  if(port >=0 && port < 4){
    util_write_short_fpga(FPGA_10GE_BASE + port * FPGA_10GE_CX4_OFFSET + FPGA_10GE_LOCAL_MAC, 3, mac);
    return 0;
  }
  return -1;
}

/**
 * Get the local MAC address for the 10GE port
 * @param port - Ethernet port [0..4]
 * @param mac - return value - array of 6 bytes LE format [00:01:02:03:...] = 00:02:02 ..
 * @return - 0 on success
 */
int fpga_10ge_get_local_mac(unsigned port, unsigned char *mac)
{
  if(port >=0 && port < 4){
    //util_read_byte_fpga(FPGA_10GE_BASE + port * FPGA_10GE_CX4_OFFSET + FPGA_10GE_LOCAL_MAC, 6, mac);
    util_read_short_fpga(FPGA_10GE_BASE + port * FPGA_10GE_CX4_OFFSET + FPGA_10GE_LOCAL_MAC, 3, mac);
    return 0;
  }
  return -1;
}

/**
 * Set the local Gateway address for the 10GE port
 * @param port - Ethernet port [0..4]
 * @param ip - 1 byte end of the local ip address 192.168.0.1 should be 1
 * @return - 0 on success
 */
int fpga_10ge_set_local_gw(unsigned port, unsigned char ip)
{
  unsigned short value = ip;
  if(port >=0 && port < 4){
    util_write_short_fpga(FPGA_10GE_BASE + port * FPGA_10GE_CX4_OFFSET + FPGA_10GE_LOCAL_GATEWAY, 1, &value);
    return 0;
  }
  return -1;
}

/**
 * Get the local Gateway address for the 10GE port
 * @param port - Ethernet port [0..4]
 * @param ip - return value - 1 byte with end of ip 192.168.0.1 returns "1"
 * @return - 0 on success
 */
int fpga_10ge_get_local_gw(unsigned port, unsigned char *ip)
{
  unsigned short value ; // type conversion
  if(port >=0 && port < 4){
    util_read_short_fpga(FPGA_10GE_BASE + port * FPGA_10GE_CX4_OFFSET + FPGA_10GE_LOCAL_GATEWAY, 1, &value);
    *ip = (unsigned char)value; // type conversion
    return 0;
  }
  return -1;
}

/**
 * Set the local IP address for the 10GE port
 * @param port - Ethernet port [0..3]
 * @param ip - 4 bytes 192.168.0.1 then ip should be [192, 168, 0, 1]
 * @return - 0 on success
 */
int fpga_10ge_set_local_ip(unsigned port, unsigned long *ip)
{
  if(port >=0 && port < 4){
    util_write_long_fpga(FPGA_10GE_BASE + port * FPGA_10GE_CX4_OFFSET + FPGA_10GE_LOCAL_IP, 1, ip);
    return 0;
  }
  return -1;
}

/**
 * Get the local IP address for the 10GE port
 * @param port - Ethernet port [0..3]
 * @param ip - return value - array of 4 bytes LE format [192, 168, 0,1] = 192.168.0.1
 * @return - 0 on success
 */
int fpga_10ge_get_local_ip(unsigned port, unsigned long *ip)
{
  if(port >=0 && port < 4){
    util_read_long_fpga(FPGA_10GE_BASE + port * FPGA_10GE_CX4_OFFSET + FPGA_10GE_LOCAL_IP, 1, ip);
    return 0;
  }
  return -1;
}

/**
 * Set the destination IP address
 * @param ip - unsigned long representation of IP address
 * @return - 0 on success
 */
int fpga_10ge_set_dest_ip(unsigned short *upper, unsigned short *lower)
{
  util_write_short_fpga(FPGA_10GE_BASE + FPGA_10GE_DEST_IP, 1, lower);
  util_write_short_fpga(FPGA_10GE_BASE + FPGA_10GE_DEST_IP + 2, 1, upper);
  return 0;
}

/**
 * Get the destination IP address
 * @return ip - return value - unsigned long representation of IP
 * @return - 0 on success
 */
int fpga_10ge_get_dest_ip(unsigned short *upper, unsigned short *lower)
{
  util_read_short_fpga(FPGA_10GE_BASE + FPGA_10GE_DEST_IP, 1, lower);
  util_read_short_fpga(FPGA_10GE_BASE + FPGA_10GE_DEST_IP + 2, 1, upper);
  return 0;
}

/**
 * Set the port control register.
 * @param ctrl -  control word for the destination control register
 * @return - 0 on success
 */
int fpga_10ge_set_local_port_ctrl(unsigned short ctrl)
{
  util_write_short_fpga(FPGA_10GE_BASE + FPGA_10GE_LOCAL_PORT_CTRL, 1, &ctrl);
  return 0;
}

/**
 * Get the port control register.
 * @return ctrl -  control word for the destination control register
 * @return - 0 on success
 */
int fpga_10ge_get_local_port_ctrl(unsigned short *ctrl)
{
  util_read_short_fpga(FPGA_10GE_BASE + FPGA_10GE_LOCAL_PORT_CTRL, 1, ctrl);
  return 0;
}

/**
 * Set the buffer size value for the RX/TX buffer
 * @param port - Ethernet port
 * @param sz - size of buffer (valid data in the buffer)
 * @return - 0 on success
 */
int fpga_10ge_set_buffer_sizes(unsigned port, unsigned short sz)
{
  if(port >=0 && port < 4){
    util_write_short_fpga(FPGA_10GE_BASE + port * FPGA_10GE_CX4_OFFSET + FPGA_10GE_BUFFER_SIZES, 1, &sz);
    return 0;
  }
  return -1;
}

/**
 * Read the value of valid data in receive buffer
 * @param port - Ethernet port
 * @param sz - valid number of bytes
 * @return - 0 on success
 */
int fpga_10ge_get_buffer_sizes(unsigned port, unsigned short *sz)
{
  if(port >=0 && port < 4){
    util_read_short_fpga(FPGA_10GE_BASE + port * FPGA_10GE_CX4_OFFSET + FPGA_10GE_BUFFER_SIZES, 1, sz);
    return 0;
  }
  return -1;
}

/**
 * TODO:
 * @param port
 * @param ports
 * @return
 */
int fpga_10ge_set_valid_ports(unsigned port, unsigned short ports)
{
  if(port >=0 && port < 4){
    util_write_short_fpga(FPGA_10GE_BASE + port * FPGA_10GE_CX4_OFFSET + FPGA_10GE_VALID_PORTS, 1, &ports);
    return 0;
  }
  return -1;
}

/**
 * TODO:
 * @param port
 * @param ports
 * @return
 */
int fpga_10ge_get_valid_ports(unsigned port, unsigned short *ports)
{
  if(port >=0 && port < 4){
    util_read_short_fpga(FPGA_10GE_BASE + port * FPGA_10GE_CX4_OFFSET + FPGA_10GE_VALID_PORTS, 1, ports);
    return 0;
  }
  return -1;
}

/**
 * Read the status register of the XILINX XAUI
 * @param port - the port to read
 * @param status - see XILINX documentation
 * @return - 0 n success
 */
int fpga_10ge_get_xaui_status(unsigned port, unsigned short *status)
{
  if(port >=0 && port < 4){
    util_read_short_fpga(FPGA_10GE_BASE + port * FPGA_10GE_CX4_OFFSET + FPGA_10GE_XAUI_STATUS, 1, status);
    return 0;
  }
  return -1;
}
/**
 * TODO:
 * @param port
 * @param config
 * @return
 */
int fpga_10ge_set_phy_config(unsigned port, unsigned short config)
{
  if(port >=0 && port < 4){
    util_write_short_fpga(FPGA_10GE_BASE + port * FPGA_10GE_CX4_OFFSET + FPGA_10GE_PHY_CONFIG, 1, &config);
    return 0;
  }
  return -1;
}

/**
 * TODO:
 * @param port - the port number [0..3]
 * @param config - return value
 * @return 0 on success
 */
int fpga_10ge_get_phy_config(unsigned port, unsigned short *config)
{
  if(port >=0 && port < 4){
    util_read_short_fpga(FPGA_10GE_BASE + port * FPGA_10GE_CX4_OFFSET + FPGA_10GE_PHY_CONFIG, 1, config);
    return 0;
  }
  return -1;
}


/**
 * Write bytes to the TX buffer on port
 * @param port - the port to write to
 * @param buf - array of bytes to write (2k always)
 * @return - 0 on success
 */
int fpga_10ge_set_tx_buffer(unsigned port, unsigned char *buf)
{
  if(port >=0 && port < 4){
    util_write_short_fpga(FPGA_10GE_BASE + port * FPGA_10GE_CX4_OFFSET + FPGA_10GE_TX_BUFFER_OFFSET, 1024, buf);
    return 0;
  }
  return -1;
}

/**
 * Read data from TX buffer on port
 * @param port - the port to read from
 * @param buf - return array of bytes from buffer (user must allocate 2k)
 * @return - 0 on success
 */
int fpga_10ge_get_tx_buffer(unsigned port, unsigned char *buf)
{
  if(port >=0 && port < 4){
    util_read_short_fpga(FPGA_10GE_BASE + port * FPGA_10GE_CX4_OFFSET + FPGA_10GE_TX_BUFFER_OFFSET, 1024, buf);
    return 0;
  }
  return -1;
}

/**
 * Write bytes to the RX buffer on port
 * @param port - the port to write to (2k always)
 * @param buf - array of bytes to write
 * @return - 0 on success
 */
int fpga_10ge_set_rx_buffer(unsigned port, unsigned char *buf)
{
  if(port >=0 && port < 4){
    util_write_short_fpga(FPGA_10GE_BASE + port * FPGA_10GE_CX4_OFFSET + FPGA_10GE_RX_BUFFER_OFFSET, 1024, buf);
    return 0;
  }
  return -1;
}
/**
 * Write bytes to the TX buffer on port
 * @param port - the port to write to
 * @param buf - return - array of bytes to write 2k user must allocate
 * @return - 0 on success
 */
int fpga_10ge_get_rx_buffer(unsigned port, unsigned char *buf)
{
  if(port >=0 && port < 4){
    util_read_short_fpga(FPGA_10GE_BASE + port * FPGA_10GE_CX4_OFFSET + FPGA_10GE_TX_BUFFER_OFFSET, 1024, buf);
    return 0;
  }
  return -1;
}

/**
 * Write a full APR cache table to FPGA port TODO: This one does not work.. table is not set this way
 * @param port - the port [0..3]
 * @param arp_table - 128 entries of 6 bytes each in LE format
 * @return - 0 on success
 */
int fpga_10ge_set_arp_cache(unsigned port, unsigned char *arp_table)
{
  if(port >=0 && port < 4){
    util_write_short_fpga(FPGA_10GE_BASE + FPGA_10GE_ARP_CACHE_OFFSET, 384 /*(128 * 6 / 2)*/, arp_table);
    return 0;
  }
  return -1;
}

/**
 * Write a full APR cache table to FPGA port  TODO: This does not work
 * User must allocate return buffer
 * @param port - the port [0..3]
 * @param arp_table - (return value) 128 entries of 6 bytes each in LE format
 * @return - 0 on success
 */
int fpga_10ge_get_arp_cache(unsigned port, unsigned char *arp_table)
{
  if(port >=0 && port < 4){
    util_read_short_fpga(FPGA_10GE_BASE + FPGA_10GE_ARP_CACHE_OFFSET, 384 /*(128 * 6 / 2)*/, arp_table);
    return 0;
  }
  return -1;
}

/**
 * Get the ARP table entry for port, and ip with ending number pos
 * User must allocate return value
 * @param port - Ethernet port [0..3]
 * @param pos - Ending IP address [0..127]
 * @param mac - return value - 6 bytes LE array of byte
 * @return - 0 on success
 */
int fpga_10ge_get_arp_value(unsigned port, unsigned char pos, unsigned char *mac)
{
  if(port >=0 && port < 4){
    util_read_short_fpga(FPGA_10GE_BASE + FPGA_10GE_ARP_CACHE_OFFSET + (16*pos), 3, mac);
    return 0;
  }
  return -1;
}

/**
 * Set the arp table entry for port, and ip with ending number pos
 * @param port - Ethernet port [0..3]
 * @param pos - Ending IP address [0..127]
 * @param mac - 6 bytes LE array of byte
 * @return - 0 on success
 */
int fpga_10ge_set_arp_value(unsigned port, unsigned char pos, unsigned char *mac)
{
  if(port >=0 && port < 4){
#if DEBUG_VERBOSE
    printf("Set Arp: Addr=%lx MAC=%d:%d:%d:%d:%d:%d\n", (unsigned long)mac, mac[4], mac[5], mac[2], mac[3], mac[0], mac[1]);
#endif
    util_write_short_fpga(FPGA_10GE_BASE + FPGA_10GE_ARP_CACHE_OFFSET + (16*pos), 3, mac);
    return 0;
  }
  return -1;
}


/**
 * Set the Maximum MTU size for the port
 * @param port 0 .. 3
 * @param mtu - only 90000 allowed
 * @return - 0 on success
 */
int fpga_10ge_set_if_mtu(unsigned port, unsigned short mtu)
{
  // currently MTU is fixed and set to 9000
  if(port >=0 && port < 4){
    if(mtu == 9000 ) return 0;
  }
  return -1;
}

/**
 * Get the current Max MTU size for port
 * @param port 0..3
 * @param mtu -- return value MTU
 * @return 0 on success
 */
int fpga_10ge_get_if_mtu(unsigned port, unsigned short *mtu)
{
  // currently MTU is fixed and set to 9000
  if(port >=0 && port < 4){
    *mtu=9000;
    return 0;
  }
  return -1;
}

/**
 * Set the interface mode to
 * @param port interface 0 .. 3
 * @param mode (2 or 4)
 * @return 0 on success
 */
int fpga_10ge_set_if_mode(unsigned port, unsigned char mode)
{
  // currently Mode is always 4
  if(port >=0 && port < 4){
    if(mode == 4 ) return 0;
  }
  return -1;
}

/**
 * Get the interface mode
 * @param port Interface 0 .. 3
 * @param mode - return value [2|4]
 * @return 0 always success
 */
int fpga_10ge_get_if_mode(unsigned port, unsigned char *mode)
{
  if(port >=0 && port < 4){
    *mode = 4;
    return 0;
  }
  return -1;
}


#define FPGA_JULIAN_TIME_WRITE 0x00000010
#define FPGA_JULIAN_TIME_READ  0x00000014

/*
 * Set the Julian time value in the FPGA
 * @param dot - JJJSSSSS
 * @return 0
 */
int fpga_set_dot(unsigned long dot)
{
  util_write_long_fpga(FPGA_JULIAN_TIME_WRITE, 1, &dot);
  return 0;
}

/**
 * Read the Julian time code value from the FPGA
 * @param dot the Julian time code as read from the FPGA
 * @return 0
 */
int fpga_get_dot(unsigned long *dot)
{
  util_read_long_fpga(FPGA_JULIAN_TIME_READ, 1, dot);

  return 0;
}



/* ****************************************************************************
 *
 *            Data Transfer Module Registers
 *
 * ****************************************************************************
 */

#define FPGA_DTM_CONTROL        0x800010  // The DTM control register
#define FPGA_DTM_STATUS         0x800012  // The DTM status register
#define FPGA_DTM_TIMESLOT_BASE  0x800014  // Start of Time-slot table inside DTM

/**
 * Set the Data Transfer Module Control register bits
 * @param ctl : control data to write
 * @return 0 - on success
 */
int fpga_dtm_set_control(unsigned short ctl)
{
	util_write_short_fpga(FPGA_DTM_CONTROL, 1, &ctl);
	return 0;
}

/**
 * Read the Data Transfer Module control register
 * @param ctl : the control register value
 * @return 0 on success
 */
int fpga_dtm_get_control(unsigned short *ctl)
{
	util_read_short_fpga(FPGA_DTM_CONTROL, 1, ctl);
	return 0;
}

/**
 * Get the Data Transfer Module Status register bits
 * @param status : the status register contents
 * @return 0 - on success
 */
int fpga_dtm_get_status(unsigned short *status)
{
	util_read_short_fpga(FPGA_DTM_STATUS, 1, status);
	return 0;
}

/**
 * Set the time to start and time to stop capture in the DTM module
 * @param slotNo - position in the DTM shall be 1 .. 16(currently only 1 slot)
 * @param tOn - 32 bit Julian time
 * @param tOff - 32 bit Julian time
 * @return - 0 on success
 */
int fpga_dtm_set_timeslot(unsigned slotNo, unsigned long tOn, unsigned long tOff)
{
  if(slotNo > 0 && slotNo <=1) {
    // need to disable MK5
    fpga_mk5_disable();
    util_write_long_fpga(FPGA_DTM_TIMESLOT_BASE + ((slotNo-1)*8), 1, &tOn);
    util_write_long_fpga(FPGA_DTM_TIMESLOT_BASE + ((slotNo-1)*8)+4, 1, &tOff);
    // Enable MK5
    fpga_mk5_enable();
    return 0;
  }
  return -1;
}

/**
 * Get the time to start and time to stop capture in the DTM module
 * @param slotNo - position in the DTM shall be 1 .. 16 (currently only 1)
 * @param tOn - 32 bit Julian time
 * @param tOff - 32 bit Julian time
 * @return - 0 on success
 */
int fpga_dtm_get_timeslot(unsigned slotNo, unsigned long *tOn, unsigned long *tOff)
{
  if(slotNo > 0 && slotNo <=1) {
    util_read_long_fpga(FPGA_DTM_TIMESLOT_BASE + ((slotNo-1)*8), 1, tOn);
    util_read_long_fpga(FPGA_DTM_TIMESLOT_BASE + ((slotNo-1)*8)+4, 1, tOff);
    return 0;
  }
  return -1;
}

/**
 * Set the time to stop capture in the DTM module
 * @param slotNo - position in the DTM shall be 1 .. 16(currently only 1 slot)
 * @param tOff - 32 bit Julian time
 * @return - 0 on success
 */
int fpga_dtm_set_timeslot_end(unsigned slotNo, unsigned long tOff)
{
	if(slotNo > 0 && slotNo <=1) {
		util_write_long_fpga(FPGA_DTM_TIMESLOT_BASE + ((slotNo-1)*8)+4, 1, &tOff);
		return 0;
	}
	return -1;
}


/* ****************************************************************************
 *
 *            ALC/Frequency Synthesizer Module Registers
 *
 * ****************************************************************************
 */

#define FPGA_ALC_CMD                0x000E0  // The ALC CMD: Attenuator Setting Register
#define FPGA_ALC_FPGA_VER           0x000E2  // The ALC FPGA Version Register
#define FPGA_ALC_PPS_STATUS         0x000E4  // The ALC PPS Status Register
#define FPGA_ALC_PPS_SYNC_LSB       0x000E6  // The ALC PPS Synchronization LSB.
#define FPGA_SYN_CMD                0x000E8  // Synthesizer Setting Register.
#define FPGA_ALC_PPS_SYNC_MSB       0x000EA  // The ALC PPS Synchronization MSB.
#define FPGA_ALC_TEST_PATTERN       0x000EB  // The ALC Test Pattern Register

/**
 * Set the ALC Control register bits
 * @param ctl : control data to write
 * @return 0 - on success
 */
int fpga_alc_set_control(unsigned short ctl)
{
  util_write_short_fpga(FPGA_ALC_CMD, 1, &ctl);
  return 0;
}

int fpga_fs_set_control(unsigned short ctl)
{
  util_write_short_fpga(FPGA_SYN_CMD, 1, &ctl);
  return 0;
}
/**
 * Read  the ALC Control register bits
 * @param ctl : control data to read
 * @return 0 - on success
 */
int fpga_alc_get_control(unsigned short *ctl)
{
  util_read_short_fpga(FPGA_ALC_CMD, 1, ctl);
  return 0;
}

/**
 * Read the ALC FPGA version register
 * @param ver : the ALC FPGA version value
 * @return 0 on success
 */
int fpga_alc_get_ver(unsigned short *ver)
{
  util_read_short_fpga(FPGA_ALC_FPGA_VER, 1, ver);
  return 0;
}

/**
 * Read the ALC PPS Status Register
 * @param status: the ALC PPS Status.
 * @return 0 on success
 */
int fpga_alc_get_pps_status(unsigned short *status)
{
  util_read_short_fpga(FPGA_ALC_PPS_STATUS, 1, status);
  return 0;
}


/**
 * Read the ALC PPS Status Register
 * @param status: the ALC PPS Sync Status.
 * @return 0 on success
 */
int fpga_alc_get_sync_status(unsigned int *status)
{
  unsigned short lsb = 0, msb = 0;

  util_read_short_fpga(FPGA_ALC_PPS_SYNC_LSB, 1, &lsb);
  util_read_short_fpga(FPGA_ALC_PPS_SYNC_MSB, 1, &msb);

  *status = ((unsigned int)msb << 16) | lsb;
  return 0;
}

/*
 * used to read data  for ALC capture and other.
 */

int fpga_alc_capture(unsigned long offset, unsigned short *data)
{
  util_read_short_fpga(offset, 1, data);
  return 0;
}

/**
 * Handshaking with the ALC to exchange log data.
 * @param offset - the offset for capture
 * @param cmd - the command to send
 * @return always 0
 */
int fpga_alc_capture_cmd(unsigned long offset, unsigned short cmd)
{
  util_write_short_fpga(offset, 1, &cmd);
  return 0;
}


#define FPGA_DDC_XBAR_ADDR   0x0200040

int fpga_xbar_set(short cmd[])
{
  unsigned long offset = FPGA_DDC_XBAR_ADDR;
  int i;
  short sband = 0;
  short ifnum;

  for(i=0; i<8; i++)
    {
      offset = FPGA_DDC_XBAR_ADDR + (i * 2);
      util_write_short_fpga(offset, 1, &cmd[i]);
    }

  /* do the VDIF Setup */
  sband = ((cmd[3] & 0x3) << 12) | ((cmd[2] & 0x3) << 8) | ((cmd[1] & 0x3) << 4)| (cmd[0] & 0x3);
  util_write_short_fpga(VDIF_START_ADDR + VDIF_SB0_3_OFFSET, 1, &sband);

  ifnum = (((cmd[3] & 0x4) >> 2) << 12) | (((cmd[2] & 0x4) >> 2) << 8) | (((cmd[1] & 0x4) >> 2) << 4)| ((cmd[0] & 0x4) >> 2);
  util_write_short_fpga(VDIF_START_ADDR + VDIF_IF0_3_OFFSET, 1, &ifnum);
  return 0;
}


int fpga_xbar_get(short cmd[])
{
  unsigned long offset = FPGA_DDC_XBAR_ADDR;
  int i;

  for(i=0; i<8; i++)
    {
      offset = FPGA_DDC_XBAR_ADDR + (i * 2);
      util_read_short_fpga(offset, 1, (unsigned short *)&cmd[i]);
    }
  return 0;
}

#define FPGA_DDC_LO_TUNING        0x200000
#define FPGA_DDC_DECIMATION_RATE  0x200020
#define FPGA_DDC_TIMESLOT_BASE    0x200060  // Start of Time-slot DDC
#define FPGA_DDC_SIDEBAND_SELECT  0x200090

int fpga_ddc_rate_set(short rate[])
{
  unsigned long offset = FPGA_DDC_DECIMATION_RATE;
  unsigned long vdif_offset;
  short sample_rate;
  short unit = 1;
  unsigned long usample;
  int i;

  for(i=0; i<8; i++)
    {
      offset = FPGA_DDC_DECIMATION_RATE + (i * 2);
      util_write_short_fpga(offset, 1, &rate[i]);
      switch(rate[i])
	{
	case 1:
	  sample_rate = 128;
	  break;
	case 2:
	  sample_rate = 64;
	  break;
	case 4:
	  sample_rate = 32;
	  break;
	case 8:
	  sample_rate = 16;
	  break;
	case 16:
	  sample_rate = 8;
	  break;
	case 32:
	  sample_rate = 4;
	  break;
	case 64:
	  sample_rate = 2;
	  break;
	case 128:
	  sample_rate = 1;
	  break;
	case 256:
	  sample_rate = 500;
	  unit = 0;
	  break;
	case 512:
	  sample_rate = 250;
	  unit = 0;
	  break;
	case 1024:
	  sample_rate = 125;
	  unit = 0;
	  break;
	case 2048:
	  sample_rate = 62.5;
	  unit = 0;
	  break;
	default:
	  sample_rate = 64;
	  break;	  
	}
      usample = (unit << 23) | sample_rate;
      vdif_offset = VDIF_START_ADDR + VDIF_SAMPLE_0_RATE_UNIT_OFFSET + (i * 4);
      util_write_long_fpga(vdif_offset, 1, &usample);
    }
  return 0;
}


int fpga_ddc_rate_get(short rate[])
{
  unsigned long offset = FPGA_DDC_DECIMATION_RATE;
  int i;

  for(i=0; i<8; i++)
    {
      offset = FPGA_DDC_DECIMATION_RATE + (i * 2);
      util_read_short_fpga(offset, 1, (short *)&rate[i]);
    }
  return 0;
}

int fpga_ddc_lo_set(short dc, short rate, unsigned long lofreq)
{
  unsigned long offset = FPGA_DDC_DECIMATION_RATE + (dc * 2);
  unsigned long vdif_offset = VDIF_START_ADDR + VDIF_LOIF_DC0_LSB_OFFSET + (dc * 4);

  short unit = 1;
  unsigned long usample;
  short sample_rate;

  util_write_short_fpga(offset, 1, &rate);

  offset = FPGA_DDC_LO_TUNING + (dc * 4);
  util_write_long_fpga(offset, 1, &lofreq);
  util_write_long_fpga(vdif_offset, 1, &lofreq);

  switch(rate)
    {
    case 1:
      sample_rate = 128;
      break;
    case 2:
      sample_rate = 64;
      break;
    case 4:
      sample_rate = 32;
      break;
    case 8:
      sample_rate = 16;
      break;
    case 16:
      sample_rate = 8;
      break;
    case 32:
      sample_rate = 4;
      break;
    case 64:
      sample_rate = 2;
      break;
    case 128:
      sample_rate = 1;
      break;
    case 256:
      sample_rate = 500;
      unit = 0;
      break;
    case 512:
      sample_rate = 250;
      unit = 0;
      break;
    case 1024:
      sample_rate = 125;
      unit = 0;
      break;
    case 2048:
      sample_rate = 62.5;
      unit = 0;
      break;
    default:
      sample_rate = 64;
      break;	  
    }
  usample = (unit << 23) | sample_rate;
  vdif_offset = VDIF_START_ADDR + VDIF_SAMPLE_0_RATE_UNIT_OFFSET + (dc * 4);
  util_write_long_fpga(vdif_offset, 1, &usample);

  return 0;
}

int fpga_ddc_set_sideband_select(short dc, short stat)
{
  short sideband_select;
  /* first we need to read the current value */
  util_read_short_fpga(FPGA_DDC_SIDEBAND_SELECT, 1, (short *)&sideband_select);

  sideband_select &= 0xFF;
  if (stat)
    sideband_select |= (1 << dc);
  else
    sideband_select &= ~(1 << dc);

  util_write_short_fpga(FPGA_DDC_SIDEBAND_SELECT, 1, &sideband_select);

  util_write_short_fpga((unsigned int)(VDIF_START_ADDR + VDIF_ESIDE_BAND_OFFSET), 1, &sideband_select);

  return 0;
}

int fpga_ddc_get_sideband_select(short * stat)
{
  util_read_short_fpga(FPGA_DDC_SIDEBAND_SELECT, 1, stat);

  *stat &= 0xFF;

  return 0;
}

int fpga_ddc_lo_set_stime(short dc, unsigned long tOn)
{
  util_write_long_fpga(FPGA_DDC_TIMESLOT_BASE + dc*4, 1, &tOn);

  return 0;
}

int fpga_ddc_lo_get_stime(short dc, unsigned long * tOn)
{    
  util_read_long_fpga(FPGA_DDC_TIMESLOT_BASE + dc*4, 1, tOn);

  return 0;
}

int fpga_ddc_lo_get(short rate[], unsigned long lofreq[], unsigned long tOn[])
{
  unsigned long offset;
  int dc;
  
  for(dc=0; dc<8; dc++)
    {
      offset = FPGA_DDC_DECIMATION_RATE + (dc * 2);
      util_read_short_fpga(offset, 1, (short *)&rate[dc]);
      
      offset = FPGA_DDC_LO_TUNING + (dc * 4);
      util_read_long_fpga(offset, 1, &lofreq[dc]);
      
      util_read_long_fpga(FPGA_DDC_TIMESLOT_BASE + dc*4, 1, &tOn[dc]);
    }
  return 0;
}
/* ----------------------------------------------------------------------------------------------------------
 * Tsys Channel Registers
 * The Tsys Channel Registers permits a user to read the 1 to 32 frequency channels Tsys values for all channels
 * The results are 48 bts padded to 64 bits
 * PPC addr 0xD0E0_0200 FPGA addr 0xE00200 – TSys ON for IF0 Channel 0 R
 * PPC addr 0xD0E0_0208 FPGA addr 0xE00204 – TSys ON for IF0 Channel 1 R
 * PPC addr 0xD0E0_0210 FPGA addr 0xE00208 – TSys ON for IF0 Channel 2 R
 * PPC addr 0xD0E0_0218 FPGA addr 0xE00203 – TSys ON for IF0 Channel 3 R
 * PPC addr 0xD0E0_0220 FPGA addr 0xE00204 – TSys ON for IF0 Channel 4 R
 * PPC addr 0xD0E0_0228 FPGA addr 0xE00205 – TSys ON for IF0 Channel 5 R
 * PPC addr 0xD0E0_0230 FPGA addr 0xE00206 – TSys ON for IF0 Channel 6 R
 * PPC addr 0xD0E0_0238 FPGA addr 0xE00207 – TSys ON for IF0 Channel 7 R
 * PPC addr 0xD0E0_0240 FPGA addr 0xE00208 – TSys ON for IF0 Channel 8 R
 * PPC addr 0xD0E0_0248 FPGA addr 0xE00209 – TSys ON for IF0 Channel 9 R
 * PPC addr 0xD0E0_0250 FPGA addr 0xE0020a – TSys ON for IF0 Channel 10 R
 * PPC addr 0xD0E0_0258 FPGA addr 0xE0020b – TSys ON for IF0 Channel 11 R
 * PPC addr 0xD0E0_0260 FPGA addr 0xE0020c – TSys ON for IF0 Channel 12 R
 * PPC addr 0xD0E0_0268 FPGA addr 0xE0020d – TSys ON for IF0 Channel 13 R
 * PPC addr 0xD0E0_0270 FPGA addr 0xE0020e – TSys ON for IF0 Channel 14 R
 * PPC addr 0xD0E0_0278 FPGA addr 0xE0020f – TSys ON for IF0 Channel 15 R
 * PPC addr 0xD0E0_0280 FPGA addr 0xE00280 – TSys ON for IF1 Channel 0 R
 * PPC addr 0xD0E0_0288 FPGA addr 0xE00281 – TSys ON for IF1 Channel 1 R
 * PPC addr 0xD0E0_0290 FPGA addr 0xE00282 – TSys ON for IF1 Channel 2 R
 * PPC addr 0xD0E0_0298 FPGA addr 0xE00283 – TSys ON for IF1 Channel 3 R
 * PPC addr 0xD0E0_02A0 FPGA addr 0xE00284 – TSys ON for IF1 Channel 4 R
 * PPC addr 0xD0E0_02A8 FPGA addr 0xE00285 – TSys ON for IF1 Channel 5 R
 * PPC addr 0xD0E0_02B0 FPGA addr 0xE00286 – TSys ON for IF1 Channel 6 R
 * PPC addr 0xD0E0_02B8 FPGA addr 0xE00287 – TSys ON for IF1 Channel 7 R
 * PPC addr 0xD0E0_02C0 FPGA addr 0xE00288 – TSys ON for IF1 Channel 8 R
 * PPC addr 0xD0E0_02C8 FPGA addr 0xE00289 – TSys ON for IF1 Channel 9 R
 * PPC addr 0xD0E0_02D0 FPGA addr 0xE0028a – TSys ON for IF1 Channel 10 R
 * PPC addr 0xD0E0_02D8 FPGA addr 0xE0028b – TSys ON for IF1 Channel 11 R
 * PPC addr 0xD0E0_02E0 FPGA addr 0xE0028c – TSys ON for IF1 Channel 12 R
 * PPC addr 0xD0E0_02E8 FPGA addr 0xE0028d – TSys ON for IF1 Channel 13 R
 * PPC addr 0xD0E0_02F0 FPGA addr 0xE0028e – TSys ON for IF1 Channel 14 R
 * PPC addr 0xD0E0_02F8 FPGA addr 0xE0028f – TSys ON for IF1 Channel 15 R
 * PPC addr 0xD0E0_0300 FPGA addr 0xE00300 – TSys OFF for IF0 Channel 0 R
 * PPC addr 0xD0E0_0308 FPGA addr 0xE00301 – TSys OFF for IF0 Channel 1 R
 * PPC addr 0xD0E0_0310 FPGA addr 0xE00302 – TSys OFF for IF0 Channel 2 R
 * PPC addr 0xD0E0_0318 FPGA addr 0xE00303 – TSys OFF for IF0 Channel 3 R
 * PPC addr 0xD0E0_0320 FPGA addr 0xE00304 – TSys OFF for IF0 Channel 4 R
 * PPC addr 0xD0E0_0328 FPGA addr 0xE00305 – TSys OFF for IF0 Channel 5 R
 * PPC addr 0xD0E0_0330 FPGA addr 0xE00306 – TSys OFF for IF0 Channel 6 R
 * PPC addr 0xD0E0_0338 FPGA addr 0xE00307 – TSys OFF for IF0 Channel 7 R
 * PPC addr 0xD0E0_0340 FPGA addr 0xE00308 – TSys OFF for IF0 Channel 8 R
 * PPC addr 0xD0E0_0348 FPGA addr 0xE00309 – TSys OFF for IF0 Channel 9 R
 * PPC addr 0xD0E0_0350 FPGA addr 0xE0030a – TSys OFF for IF0 Channel 10 R
 * PPC addr 0xD0E0_0358 FPGA addr 0xE0030b – TSys OFF for IF0 Channel 11 R
 * PPC addr 0xD0E0_0360 FPGA addr 0xE0030c – TSys OFF for IF0 Channel 12 R
 * PPC addr 0xD0E0_0368 FPGA addr 0xE0030d – TSys OFF for IF0 Channel 13 R
 * PPC addr 0xD0E0_0370 FPGA addr 0xE0030e – TSys OFF for IF0 Channel 14 R
 * PPC addr 0xD0E0_0378 FPGA addr 0xE0030f – TSys OFF for IF0 Channel 15 R
 * PPC addr 0xD0E0_0380 FPGA addr 0xE00380 – TSys OFF for IF1 Channel 0 R
 * PPC addr 0xD0E0_0388 FPGA addr 0xE00381 – TSys OFF for IF1 Channel 1 R
 * PPC addr 0xD0E0_0390 FPGA addr 0xE00382 – TSys OFF for IF1 Channel 2 R
 * PPC addr 0xD0E0_0398 FPGA addr 0xE00383 – TSys OFF for IF1 Channel 3 R
 * PPC addr 0xD0E0_03A0 FPGA addr 0xE00384 – TSys OFF for IF1 Channel 4 R
 * PPC addr 0xD0E0_03A8 FPGA addr 0xE00385 – TSys OFF for IF1 Channel 5 R
 * PPC addr 0xD0E0_03B0 FPGA addr 0xE00386 – TSys OFF for IF1 Channel 6 R
 * PPC addr 0xD0E0_03B8 FPGA addr 0xE00387 – TSys OFF for IF1 Channel 7 R
 * PPC addr 0xD0E0_03C0 FPGA addr 0xE00388 – TSys OFF for IF1 Channel 8 R
 * PPC addr 0xD0E0_03C8 FPGA addr 0xE00389 – TSys OFF for IF1 Channel 9 R
 * PPC addr 0xD0E0_03D0 FPGA addr 0xE0038a – TSys OFF for IF1 Channel 10 R
 * PPC addr 0xD0E0_03D8 FPGA addr 0xE0038b – TSys OFF for IF1 Channel 11 R
 * PPC addr 0xD0E0_03E0 FPGA addr 0xE0038c – TSys OFF for IF1 Channel 12 R
 * PPC addr 0xD0E0_03E8 FPGA addr 0xE0038d – TSys OFF for IF1 Channel 13 R
 * PPC addr 0xD0E0_03F0 FPGA addr 0xE0038e – TSys OFF for IF1 Channel 14 R
 * PPC addr 0xD0E0_03F8 FPGA addr 0xE0038f – TSys OFF for IF1 Channel 15 R
 *
 */

#define FPGA_TSYS_BASE_OFF 0X0E00200
#define FPGA_TSYS_BASE_ON 0X0E00300

#define TSYS_CH_OFFSET 8
#define TSYS_IF_OFFSET 128

/**
 * Get tsys on / off value as 48bit integer padded with 0xbeef extended to 68 bits
 * The value is a "real" with the lower 20 bits as fraction
 * @param intFreq - IF [0 or 1]
 * @param channel - Channel [0 .. 15]
 * @param value - the return value
 * @return - 0 on success
 */
int fpga_get_tsys_off(int intFreq, int channel, unsigned long *val_low, unsigned long *val_high )
{
     //unsigned long val_low;
     //unsigned long val_high;
    
  if(intFreq >= 0 && intFreq < 2 && channel >=0 && channel < 16) 
    {
      util_read_long_fpga(FPGA_TSYS_BASE_OFF + (intFreq * TSYS_IF_OFFSET) + (TSYS_CH_OFFSET * channel), 1, val_low);
      util_read_long_fpga(FPGA_TSYS_BASE_OFF + (intFreq * TSYS_IF_OFFSET) + (TSYS_CH_OFFSET * channel + 4), 1, val_high);
      return 0;
    }
  printf("invalid intFreq %d ch %d\n", intFreq, channel);
  return -1;
}
/**
 * Get tsys on / off value as 48bit integer padded with 0xbeef extended to 68 bits
 * The value is a "real" with the lower 20 bits as fraction
 * @param intFreq - IF [0 or 1]
 * @param channel - Channel [0 .. 15]
 * @param value - the return value
 * @return - 0 on success
 */
int fpga_get_tsys_on(int intFreq, int channel, unsigned long *val_low, unsigned long *val_high)
{
     //unsigned long val_low;
     //unsigned long val_high;

     if(intFreq >= 0 && intFreq < 2 && channel >=0 && channel < 16) 
     {
	  util_read_long_fpga(FPGA_TSYS_BASE_ON + (intFreq * TSYS_IF_OFFSET) + (TSYS_CH_OFFSET * channel), 1, val_low);
	  util_read_long_fpga(FPGA_TSYS_BASE_ON + (intFreq * TSYS_IF_OFFSET) + (TSYS_CH_OFFSET * channel + 4), 1, val_high);
	  return 0;
     }
     printf("invalid intFreq %d ch %d\n", intFreq, channel);
     return -1;
}


/* ****************************************************************************
 *
 *            TSYS DIODE CONTROL Registers
 *
 * ****************************************************************************
 */

#define FPGA_TSYS_DIODE_CTRL      0xE00000
#define FPGA_TSYS_DIODE_A         0xE00002
#define FPGA_TSYS_DIODE_B         0xE00004
#define FPGA_TSYS_DIODE_BLANK     0xE00006
#define FPGA_TSYS_DIODE_SCALE     0xE00008
#define FPGA_TSYS_DIODE_SIGN_SEL  0xE0000A
#define FPGA_TSYS_DIODE_ACC_ON    0xE0000C
#define FPGA_TSYS_DIODE_ACC_OFF   0xE00010

/**
 * Set the TSYS_diode Control register bits
 * @param ctl : control data to write
 * @return 0 - on success
 */
int fpga_tsys_diode_set_control(unsigned short dp, unsigned short bt)
{
  util_write_short_fpga(FPGA_TSYS_DIODE_CTRL, 1, &dp);
  util_write_short_fpga(FPGA_TSYS_DIODE_CTRL, 1, &bt);
  return 0;
}

int fpga_tsys_diode_set_blanking(unsigned short bt)
{
     unsigned short ba;
     /* MUST CONVERT THE BLANK TIME GIVEN IN USECS TO CLOCK CYCLES */
     /* since it is 64Mhz / bt which is usescs reduces to */
     ba = 64 * bt -1;
     printf("blank cycles %d secs %d\n", ba, bt);
     util_write_short_fpga(FPGA_TSYS_DIODE_BLANK, 1, &ba);

     return 0;
}

int fpga_tsys_diode_set_period(unsigned short dp)
{
  unsigned short da; /* --- THE DIODE TIME FRACTIONAL COMPONENT */
  unsigned short db; /* --- THE DIODE TIME INTEGER COMPONENT */
  unsigned long diode; /* --- conversion of diode frequency to clock cycles */
  const unsigned short trs = 0x10000; /* --- 2^16 */
  
  diode=64e6/dp/2 - 1;
  //printf("diode = %d, dp =%d\n", diode,dp);
  
  da = diode % trs;
  //printf("da = %d \n", da);
  util_write_short_fpga(FPGA_TSYS_DIODE_A, 1, &da);
  
  db = diode / trs;
  //printf("db = %d \n", db);
  util_write_short_fpga(FPGA_TSYS_DIODE_B, 1, &db);
  
  return 0;
}
/**
 * Read  the TSYS Control register bits
 * @param ctl : control data to read
 * @return 0 - on success
 */
int fpga_tsys_diode_get_control(unsigned short *da, unsigned short *db, unsigned short *bt, unsigned long *accum_on, unsigned long *accum_off)
{
  util_read_short_fpga(FPGA_TSYS_DIODE_A, 1, da);
  util_read_short_fpga(FPGA_TSYS_DIODE_B, 1, db);
  util_read_short_fpga(FPGA_TSYS_DIODE_BLANK, 1, bt);
  util_read_long_fpga(FPGA_TSYS_DIODE_ACC_ON, 1, accum_on);
  util_read_long_fpga(FPGA_TSYS_DIODE_ACC_OFF, 1, accum_off);
  return 0;
}

#define BLANK_COUNT_REG         0xE00003
#define DDC_SCALE_REG           0xE00020

#define ON_COUNT_REG            0xE0000C
#define OFF_COUNT_REG           0xE00010

#define PSF_START_REG           0xE00200
#define PSN_START_REG           0xE00300 

#define VSF_START_REG           0xE00400
#define VSN_START_REG           0xE00500

int fpga_ddc_tsys_get_scale(short chan, short *val)
{
  util_read_short_fpga((DDC_SCALE_REG + (chan << 1)), 1, val);
  return 0;
}

int fpga_ddc_tsys_set_scale(short chan, short val)
{
  util_write_short_fpga((DDC_SCALE_REG + (chan << 1)), 1, &val);
  return 0;
}

int fpga_ddc_tsys_get_power_tsys_off(short chan, unsigned long long * val)
{
  unsigned short lsb, wsb, msb;
  
  util_read_short_fpga((chan << 3) + PSF_START_REG, 1, &lsb);
  util_read_short_fpga((chan << 3) + PSF_START_REG+2, 1, &wsb);
  util_read_short_fpga((chan << 3) + PSF_START_REG+4, 1, &msb);

  *val = (unsigned long long)((((unsigned long long)(msb)) << 32) | (((unsigned long long)(wsb)) << 16) | (unsigned long long)(lsb));

  return 0;
}

int fpga_ddc_tsys_get_power_tsys_on(short chan, unsigned long long * val)
{
  unsigned short lsb, wsb, msb;
  
  util_read_short_fpga((chan << 3) + PSN_START_REG, 1, &lsb);
  util_read_short_fpga((chan << 3) + PSN_START_REG+2, 1, &wsb);
  util_read_short_fpga((chan << 3) + PSN_START_REG+4, 1, &msb);

  *val =  (unsigned long long)((((unsigned long long)(msb)) << 32) | (((unsigned long long)(wsb)) << 16) | (unsigned long long)(lsb));

  return 0;
}

int fpga_ddc_tsys_get_voltage_tsys_off(short chan, long long * val)
{
  unsigned short lsb, wsb, msb;
  
  util_read_short_fpga((chan << 3) + VSF_START_REG, 1, &lsb);
  util_read_short_fpga((chan << 3) + VSF_START_REG+2, 1, &wsb);
  util_read_short_fpga((chan << 3) + VSF_START_REG+4, 1, &msb);

  *val =  (long long)((((long long)(msb)) << 32) | (((long)(wsb)) << 16) | lsb);

  return 0;
}

int fpga_ddc_tsys_get_voltage_tsys_on(short chan, long long * val)
{
  unsigned short lsb, wsb, msb;
  
  util_read_short_fpga((chan << 3) + VSN_START_REG, 1, &lsb);
  util_read_short_fpga((chan << 3) + VSN_START_REG+2, 1, &wsb);
  util_read_short_fpga((chan << 3) + VSN_START_REG+4, 1, &msb);

  *val =  (long long)((((long long)(msb)) << 32) | (((long)(wsb)) << 16) | lsb);

  return 0;
}

int fpga_ddc_tsys_get_on_count(unsigned int * count)
{
  unsigned short lsb, msb;

  util_read_short_fpga(ON_COUNT_REG, 1, &lsb);
  util_read_short_fpga(ON_COUNT_REG+2, 1, &msb);
  
  *count = (msb << 16) | lsb;

  return 0;
}

int fpga_ddc_tsys_get_off_count(unsigned int * count)
{
  unsigned short lsb, msb;

  util_read_short_fpga(OFF_COUNT_REG, 1, &lsb);
  util_read_short_fpga(OFF_COUNT_REG+2, 1, &msb);
  
  *count = (msb << 16) | lsb;

  return 0;
}

#define FPGA_SYS_STATUS_REG        0xE

int fpga_get_fpga_status(unsigned short * stat)
{
  util_read_short_fpga(FPGA_SYS_STATUS_REG, 1, stat);

  return 0;
}

int fpga_ddc_get_vdif_epoch(short * ref_epoch, unsigned long * seconds_from_ref_epoch)
{
  unsigned long offset = VDIF_START_ADDR + VDIF_REF_EPOCH_OFFSET;
#if 0
  unsigned short d_lsb, d_msb;
#endif

  util_read_short_fpga(offset, 1, ref_epoch);
  offset = VDIF_START_ADDR + VDIF_EPOCH_SECS_READ_OFFSET;
  util_read_long_fpga(offset, 1, seconds_from_ref_epoch);
#if 0
  util_read_short_fpga(offset, 1, &d_lsb);
  util_read_short_fpga(offset+2, 1, &d_msb);
  *seconds_from_ref_epoch = (unsigned long *)((d_msb << 16) | d_lsb); 
#endif

  return 0;
}

int fpga_ddc_set_vdif_epoch(short * ref_epoch, unsigned long * seconds_from_ref_epoch)
{
  unsigned long offset = VDIF_START_ADDR + VDIF_REF_EPOCH_OFFSET;
  util_write_short_fpga(offset, 1, ref_epoch);
  offset = VDIF_START_ADDR + VDIF_EPOCH_SECS_OFFSET;
  util_write_long_fpga(offset, 1, seconds_from_ref_epoch);

  return 0;
}

int fpga_ddc_set_vdif_Bits_Per_Sample(short sample[])
{
  unsigned long offset = VDIF_START_ADDR + VDIF_SAMPLE_0_1_OFFSET;
  short reg = sample[0] | (sample[1] << 8);
  util_write_short_fpga(offset, 1, &reg);

  reg = sample[2] | (sample[3] << 8);
  offset = VDIF_START_ADDR + VDIF_SAMPLE_2_3_OFFSET;
  util_write_short_fpga(offset, 1, &reg);

  reg = sample[4] | (sample[5] << 8);
  offset = VDIF_START_ADDR + VDIF_SAMPLE_4_5_OFFSET;
  util_write_short_fpga(offset, 1, &reg);

  reg = sample[6] | (sample[7] << 8);
  offset = VDIF_START_ADDR + VDIF_SAMPLE_6_7_OFFSET;
  util_write_short_fpga(offset, 1, &reg);
  
  return 0;
}

int fpga_ddc_set_vdif_thread_ids(short thids[])
{
  int i;
  unsigned int offset;

  for(i=0; i<8; i++)
    {
      offset = VDIF_START_ADDR + VDIF_THREAD_ID_0_OFFSET + i*2;
      util_write_short_fpga(offset, 1, &thids[i]);
    }

  return 0;
}

int fpga_ddc_set_vdif_Log2NumChan(short * count)
{
  short sel_inp = 0;
  int i;

#if 0 /* Per Walter's request. It is not done */
  short log2num = (short)(log2(*count));
  util_write_short_fpga(VDIF_START_ADDR+VDIF_LOG_2_NUM_CHAN_OFFSET, 1, &log2num);
#endif

  for (i=0; i< *count; i++)
    sel_inp |= (1 << i);
  
  util_write_short_fpga(VDIF_START_ADDR+VDIF_SELECT_INPUT_OFFSET, 1, &sel_inp);
  return 0;
}

int fpga_ddc_set_vdif_StationID(short * id)
{

  util_write_short_fpga((unsigned int)(VDIF_START_ADDR+VDIF_STATION_ID_OFFSET), 1, id);

  return 0;
}

int fpga_ddc_set_vdif_DBEnum(short * num)
{

  util_write_short_fpga((unsigned int)(VDIF_START_ADDR+VDIF_DBE_NUM_OFFSET), 1, num);

  return 0;
}

#define SYNC_ENABLE    0x008
#define IPPS_STATUS    0x100
#define IPPS_DELTA     0x102

int fpga_get_1pps_status(unsigned short * sync_en, unsigned short *stat, unsigned int * delta)
{
  unsigned short d_lsb, d_msb;

  util_read_short_fpga((unsigned long)SYNC_ENABLE, 1, sync_en);
  util_read_short_fpga((unsigned long)IPPS_STATUS, 1, stat);

  util_read_short_fpga((unsigned long)IPPS_DELTA, 1, &d_lsb);
  util_read_short_fpga((unsigned long)(IPPS_DELTA+2), 1, &d_msb);

  *delta = (unsigned int)((d_msb << 16) | d_lsb);

  return 0;
}

int fpga_set_1pps_status(unsigned short stat)
{
  util_write_short_fpga((unsigned long)SYNC_ENABLE, 1, &stat);

  return 0;
}

#define ADC0_RELOAD            0xF0

int fpga_write_Adc_reload(unsigned short stat)
{
  util_write_short_fpga((unsigned long)ADC0_RELOAD, 1, &stat);
}
