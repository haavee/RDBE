/*
 * cmd_base.c
 *
 *  Created on: Aug 26, 2009
 *      Author: Mikael Taveniku XCube Communication Inc.
 *      License: GPL
 *      Description: Common commands that the rdbe server understands.
 *      this file implements VSIS compatible commands that are defined by XXX.XXX
 *  Modified by CAR March 01 2010 to add the truncated modified julian time to
 *  the dot command
 *
 * dbe_arp - set / get the IP to MAC address resolution
 * dbe_data_connect - set / get the destination IP the data is being sent
 * dbe_data_format - set the packet format mode to either the Mark5C native mode or Mark5B compatibility mode
 * dbe_data_send - send a valid data stream out of the DBE 10G interface
 * dbe_dot - get the Data Observable Time (DOT) clock information (query only)
 * dbe_dot_inc - increment the DOT clock
 * dbe_dot_set - set the DOT clock on next 1pps tick
 * dbe_hw_version - get the hardware version information from the DBE
 * dbe_ifconfig - set / get DBE 10G network interface configuration
 * dbe_ioch_assign - set / get the input IF to payload assignement configuration
 * dbe_opt_level - measure or set the input level of IF 0/1
 * dbe_packet - set / get packet transmission criteria
 * dbe_personality - set / get the DBE FPGA bit code personality
 * dbe_quantize - get channel quantization values (query only)
 * dbe_reset - reboot the DBE
 * dbe_status - get system status (query only)
 * dbe_sw_version - get the software version information from the DBE
 * dbe_tid2addr - set / get the thread ID association resolution to either IP or  MAC address, used with vdif
 * dbe_alc - set / get the attenuation and solar mode settings
 * dbe_alc_pps - get the PPS status and PPS sync for the ALC
 * dbe_alc_fpgaver - get the ALC FPGA version.
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <errno.h>
#include <string.h>
#include <fcntl.h>      // open. ioctl
#include <unistd.h>     // close
#include <sys/stat.h>
#include <linux/mman.h> // memory management things
#include <sys/mman.h>   //mmap
#include <time.h>       // FOR MODIFIED JULIAN DATE CALCULATION ON MARK5B - CAR
#include <assert.h>

#include <math.h>

/* to retreive IP @ */
#include <net/if.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/ioctl.h>

#include <sys/time.h>

#include <sys/sysinfo.h>

#include <netinet/tcp.h>

#include <semaphore.h>
#include <pthread.h>

#include "rdbe_exports.h"     // device driver information access functions and types
#include "cmd_parser.h"
#include "serv_storage.h"
#include "hal.h"
#include "cmd_stubs.h"
#include "cmd_common.h"
#include "cmd_base.h"

#define MAX_IFS      2
#define MAX_CHANNELS 16

#define IP_LEN        4
#define MAC_LEN       6
#define MAX_IP_ENTRY  256

extern int serv_rdbe_ioctl(int funNo, char*arg); // defined in server main for now
extern int serv_get_data(int bufNo, unsigned long length);
extern int fpga_prg_cmd(int argc, void **argv, void **retVal, int *retLen);

int string2JD(char * str_time, unsigned long *bcdTimeCode);
int time2JD(struct tm * dotTime, unsigned long *bcdTimeCode);
int Bcd2Human(unsigned long dotTime, char * str_time, int * offset);

int messageparse(char *message, char **ptr, int maxparams);

int setupVdifStationID(void);
int LoadSavedSettings(void);
int saveSettings(void);

char * getmyIP(void);

void *dotset_thread(void *);

void *pcal_thread(void *arg);

rdbe_settings_t current_settings;
rdbe_settings_t pre_current_settings;

// static rdbe_config_t rdbe_config;

/* typedef struct
{
        ;
	char filePath[1024];
	unsigned long len;

	} rdbe_ipv4_t; */

typedef struct
{
  unsigned char ip[4];
	int ifno;
} rdbe_ipv4_t;

rdbe_ipv4_t rdbe_ipv4[4];

/* keep track of the current status of the If port */
int curIfStat[MAX_PORTS];
/* Mutex uesed to sync access to curIfStat and avoid overwrting between different threads */
pthread_mutex_t mutexIf = PTHREAD_MUTEX_INITIALIZER;

/* mutex to guard access to rms value to be atomic */
pthread_mutex_t mutex_rms = PTHREAD_MUTEX_INITIALIZER;

/* Gets a copy of the current Arp setting in the FPGA */
unsigned char ArpTable[MAX_PORTS][MAX_IP_ENTRY][MAC_LEN];
/* Mutex uesed to sync access to ArpTable and avoid overwrting between different threads */
pthread_mutex_t mutexArp = PTHREAD_MUTEX_INITIALIZER;

/* Keeps track of previous settings for IFs ALC & solor */
unsigned char pre_if_cmd[MAX_IFS];
/* Mutex uesed to sync access to ALC settings and avoid overwrting between different threads */
pthread_mutex_t mutexAlc = PTHREAD_MUTEX_INITIALIZER;

/* Mutex uesed to sync access to Personality Load between different threads */
pthread_mutex_t mutexPerso = PTHREAD_MUTEX_INITIALIZER;

/* Mutex uesed to sync access to Settings file */
pthread_mutex_t mutexSettings = PTHREAD_MUTEX_INITIALIZER;


/* Mutex uesed to sync access to data collection for alc & raw data */
pthread_mutex_t mutexDataCollection = PTHREAD_MUTEX_INITIALIZER;

#ifdef _FFT_SUPPORT_ 
/* Mutex uesed to sync access to data collection for fft data */
pthread_mutex_t mutexFftData = PTHREAD_MUTEX_INITIALIZER;
#endif

sem_t dot_set_ops;

pthread_t dot_set_task;

pthread_t var_mon_task;
pthread_t pcal_task;

/* RDBE's IP */
extern char roach_ip[];

extern FILE * logfp;

/**
 * List the commands and usage of them that we know of
 * @param argc - should be 0
 * @param argv - no command arguments
 * @param retVal - return c
 * @param retLen - length of the buffer
 * @return - always 0
 */
int dbe_list_cmd(int argc, void **argv, void **retVal, int *retLen)
{
  char *retStart = "!dbe_list_cmd=0"; // beginning of return string
  char *retEnd   = ";\n";       // end of return string
  
  int i;
  int nCmd;
  cmd_desc_t *tmpDesc;
  const char *usageStr;
  
  char *wrPtr;
  
  *retLen = 0;
  
  wrPtr = *retVal;
  sprintf(wrPtr, "%s", retStart);
  
  nCmd = cmd_get_num_cmd();
  for(i=0; i<nCmd;i++){
    tmpDesc = cmd_find_cmdNo(i); // get command number i;
    if(tmpDesc != NULL){
      // write this command to the return buffer
      usageStr = cmd_get_usage(tmpDesc);
      if(usageStr != 0){
	wrPtr= *retVal + strlen(*retVal);
	sprintf(wrPtr, "\n:%s", usageStr);
      }
    }
  }
  
  wrPtr= *retVal + strlen(*retVal);
  sprintf(wrPtr,"%s", retEnd);
  *retLen = strlen(*retVal);
  
  return VSIS_RET_SUCCESS;
}

/**
 * Definition of the dbe_list_cmd command
 */
void insert_dbe_list_cmd(void)
{
  char *name = "dbe_list_cmd";
  char *usage= "dbe_list_cmd?;";
  int nParams = 0;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[0] = {};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_list_cmd, cmdType);
}

/**
 * Provide help on a specific command
 * @param argc - should be 1
 * @param argv - the command name to get help with
 * @param retVal - return buffer
 * @param retLen - length of the buffer
 * @return - always 0
 */
int dbe_help_cmd(int argc, void **argv, void **retVal, int *retLen)
{
  const char *retStart = "!dbe_help_cmd?0"; // beginning of return string
  const char *retEnd   = ";\n";       // end of return string
  const char *useStr   = "Command not found"; // string to print if not found
  
  cmd_desc_t *tmpDesc;
  char *theCmd; // the command to look for
  
  // check parameters
  theCmd = argv[0]; // first parameter is name of command to search for
  if(theCmd == 0){
    sprintf(*retVal, "%s%d:Parameter Error;\n", retStart,VSIS_RET_PARAMETER_ERROR);
    *retLen = strlen(*retVal);
    return -VSIS_RET_PARAMETER_ERROR;
  }
  // good to go
  printf("searching for command %s\n", theCmd); // debug
  
  tmpDesc = cmd_find_cmdName(theCmd); // find the command;
  
  if(tmpDesc != 0 ){
    if(cmd_get_usage(tmpDesc) != 0){
      useStr = cmd_get_usage(tmpDesc);
    } else {
      useStr = "no description";
    }
  }
  sprintf(*retVal,"%s:%s%s", retStart, useStr,retEnd);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS;
}


/**
 * Definition of the dbe_help_cmd command
 */
void insert_dbe_help_cmd(void)
{
  char *name = "dbe_help_cmd";
  char *usage= "dbe_help_cmd?<cmd>;";
  int nParams = 1;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[1] = {CMD_PARAM_STRING};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_help_cmd, cmdType);
}

void restoreSettings(void)
{
  if (strlen(pre_current_settings.personality_file_name))
    strcpy(current_settings.personality_file_name, pre_current_settings.personality_file_name);
  if (strlen(pre_current_settings.personality_type))
    strcpy(current_settings.personality_type, pre_current_settings.personality_type);
  current_settings.personality_load_status = pre_current_settings.personality_load_status;
}

/**
 * Set a specific personality for the FPGA device
 * @param argc - 2
 * @param argv - <personality> <location>
 * @param retVal - <return code>
 * @param retLen - length of
 * @return - 0 on success negative return code otherwise
 */
int dbe_personality_set(int argc, void **argv, void **retVal, int *retLen)
{
  char *retStart = "!dbe_personality=";
  char *retEnd   = ";\n";
  char fullPath[2048];          // string that points to the actual file we want to load
  char *fName;                  // temporary file name
  int  inFile = -1;              // Input file descriptor
  struct stat fileStat;
  void  *bitFilePtr;            // Pointer to the memory mapped file
  rdbe_configure_cmd_t cmdPar;  // structure used to call IOCTL

  char *perType;   // will hold a personality type from command
  char *usrPath;   // will hold a user specified file name from command

  // For debugging how long it takes to load a personality */
  clock_t start;
  double duration;

  start = clock();

  memset(fullPath, '\0', 2048 * sizeof(char));

  if (pthread_mutex_trylock(&mutexPerso))
    {
      fprintf(logfp, "ERROR: A load personality already in progress.\n");

      sprintf(*retVal, "%s%d:A load personality already in progress;\n", retStart,VSIS_RET_PARAMETER_ERROR);
      *retLen = strlen(*retVal);
      return VSIS_RET_EXECUTION_ERROR;
    }


  // Check input parameters
  if(argc != 2 ) {
    // Return an Error we have Illegal parameters
    fprintf(logfp, "ERROR: Number of arguments is %d should be 2!!\n\n", argc);
    sprintf(*retVal, "%s%d:Parameter Error;\n", retStart,VSIS_RET_PARAMETER_ERROR);
    *retLen = strlen(*retVal);
    /* unlock the mutex for others */
    pthread_mutex_unlock(&mutexPerso);
    return -VSIS_RET_PARAMETER_ERROR;
  }

  // Assign input arguments to real names
  perType  = argv[0] != 0 ? (char*)argv[0] : ""; // empty string if null
  usrPath =  argv[1] != 0 ? (char*)argv[1] : ""; // empty string if null


  // Find out what file to load .. user defined path has precedence
  fName = "";  // initialize file name to nothing .. check for this after
  if(strlen(usrPath) > 0){
    fprintf(logfp, "user file load with usrPath=\"%s\"\n",usrPath);
    fName = usrPath;
  } else {
    fprintf(logfp, "default file load with perType=\"%s\"\n",perType);
    // We have a default file load to do, figure out which one
    if      ( strcasecmp(perType, "DDC") == 0)	fName = "ddc.bin";
    else if ( strcasecmp(perType, "PFBG") == 0 ) fName = "pfbg.bin";
    else if ( strcasecmp(perType, "PFBA") == 0 ) fName = "pfba.bin";
  }

  // check that we have a file name to use
  if(strlen(fName) <= 0){
    fprintf(logfp, "ERROR: No valid filename or type specified\n\n");
    sprintf(*retVal, "%s%d:Parameter Error;\n", retStart,VSIS_RET_PARAMETER_ERROR);
    *retLen = strlen(*retVal);
    /* unlock the mutex for others */
    pthread_mutex_unlock(&mutexPerso);
    return VSIS_RET_PARAMETER_ERROR;
  }

  // check that path is not silly long
  if((strlen(HAL_RDBE_HOME) + strlen(fName) + 1) > 2048) {
    sprintf(*retVal, "%s%d:Path > 2048 characters;\n", retStart,VSIS_RET_PARAMETER_ERROR);
    *retLen = strlen(*retVal);
    /* unlock the mutex for others */
    pthread_mutex_unlock(&mutexPerso);
    return VSIS_RET_PARAMETER_ERROR;
  }
  // build our path variable
  strcpy(fullPath, HAL_RDBE_HOME);
  strcat(fullPath, fName);
  
  fprintf(logfp, "\nLoad personality path=\"%s\"  \n", fullPath); // debug print

  /* save the previous settings */
  pre_current_settings = current_settings;

  /* reset the file name for loaded personality */
  memset(current_settings.personality_file_name, '\0', MAX_FILE_NAME_LEN * sizeof(char));
  /* reset the type for loaded personality */
  memset(current_settings.personality_type, '\0', PERSONALITY_TYPE_LEN * sizeof(char));

  /* see the status load to fail by default */
  current_settings.personality_load_status = 0;

  // Check that the file exists .
  if((inFile = open(fullPath, O_RDWR))<=0)  {
    fprintf(logfp, "ERROR: file not found \n\n");
    sprintf(*retVal, "%s%d:File not found;\n", retStart,VSIS_RET_PARAMETER_ERROR);
    *retLen = strlen(*retVal);

    /* restore previous settings */
    restoreSettings();
    
    /* unlock the mutex for others */
    pthread_mutex_unlock(&mutexPerso);
    
    return VSIS_RET_PARAMETER_ERROR;
  }

  // Can we get the file status ?
  if (fstat(inFile, &fileStat) < 0) {
    fprintf(logfp, "ERROR: could not STAT file %s \n\n", fullPath);
    sprintf(*retVal, "%s%d:File not found;\n", retStart,VSIS_RET_PARAMETER_ERROR);
    *retLen = strlen(*retVal);
    close(inFile);

    /* restore previous settings */
    restoreSettings();

    /* unlock the mutex for others */
    pthread_mutex_unlock(&mutexPerso);

    return VSIS_RET_PARAMETER_ERROR;
  }

  // Can we map the file to memory?
  if(!(bitFilePtr = mmap(0, fileStat.st_size, (PROT_READ|PROT_WRITE), MAP_SHARED, inFile, 0))){
    fprintf(logfp, "ERROR: could not MMAP file %s \n\n", fullPath);
    sprintf(*retVal, "%s%d:File not found;\n", retStart,VSIS_RET_PARAMETER_ERROR);
    *retLen = strlen(*retVal);
    if (inFile) 
      close(inFile);

    /* restore previous settings */
    restoreSettings();

    /* unlock the mutex for others */
    pthread_mutex_unlock(&mutexPerso);
    
    return VSIS_RET_PARAMETER_ERROR;
  }
  

  // Now we got everything setup to program the thing

  // create command packet
  cmdPar.buf = bitFilePtr;
  cmdPar.len = fileStat.st_size;

#ifdef DEBUG_VERBOSE
  printf("Calling Server IOCTL with %p file ptr and len =%lx\n",bitFilePtr, cmdPar.len );
#endif

  // Call the driver to program the FPGA
  if(serv_rdbe_ioctl(RDBE_DEV_CONFIGURE, (char *) &cmdPar))
    {
      /* we need to  unmap the memory */
      munmap(bitFilePtr, fileStat.st_size);

      //Something went wrong and we have an undefined state on the FPGA
      strncpy(current_settings.personality_file_name, "undefined", MAX_FILE_NAME_LEN);
      strncpy(current_settings.personality_type, "undef", PERSONALITY_TYPE_LEN);
      /* tell everybody that we failed */
      current_settings.personality_load_status = 0;
      
      /* save current status */
      saveSettings();
      
      fprintf(logfp, "ERROR: Execution FPGA driver could not program FPGA file: %s \n\n", fullPath);
      sprintf(*retVal, "%s%d:driver could not program fpga;\n", retStart,VSIS_RET_PARAMETER_ERROR);
      *retLen = strlen(*retVal);
      if (inFile) 
	close(inFile);
      
      /* unlock the mutex for others */
      pthread_mutex_unlock(&mutexPerso);
      
      return VSIS_RET_EXECUTION_ERROR;
  }

  // Here everything went well and we can safely update the internal configuration parameters
  // and return success

  fprintf(logfp, "Load personality complete. with return code %d\n", VSIS_RET_SUCCESS); //debug

  /* tell everybody that we were successful */
  current_settings.personality_load_status = 1;
  /* copy the name to be used by the init function */
  strncpy(current_settings.personality_file_name, fName, MAX_FILE_NAME_LEN);
  /* store the type for later use */
  if (0 == strcmp(perType, ""))
    strncpy(current_settings.personality_type, "PFBG", PERSONALITY_TYPE_LEN);
  else
    strncpy(current_settings.personality_type, perType, PERSONALITY_TYPE_LEN);

  /* we need to  unmap the memory */
  munmap(bitFilePtr, fileStat.st_size);

  /* save out current status */
  saveSettings();

  // Create and send out up the return string
  sprintf(*retVal,"%s%d%s", retStart, VSIS_RET_SUCCESS, retEnd);
  *retLen = strlen( (char*)*retVal );

  /* unlock the mutex for others */
  pthread_mutex_unlock(&mutexPerso);

  if (inFile) 
    close(inFile);

  duration = ((double)(clock() - start)/CLOCKS_PER_SEC);

  fprintf(logfp, "Personality Loading -- Time Elapsed: %f\n", duration);

  return VSIS_RET_SUCCESS;
}



/**
 * Definition of the rdbe_personality_set command
 */
void insert_dbe_personality_set(void)
{
    char *name  = "dbe_personality";
    char *usage = "dbe_personality = <type>[:<location>];";
    int nParams = 2;
    int cmdType = CMD_VSIS_COMMAND;
    int paramTypes[2] = {CMD_PARAM_STRING, CMD_PARAM_STRING};
    cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_personality_set, cmdType);
}


/**
 * Get a specific personality for the FPGA device
 * @param argc - 0
 * @param argv -
 * @param retVal - <return code>
 * @param retLen - length of
 * @return - 0 on success negative return code otherwise
 */
int dbe_personality_get(int argc, void **argv, void **retVal, int *retLen)
{
  // initialize variables
  int retCode = -1;

  unsigned short id = 0;
  unsigned short rev_major = 0;
  unsigned short rev_minor = 0;
  unsigned short rev_rcs   = 0;


  *retLen = 0;

  retCode = fpga_get_firmware_id(&id);
  retCode = fpga_get_firmware_revision(&rev_major, &rev_minor, &rev_rcs);

  if (current_settings.personality_load_status)
    sprintf(*retVal,"!dbe_personality?%d:%s:%s:%s;\n", 
	    retCode, 
	    current_settings.personality_type, 
	    current_settings.personality_file_name,
	    "loaded");
  else
    sprintf(*retVal,"!dbe_personality?%d:%s:%s:%s;\n", 
	    retCode, 
	    current_settings.personality_type, 
	    current_settings.personality_file_name,
	    "not loaded");
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS;
}

/**
 * Definition of the get rdbe_personality_get query
 */
void insert_dbe_personality_get(void)
{
  char *name = "dbe_personality";
  char *usage= "dbe_personality ? ;";
  int nParams = 0;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[0] = {};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_personality_get, cmdType);
}


/**
 * Set data transmission mode
 * @param argc   - 2
 * @param argv   - <personality> <location>
 * @param retVal - <return code>
 * @param retLen - length of
 * @return       - 0 on success negative return code otherwise
 */
int bc_mode_set(int argc, void **argv, void **retVal, int *retLen)
{
  // initialize variables
  *retLen = 0;
  sprintf(*retVal,"!bc_mode=%d:Not Implemented;\n", VSIS_RET_NOT_IMPLEMENTED);
  *retLen = strlen(*retVal);
  return -VSIS_RET_NOT_IMPLEMENTED;
}
/**
 * Definition of the bc_mode  command
 */
void insert_bc_mode_set(void)
{
  char *name = "bc_modes";
  char *usage= "bc_modes = <type>[:<location>];";
  int nParams = 2;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[3] = {CMD_PARAM_STRING, CMD_PARAM_STRING};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, bc_mode_set, cmdType);
}


/**
 * Get data transmission mode
 * @param argc   - 0
 * @param argv   -
 * @param retVal - <return code>
 * @param retLen - length of
 * @return       - 0 on success negative return code otherwise
 */
int bc_mode_get(int argc, void **argv, void **retVal, int *retLen)
{
  // initialize variables
  *retLen = 0;
  sprintf(*retVal,"!bc_mode?%d:Not Implemented;\n", VSIS_RET_NOT_IMPLEMENTED);
  *retLen = strlen(*retVal);
  return -VSIS_RET_NOT_IMPLEMENTED;
}
/**
 * Definition of the bc_mode get command
 */
void insert_bc_mode_get(void)
{
  char *name = "bc_modes";
  char *usage= "bc_modes ? ;";
  int nParams = 0;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[0] = {};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, bc_mode_get, cmdType);
}


/**
 * Specify dbe clock source and frequency
 * @param argc   - 3
 * @param argv   - <clock frequency> <clock source> <clock generator frequency>
 * @param retVal - <return code>
 * @param retLen - length of
 * @return       - 0 on success negative return code otherwise
 */
int dbe_clock_set(int argc, void **argv, void **retVal, int *retLen)
{
  // initialize variables
  *retLen = 0;
  sprintf(*retVal,"!dbe_clock_set=%d:Not Implemented;\n", VSIS_RET_NOT_IMPLEMENTED);
  *retLen = strlen(*retVal);
  return -VSIS_RET_NOT_IMPLEMENTED;
}

/**
 * Definition of the dbe_clock_set  command
 */
void insert_dbe_clock_set(void)
{
  char *name = "dbe_clock_set";
  char *usage= "dbe_clock_set = <clock frequency>:<clock source>[:<clock generator frequency><type>];";
  int nParams = 3;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[3] = {CMD_PARAM_UNSIGNEDLONG, CMD_PARAM_STRING, CMD_PARAM_UNSIGNEDLONG};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_clock_set, cmdType);
}

/**
 * Query dbe clock source and frequency
 * @param argc   - 0
 * @param argv   -
 * @param retVal - <return code>
 * @param retLen - length of
 * @return       - 0 on success negative return code otherwise
 */
int dbe_clock_get(int argc, void **argv, void **retVal, int *retLen)
{
  // initialize variables
  *retLen = 0;
  sprintf(*retVal,"!dbe_clock_get?%d:Not Implemented;\n", VSIS_RET_NOT_IMPLEMENTED);
  *retLen = strlen(*retVal);
  return -VSIS_RET_NOT_IMPLEMENTED;
}

/**
 * Definition of the dbe_clock_set query command
 */
void insert_dbe_clock_get(void)
{
  char *name = "dbe_clock_get";
  char *usage= "dbe_clock_get ?;";
  int nParams = 0;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[0] = {};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_clock_get, cmdType);
}

int checkSynch(int dotOsDif, char * synchString)
{
 if (0 == dotOsDif)
    strcpy(synchString, "syncerr_eq_0");
  else if (dotOsDif <=3 )
    strcpy(synchString, "syncerr_le_3");
  else if (dotOsDif > 3)
    strcpy(synchString, "syncerr_gt_3");
  else
    strcpy(synchString, "not_synced");

 return 0;
}
int number_of_days_month[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

/**
 * Query dbe DOT
 * @param argc   - 0
 * @param argv   -
 * @param retVal - <return code>
 * @param retLen - length of
 * @return       - 0 on success negative return code otherwise
 */
int dbe_dot(int argc, void **argv, void **retVal, int *retLen)
{

  // initialize variables
  int retCode = -1;
  unsigned long ul_dotTime = 0;
  
  // get current OS time
  struct tm osTime = {0};
  time_t osSecs, hoSecs;

  int dotOsDif = 0, v_dotOsDif = 0;
  
  char synchString[32];
  char osTimeBuf[14]  = {0};
  char doTimeBuf[14]  = {0};
  
  char str_time[14] = {};

  struct timeval tv;

  int nbre_days_ref;
  int nbre_days_jan;
  short epoch_ref;
  unsigned long secs_ref_epoch;
  unsigned short val;
  unsigned short p_type;
  int new_format = 0;
  struct tm dotTime;
  int i, month;

#if 0
  char str_time_2[14] = {};
#endif
  *retLen = 0;

  gettimeofday(&tv, NULL);
  
  memset(synchString, '\0', 32 * sizeof (char));
  
  if (0 == strcmp("DDC", current_settings.personality_type))
    {
      util_read_short_fpga(6, 1, &val); /* since FPGA_SYSBLOCK_BASE 0 */
      p_type = ((val & 0xFF00) >> 8);
      if (0x83 == p_type)       
	new_format = 1;       
    }
  
  // get current local OS time here to have comparable time
  tzset();
  memset(&dotTime, 0, sizeof(struct tm));

  osSecs     = time(NULL);
  localtime_r(&osSecs, &osTime);

  /* update the Feb field */
  if (0 == osTime.tm_year % 4)
    {
      number_of_days_month[1] = 29;
      nbre_days_jan = 182;
    }
  else
    {
      number_of_days_month[1] = 28;
      nbre_days_jan = 181;
    }

  osSecs     = time(NULL);
  localtime_r(&osSecs, &osTime);

  if (new_format)
    {
      // Get the DOT running time in BCD
      retCode = fpga_get_dot(&ul_dotTime);
      // Get the DOT in VDIFF format
      retCode = fpga_ddc_get_vdif_epoch(&epoch_ref, &secs_ref_epoch);

      Bcd2Human(ul_dotTime, str_time, &dotOsDif);
      checkSynch((int)dotOsDif, synchString);

#if 0 /* FOR AUTO TESTING */
      osSecs     = time(NULL);
      localtime_r(&osSecs, &osTime);
      epoch_ref = (osTime.tm_year - 100 ) * 2;
      if (osTime.tm_mon >= 6)
	epoch_ref += 1;

      if (0 == osTime.tm_year % 4)
	nbre_days_jan = 182;
      else
	nbre_days_jan = 181;
      
      nbre_days_ref = osTime.tm_yday;
      if (osTime.tm_mon > 5)
	nbre_days_ref -= nbre_days_jan;

      secs_ref_epoch = nbre_days_ref * 86400 +  osTime.tm_hour * 3600 + osTime.tm_min * 60 + osTime.tm_sec;

#endif

      /* process the time */
      nbre_days_ref = secs_ref_epoch / 86400;
      secs_ref_epoch %= 86400;
      dotTime.tm_hour = secs_ref_epoch / 3600;
      secs_ref_epoch %= 3600;
      dotTime.tm_min = secs_ref_epoch / 60;
      dotTime.tm_sec = secs_ref_epoch % 60;

#if 0      
      dotTime.tm_yday = nbre_days_ref;
      /* find the month using the nbre_days_ref */
      i=0;
      while(i<12)
	{
	  nbre_days_ref -= number_of_days_month[i];
	  if (nbre_days_ref <= 28)
	    break;
	  i++;
	}
#endif
      dotTime.tm_year = epoch_ref/2 + 100;

      //dotTime.tm_yday  = (epoch_ref % 2) * nbre_days_jan + nbre_days_ref;

      dotTime.tm_zone = "UTC";

      
      month = 0;
      i = (epoch_ref % 2) * 6;
      while((i<12) && (nbre_days_ref >= number_of_days_month[i]))
	{
	  nbre_days_ref -= number_of_days_month[i];
	  i++;
	  month++;
	}

      dotTime.tm_mon = ((epoch_ref % 2) * 6) + month;
      dotTime.tm_mday = 1 + nbre_days_ref;

      hoSecs = mktime(&dotTime);
      v_dotOsDif = hoSecs - osSecs;
  
#if 0    
      sprintf(str_time, "%04d%03d%02d%02d%02d",
	      1900+dotTime.tm_year, dotTime.tm_yday, dotTime.tm_hour, dotTime.tm_min, dotTime.tm_sec);

      sprintf(str_time_2, "%04d%03d%02d%02d%02d",
	      1900+osTime.tm_year, osTime.tm_yday, osTime.tm_hour, osTime.tm_min, osTime.tm_sec);
#endif

      //checkSynch(dotOsDif, synchString);
      strftime(osTimeBuf, sizeof (osTimeBuf), "%Y%j%H%M%S", &osTime);

      strftime(doTimeBuf, sizeof(doTimeBuf), "%Y%j%H%M%S", &dotTime);
#if 0
      sprintf(*retVal, "!dbe_dot?%d:%s:%s:%s:%u:%u;\n",
	      retCode, doTimeBuf, synchString, osTimeBuf, v_dotOsDif, hoSecs);
#endif

      sprintf(*retVal, "!dbe_dot?%d:%s:%s:%s:%d:%08lx:%s:%d:%u;\n",
	      retCode, str_time, synchString, osTimeBuf, (int)dotOsDif, ul_dotTime,
	      doTimeBuf, (int)v_dotOsDif, (unsigned int)hoSecs); 
    }
  else
    {
      // Get the DOT running time in BCD
      retCode = fpga_get_dot(&ul_dotTime);
      /* process the DOT */
      Bcd2Human(ul_dotTime, str_time, &dotOsDif);
      checkSynch(dotOsDif, synchString);
      strftime(osTimeBuf, sizeof (osTimeBuf), "%Y%j%H%M%S", &osTime);
      sprintf(*retVal, "!dbe_dot?%d:%s:%s:%s:%d:%08lx;\n",
	      retCode, str_time, synchString, osTimeBuf, (int)dotOsDif, ul_dotTime);
    }

  // package up the result and return

  //#ifdef _DEBUG_1PPS_
  //printf("%ld:%ld -- %d -- %ld:%s:%s:%d\n", 
  //tv.tv_sec, tv.tv_usec, osTime.tm_sec, dotTime, str_time, osTimeBuf, dotOsDif);
  
  *retLen = strlen(*retVal);
  return retCode;
}

/**
 * Definition of the dbe_dot Query
 */
void insert_dbe_dot(void)
{
  char *name = "dbe_dot";
  char *usage= "dbe_dot ? ;";
  int nParams = 0;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[0] = {};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_dot, cmdType);
}


/**
 * Specify dbe DOT
 * @param argc   - 2
 * @param argv   - <time> [<option>]
 * @param retVal - <return code>
 * @param retLen - length of
 * @return       - 0 on success negative return code otherwise
 */
int dbe_dot_set(int argc, void **argv, void **retVal, int *retLen)
{
  // FOR CALCULATION OF JJJ
  time_t timex; /* from time() */

  // initialize variables
  int retCode = -1;

  *retLen = 0;
  timex = time((time_t *) NULL);

  // initialixe high order time and option parameters
  char* hoTimePtr = (char*)argv[0];
  // initialize time variables

  unsigned long bcdTimeCode = 0x0l;
  
  // get time for first day of year.
  if (hoTimePtr != 0)
    {
      string2JD(hoTimePtr, &bcdTimeCode);
    }
  else // -- use the OS time in seconds
    {
#if 1
      sem_post(&dot_set_ops);
      sprintf(*retVal,"!dbe_dot_set=%d;\n", 0);
      *retLen = strlen(*retVal);
   
      return 0;
#else
      secsToSet = time(NULL);
      localtime_r(&secsToSet, &dotTime);
      
      // create BCD from time code
      time2JD(&dotTime, &bcdTimeCode);
#endif
    }
  
#if DEBUG_VERBOSE
   printf( "\nTime code to set DOT clock: %lu 0x%08x 0x%08x 0x%08x\n",
           bcdTimeCode,
           (unsigned int)(bcdTimeCode&0xffff0000),
           (unsigned int)(bcdTimeCode&0x0000ffff),
           ((unsigned int)(bcdTimeCode&0xffff0000))|((unsigned int)(bcdTimeCode&0x0000ffff)) );
#endif

   // set the DOT time and return
#if DEBUG_VERBOSE
   printf("\nfpga_set_dot - set DOT clock: dotTime=%lu (0x%08x) \n", bcdTimeCode,  (unsigned int)bcdTimeCode );
#endif 
   retCode = fpga_set_dot(bcdTimeCode);
   
   sprintf(*retVal,"!dbe_dot_set=%d;\n", retCode);
   *retLen = strlen(*retVal);
   
   return retCode;
}

/**
 * Definition of the dbe_dot_set command
 */
void insert_dbe_dot_set(void)
{
  char *name = "dbe_dot_set";
  char *usage= "dbe_dot_set = <time>[:<option>];";
  int nParams = 2;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[2] = {CMD_PARAM_TIME, CMD_PARAM_STRING};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_dot_set, cmdType);
}

int dbe_dot_set_nw(int argc, void **argv, void **retVal, int *retLen)
{
  // FOR CALCULATION OF JJJ
  time_t timex; /* from time() */

  // initialize variables
  int retCode = -1;
  time_t secsToSet;
  struct tm dotTime;

  *retLen = 0;
  timex = time((time_t *) NULL);

  // initialixe high order time and option parameters
  char* hoTimePtr = (char*)argv[0];
  // initialize time variables

  unsigned long bcdTimeCode = 0x0l;
  
  // get time for first day of year.
  if (hoTimePtr != 0)
    {
      string2JD(hoTimePtr, &bcdTimeCode);
    }
  else // -- use the OS time in seconds
    {
      secsToSet = time(NULL);
      localtime_r(&secsToSet, &dotTime);
      
      // create BCD from time code
      time2JD(&dotTime, &bcdTimeCode);
    }
  
#if DEBUG_VERBOSE
   printf( "\ndot_set_nw Time code to set DOT clock: %lu 0x%08x 0x%08x 0x%08x\n",
           bcdTimeCode,
           (unsigned int)(bcdTimeCode&0xffff0000),
           (unsigned int)(bcdTimeCode&0x0000ffff),
           ((unsigned int)(bcdTimeCode&0xffff0000))|((unsigned int)(bcdTimeCode&0x0000ffff)) );
#endif

   // set the DOT time and return
#if DEBUG_VERBOSE
   printf("\nfpga_set_dot_nw - set DOT clock: dotTime=%lu (0x%08x) \n", 
	  bcdTimeCode,  (unsigned int)bcdTimeCode );
#endif 
   retCode = fpga_set_dot(bcdTimeCode);
   
   sprintf(*retVal,"!dbe_dot_set_nw=%d;\n", retCode);
   *retLen = strlen(*retVal);
   
   return retCode;
}

/**
 * Definition of the dbe_dot_set command
 */
void insert_dbe_dot_set_nw(void)
{
  char *name = "dbe_dot_set_nw";
  char *usage= "dbe_dot_set_nw = <time>[:<option>];";
  int nParams = 2;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[2] = {CMD_PARAM_TIME, CMD_PARAM_STRING};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_dot_set_nw, cmdType);
}

/**
 * Query dbe DOT
 * @param argc   - 0
 * @param argv   -
 * @param retVal - <return code>
 * @param retLen - length of
 * @return       - 0 on success negative return code otherwise
 */
int dbe_dot_get(int argc, void **argv, void **retVal, int *retLen)
{
  // initialize variables
   int retCode = -1;
   
   char str_time[14] = {};
   
   unsigned long dotTime       = 0L;

   int offset = 0;

   *retLen = 0;

   // -- convert from BCD 'JJJSSSSS' into day of year and seconds in day

   // Get the DOT running time in BCD
   retCode   = fpga_get_dot(&dotTime);
#if DEBUG_VERBOSE
   printf("\nfpga_get_dot - get DOT clock: dotTime=%lu (0x%08x) \n", dotTime,  (unsigned int)dotTime );
#endif

   if (-1 != retCode)
     {
       /* process the DOT */
       Bcd2Human(dotTime, str_time, 0);
       
       // package up the result and return
       sprintf(*retVal,"!dbe_dot_set?%d:%s:%d;\n", retCode, str_time, offset);
     }
   else
     sprintf(*retVal,"!dbe_dot_set?%d:%s:%d;\n", retCode, "", offset);

   *retLen = strlen(*retVal);

   return retCode;
}

/**
 * Definition of the dbe_dot_set query
 */
void insert_dbe_dot_get(void)
{
  char *name = "dbe_dot_set";
  char *usage= "dbe_dot_set ? ;";
  int nParams = 0;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[0] = {};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_dot_get, cmdType);
}

/*
 * get the status of the internal 1PPS
 * @param argc   - 0
 * @param argv   -
 * @param retVal - <return code>
 * @param retLen - length of
 * @return       - 0 on success negative return code otherwise
 */
int dbe_ipps_get(int argc, void **argv, void **retVal, int *retLen)
{
  // initialize variables
  int retCode = -1;
  int ret;

  unsigned int delta;
  unsigned short stat;
  unsigned short sync_en;

  *retLen = 0;
  
  retCode = fpga_get_1pps_status(&sync_en, &stat, &delta);
  if (!retCode)
    {
      sprintf(*retVal,"!dbe_ipps?%d:%d:%d:%d:%d:%u;\n", 
	      VSIS_RET_SUCCESS, sync_en & 0x1, stat & 0x1, (stat & 0x2) >> 1, (stat & 0x4) >> 2, delta);
      ret = VSIS_RET_SUCCESS;
    }
  else
    {
      sprintf(*retVal,"!dbe_ipps?%d:%d;\n", VSIS_RET_EXECUTION_ERROR, retCode);
      ret = VSIS_RET_EXECUTION_ERROR;
    }

  *retLen = strlen(*retVal);
  return ret;
}

/**
 * Definition of the dbe_ipps query
 */
void insert_dbe_ipps_get(void)
{
  char *name = "dbe_ipps";
  char *usage= "dbe_ipps ? ;";
  int nParams = 0;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[0] = {};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_ipps_get, cmdType);
}

/*
 * set the status of the internal 1PPS (trigger it)
 * @param argc   - 0
 * @param argv   -
 * @param retVal - <return code>
 * @param retLen - length of
 * @return       - 0 on success negative return code otherwise
 */
int dbe_ipps_set(int argc, void **argv, void **retVal, int *retLen)
{
  // initialize variables
  int retCode = -1;
  int ret;

  unsigned short stat;

  *retLen = 0;

  if (argv[0])
    stat = (short)*(long int*) argv[0];
  else
    {
      sprintf(*retVal,"!dbe_ipps=%d:%d;\n", VSIS_RET_EXECUTION_ERROR, retCode);
      ret = VSIS_RET_EXECUTION_ERROR;
      *retLen = strlen(*retVal);
      return ret;
    }

  stat &= 0x1;

  retCode = fpga_set_1pps_status(stat);
  if (!retCode)
    {
      sprintf(*retVal,"!dbe_ipps=%d;\n", VSIS_RET_SUCCESS);
      ret = VSIS_RET_SUCCESS;
    }
  else
    {
      sprintf(*retVal,"!dbe_ipps=%d:%d;\n", VSIS_RET_EXECUTION_ERROR, retCode);
      ret = VSIS_RET_EXECUTION_ERROR;
    }

  *retLen = strlen(*retVal);
  return ret;
}

/**
 * Definition of the dbe_ipps query
 */
void insert_dbe_ipps_set(void)
{
  char *name = "dbe_ipps";
  char *usage= "dbe_ipps = <stat>;";
  int nParams = 1;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[1] = {CMD_PARAM_INTEGER};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_ipps_set, cmdType);
}


/**
 * Increment the dbe DOT
 * @param argc   - 1
 * @param argv   - <increment value>
 * @param retVal - <return code>
 * @param retLen - length of
 * @return       - 0 on success negative return code otherwise
 */
int dbe_dot_inc_set(int argc, void **argv, void **retVal, int *retLen)
{
   // initialize variables
   int retCode = -1;

   int incSecs = 1;

   *retLen = 0;

   if (argv[0])
     // get seconds to inc the dot
     incSecs = (int)*(unsigned long*)argv[0];

   retCode = hal_dot_inc_set(incSecs);
   sprintf(*retVal,"!dbe_dot_inc=%d;\n", retCode);
   *retLen = strlen(*retVal);
   return retCode;

}

/**
 * Definition of the dbe_dot_inc_set  command
 */
void insert_dbe_dot_inc_set(void)
{
  char *name = "dbe_dot_inc";
  char *usage= "dbe_dot_inc = <increment>;";
  int nParams = 1;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[1] = {CMD_PARAM_LONG};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_dot_inc_set, cmdType);
}

/**
 * Query the Increment the DOT value
 * @param argc   -
 * @param argv   -
 * @param retVal - <return code>
 * @param retLen - length of
 * @return       - 0 on success negative return code otherwise
 */
int dbe_dot_inc_get(int argc, void **argv, void **retVal, int *retLen)
{
  int retCode = -1;
  int secs = 0;

  // initialize variables
  *retLen = 0;

  retCode = hal_dot_inc_get(&secs);
  sprintf(*retVal,"!dbe_dot_inc?%d:%d;\n", retCode, secs);
  *retLen = strlen(*retVal);
  return retCode;
}

/**
 * Definition of the dbe_dot_inc_get  command
 */
void insert_dbe_dot_inc_get(void)
{
  char *name = "dbe_dot_inc";
  char *usage= "dbe_dot_inc ? ;";
  int nParams = 0;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[0] = {};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_dot_inc_get, cmdType);
}

/* ***************************************************************************************************** */
/* ***************************************************************************************************** */
/* ***************************************************************************************************** */
/*                  General Commands                                                                     */
/* ***************************************************************************************************** */
/* ***************************************************************************************************** */

/**
 * get rdbe status
 * @param argc   - 0
 * @param argv   -
 * @param retVal - <return code>
 * @param retLen - length of
 * @return       - 0 on success negative return code otherwise
 */
int dbe_status_get(int argc, void **argv, void **retVal, int *retLen)
{
  int retCode = -1;
  unsigned short ctl;

  short status = 0x0001;

  // initialize variables
  *retLen = 0;
  // read the status register(s)
  retCode = hal_status(&status);

  status = 0x0001;
  status |= ((current_settings.personality_load_status & 0x1) << 8);

  retCode = fpga_dtm_get_status(&ctl);
  if (!retCode)
    {
      ctl &= 0x3;
      if (1 == ctl)
	status |= (1 << 6);
    }

  sprintf(*retVal, "!dbe_status?%d:0x%04x;\n", retCode, status); /* 0x0001); // status */
  *retLen = strlen(*retVal);
  return retCode;
}

/**
 * Definition of the dbe_status_get query
 */
void insert_dbe_status_get(void)
{
  char *name = "dbe_status";
  char *usage= "dbe_status ? ;";
  int nParams = 0;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[0] = {};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_status_get, cmdType);
}

/**
 * Get dbe hardware version
 * @param argc   - 0
 * @param argv   -
 * @param retVal - <return code>
 * @param retLen - length of
 * @return       - 0 on success negative return code otherwise
 */
int dbe_hw_version_get(int argc, void **argv, void **retVal, int *retLen)
{
  // initialize variables
  *retLen = 0;

  sprintf(*retVal,"!dbe_hw_version=%d:%s:%s:%s;\n", VSIS_RET_SUCCESS,
	  ROACH_BOARD_VERSION,
	  TIMING_BOARD_VERSION,
	  ALC_BOARD_VERSION);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS;
}

/**
 * Definition of the dbe_hw_version_get query
 */
void insert_dbe_hw_version_get(void)
{
   // add to the global list of available commands
   char *name = "dbe_hw_version";
   char *usage= "dbe_hw_version ? ;";
   int nParams = 0;
   int cmdType = CMD_VSIS_QUERY;
   int paramTypes[0] = {};
   cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_hw_version_get, cmdType);
}

/**
 * Get dbe software version
 * @param argc   - 0
 * @param argv   -
 * @param retVal - <return code>
 * @param retLen - length of
 * @return       - 0 on success negative return code otherwise
 */
int dbe_sw_version_get(int argc, void **argv, void **retVal, int *retLen)
{
  // initialize variables
  *retLen = 0;

  sprintf(*retVal,"!dbe_sw_version=%d:%s:%s:%s;\n", VSIS_RET_SUCCESS,
	  APP_DESCRIPTION,
	  HAL_DESCRIPTION,
	  OS_DESCRIPTION);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS;
}

/**
 * Definition of the dbe_sw_version_get query
 */
void insert_dbe_sw_version_get(void)
{
   // add to the global list of available commands
   char *name = "dbe_sw_version";
   char *usage= "dbe_sw_version ? ;";
   int nParams = 0;
   int cmdType = CMD_VSIS_QUERY;
   int paramTypes[0] = {};
   cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_sw_version_get, cmdType);
}

/*
 *  ******************************************************************************************
 *
 * Data communication commands
 *
 * ******************************************************************************************
 */

int dbe_mac_get(int argc, void **argv, void **retVal, int *retLen)
{
  // initialize variables
  int retCode = -1;
  unsigned char mac[6];

  // initialize return string and length
  *retLen = 0;

  retCode = fpga_10ge_get_local_mac(0, mac);
  if (!retCode)
    {
      sprintf(*retVal, "!dbe_mac?:%d:%02x:%02x:%02x:%02x:%02x:%02x;\n",
	      retCode, mac[4], mac[5], mac[2], mac[3], mac[0], mac[1]);
    }
  else
    {
      sprintf(*retVal, "!dbe_mac?:%d\n", VSIS_RET_EXECUTION_ERROR);
      retCode = -VSIS_RET_EXECUTION_ERROR;
    }

  *retLen = strlen(*retVal);
  return retCode;
}

void insert_dbe_mac_get(void)
{
  char *name = "dbe_mac";
  char *usage= "dbe_mac ? ;";
  int nParams = 0;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[0] = {};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_mac_get, cmdType);
}

int dbe_mac_set(int argc, void **argv, void **retVal, int *retLen)
{
  // initialize variables
  int retCode = -1;
  unsigned port = 0;   // always 0 for now

  char* argPtr    = 0;
  unsigned char mac[6];;
  unsigned int macs[6];
  int stat = 0;

  // initialize return string and length
  *retLen = 0;
  
  // get the parameters
  argPtr  = (char*) argv[0];
  if (argPtr)
    {
      stat = sscanf(argPtr, "%x.%x.%x.%x.%x.%x",
		    &macs[0],
		    &macs[1],
		    &macs[2],
		    &macs[3],
		    &macs[4],
		    &macs[5]);
      if (stat < MAC_LEN)
	{
	  sprintf(*retVal, "!dbe_mac=%d\n", VSIS_RET_PARAMETER_ERROR);
	  *retLen = strlen(*retVal);
	  return -VSIS_RET_PARAMETER_ERROR;
	}

      mac[0] = (unsigned char)macs[4];
      mac[1] = (unsigned char)macs[5];

      mac[2] = (unsigned char)macs[2];
      mac[3] = (unsigned char)macs[3];

      mac[4] = (unsigned char)macs[0];
      mac[5] = (unsigned char)macs[1];

      retCode = fpga_10ge_set_local_mac(port, mac);
      if (!retCode)
	{
	  sprintf(*retVal,"!dbe_mac=%d;\n", retCode);
	  *retLen = strlen(*retVal);
	  return retCode;
	}
      else
	{
	  sprintf(*retVal, "!dbe_mac=%d\n", VSIS_RET_EXECUTION_ERROR);
	  *retLen = strlen(*retVal);
	  return -VSIS_RET_EXECUTION_ERROR;
	}

    }
  else
    {
      sprintf(*retVal, "!dbe_mac=%d\n", VSIS_RET_PARAMETER_ERROR);
      *retLen = strlen(*retVal);
      return -VSIS_RET_PARAMETER_ERROR;
    }

}

void insert_dbe_mac_set(void)
{
  char *name = "dbe_mac";
  char *usage= "dbe_mac = <mac>;";
  int nParams = 1;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[1] = {CMD_PARAM_STRING};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_mac_set, cmdType);
}
/**
 * Implement dbe ifgonfig command
 * @param argc   - 5
 * @param argv   - <state> <MTU> <mode> <IP Address> <Local Gateway>
 * @param retVal - <return code>
 * @param retLen - length of
 * @return       - 0 on success negative return code otherwise
 */
int dbe_ifconfig_set(int argc, void **argv, void **retVal, int *retLen)
{
  // initialize variables
  int retCode = -1;
  const unsigned port = 0;   // always 0 for now
  char* state = 0;
  unsigned short mtu = 0;
  unsigned short mode = 0;
  unsigned short gw = 1;
  unsigned char* ipPtr = 0;
  int ip[4];
  unsigned long uip;
  int stat = 0;

  // initialize return string and length
  *retLen = 0;

  // get the parameters
  state = (char*)argv[0];
  if (argv[1])
    mtu   = (unsigned short)*(unsigned long*)argv[1];
  if (argv[2])
    mode  = (unsigned short)*(unsigned long*)argv[2];
  ipPtr = (unsigned char*)argv[3];

  /* check data for validity */

  if ((unsigned char *)0x0 == ipPtr)
    {
      /* return error */
      sprintf(*retVal,"!dbe_ifconfig=%d;\n", VSIS_RET_PARAMETER_ERROR);
      *retLen = strlen(*retVal);
      return -VSIS_RET_PARAMETER_ERROR;
    }

  if (argv[4])
    gw = (unsigned short)*(unsigned long*)argv[4];

  if (strcmp("up", state) &&
      strcmp("down", state))
    {
      /* return error */
      sprintf(*retVal,"!dbe_ifconfig=%d;\n", VSIS_RET_PARAMETER_ERROR);
      *retLen = strlen(*retVal);
      return -VSIS_RET_PARAMETER_ERROR;
    }
  if ((mtu > MAX_MTU) ||
      (mtu < MIN_MTU))
    {
      /* return error. */
      sprintf(*retVal,"!dbe_ifconfig=%d;\n", VSIS_RET_PARAMETER_ERROR);
      *retLen = strlen(*retVal);
      return -VSIS_RET_PARAMETER_ERROR;
    }

  if ((LAYER_2_TX != mode) &&
      (LAYER_4_TX != mode))
    {
      /* return error */
      sprintf(*retVal,"!dbe_ifconfig=%d;\n", VSIS_RET_PARAMETER_ERROR);
      *retLen = strlen(*retVal);
      return -VSIS_RET_PARAMETER_ERROR;
    }

  /* extract the IP */
  stat = sscanf((const char *)ipPtr, "%d.%d.%d.%d",
		&ip[0], &ip[1], &ip[2], &ip[3]);
  if (stat < IP_LEN)
    {
      /* return error */
      sprintf(*retVal,"!dbe_ifconfig=%d;\n", VSIS_RET_PARAMETER_ERROR);
      *retLen = strlen(*retVal);
      return -VSIS_RET_PARAMETER_ERROR;
    }

  uip = ip[0] << 24 | ip[1] << 16 | ip[2] << 8 | ip[3];

  pthread_mutex_lock(&mutexIf);

  // set the state, MTU, mode and IP of the 10GEthernet interface
  //retCode = fpga_10ge_set_if_state(port, state);
  if (0 == strcmp(state, "up"))
    {
      retCode = fpga_10ge_set_phy_config(port, 0x1);
      if (!retCode)
	curIfStat[port] = 1;
      else
	{
	  sprintf(*retVal, "!dbe_ifconfig=%d\n", VSIS_RET_EXECUTION_ERROR);
	  *retLen = strlen(*retVal);
	  pthread_mutex_unlock(&mutexIf);
	  return -VSIS_RET_EXECUTION_ERROR;
	}
    }
  else if (0 == strcmp(state, "down"))
    {
      retCode = fpga_10ge_set_phy_config(port, 0x0);
      if (!retCode)
	curIfStat[port] = 0;
      else
	{
	  sprintf(*retVal, "!dbe_ifconfig=%d\n", VSIS_RET_EXECUTION_ERROR);
	  *retLen = strlen(*retVal);
	  pthread_mutex_unlock(&mutexIf);
	  return -VSIS_RET_EXECUTION_ERROR;
	}
    }

  /* before setting any of these, turn off the interface if it was up*/
  if (curIfStat[port])
    {
      retCode = fpga_10ge_set_phy_config(port, 0x0);
    }

  // set mtu, mode and ip address
  retCode = fpga_10ge_set_if_mtu(port, mtu);       // fixed can not change
  retCode = fpga_10ge_set_if_mode(port, mode);     // fixed can not change
  retCode = fpga_10ge_set_local_ip(port, &uip);
  retCode = fpga_10ge_set_local_gw(port, gw);

  /* return the interface to is previous state */
  if (curIfStat[port])
    {
      retCode = fpga_10ge_set_phy_config(port, 0x1);
    }

  pthread_mutex_unlock(&mutexIf);

  sprintf(*retVal,"!dbe_ifconfig=%d;\n", retCode);
  *retLen = strlen(*retVal);
  return retCode;
}

/**
 * Definition of the dbe_ifconfig_set  command
 */
void insert_dbe_ifconfig_set(void)
{
  char *name = "dbe_ifconfig";
  char *usage= "dbe_ifconfig = <state>:<MTU>:<mode>:<IP Address>:<GW>;";
  int nParams = 5;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[5] = {CMD_PARAM_STRING, CMD_PARAM_UNSIGNEDLONG, CMD_PARAM_UNSIGNEDLONG, CMD_PARAM_STRING,
		       CMD_PARAM_UNSIGNEDLONG};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_ifconfig_set, cmdType);
}

/**
 * Implement dbe ifgonfig query
 * @param argc   - 0
 * @param argv   -
 * @param retVal - <return code>
 * @param retLen - length of
 * @return       - 0 on success negative return code otherwise
 */
int dbe_ifconfig_get(int argc, void **argv, void **retVal, int *retLen)
{
   int retCode = -1;

   unsigned port = 0;
   char* stateStr = "notdefined";
   unsigned short state = 0;
   unsigned short mtu   = 0;
   unsigned char  mode  = 0;
   unsigned char gw;
   unsigned char ip[4]  = {'\0'};
   unsigned long uip;
   int packs    = 0;
   int errors   = 0;
   int dropped  = 0;
   int overrun  = 0;
   int queuelen = 0;

   // initialize variables
   *retLen = 0;

   //retCode = fpga_10ge_get_if_state(port, state);
   retCode = fpga_10ge_get_phy_config(port, &state);
#ifdef DEBUG_VERBOSE
   printf("cmd_base:dbe_ifconfig_get state of 10GE Phy is 0x%x and retcode = %d \n", state, retCode);
#endif
   state &= 0x1;

   if ( state )
   {
      stateStr = "up";
   }
   else if ( !state )
   {
      stateStr = "down";
   }

   retCode = fpga_10ge_get_if_mtu(port, &mtu);
   retCode = fpga_10ge_get_if_mode(port, &mode);
   retCode = fpga_10ge_get_local_ip(port, &uip);

   retCode = fpga_10ge_get_local_gw(port, &gw);

   retCode = fpga_10ge_get_tx_packets(port, &packs);
   retCode = fpga_10ge_get_tx_errors(port, &errors);
   retCode = fpga_10ge_get_tx_dropped(port, &dropped);
   retCode = fpga_10ge_get_tx_overrun(port, &overrun);
   retCode = fpga_10ge_get_tx_queuelen(port, &queuelen);

   ip[0] = (uip & 0xFF000000) >> 24;
   ip[1] = (uip & 0xFF0000) >> 16;
   ip[2] = (uip & 0xFF00) >> 8;
   ip[3] = uip & 0xFF;
   

   sprintf(*retVal,"!dbe_ifconfig?%d:%s:%d:%d:%d.%d.%d.%d:%d:%d:%d:%d:%d:%d;\n",
	   retCode, stateStr, mtu, mode, ip[0], ip[1], ip[2], ip[3], gw,
	   packs, errors, dropped, overrun, queuelen);
   *retLen = strlen(*retVal);
   return retCode;
}

enum ArpCmdState
{
  ARP_CMD_ADD,
  ARP_CMD_DEL,
  ARP_CMD_FLU,
  ARP_CMD_FOR,
  ARP_CMD_UNK
};

/**
 * Definition of the dbe_ifconfig_get query
 */
void insert_dbe_ifconfig_get(void)
{
  char *name = "dbe_ifconfig";
  char *usage= "dbe_ifconfig ? ;";
  int nParams = 0;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[0] = {};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_ifconfig_get, cmdType);
}

/**
 * Implement dbe arp command
 * @param argc   - 512 (maximum number of ip:mac pairs
 * @param argv   - [<IP> <MAC>]+ (up to 255 pairs)
 * @param retVal - <return code>
 * @param retLen - length of
 * @return       - 0 on success negative return code otherwise
 */
int dbe_arp_set(int argc, void **argv, void **retVal, int *retLen)
{
  int i           = 0;
  int retCode     = -1;
  int stat;

  char * state;
  enum ArpCmdState action = ARP_CMD_UNK;

  unsigned port   = 0;

  char* argPtr    = 0;

  unsigned char endIp;
  unsigned int ip[IP_LEN];

  unsigned char mac[6] = {'\0'};

  unsigned int macs[6];

  // initialize return string and length
  *retLen = 0;

  /* get state */
  state = (char *)argv[0];
  if (!state)
    {
      /* return */
      sprintf(*retVal, "!dbe_arp=%d\n", VSIS_RET_PARAMETER_ERROR);
      *retLen = strlen(*retVal);
      return -VSIS_RET_PARAMETER_ERROR;
    }
  if (0 == strcmp(state, "add"))
    action = ARP_CMD_ADD;
  else if (0 == strcmp(state, "delete"))
    action = ARP_CMD_DEL;
  else if (0 == strcmp(state, "flush"))
    action = ARP_CMD_FLU;
  else if (0 == strcmp(state, "force"))
    action = ARP_CMD_FOR;

  if (ARP_CMD_UNK == action)
    {
      /* return */
      sprintf(*retVal, "!dbe_arp=%d\n", VSIS_RET_PARAMETER_ERROR);
      *retLen = strlen(*retVal);
      return -VSIS_RET_PARAMETER_ERROR;
    }

  /* gard access to the table */
  pthread_mutex_lock(&mutexArp);

  switch(action)
    {
    case ARP_CMD_ADD:
    case ARP_CMD_FOR:
      // process each <ip, mac> address. Only neede when adding or force
      for (i = 1; i < argc; i++)
	{
	  // parse to get end ip
	  argPtr = (char*) argv[i];
	  if (0x0 == argPtr)
	    {
	      if (0 == i)
		{
		  sprintf(*retVal, "!dbe_arp=%d\n", VSIS_RET_PARAMETER_ERROR);
		  *retLen = strlen(*retVal);
		  pthread_mutex_unlock(&mutexArp);
		  return -VSIS_RET_PARAMETER_ERROR;
		}
	      else
		break;
	    }

	  stat = sscanf(argPtr, "%u.%u.%u.%u",
			&ip[0], &ip[1], &ip[2], &ip[3]);

	  if (stat < IP_LEN)
	    {
	      sprintf(*retVal, "!dbe_arp=%d\n", VSIS_RET_PARAMETER_ERROR);
	      *retLen = strlen(*retVal);
	      pthread_mutex_unlock(&mutexArp);
	      return -VSIS_RET_PARAMETER_ERROR;
	    }

	  endIp = (unsigned char)ip[3];

	  /* these values are not allowed */
	  if ((0 == endIp) ||
	      (0xFF == endIp))
	    {
	      sprintf(*retVal, "!dbe_arp=%d\n", VSIS_RET_PARAMETER_ERROR);
	      *retLen = strlen(*retVal);
	      pthread_mutex_unlock(&mutexArp);
	      return -VSIS_RET_PARAMETER_ERROR;
	    }

	  // parse to get 6 byte mac, remove "."
	  i++;
	  argPtr  = (char*) argv[i];
	  if (argPtr)
	    {
	      stat = sscanf(argPtr, "%x.%x.%x.%x.%x.%x",
			    &macs[0],
			    &macs[1],
			    &macs[2],
			    &macs[3],
			    &macs[4],
			    &macs[5]);
	      if (stat < MAC_LEN)
		{
		  sprintf(*retVal, "!dbe_arp=%d\n", VSIS_RET_PARAMETER_ERROR);
		  *retLen = strlen(*retVal);
		  pthread_mutex_unlock(&mutexArp);
		  return -VSIS_RET_PARAMETER_ERROR;
		}

	      mac[0] = (unsigned char)macs[4];
	      mac[1] = (unsigned char)macs[5];
	      
	      mac[2] = (unsigned char)macs[2];
	      mac[3] = (unsigned char)macs[3];
	      
	      mac[4] = (unsigned char)macs[0];
	      mac[5] = (unsigned char)macs[1];
	    }
	  else
	    {
	      sprintf(*retVal, "!dbe_arp=%d\n", VSIS_RET_PARAMETER_ERROR);
	      *retLen = strlen(*retVal);
	      pthread_mutex_unlock(&mutexArp);
	      return -VSIS_RET_PARAMETER_ERROR;
	    }

	  /* before sending the command to HAL. make sure it is correct */

	  /* check if the couple exist already */

	  if ((0x0 != (ArpTable[port][endIp][0] | ArpTable[port][endIp][1] |
		       ArpTable[port][endIp][2] | ArpTable[port][endIp][3] |
		       ArpTable[port][endIp][4] | ArpTable[port][endIp][5])) &&
	      (ARP_CMD_ADD == action))
	    {
	      sprintf(*retVal, "!dbe_arp=%d\n", VSIS_RET_PARAMETER_ERROR);
	      *retLen = strlen(*retVal);
	      pthread_mutex_unlock(&mutexArp);
	      return -VSIS_RET_PARAMETER_ERROR;
	    }
	  else
	    {
	      // Call the HAL to configure the ARP
#ifdef DEBUG_VERBOSE
	      printf("Add: calling ARP set Port=%d, IP=%d, MAC=%x:%x:%x:%x:%x:%x\n",
		     port, endIp, mac[0],mac[1],mac[2],mac[3],mac[4],mac[5]);
#endif
	      retCode = fpga_10ge_set_arp_value(port, endIp, mac);

	      if (!retCode)
		{
		  /* update tabe with the new value otherwise igonre it */
		  strncpy((char *)&ArpTable[port][endIp], (char *)mac, MAC_LEN);
		}
	      else
		{
		  sprintf(*retVal, "!dbe_arp=%d\n", VSIS_RET_EXECUTION_ERROR);
		  *retLen = strlen(*retVal);
		  pthread_mutex_unlock(&mutexArp);
		  return -VSIS_RET_EXECUTION_ERROR;
		}
	    }
	} // -- for (i = 0; i < argc; ++i)
      sprintf(*retVal, "!dbe_arp=%d;\n", retCode);
#if DEBUG_VERBOSE
      printf("returnVal: %s\n", (char*)*retVal);
#endif 

      *retLen = strlen(*retVal);
      pthread_mutex_unlock(&mutexArp);
      return retCode;
      break;
    case ARP_CMD_DEL:
      /* in this case we only need the Ips */
      // process each ips.
      for (i = 1; i < 255; i++)
	{
	  // parse to get end ip
	  argPtr = (char*) argv[i];

	  if (0x0 == argPtr)
	    {
	      sprintf(*retVal, "!dbe_arp=%d\n", VSIS_RET_PARAMETER_ERROR);
	      *retLen = strlen(*retVal);
	      pthread_mutex_unlock(&mutexArp);
	      return -VSIS_RET_PARAMETER_ERROR;
	    }

	  stat = sscanf(argPtr, "%u.%u.%u.%u",
			&ip[0], &ip[1], &ip[2], &ip[3]);

	  if (stat < IP_LEN)
	    {
	      sprintf(*retVal, "!dbe_arp=%d\n", VSIS_RET_PARAMETER_ERROR);
	      *retLen = strlen(*retVal);
	      pthread_mutex_unlock(&mutexArp);
	      return -VSIS_RET_PARAMETER_ERROR;
	    }

	  endIp = (unsigned char)ip[3];

	  if (0x0 != (ArpTable[port][endIp][0] | ArpTable[port][endIp][1] |
		      ArpTable[port][endIp][2] | ArpTable[port][endIp][3] |
		      ArpTable[port][endIp][4] | ArpTable[port][endIp][5]))
	    {
	      mac[0] = mac[1] = mac[2] = mac[3] = mac[4] = mac[5] = mac[6] = 0;
#if DEBUG_VERBOSE
	      printf("Del: calling ARP set Port=%d, IP=%d, MAC=%x:%x:%x:%x:%x:%x\n",
		     port, endIp, mac[4], mac[5], mac[2], mac[3], mac[0], mac[1]);
#endif 
	      /* send a command to del ? */
	      retCode = fpga_10ge_set_arp_value(port, endIp, mac);
	      if (!retCode)
		{
		  /* update tabe with the new value otherwise igonre it */
		  memset(ArpTable[port][endIp], 0, MAC_LEN * sizeof(unsigned char));
		}
	      else
		{
		  sprintf(*retVal, "!dbe_arp=%d\n", VSIS_RET_EXECUTION_ERROR);
		  *retLen = strlen(*retVal);
		  pthread_mutex_unlock(&mutexArp);
		  return -VSIS_RET_EXECUTION_ERROR;
		}
	    }
	  else
	    {
	      sprintf(*retVal, "!dbe_arp=%d\n", VSIS_RET_PARAMETER_ERROR);
	      *retLen = strlen(*retVal);
	      pthread_mutex_unlock(&mutexArp);
	      return -VSIS_RET_PARAMETER_ERROR;
	    }
	}
      sprintf(*retVal, "!dbe_arp=%d;\n", retCode);
#if DEBUG_VERBOSE
      printf("returnVal: %s\n", (char*)*retVal);
#endif 

      pthread_mutex_unlock(&mutexArp);
      *retLen = strlen(*retVal);
      return retCode;
      break;
    case ARP_CMD_FLU:
      {
	unsigned char arp_table[128][MAC_LEN];
	memset(arp_table, 0, 128 * MAC_LEN *sizeof(unsigned char));
	/* clear the table: in this no input is needed */
	fpga_10ge_set_arp_cache(port, (unsigned char *)arp_table);
	/* send a command (?) to HAL */
	if (!retCode)
	  {
	    memset(ArpTable, 0, MAX_PORTS * MAX_IP_ENTRY * MAC_LEN * sizeof(unsigned char));
	    sprintf(*retVal, "!dbe_arp=%d;\n", retCode);
	    *retLen = strlen(*retVal);
	  }
	else
	  {
	    sprintf(*retVal, "!dbe_arp=%d\n", VSIS_RET_EXECUTION_ERROR);
	    *retLen = strlen(*retVal);
	    pthread_mutex_unlock(&mutexArp);
	    return -VSIS_RET_EXECUTION_ERROR;
	  }
      }
      break;
    default:
      break;
    }
  pthread_mutex_unlock(&mutexArp);
  return retCode;
}

/**
 * Definition of the dbe_arp_set  command
 */
void insert_dbe_arp_set(void)
{
    char *name = "dbe_arp";
    char *usage= "dbe_arp = <state><IP>:<MAC>[:<IP>:<MAC>]* ;";
    int nParams = 512;
    int cmdType = CMD_VSIS_COMMAND;
    int paramTypes[512];
    int i;
    for(i=0; i<512;i++) paramTypes[i]= CMD_PARAM_STRING;
    cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_arp_set, cmdType);
}

/**
 * Implement dbe arp query
 * @param argc   - 512 (maximum number of ip:mac pairs
 * @param argv   - [<IP> <MAC>]+ (up to 255 pairs)
 * @param retVal - <return code>
 * @param retLen - length of
 * @return       - 0 on success negative return code otherwise
 */
int dbe_arp_get(int argc, void **argv, void **retVal, int *retLen)
{
   int retCode        = -1;
   unsigned port      = 3;
   unsigned short pos = 0;
   unsigned char mac[MAC_LEN] = {0};

   int outbytes = 0;

   // initialize return string and length
   *retLen = 0;

   outbytes = sprintf(*retVal, "!dbe_arp?:%d:", 0);

   // for all ips (0-255) get the arp mac address, concat into the return value
   //for (pos = 0; pos < 256; pos++)
   for (pos = 0; pos < 256; pos++)
   {
      retCode = fpga_10ge_get_arp_value(port, pos, mac);
      if ( (mac[0] | mac[1] | mac[2] | mac[3] | mac[4] | mac[5]) != 0x00 )
      {
	outbytes += sprintf(*retVal+outbytes, "%d:%02x:%02x:%02x:%02x:%02x:%02x:",
			    pos, mac[4], mac[5], mac[2], mac[3], mac[0], mac[1]);
      }

   } // -- for (pos = 0; pos < 256; pos++)

   // Set the return string and length(char*)*retVal

   if (!retCode)
     sprintf(*retVal+outbytes-1, ";\n");
  else
    {
      memset(*retVal, '\0', RESP_BUF_SIZE*sizeof(char));
      sprintf(*retVal, "!dbe_arp?:%d;\n", VSIS_RET_EXECUTION_ERROR);
      retCode = -VSIS_RET_EXECUTION_ERROR;
    }

   *retLen = strlen(*retVal);

   return retCode;
}

/**
 * Definition of the dbe_arp_get  query
 */
void insert_dbe_arp_get(void)
{
  char *name = "dbe_arp";
  char *usage= "dbe_arp ?  ;";
  int nParams = 0;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[] = {};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_arp_get, cmdType);
}

/**
 * Set data destination IP address
 * @param argc   - 512
 * @param argv   - <IP1> [<IF1>][<IP2>][<IF2>]+
 * @param retVal - <return code>
 * @param retLen - length of
 * @return       - 0 on success negative return code otherwise
 */
int dbe_data_connect_set(int argc, void **argv, void **retVal, int *retLen)
{
  int retCode = -1;

  int i = 0;
  int j = 0;

  int input[64]; // intermediate frequency port number, default to 0
  int threadid[64];

  unsigned char* ipPtr = 0;
  int ip[4];
  unsigned short upper[64];
  unsigned short lower[64];

  int stat;

  // initialize variables
  *retLen = 0;

  // step through the arguments and process each <ip, if> assignment
  for (i = 0; i < argc; i++, j++)
    {
      // parse each argument
      ipPtr = argv[i];

      /* check data for validity */
      if ((unsigned char *)0x0 == ipPtr)
	{
	  if (0 == i)
	    {
	      sprintf(*retVal, "!dbe_data_connect=%d\n", VSIS_RET_PARAMETER_ERROR);
	      *retLen = strlen(*retVal);
	      return -VSIS_RET_PARAMETER_ERROR;
	    }
	  else
	    break;
	}

      /* extract the IP */
      stat = sscanf((const char *)ipPtr, "%d.%d.%d.%d",
		    &ip[0], &ip[1], &ip[2], &ip[3]);
      if (stat < IP_LEN)
	{
	  /* return error */
	  sprintf(*retVal,"!dbe_data_connect=%d;\n", VSIS_RET_PARAMETER_ERROR);
	  *retLen = strlen(*retVal);
	  return -VSIS_RET_PARAMETER_ERROR;
	}
      
      upper[j] = ip[0] << 8 | ip[1];
      lower[j] = ip[2] << 8 | ip[3];

      i++;
      if (argv[i])
	input[j] = (unsigned int)*(unsigned long*)argv[i];
      else
	input[j] = 0;
      i++;
      if (argv[i])
	threadid[j] = (unsigned int)*(unsigned long*)argv[i];
      else
	threadid[j] = 0;

    } // for (i = 0; i < argc; i++)

#if 0
  for (i=0; i<j; i++)
    {
      /* retCode = fpga_set_if_ip_connection(&uip[i], input[i], threadid[i]); */
    }
#endif

  retCode = fpga_10ge_set_dest_ip(&upper[0], &lower[0]);
  retCode = fpga_10ge_set_local_port_ctrl(0x0101);

  sprintf(*retVal, "!dbe_data_connect=%d;\n", retCode);
  *retLen = strlen(*retVal);
  return retCode;
}

/**
 * Definition of the dbe_data_connect command
 */
void insert_dbe_data_connect_set(void)
{
  char *name = "dbe_data_connect";
  char *usage = "dbe_data_connect = <IP>[:<IF>][:<IP>:<IF>]* ;";
  int nParams = 64; //2
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[64];
  int i;
  for (i = 0; i < 64; i++) 
    {
      paramTypes[i] = CMD_PARAM_STRING;
      i++;
      paramTypes[i] = CMD_PARAM_UNSIGNEDLONG;
      i++;
      paramTypes[i] = CMD_PARAM_UNSIGNEDLONG;
    }
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_data_connect_set, cmdType);
}


/**
 * Get data destination IP address
 * @param argc   - 0
 * @param argv   -
 * @param retVal - <return code>
 * @param retLen - length of
 * @return       - 0 on success negative return code otherwise
 */
int dbe_data_connect_get(int argc, void **argv, void **retVal, int *retLen)
{
  int retCode = -1;
  int  input     = 0;
  int threadid = 0;

  unsigned char ip[4]  = {'\0'};
  unsigned short upper;
  unsigned short lower;

  // initialize variables
  *retLen = 0;
  retCode = fpga_10ge_get_dest_ip(&upper, &lower);

  ip[0] = (upper & 0xFF00) >> 8;
  ip[1] = upper & 0x00FF;

  ip[2] = (lower & 0xFF00) >> 8;
  ip[3] = lower & 0x00FF;
  

  sprintf(*retVal,"!dbe_data_connect?%d:%d.%d.%d.%d:%d:%d;\n", 
	  retCode, 
	  ip[0], ip[1], ip[2], ip[3], 
	  input, threadid);

  *retLen = strlen(*retVal);
  return retCode;
}

/**
 * Definition of the bc_mode get command
 */
void insert_dbe_data_connect_get(void)
{
  char *name = "dbe_data_connect";
  char *usage= "dbe_data_connect ? ;";
  int nParams = 0;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[0];
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_data_connect_get, cmdType);
}

/**
 * Implement dbe tid2addr command
 * @param argc   - 32 (maximum number of TID : IP pairs
 * @param argv   - [<TID> <IP>]+ (up to 16 pairs)
 * @param retVal - <return code>
 * @param retLen - length of
 * @return       - 0 on success negative return code otherwise
 */
#define TID2ADDR_MAX_IPS  16
#define MAX_THREAD_ID     1024

struct ti2addr_struct
{
  int ip[IP_LEN];
  unsigned int thread_id;
};

int dbe_tid2addr_set(int argc, void **argv, void **retVal, int *retLen)
{
  int retCode = -1;
  int i, stat;

  struct ti2addr_struct tid2ad[TID2ADDR_MAX_IPS];

  // initialize variables
  *retLen = 0;
  sprintf(*retVal,"!dbe_tid2addr=%d:Not Implemented;\n", VSIS_RET_NOT_IMPLEMENTED);
  *retLen = strlen(*retVal);
  return -VSIS_RET_NOT_IMPLEMENTED;

  for(i=0; i<argc; i +=2)
    {
      /* check the thread id. It should be between 0 - 1024 */
      if (argv[i])
	{
	  tid2ad[i].thread_id = atoi(argv[i]);
	  if (tid2ad[i].thread_id > MAX_THREAD_ID)
	    {
	      sprintf(*retVal, "!dbe_tid2addr=%d\n", VSIS_RET_PARAMETER_ERROR);
	      *retLen = strlen(*retVal);
	      return -VSIS_RET_PARAMETER_ERROR;
	    }
	}
      else
	{
	  if (0 == i)
	    {
	      sprintf(*retVal, "!dbe_tid2addr=%d\n", VSIS_RET_PARAMETER_ERROR);
	      *retLen = strlen(*retVal);
	      return -VSIS_RET_PARAMETER_ERROR;
	    }
	  break;
	}
      /* now check the IP address */
      if (argv[i+1])
	{
	  stat = sscanf(argv[i+1], "%d.%d.%d.%d",
			&tid2ad[i].ip[0],
			&tid2ad[i].ip[1],
			&tid2ad[i].ip[2],
			&tid2ad[i].ip[3]);

	  if (stat < IP_LEN)
	    {
	      if (0 == i)
		{
		  sprintf(*retVal, "!dbe_tid2addr=%d\n", VSIS_RET_PARAMETER_ERROR);
		  *retLen = strlen(*retVal);
		  return -VSIS_RET_PARAMETER_ERROR;
		}
	      break;
	    }
	}
      else
	{
	  if (0 == i)
	    {
	      /* only of the first couple. set error and return */
	      sprintf(*retVal, "!dbe_tid2addr=%d;\n", VSIS_RET_PARAMETER_ERROR);
	      *retLen = strlen(*retVal);
	      return -VSIS_RET_PARAMETER_ERROR;
	    }
	  break;
	}
    } /* For (i... */

  /* call the HAL function which one ? */
  /* retCode = fpga_..... */
  if (retCode)
    {
      sprintf(*retVal, "!dbe_tid2addr=%d;\n", VSIS_RET_EXECUTION_ERROR);
      *retLen = strlen(*retVal);
      return -VSIS_RET_EXECUTION_ERROR;
    }

  sprintf(*retVal, "!dbe_tid2addr=%d;\n",  VSIS_RET_SUCCESS);
  *retLen = strlen(*retVal);
  return  VSIS_RET_SUCCESS;
}

/**
 * Definition of the dbe_tid2addr_set command
 */
void insert_dbe_tid2addr_set(void)
{
  char *name = "dbe_tid2addr";
  char *usage= "dbe_tid2addr = <tid>:<IP Address> [<tid>:<IP Address>] ;";
  int nParams = 32;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[32];
  int i;
  for(i=0; i< 32; i++) paramTypes[i] = CMD_PARAM_STRING;
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_tid2addr_set, cmdType);
}

/**
 * Implement dbe tid2addr query
 * @param argc   -
 * @param argv   -
 * @param retVal - <return code>
 * @param retLen - length of
 * @return       - 0 on success negative return code otherwise
 */
int dbe_tid2addr_get(int argc, void **argv, void **retVal, int *retLen)
{
  // initialize variables
  *retLen = 0;
  sprintf(*retVal,"!dbe_tid2addr?%d:Not Implemented;\n", VSIS_RET_NOT_IMPLEMENTED);
  *retLen = strlen(*retVal);
  return -VSIS_RET_NOT_IMPLEMENTED;
}

/**
 * Definition of the dbe_tid2addr_get query
 */
void insert_dbe_tid2addr_get(void)
{
  char *name = "dbe_tid2addr";
  char *usage= "dbe_tid2addr ? ;";
  int nParams = 0;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[0] = {};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_tid2addr_get, cmdType);
}

/*
 * *************************************************************************************
 *
 * Packet Format Commands
 *
 * *************************************************************************************
 */

/**
 * Implement data_format command
 * @param argc   - 4
 * @param argv   - <data mode>:<data submode 1>[:<data submode 2>]
 * @param retVal - <return code>
 * @param retLen - length of
 * @return       - 0 on success negative return code otherwise
 */
int dbe_data_format_set(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode  = -1;
  char* payload  = 0;
  unsigned short   submode1 = 0;
  unsigned short   submode2 = 0;
  unsigned short   type;

  // initialize variables
  *retLen = 0;

  if (argv[0])
    payload  = (char*)argv[0];
  else
    {
      sprintf(*retVal,"!data_format=%d;\n", VSIS_RET_PARAMETER_ERROR);
      *retLen = strlen(*retVal);
      return -VSIS_RET_PARAMETER_ERROR;
    }

  if (argv[1])
    submode1 = (int)*(long int*)argv[1];
  else
    {
      sprintf(*retVal,"!data_format=%d;\n", VSIS_RET_PARAMETER_ERROR);
      *retLen = strlen(*retVal);
      return -VSIS_RET_PARAMETER_ERROR;
    }

  if (argv[2])
    submode2 = (int)*(long int*)argv[2];

   if (strcasecmp(payload, "vdif") == 0)
   {
      type = 0;
   }
   else if (strcasecmp(payload, "mark5B") == 0)
   {
      type = 1;
   }
   else if (strcasecmp(payload, "tvgvdif") == 0)
   {
      type = 2;
   }
   else if (strcasecmp(payload, "tvg5b") == 0)
   {
      type = 3;
   }
   else
   {
     sprintf(*retVal,"!data_format=%d;\n", VSIS_RET_PARAMETER_ERROR);
     *retLen = strlen(*retVal);
     return -VSIS_RET_PARAMETER_ERROR;
   }

   retCode = hal_drs_set_transmission_mode(type, submode1, submode2);
   sprintf(*retVal,"!data_format=%d;\n", retCode);
   *retLen = strlen(*retVal);
   return retCode;
}

/**
 * Definition of the data_format_set command
 */
void insert_dbe_data_format_set(void)
{
  char *name = "dbe_data_format";
  char *usage= "dbe_data_format = <data mode>:<data submode 1>[:<data submode 2>];";
  int nParams = 3;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[3] = {CMD_PARAM_STRING,CMD_PARAM_UNSIGNEDLONG,CMD_PARAM_UNSIGNEDLONG};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_data_format_set, cmdType);
}

/* Implement data_format query
 * @param argc   - 0
 * @param argv   -
 * @param retVal - <return code>
 * @param retLen - length of
 * @return       - 0 on success negative return code otherwise
 */
int dbe_data_format_get(int argc, void **argv, void **retVal, int *retLen)
{
  int   retCode = -1;
  char  payload[10]  = {0};
  unsigned short  submode1 = 0x00;
  unsigned short  submode2 = 0x00;
  unsigned short  type     = 0;

  // initialize variables
  *retLen = 0;

  retCode = hal_drs_get_transmission_mode(&type, &submode1, &submode2);
  switch(type)
    {
    case 0:
      {
	strcpy(payload, "vdif");
	break;
      }
    case 1:
      {
	strcpy(payload, "mark5B");
	break;
      }
    case 2:
      {
	strcpy(payload, "tvgvdif");
	break;
      }
    case 3:
      {
	strcpy(payload, "tvg5b");
	break;
      }
    default:
      {
	strcpy(payload, "undef");
      }
    }
  sprintf(*retVal,"!data_format?%d:%s:%#x:%d;\n", retCode, payload, submode1, submode2);
  *retLen = strlen(*retVal);
  return retCode;
}

/**
 * Definition of the data_format_get query
 */
void insert_dbe_data_format_get(void)
{
  char *name = "dbe_data_format";
  char *usage= "dbe_data_format ? ;";
  int nParams = 0;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[0] = {};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_data_format_get, cmdType);
}


/**
 * Implement packet command
 * @param argc   - 5
 * @param argv   - <DOFST>:<DFOFST>:<length>:<PSN mode>:<PSNOFST>
 * @param retVal - <return code>
 * @param retLen - length of
 * @return       - 0 on success negative return code otherwise
 */
int dbe_packet_set(int argc, void **argv, void **retVal, int *retLen)
{
  // initialize variables
  int retCode = -1;
  int dp_offset = 0;
  int df_offset = 0;
  int len, psn_mode, psn_offset;
  int i;

  *retLen = 0;

  // Get arguments
  for (i=0; i<argc; i++)
    {
      if (argv[i])
	{
	  switch(i)
	    {
	    case 0:
	      dp_offset = (int)*(long int*)argv[i];
	      break;
	    case 1:
	      df_offset = (int)*(long int*)argv[i];
	      break;
	    case 2:
	      len = (int)*(long int*)argv[i];
	      break;
	    case 3:
	      psn_mode = (int)*(long int*)argv[i];
	      break;
	    case 4:
	      psn_offset = (int)*(long int*)argv[i];
	      break;
	    } /* switch... */
	}
      else
	{
	  sprintf(*retVal,"!dbe_packet=%d;\n", VSIS_RET_PARAMETER_ERROR);
	  *retLen = strlen(*retVal);
	  return -VSIS_RET_PARAMETER_ERROR;
	}
    } /* for (i... */

  retCode = fpga_drs_set_packet(dp_offset);
  if (!retCode)
    {
      retCode = VSIS_RET_SUCCESS;
      sprintf(*retVal,"!dbe_packet=%d;\n", retCode);
    }
  else
    {
      retCode = VSIS_RET_EXECUTION_ERROR;
      sprintf(*retVal,"!dbe_packet=%d;\n", retCode);
    }

  *retLen = strlen(*retVal);
  return retCode;
}

/**
 * Definition of the dbe_packet_set command
 */
void insert_dbe_packet_set(void)
{
  char *name = "dbe_packet";
  char *usage= "dbe_packet = <DOFST>:<DFOFST>:<length>:<PSN mode>:<PSNOFST>;";
  int nParams = 5;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[5] = {CMD_PARAM_UNSIGNEDLONG,CMD_PARAM_UNSIGNEDLONG,CMD_PARAM_UNSIGNEDLONG,
		       CMD_PARAM_UNSIGNEDLONG,CMD_PARAM_UNSIGNEDLONG };
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_packet_set, cmdType);
}


/**
 * Implement packet query
 * @param argc   - 0
 * @param argv   -
 * @param retVal - <return code>
 * @param retLen - length of
 * @return       - 0 on success negative return code otherwise
 */
int dbe_packet_get(int argc, void **argv, void **retVal, int *retLen)
{
  int dpofst = 32, dfofst = 8, len = 5008, psn_mode = 1, psnofst = 4;
  // initialize variables
  *retLen = 0;

  int fpga_drs_get_packet(int* dpOffset);

  sprintf(*retVal,"!dbe_packet?%d:%d:%d:%d:%d:%d;\n",
	  VSIS_RET_SUCCESS,
	  dpofst,
	  dfofst,
	  len,
	  psn_mode,
	  psnofst);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS;
}

/**
 * Definition of the dbe_packet_get query
 */
void insert_dbe_packet_get(void)
{
  char *name = "dbe_packet";
  char *usage= "dbe_packet ? ;";
  int nParams = 0;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[0] = {};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_packet_get, cmdType);
}

enum DataSendQualificationType
{
  DATA_SEND_ARG_START_END_QUALIFIED,
  DATA_SEND_ARG_START_DELTA_QUALIFED,
  DATA_SEND_ARG_ONLY_START_QUALIFIED,
  DATA_SEND_ARG_NOT_DEF
};


/*
 * input time: time in BCD to verify.
 * input ops: specify if it is an addition or substruction
 */
void validateBCD(unsigned long * time, int ops)
{
  int i;
  int adjuster = 0;
  
  for(i=0; i<8; i++)
    {
      if (((*time & (0xF << (i<<2))) >> (i<<2)) > 9)
	adjuster |= 6<<(i<<2);
    }

  if (adjuster)
    {
      if (ops)
	*time += adjuster;
      else
	*time -= adjuster;
      
      validateBCD(time, ops);
    }
}

/**
 * Implement data send command
 * @param argc   - 4
 * @param argv   - <state>:<ts>[:<te>][:<delta>]
 * @param retVal - <return code>
 * @param retLen - length of
 * @return       - 0 on success negative return code otherwise
 */
int dbe_data_send_set(int argc, void **argv, void **retVal, int *retLen)
{
  char * state = (char *)NULL;
  char * ts = (char *)NULL;
  char * te = (char *)NULL;
  unsigned long delta = 1;
  unsigned char def = 0;

  int retCode;

  unsigned long tOn = 0;
  unsigned long tOff = 0;
  const unsigned slotNo = 1;

  enum DataSendActionType act = DBE_DATA_SEND_UNKOWN;
  // initialize variables
  *retLen = 0;

  state = (char *)argv[0];
  ts = (char *)argv[1];
  te = (char *)argv[2];

  if (state)
    {
      if (0 == strcmp(state, "on"))
	act = DBE_DATA_SEND_ON;
      else if (0 == strcmp(state, "off"))
	act = DBE_DATA_SEND_OFF;
      else if (0 == strcmp(state, "enable"))
	act = DBE_DATA_SEND_ENABLE;
      else if (0 == strcmp(state, "disable"))
	act = DBE_DATA_SEND_DISABLE;
    }
  else
    {
      sprintf(*retVal, "!dbe_data_send=%d;\n", VSIS_RET_PARAMETER_ERROR);
      *retLen = strlen(*retVal);
      return -VSIS_RET_PARAMETER_ERROR;
    }

  if (DBE_DATA_SEND_UNKOWN == act)
    {
      sprintf(*retVal, "!dbe_data_send=%d;\n", VSIS_RET_PARAMETER_ERROR);
      *retLen = strlen(*retVal);
      return -VSIS_RET_PARAMETER_ERROR;
    }

  if ((DBE_DATA_SEND_ON == act) ||
      (DBE_DATA_SEND_OFF == act))
    {
      /* this is the only case these are needed */
      if (argv[3])
	{
	  delta = (unsigned long)atoi(argv[3]);
	  def |= 0x1;
	}
      /* now make sure we got valid start time and end time */
      if (DBE_DATA_SEND_ON == act)
	{
	  if (ts)
	    {
	      if (string2JD(ts, &tOn))
		{
		  sprintf(*retVal,"!dbe_data_send?%d;\n", VSIS_RET_PARAMETER_ERROR);
		  *retLen = strlen(*retVal);
		  return -VSIS_RET_PARAMETER_ERROR; /*error */
		}
	      def |= 0x4;
	    }
	  else
	    {
	      sprintf(*retVal, "!dbe_data_send=%d;\n", VSIS_RET_PARAMETER_ERROR);
	      *retLen = strlen(*retVal);
	      return -VSIS_RET_PARAMETER_ERROR;
	    }
	}
      if (te)
	{
	  if (string2JD(te, &tOff))
	    {
	      sprintf(*retVal,"!dbe_data_send?%d;\n", VSIS_RET_PARAMETER_ERROR);
	      *retLen = strlen(*retVal);
	      return -VSIS_RET_PARAMETER_ERROR; /*error */
	    }

	  /* make sure that en time is greater than start time. Only for ON */
	  if ((DBE_DATA_SEND_ON == act) &&
	      (def & 0x4) &&
	      (tOff < tOn))
	    {
	      sprintf(*retVal,"!dbe_data_send?%d;\n", VSIS_RET_PARAMETER_ERROR);
	      *retLen = strlen(*retVal);
	      return -VSIS_RET_PARAMETER_ERROR; /*error */
	    }
	  def |= 0x2;
	}

    } // if (DBE_DATA_SEND_ON == act...

  switch(act)
    {
    case DBE_DATA_SEND_ON:
      switch(def)
	{
	  // case 0x0 does not make till here.
	case 0x1:
	  /* only delta set, is it useful? */
	  /* for this to work we should let through the above condition */
	  fpga_get_dot(&tOn);
	  LongToBcd(&delta);
	  tOff = tOn + delta;
	  validateBCD(&tOff, 1);
	  break;
	case 0x2:
	  /* only time end is set. Compute now time as start time */
	  fpga_get_dot(&tOn);
	  break;
	case 0x3:
	  /* end time & delta set. maybe we need to compute the start time */
	  /* for this to work we should let through the above condition */
	  LongToBcd(&delta);
	  tOn = tOff - delta;
	  validateBCD(&tOff, 0);
	  break;
	case 0x4:
	  /* only start time is defined. Set end time to -1 */
	  tOff = -1;
	  break;
	case 0x5:
	  /* start time and delta are provided */
	  LongToBcd(&delta);
	  tOff = tOn + delta;
	  validateBCD(&tOff, 1);
	  break;
	case 0x6:
	  /* start time and end time are defined. Already computed above. Nothing to do. */
	case 0x7:
	  /* start time, end time and delta are defined. I guess delta is useless */
	  /* Nothing to do let it fall through */
	  break;
	default:
	  break;
	} // switch(def...

      retCode = fpga_dtm_set_timeslot(slotNo, tOn, tOff);
      if (!retCode)
	{
	  sprintf(*retVal,"!dbe_data_send=%d;\n", VSIS_RET_SUCCESS);
	  *retLen = strlen(*retVal);
	  return VSIS_RET_SUCCESS;
	}
      else
	{
	  sprintf(*retVal,"!dbe_data_send=%d;\n", VSIS_RET_EXECUTION_ERROR);
	  *retLen = strlen(*retVal);
	  return -VSIS_RET_EXECUTION_ERROR;
	}
      break;
    case DBE_DATA_SEND_OFF:
      switch (def)
	{
	case 0x0:
	  /* no inpout defined. tOff is already set to 0. Nothing to be done. */
	  break;
	case 0x1:
	  /* tOff will be equal now + delta */
	  fpga_get_dot(&tOn);
	  LongToBcd(&delta);
	  tOff = tOn + delta;
	  validateBCD(&tOff, 1);
	  break;
	case 0x2:
	  /* end time given, pass it along. */
	  break;
	default:
	  break;
	} // switch(def...
      retCode = fpga_dtm_set_timeslot_end(slotNo, tOff);
      if (!retCode)
	{
	  sprintf(*retVal,"!dbe_data_send=%d;\n", VSIS_RET_SUCCESS);
	  *retLen = strlen(*retVal);
	  return VSIS_RET_SUCCESS;
	}
      else
	{
	  sprintf(*retVal,"!dbe_data_send=%d;\n", VSIS_RET_EXECUTION_ERROR);
	  *retLen = strlen(*retVal);
	  return -VSIS_RET_EXECUTION_ERROR;
	}
      break;
    case DBE_DATA_SEND_ENABLE:
      retCode = fpga_dtm_set_control(1);
      if (!retCode)
	{
	  sprintf(*retVal,"!dbe_data_send=%d;\n", VSIS_RET_SUCCESS);
	  *retLen = strlen(*retVal);
	  return VSIS_RET_SUCCESS;
	}
      else
	{
	  sprintf(*retVal,"!dbe_data_send=%d;\n", VSIS_RET_EXECUTION_ERROR);
	  *retLen = strlen(*retVal);
	  return -VSIS_RET_EXECUTION_ERROR;
	}
      break;
    case DBE_DATA_SEND_DISABLE:
      retCode = fpga_dtm_set_control(0);
      if (!retCode)
	{
	  sprintf(*retVal,"!dbe_data_send=%d;\n", VSIS_RET_SUCCESS);
	  *retLen = strlen(*retVal);
	  return VSIS_RET_SUCCESS;
	}
      else
	{
	  sprintf(*retVal,"!dbe_data_send=%d;\n", VSIS_RET_EXECUTION_ERROR);
	  *retLen = strlen(*retVal);
	  return -VSIS_RET_EXECUTION_ERROR;
	}
      break;
    case DBE_DATA_SEND_UNKOWN:
      break;
    default:
      break;
    } // switch(act....
  return retCode;
}

/**
 * Definition of the data_send_set command
 */
void insert_dbe_data_send_set(void)
{
  char *name = "dbe_data_send";
  char *usage= "dbe_data_send = <state>:<TS>[:<TE>][:<delta>];";
  int nParams = 4;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[4] = {CMD_PARAM_STRING,CMD_PARAM_TIME,CMD_PARAM_TIME,CMD_PARAM_TIME };
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_data_send_set, cmdType);
}


/**
 * Implement data xfer query
 * @param argc   - 0
 * @param argv   -
 * @param retVal - <return code>
 * @param retLen - length of
 * @return       - 0 on success negative return code otherwise
 */
int dbe_data_send_get(int argc, void **argv, void **retVal, int *retLen)
{
  unsigned short ctl;
  char state[10];
  char error_str[50];
  int retCode;

  char dot_str_time[14] = {};
  char s_str_time[14] = {};
  char e_str_time[14] = {};

  unsigned long dotTime = 0;
  unsigned long tOn = 0;
  unsigned long tOff = 0;

  const unsigned slotNo = 1;

  // initialize variables
  memset(state, '\0', 10 * sizeof(char));
  memset(error_str, '\0', 50 * sizeof(char));

  *retLen = 0;

  retCode = fpga_dtm_get_status(&ctl);
  if (!retCode)
    {
      ctl &= 0x3;

      switch(ctl)
	{
	case 0:
	  sprintf(state, "off");
	  break;
	case 1:
	  sprintf(state, "on");
	  break;	
	case 2:
	  sprintf(state, "waiting");
	  break;
	case 3:
	  sprintf(state, "disabled");
	  break;
	default:
	  sprintf(state, "unkown");
	  break;
	}
    }
  else
    {
      sprintf(*retVal,"!dbe_data_send?%d;\n", VSIS_RET_EXECUTION_ERROR);
      *retLen = strlen(*retVal);
      return -VSIS_RET_EXECUTION_ERROR;
    }

  retCode = fpga_get_dot(&dotTime);
  retCode = fpga_dtm_get_timeslot(slotNo, &tOn, &tOff);
  if (retCode)
    {
      sprintf(*retVal,"!dbe_data_send?%d;\n", VSIS_RET_EXECUTION_ERROR);
      *retLen = strlen(*retVal);
      return -VSIS_RET_EXECUTION_ERROR;
    }

  /* process the DOT */
  Bcd2Human(dotTime, dot_str_time, 0);
  Bcd2Human(tOn, s_str_time, 0);
  Bcd2Human(tOff, e_str_time, 0);

  sprintf(*retVal, "!dbe_data_send?%d:%s:%s:%s:%s:%s;\n", 
	  retCode, state, 
	  s_str_time, e_str_time, dot_str_time, error_str);

  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS;
}

/**
 * Definition of the data_send_get query
 */
void insert_dbe_data_send_get(void)
{
  char *name = "dbe_data_send";
  char *usage= "dbe_data_send ? ;";
  int nParams = 0;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[0] = {};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_data_send_get, cmdType);
}

/*
 * *************************************************************************************************
 *  New Commands
 * *************************************************************************************************
 */

/**
 * Set dbe reset
 * @param argc   - 1
 * @param argv   - <time>
 * @param retVal - <return code>
 * @param retLen - length of
 * @return       - 0 on success negative return code otherwise
 */
int dbe_reset_set(int argc, void **argv, void **retVal, int *retLen)
{
    // initialize variables
    int retCode = -1;

    // seconds before system reboot
    int secs = (int)*(long int*) argv[0];

    *retLen = 0;

    // send back a reply and reboot
    sprintf(*retVal, "!dbe_reset=%d;\n", retCode);
    //sleep(secs);
    //system("reboot");
    sprintf(*retVal, "shutdown -r -t %d \n", secs);
    system(*retVal);
    system("PAUSE");
    *retLen = strlen(*retVal);
    return retCode;
}

/**
 * Definition of the dbe_reset set command
 */
void insert_dbe_reset_set(void)
{
  char *name = "dbe_reset";
  char *usage= "dbe_reset = <size>;";
  int nParams = 1;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[1] = {CMD_PARAM_STRING};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_reset_set, cmdType);
}

/**
 * Implement quantize seed command
 * @param argc   - 1
 * @param argv   - <seed>
 * @param retVal - <return code>
 * @param retLen - length of
 * @return       - 0 on success negative return code otherwise
 */
int dbe_ddc_quantize_set(int argc, void **argv, void **retVal, int *retLen)
{
  int channel = 0;
  short plus_thresh = 120;
  short zero_thresh = 0;
  short minus_thresh = -120;
  int retCode;

  // initialize variables  
  *retLen = 0;
  if (argv[0])
    channel = (int)*(long int*) argv[0];

  if (argv[1])
    plus_thresh = (short)*(long int*) argv[1];

  if (argv[2])
    zero_thresh = (short)*(long int*) argv[2];

  if (argv[3])
    minus_thresh = (short)*(long int*) argv[3];

#if 0
  if (((channel <0) || (channel > 7)) ||
      (plus_thresh < 0) ||
      (minus_thresh > 0) ||
      (zero_thresh < 0))
#endif
  if ((channel <0) || (channel > 7))
    {
      sprintf(*retVal,"!dbe_ddc_quantize=%d:parameter error;\n", VSIS_RET_PARAMETER_ERROR);
      *retLen = strlen(*retVal);
      return VSIS_RET_PARAMETER_ERROR;
    }

  retCode = fpga_ddc_qt_set_threshold_plus(channel, plus_thresh);
  retCode = fpga_ddc_qt_set_threshold_minus(channel, minus_thresh);
  retCode = fpga_ddc_qt_set_threshold_zero(channel, zero_thresh);


  sprintf(*retVal,"!dbe_ddc_quantize=%d;\n", VSIS_RET_SUCCESS);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS;
}

/**
 * Definition of the dbe_quantize_set command
 */
void insert_dbe_ddc_quantize_set(void)
{
  char *name = "dbe_ddc_quantize";
  char *usage= "dbe_ddc_quantize = [<channel>]:<+thresh>:<zthresh><-thresh>;";
  int nParams = 4;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[4] = {CMD_PARAM_INTEGER, CMD_PARAM_INTEGER, CMD_PARAM_INTEGER, CMD_PARAM_INTEGER};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_ddc_quantize_set, cmdType);
}

int dbe_ddc_quantize_hold_set(int argc, void **argv, void **retVal, int *retLen)
{
  short hold = 1;
  int retCode;

  // initialize variables  
  *retLen = 0;
  if (argv[0])
    hold = (short)*(long int*) argv[0];

  hold &= 0x1;
  retCode = fpga_ddc_qt_set_hold(hold);
  
  sprintf(*retVal,"!dbe_ddc_quantize_hold=%d;\n", VSIS_RET_SUCCESS);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS;
}

void insert_dbe_ddc_quantize_hold_set(void)
{
  char *name = "dbe_ddc_quantize_hold";
  char *usage= "dbe_ddc_quantize = <hold>;";
  int nParams = 1;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[1] = {CMD_PARAM_UNSIGNEDLONG};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_ddc_quantize_hold_set, cmdType);
}

int dbe_ddc_quantize_hold_get(int argc, void **argv, void **retVal, int *retLen)
{
  int retCode;
  short hold_stat;

  // initialize variables  
  *retLen = 0;

  retCode = fpga_ddc_qt_get_hold(&hold_stat);
  
  sprintf(*retVal,"!dbe_ddc_quantize_hold=%d:%d;\n", VSIS_RET_SUCCESS, hold_stat);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS;
}

void insert_dbe_ddc_quantize_hold_get(void)
{
  char *name = "dbe_ddc_quantize_hold";
  char *usage= "dbe_ddc_quantize?;";
  int nParams = 0;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[0] = {};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_ddc_quantize_hold_get, cmdType);
}

typedef struct
{
  double thres_plus, thres_minus, gain;
  unsigned short state_count;
} QUANTIZE_DATA_STRUCT;


enum ArgQualficationType
{
  ARG_NOT_QUALIFIED,
  ARG_PARTIAL_1_QUALIFIED,
  ARG_PARTIAL_2_QUALIFIED,
  ARG_FULLY_QUALIFIED
};


int vout(char * str, char *fmt, ...)
{
  va_list arg_ptr;
  int outbytes;

  va_start(arg_ptr, fmt);
  outbytes = vsprintf(str, fmt, arg_ptr);
  va_end(arg_ptr);

  return outbytes;
}


/**
 * Definition of the dbe_quantize_set command
 */

int dbe_quantize_set(int argc, void **argv, void **retVal, int *retLen)
{
  // initialize variables
  int retCode = -1;
  int ret;

  unsigned char reset_qt = 0;

  *retLen = 0;
  
  if (argv[0])
    {
      /* this got to be the synchronize pps */
      if (0 == strcasecmp(argv[0], "hold_set"))
	reset_qt = 0;
      else if (0 == strcasecmp(argv[0], "reset"))
	reset_qt = 1;
      else
	{
	  sprintf(*retVal,"!dbe_quantize?%d:need a valid state (reset, hold_set) for requantizing;\n", VSIS_RET_PARAMETER_ERROR);
	  *retLen = strlen(*retVal);
	  return -VSIS_RET_PARAMETER_ERROR;
	}
    }

  if(reset_qt)
    {
    retCode = fpga_qt_set_initial();
    }
  else
    {
      retCode = fpga_qt_set_requantize();
    }
  //retCode = fpga_qt_set(reset_qt);
  retCode = 0;
  if (!retCode)
    {
      sprintf(*retVal,"!dbe_quantize:%d;\n", VSIS_RET_SUCCESS);
      ret = VSIS_RET_SUCCESS;
    }
  else
    {
      sprintf(*retVal,"!dbe_quantize:%d:%d;\n",VSIS_RET_EXECUTION_ERROR, retCode);
      ret = VSIS_RET_EXECUTION_ERROR;
    }
 
   *retLen = strlen(*retVal);
   return ret;
}

/**
 * Definition of the dbe_quantize_set command
 */
void insert_dbe_quantize_set(void)
{
  char *name = "dbe_quantize";
  char *usage= "dbe_quantize = <state>;";
  int nParams = 1;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[1] = {CMD_PARAM_STRING};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_quantize_set, cmdType);
}

/**
 * Implement quantize seed query
 * @param argc   - 1
 * @param argv   - <channel>
 * @param retVal - <return code>
 * @param retLen - length of
 * @return       - 0 on success negative return code otherwise
 */
int dbe_quantize_get(int argc, void **argv, void **retVal, int *retLen)
{
  QUANTIZE_DATA_STRUCT qt_data[MAX_IFS][MAX_CHANNELS];
  int intFreq, channel;
  int retCode = -1;

  long int thres_plus, thres_minus, gain;
  double qt_thres_plus, qt_thres_minus, qt_gain;
  short qt_state_count;

  enum ArgQualficationType qual = ARG_NOT_QUALIFIED;

  int outbytes = 0;

  const unsigned nbits = 25, dotpos = 17;
  const unsigned printBits=8, printDot=5;

  char format[64];

  // initialize variables
  *retLen = 0;
  memset(qt_data, 0, MAX_IFS * MAX_CHANNELS *sizeof(QUANTIZE_DATA_STRUCT));

  memset(format, '\0', 64 * sizeof(char));
  sprintf(format, "%%d:%%d:%%%d.%df:%%%d.%df:%%%d.%df:%%d:",
	  printBits, printDot,
	  printBits, printDot,
	  printBits, printDot);

  if (argv[0] && argv[1])
    {
      qual = ARG_FULLY_QUALIFIED;
      // get the parameters
      intFreq  = (int)*(unsigned long *)argv[0];
      channel = (int)* (unsigned long *)argv[1];
    }
  else if (argv[0])
    {
      qual = ARG_PARTIAL_1_QUALIFIED;
      intFreq  = (int)*(unsigned long *)argv[0];
    }
  else if (argv[1])
    {
      qual = ARG_PARTIAL_2_QUALIFIED;
      channel = (int)* (unsigned long *)argv[1];
    }

  switch(qual)
    {
    case ARG_FULLY_QUALIFIED:
      *retLen = 0;

      // get the parameters
      if ((intFreq > MAX_IFS) || (channel > MAX_CHANNELS))
	{
	  sprintf(*retVal,"!dbe_quantize?%d:parameter error;\n", VSIS_RET_PARAMETER_ERROR);
	  *retLen = strlen(*retVal);
	  return -VSIS_RET_PARAMETER_ERROR; /*error */
	}

      outbytes = sprintf(*retVal, "!dbe_quantize?%d:", 0);

      retCode = fpga_qt_get_threshold_plus(intFreq, channel, &thres_plus);
      if (!retCode)
	{
	  lsb_pad_frac2dbl(&qt_thres_plus, thres_plus, nbits, dotpos);
	  retCode = fpga_qt_get_threshold_minus(intFreq, channel, &thres_minus);
	  if (!retCode)
	    {
	      lsb_pad_frac2dbl(&qt_thres_minus, thres_minus, nbits, dotpos);
	      retCode = fpga_qt_get_bit_state_count(intFreq, channel, (unsigned short *)&qt_state_count);
	      if (!retCode)
		{
		  retCode = fpga_qt_get_gain(intFreq, channel, &gain);
		  if (!retCode)
		    {
		      lsb_pad_frac2dbl(&qt_gain, gain, nbits, dotpos);
		      outbytes += vout(*retVal + outbytes, format,
				      intFreq, channel,
				      qt_thres_plus,
				      qt_thres_minus,
				      qt_gain,
				      qt_state_count);
		    }

		}
	    }
	}
      break;

    case ARG_NOT_QUALIFIED:
      outbytes = sprintf(*retVal, "!dbe_quantize?%d:", 0);

      for (intFreq=0; intFreq<MAX_IFS; intFreq++)
	{
	  for (channel=0; channel<MAX_CHANNELS; channel++)
	    {
	      retCode = fpga_qt_get_threshold_plus(intFreq, channel, &thres_plus);
	      if (!retCode)
		{
	      lsb_pad_frac2dbl(&qt_data[intFreq][channel].thres_plus, thres_plus, nbits, dotpos);
		  retCode = fpga_qt_get_threshold_minus(intFreq, channel, &thres_minus);
		  if (!retCode)
		    {
		      lsb_pad_frac2dbl(&qt_data[intFreq][channel].thres_minus, thres_minus, nbits, dotpos);
		      retCode = fpga_qt_get_bit_state_count(intFreq, channel,
							    (unsigned short *)&qt_data[intFreq][channel].state_count);
		      if (!retCode)
			{
			  retCode = fpga_qt_get_gain(intFreq, channel, &gain);
			  if (!retCode)
			    {
			      lsb_pad_frac2dbl(&qt_data[intFreq][channel].gain, gain, nbits, dotpos);
			      outbytes += vout(*retVal+outbytes, format,
					       intFreq,
					       channel,
					       qt_data[intFreq][channel].thres_plus,
					       qt_data[intFreq][channel].thres_minus,
					       qt_data[intFreq][channel].gain,
					       qt_data[intFreq][channel].state_count);
			    }
			}
		    }
		}
	    }
	}
      break;

    case ARG_PARTIAL_1_QUALIFIED:
      *retLen = 0;

      if (intFreq > MAX_IFS)
	{
	  sprintf(*retVal,"!dbe_quantize?%d:parameter error;\n", VSIS_RET_PARAMETER_ERROR);
	  *retLen = strlen(*retVal);
	  return -VSIS_RET_PARAMETER_ERROR; /*error */
	}

      outbytes = sprintf(*retVal, "!dbe_quantize?%d:", 0);

      /* only IF provided */
      for (channel=0; channel<MAX_CHANNELS; channel++)
	{
	  retCode = fpga_qt_get_threshold_plus(intFreq, channel, &thres_plus);
	  if (!retCode)
	    {
	      lsb_pad_frac2dbl(&qt_data[intFreq][channel].thres_plus, thres_plus, nbits, dotpos);
	      retCode = fpga_qt_get_threshold_minus(intFreq, channel, &thres_minus);
	      if (!retCode)
		{
	    	  lsb_pad_frac2dbl(&qt_data[intFreq][channel].thres_minus, thres_minus, nbits, dotpos);
		  retCode = fpga_qt_get_bit_state_count(intFreq, channel,
							(unsigned short *)&qt_data[intFreq][channel].state_count);
		  if (!retCode)
		    {
		      retCode = fpga_qt_get_gain(intFreq, channel, &gain);
		      if (!retCode)
			{
		    	  lsb_pad_frac2dbl(&qt_data[intFreq][channel].gain, gain, nbits, dotpos);
			  outbytes +=vout(*retVal+outbytes, format,
					  intFreq,
					  channel,
					  qt_data[intFreq][channel].thres_plus,
					  qt_data[intFreq][channel].thres_minus,
					  qt_data[intFreq][channel].gain,
					  qt_data[intFreq][channel].state_count);
			}
		    }
		}
	    }
	}
      break;

    case ARG_PARTIAL_2_QUALIFIED:

      if (channel > MAX_CHANNELS)
	{
	  sprintf(*retVal,"!dbe_quantize?%d:parameter error;\n", VSIS_RET_PARAMETER_ERROR);
	  *retLen = strlen(*retVal);
	  return -VSIS_RET_PARAMETER_ERROR; /*error */
	}

      outbytes = sprintf(*retVal, "!dbe_quantize?%d:", 0);

      *retLen = 0;
      /* only channel provided */
      for (intFreq=0; intFreq<MAX_IFS; intFreq++)
	{
	  retCode = fpga_qt_get_threshold_plus(intFreq, channel, &thres_plus);
	  if (!retCode)
	    {
	      lsb_pad_frac2dbl(&qt_data[intFreq][channel].thres_plus, thres_plus, nbits, dotpos);
	      retCode = fpga_qt_get_threshold_minus(intFreq, channel, &thres_minus);
	      if (!retCode)
		{
	    	  lsb_pad_frac2dbl(&qt_data[intFreq][channel].thres_minus, thres_minus, nbits, dotpos);
		  retCode = fpga_qt_get_bit_state_count(intFreq, channel,
							(unsigned short *)&qt_data[intFreq][channel].state_count);
		  if (!retCode)
		    {
		      retCode = fpga_qt_get_gain(intFreq, channel, &gain);
		      if (!retCode)
			{
		    	  lsb_pad_frac2dbl(&qt_data[intFreq][channel].gain, gain, nbits, dotpos);
			  outbytes += vout(*retVal + outbytes, format,
					   intFreq,
					   channel,
					   qt_data[intFreq][channel].thres_plus,
					   qt_data[intFreq][channel].thres_minus,
					   qt_data[intFreq][channel].gain,
					   qt_data[intFreq][channel].state_count);
			}
		    }
		}
	    }
	}
      break;
    default:
      break;
    }

  if (!retCode)
    sprintf(*retVal+outbytes-1, ";\n");
  else
    {
      memset(*retVal, '\0', RESP_BUF_SIZE*sizeof(char));
      sprintf(*retVal, "!dbe_quantize?%d;\n", VSIS_RET_EXECUTION_ERROR);
      retCode = -VSIS_RET_EXECUTION_ERROR;
    }
  *retLen = strlen(*retVal);
  return retCode;
}

/**
 * Definition of the dbe_quantize_get command
 */
void insert_dbe_quantize_get(void)
{
  char *name = "dbe_quantize";
  char *usage= "dbe_quantize?:[if]:[channel];";
  int nParams = 2;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[2] = {CMD_PARAM_UNSIGNEDLONG, CMD_PARAM_UNSIGNEDLONG};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_quantize_get, cmdType);
}

int dbe_ddc_quantize_get(int argc, void **argv, void **retVal, int *retLen)
{
  int channel = 0;
  int retCode = -1;

  short thresh_plus = 0, thresh_minus = 0, thresh_zero = 0;

  unsigned short lo_count00 = 0, lo_count01 = 0, lo_count10 = 0, lo_count11 = 0;
  unsigned short hi_count00 = 0, hi_count01 = 0, hi_count10 = 0, hi_count11 = 0;

  *retLen = 0;

  if (argv[0])
    channel = (int)*(long int*) argv[0];

  if ((channel <0) || (channel > 7))
    {
      sprintf(*retVal,"!dbe_ddc_quantize?%d:parameter error;\n", VSIS_RET_PARAMETER_ERROR);
      *retLen = strlen(*retVal);
      return VSIS_RET_PARAMETER_ERROR;
    }

  /* hold the data first */
  /* retCode = fpga_ddc_qt_set_hold(1); */

  retCode = fpga_ddc_qt_get_count_lo_state00(channel, (unsigned short*)&lo_count00);
  retCode = fpga_ddc_qt_get_count_lo_state01(channel, (unsigned short*)&lo_count01);
  retCode = fpga_ddc_qt_get_count_lo_state10(channel, (unsigned short*)&lo_count10);
  retCode = fpga_ddc_qt_get_count_lo_state11(channel, (unsigned short*)&lo_count11);
  
  retCode = fpga_ddc_qt_get_count_hi_state00(channel, (unsigned short*)&hi_count00);
  retCode = fpga_ddc_qt_get_count_hi_state01(channel, (unsigned short*)&hi_count01);
  retCode = fpga_ddc_qt_get_count_hi_state10(channel, (unsigned short*)&hi_count10);
  retCode = fpga_ddc_qt_get_count_hi_state11(channel, (unsigned short*)&hi_count11);

  retCode = fpga_ddc_qt_get_threshold_plus(channel, (short*)&thresh_plus);
  retCode = fpga_ddc_qt_get_threshold_minus(channel, (short*)&thresh_minus);
  retCode = fpga_ddc_qt_get_threshold_zero(channel, (short*)&thresh_zero);

  /* release the hold register */
  /* retCode = fpga_ddc_qt_set_hold(0); */

  sprintf(*retVal, "!dbe_ddc_quantize?%d:%d:%u:%u:%u:%u:%d:%d:%d;\n",
	  VSIS_RET_SUCCESS,
	  channel,
	  ((unsigned int)(hi_count00 << 16)) | lo_count00,
	  ((unsigned int)(hi_count01 << 16)) | lo_count01,
	  ((unsigned int)(hi_count10 << 16)) | lo_count10,
	  ((unsigned int)(hi_count11 << 16)) | lo_count11,
	  thresh_plus,
	  thresh_minus,
	  thresh_zero);

  *retLen = strlen(*retVal);
  return retCode;  
}

void insert_dbe_ddc_quantize_get(void)
{
  char *name = "dbe_ddc_quantize";
  char *usage= "dbe_ddc_quantize?:[channel];";
  int nParams = 1;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[1] = {CMD_PARAM_UNSIGNEDLONG};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_ddc_quantize_get, cmdType);
}


/**
 * Implement quantize seed command
 * @param argc   - 1
 * @param argv   - <seed>
 * @param retVal - <return code>
 * @param retLen - length of
 * @return       - 0 on success negative return code otherwise
 */
int dbe_opt_level_set(int argc, void **argv, void **retVal, int *retLen)
{
  // initialize variables
  *retLen = 0;
  sprintf(*retVal,"!dbe_opt_level=%d:Not Implemented;\n", VSIS_RET_NOT_IMPLEMENTED);
  *retLen = strlen(*retVal);
  return -VSIS_RET_NOT_IMPLEMENTED;
}

/**
 * Definition of the dbe_quantize_set command
 */
void insert_dbe_opt_level_set(void)
{
  char *name = "dbe_opt_level";
  char *usage= "dbe_opt_level = <if>:<low>:<mid>:<high>;";
  int nParams = 1;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[1] = {CMD_PARAM_UNSIGNEDLONG };
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_opt_level_set, cmdType);
}

/**
 * Implement quantize seed query
 * @param argc   - 1
 * @param argv   - <channel>
 * @param retVal - <return code>
 * @param retLen - length of
 * @return       - 0 on success negative return code otherwise
 */
int dbe_opt_level_get(int argc, void **argv, void **retVal, int *retLen)
{
  // initialize variables
  *retLen = 0;
  sprintf(*retVal,"!dbe_opt_level?%d:Not Implemented;\n", VSIS_RET_NOT_IMPLEMENTED);
  *retLen = strlen(*retVal);
  return -VSIS_RET_NOT_IMPLEMENTED;
}

/**
 * Definition of the dbe_quantize_sgt command
 */
void insert_dbe_opt_level_get(void)
{
  char *name = "dbe_opt_level";
  char *usage= "dbe_opt_level[<if>] ?;";
  int nParams = 1;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[1] = {CMD_PARAM_UNSIGNEDLONG };
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_opt_level_get, cmdType);
}


/**
 * Set dbe reset
 * @param argc   - 0
 * @param argv   -
 * @param retVal - <return code>
 * @param retLen - length of
 * @return       - 0 on success negative return code otherwise
 */

#if 0
int dbe_init_set(int argc, void **argv, void **retVal, int *retLen)
{
  // initialize variables
  int retCode = -1;

  *retLen = 0;

  // initialize memory
  retCode = hal_init();

  sprintf(*retVal,"!dbe_init=%d;\n", retCode);
  *retLen = strlen(*retVal);
  return retCode;
}
#endif

char respBuf[MAX_FILE_NAME_LEN];

int processCmd(char * cmdBuf)
{
  cmd_pkt_t *cmdPkt;
  int retVal;
  int   retLen;      // length of return buffer

  char * ret_ptr = (char *)NULL;
  int retCode = -1;
  char * resp;

  void * retBuf = &respBuf;

  /* Ask parser to build a command from the string */
  retVal = vsis_get_command(&cmdPkt, cmdBuf, strlen(cmdBuf));

  if(retVal == 0 && cmdPkt != 0)
    {  // parse OK, and cmdPkt exists
      memset(respBuf, '\0', MAX_FILE_NAME_LEN * sizeof(char));

#if DEBUG_VERBOSE
      printf("dbe_init: executing command %p\n", cmdPkt);
#endif
      retVal = cmd_execute_cmd(cmdPkt, &retBuf, &retLen);

      parser_free_cmd(cmdPkt);
      retCode = 0;
      resp = (char *)retBuf;
      if(resp[0])
	{
	  /* need to check the return value */
	  ret_ptr = strchr(resp, '=');
	  if ((char *)NULL != ret_ptr)
	    {
	      ret_ptr++;
	      if ('0' != *ret_ptr)
		{
		  /* there was an error. Abort! */
		  retCode = -1;
		}
	    }
	}
    }
  return retCode;
}

const char * startup_file_name = "/etc/default/rdbe/startup.conf";

int processAppStartupFile(void)
{
  int retCode = 0;

  FILE * startup_fp = (FILE *)NULL;
  char perso_path[MAX_FILE_NAME_LEN];

  char line[MAX_FILE_NAME_LEN];
  char * cmd_ptr;
  char * comment_ptr = (char *)NULL;

  int port, nconnx;
  int cntr = 0;

  startup_fp = fopen(startup_file_name, "r");
  if ((FILE *)NULL == startup_fp)
    {
      /* should we quit or what. */
    }

  memset(perso_path, '\0', MAX_FILE_NAME_LEN * sizeof(char));

  /* we found the file process the lines */
  while(1)
    {
      memset(line, '\0', MAX_FILE_NAME_LEN * sizeof(char));
      if ((char *)NULL == fgets(line, MAX_FILE_NAME_LEN, startup_fp))
	break;
      cntr++;
      cmd_ptr = line;
      /* first trim any blancs from the start */
      while(' ' == *cmd_ptr) cmd_ptr++;
      /* look for port commands */
      if (0 == strncasecmp(cmd_ptr, "port=", 5))
	{
	  /* grab the port number */
	  sscanf(cmd_ptr, "port=%d", &port);
	  continue;
	}
      /* look for the number of connections */
      if (0 == strncasecmp(cmd_ptr, "connections=", 12))
	{
	  /* grab the number of allowed connections */
	  sscanf(cmd_ptr, "connections=%d", &nconnx);
	  continue;
	}

      /* look for the default path of personlity files */
      if (0 == strncasecmp(cmd_ptr, "personality path=", 17))
	{
	  /* grab the path for the personality files */
	  sscanf(cmd_ptr, "personality path=%s", perso_path);
	  /* set the global path used to in the load personality function */
	  continue;
	}
      /* we need to remove any comments from the line */
      comment_ptr = strchr(cmd_ptr, '#');

      if ((char *)NULL != comment_ptr)
	{
	  /* remove the comment */
	  memset(comment_ptr, '\0', (MAX_FILE_NAME_LEN - (comment_ptr -cmd_ptr)) * sizeof(char));
	}

      retCode = processCmd(cmd_ptr);
      if (retCode)
	{
	  /* there was an error. Abort! */
	  retCode = cntr;
	  break;
	}
    } /* while(1... */

  fclose(startup_fp);

  return retCode;
}

int processConfigFile(char * config_file_name)
{
  int retCode = 0;

  FILE * config_fp = (FILE *)NULL;

  float sleep_time = 0;

  char line[MAX_FILE_NAME_LEN];

  char * cmd_ptr;
  char * comment_ptr = (char *)NULL;

  
  config_fp = fopen(config_file_name, "r");
  if ((FILE *)NULL == config_fp)
    {
      /* should we revert to default file or return and error. */
      return -1;
    }

  /* we found the file process the lines */
  while(1)
    {
      memset(line, '\0', MAX_FILE_NAME_LEN * sizeof(char));
      if ((char *)NULL == fgets(line, MAX_FILE_NAME_LEN, config_fp))
	break;
      cmd_ptr = line;      
      /* first trim any blancs from the start */
      while(' ' == *cmd_ptr) cmd_ptr++;
      /* look for comments */
      if (0 == strncmp(cmd_ptr, "#", 1))
	{
	  /* comment, skip it */
	  continue;
	}
      /* look for sleep commands */
      if ((0 == strncasecmp(cmd_ptr, "usleep(", 7)) ||
	  (0 == strncasecmp(cmd_ptr, "sleep(", 6)))
	{
	  /* grab the sleep time */
	  if (0 == strncasecmp(cmd_ptr, "usleep(", 7))
	    sscanf(cmd_ptr, "usleep(%f)", &sleep_time);
	  else
	    sscanf(cmd_ptr, "sleep(%f)", &sleep_time);
	  /* sleep it ! */
	  usleep(sleep_time*1e5);
	  continue;
	}
      /* we need to remove any comments from the line */
      comment_ptr = strchr(cmd_ptr, '#');

      if ((char *)NULL != comment_ptr)
	{
	  /* remove the comment */
	  memset(comment_ptr, '\0', (MAX_FILE_NAME_LEN - (comment_ptr -cmd_ptr)) * sizeof(char));
	}

      /* does it have a ;\n? if no added it */
      comment_ptr = strchr(cmd_ptr, ';');
      if ((char *)NULL == comment_ptr)
	{
	  /* add a ";\n" */
	  strcat(cmd_ptr, ";\n");
	}

      retCode = processCmd(cmd_ptr);
      if (retCode)
	{
	  /* there was an error. Abort! */
	  break;
	}
    }

  fclose(config_fp);

  return retCode;
}

#if 1
int dbe_init_set(int argc, void **argv, void **retVal, int *retLen)
{
  // initialize variables
  int retCode = -1;

  *retLen = 0;

  /* process the config file and execute commands */
  retCode = processConfigFile("RoachVLBI2010_may18.conf");

  sprintf(*retVal,"!dbe_init=%d;\n", retCode);
  *retLen = strlen(*retVal);
  return retCode;
}
#endif
/*
 * This function will read the current settings for ifconfig state, arp setting
 * and ALC attenuation attenuation and solr mode. This needed to control access
 * to those resources.
 * this function is called in server_main in main() before accepting connections.
 * Also this function should be called every time dbe_init is called to accomodated
 * changes in formats, etc...
 */
int InitRdbeAppStat()
{
  int retCode = -1;
  unsigned port = 0;
  int pos;
  unsigned short state = 0;
  unsigned char mac[6];

  unsigned short att_cmd;

  /* TO DO: set the floating point formatting base on the personality from the config file */

  /* get the current status of the ALC settings */
  retCode = fpga_alc_get_control(&att_cmd);
  if (!retCode)
    {
      pre_if_cmd[0] = (att_cmd & 0xFF00) >> 8;
      pre_if_cmd[1] = att_cmd & 0xFF;
    }

  /* Initialize the if state for all the port */
  for (port=0; port<MAX_PORTS; port++)
    {
      /* get the status of the ifconfig up or down */
      retCode = fpga_10ge_get_phy_config(port, &state);
      if (!retCode)
	curIfStat[port] = state;
    }

  memset(ArpTable, 0, MAX_PORTS * MAX_IP_ENTRY * MAC_LEN * sizeof(char));

  /* initialize the ARP table for all the ports? */
  for (port=0; port<MAX_PORTS; port++)
    {
      for (pos=0; pos<MAX_IP_ENTRY; pos++)
	{
	  retCode = fpga_10ge_get_arp_value(port, pos, mac);
	  if (!retCode &&( (mac[0] | mac[1] | mac[2] | mac[3] | mac[4] | mac[5]) != 0x00 ))
	    {
	      /* add an entry into the table */
	      sprintf((char *)&ArpTable[port][pos],
		      "%d.%d.%d.%d.%d.%d",
		      mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
	    }
	}
    }
  return 0;
}

int Bcd2Human(unsigned long dotTime, char * str_time, int * offset)
{
  unsigned long secsInDay     = 0l;
  unsigned long timeInSeconds = 0l;
  unsigned long dayOfYear     = 0l;
  int hours   = 0;
  int minutes = 0;
  int seconds = 0;
  
  struct tm hoTime = {0};
  //struct timeval tv;
  time_t hoSecs;

  struct tm osTime = {0};
  time_t osSecs     = time(NULL);
  int a, y, m;
  int mjd_base_offset;
  int doy;

  unsigned long dotSecs  = 0;

  /* we need this to know what year we are in and to compute the mjd_base_offset */
  //gettimeofday(&tv, NULL);
  //localtime_r(&tv.tv_sec, &osTime);
  localtime_r(&osSecs, &osTime);

  // init to first day of this year at 00:00:00
  hoTime.tm_sec     = 0;
  hoTime.tm_min     = 0;
  hoTime.tm_hour    = 0;
  hoTime.tm_mday    = 1;
  hoTime.tm_year    = osTime.tm_year;
  hoTime.tm_wday    = 0;
  hoTime.tm_yday    = 0;
  hoTime.tm_isdst   = 0;
  
  // get seconds since first day of 1970
  hoSecs     = mktime(&hoTime);  
  // Extract seconds in the day and day of year in BCD 'JJJSSSSS'
  secsInDay = (dotTime)&(0x000FFFFF);
  /* --- this is the truncated modified julian date, still need to convert to day of year */
  dayOfYear = (int) ((dotTime >> 20)&(0x00000FFF));
  
  // Convert BCD to long
  BcdToLong(&secsInDay);
  BcdToLong(&dayOfYear);
  timeInSeconds = secsInDay;

  doy = (int)dayOfYear;

  a = (14 - (hoTime.tm_mon + 1))/12;

  y = 1900+hoTime.tm_year + 4800 - a;

  m = hoTime.tm_mon + (12 * a) - 2;

  mjd_base_offset = ((153 * m)+2)/5 + 365*y+ y/4 - y/100 + y/400 - 32045;
  
  mjd_base_offset %= 1000;
  
  doy -= mjd_base_offset;

  if (doy < 0)
    doy = 1000 + doy;

  // calculate the hour, minute, and second for the particular day of the year
  timeInSeconds = secsInDay;
  hours = (int) (timeInSeconds / 3600);
  //timeInSeconds = timeInSeconds - (hours * 3600);
  timeInSeconds = timeInSeconds % 3600;
  minutes = (int) (timeInSeconds / 60);
  //timeInSeconds = timeInSeconds - (minutes * 60);
  timeInSeconds = timeInSeconds % 60;
  seconds = (int) timeInSeconds;

  if (offset)
    {
      // calcuate the DOT difference
      dotSecs  = ((hoSecs + ((doy * 86400) + secsInDay)));
      //*offset = (dotSecs - tv.tv_sec);
      *offset = (dotSecs - osSecs);
      //printf("dotSecs: %ld, clock sec: %ld\n", dotSecs, tv.tv_sec);
    }
    
  sprintf(str_time, "%04d%03d%02d%02d%02d",1900+osTime.tm_year, (unsigned int)doy+1, hours, minutes, seconds);
  
  return 0;
}

int string2JD(char * str_time, unsigned long *bcdTimeCode)
{
  char  str_year[5] = {0}; // same as {'\0'} or NULL
  char  str_day[4]  = {0};
  char  str_hour[3] = {0};
  char  str_min[3]  = {0};
  char  str_sec[4]  = {0};
  int   year  = 1900;
  int   day   = 000;
  int   hour  = 00;
  int   min   = 00;
  int   sec   = 00;

  struct tm  tTime  = {0}; // extracted time to set 

  *bcdTimeCode = 0x0l;

  // pull the high order time from the incoming parameters
  strncpy(str_year, str_time+0,  4);
  strncpy(str_day,  str_time+4,  3);
  strncpy(str_hour, str_time+7,  2);
  strncpy(str_min,  str_time+9,  2);
  strncpy(str_sec,  str_time+11, 2);

  year = atoi(str_year);
  day  = atoi(str_day);
  hour = atoi(str_hour);
  min  = atoi(str_min);
  sec  = atoi(str_sec);

  if (year/4)
    {
      if (day > 366)
	return 1;
    }
  else
    if (day > 365)
      return 1;

  if ((hour > 24) ||
      (min > 59) ||
      (sec > 59))
    {
      return 1;
    }

  // parse the high order time
  tTime.tm_year  = year-1900;
  tTime.tm_yday  = day - 1;
  tTime.tm_hour  = hour;
  tTime.tm_min   = min;
  tTime.tm_sec   = sec;

  time2JD(&tTime, bcdTimeCode);
  
  return 0;
}


int time2JD(struct tm * tTime, unsigned long *bcdTimeCode)
{
  int juld;
  int tmjd; /* Julian day numbers */
  int nyr1;
  
  unsigned long secsOfDay   = 0x0l;
  unsigned long dayOfYear   = 0x0l;

  secsOfDay = (tTime->tm_hour*3600) + (tTime->tm_min*60) + (tTime->tm_sec);

#ifdef DEBUG_VERBOSE
  printf("\ntime2JD: Pre-LongTLongToBcd(&secsOfDay);oBCD secsOfDay=%lu (0x%08x) \n", secsOfDay, (unsigned int)secsOfDay);
#endif

  LongToBcd(&secsOfDay);

 
 nyr1 = tTime->tm_year + 1900 - 1;
 juld = tTime->tm_yday + 1+ 1721425 + nyr1 * 365 + nyr1 / 4 - nyr1 / 100 +  nyr1 / 400;

  tmjd = (juld - 1) % 1000; /* Today's equivalent mjd (3 digits) */
  dayOfYear = tmjd;  /* --- to keep miguels previous structure */

#ifdef DEBUG_VERBOSE
  printf("time2JD: Pre-LongToBCD dayOfYear=%lu (0x%08x) \n", dayOfYear, (unsigned int)dayOfYear);
#endif

  LongToBcd(&dayOfYear);

#ifdef DEBUG_VERBOSE
  printf("time2JD: Post-LongToBCD dayOfYear=%lu (0x%08x) \n", dayOfYear, (unsigned int)dayOfYear);
#endif

  // create BCD from time code
  *bcdTimeCode = (dayOfYear<<20)|(secsOfDay);

  return 0;
}

#define MAX_LEN             255

#define RAW_SAMPLES         8192
#define RAW_SAMPLES_MAX     4 * RAW_SAMPLES

#define RAW_CAPTURE_ADDR_1  (unsigned long)0xC00002
#define RAW_CAPTURE_ADDR_2  (unsigned long)0xC00004
#define RAW_CAPTURE_CMD     (unsigned long)0xC00000

unsigned char raw_samples[RAW_SAMPLES * 4];
unsigned char mib_raw_samples[RAW_SAMPLES * 4];

/*
 * Used to capture continueos data from the FPGA.
 * We will capture 8192 32 bits (4 bytes) data. 
 */

int grab_raw_data(int ifreq, unsigned char * buf)
{
  int i, j=0;
  unsigned short data;
  int retCode;
  int ifbit;
  
  ifbit = ifreq << 2;

  /* tell the FPGA to start collection */
  retCode = fpga_alc_capture_cmd(RAW_CAPTURE_CMD, 0x0001 | ifbit);

  /* sleep for 40 us. 1 ms should be plenty */
  usleep(1000);

  /* every read we get four bytes for 8192 reads */
  for(i=0; i<RAW_SAMPLES; i++)
    {      
      //retCode = fpga_alc_capture(RAW_CAPTURE_ADDR_1, &data);
      util_read_short_fpga(RAW_CAPTURE_ADDR_1, 1, &data);
      /* unpack the data */
      buf[j++] = data & 0xFF;
      buf[j++] = (data & 0xFF00) >> 8;

      //retCode = fpga_alc_capture(RAW_CAPTURE_ADDR_2, &data);
      util_read_short_fpga(RAW_CAPTURE_ADDR_2, 1, &data);
      /* unpack the data */
      buf[j++] = data & 0xFF;
      buf[j++] = (data & 0xFF00) >> 8;

      /* set read ACK */
      retCode = fpga_alc_capture_cmd(RAW_CAPTURE_CMD, 0x0003 | ifbit);

      /* clear read ACK */
      retCode = fpga_alc_capture_cmd(RAW_CAPTURE_CMD, 0x0001 | ifbit);
    }

  /* clear the start bit */
  retCode = fpga_alc_capture_cmd(RAW_CAPTURE_CMD, 0x0);

  return retCode;
}

/*
 * Modified version of grab_raw_data that reads only 8K of data.
 */

int bp_grab_raw_data(int ifreq, unsigned char * buf)
{
  int i, j=0;
  unsigned short data;
  int retCode;
  int ifbit;
  
  ifbit = ifreq << 2;

  /* tell the FPGA to start collection */
  retCode = fpga_alc_capture_cmd(RAW_CAPTURE_CMD, 0x0001 | ifbit);

  /* sleep for 40 us. 1 ms should be plenty */
  usleep(1000);

  /* every read we get four bytes for 2048 reads */
  for(i=0; i<2048; i++)
    {      
      //retCode = fpga_alc_capture(RAW_CAPTURE_ADDR_1, &data);
      util_read_short_fpga(RAW_CAPTURE_ADDR_1, 1, &data);
      /* unpack the data */
      buf[j++] = data & 0xFF;
      buf[j++] = (data & 0xFF00) >> 8;

      //retCode = fpga_alc_capture(RAW_CAPTURE_ADDR_2, &data);
      util_read_short_fpga(RAW_CAPTURE_ADDR_2, 1, &data);
      /* unpack the data */
      buf[j++] = data & 0xFF;
      buf[j++] = (data & 0xFF00) >> 8;

      /* set read ACK */
      retCode = fpga_alc_capture_cmd(RAW_CAPTURE_CMD, 0x0003 | ifbit);

      /* clear read ACK */
      retCode = fpga_alc_capture_cmd(RAW_CAPTURE_CMD, 0x0001 | ifbit);
    }
  
  /* The FPGA expect 8192 ACK */
  for(i=2048; i<8192; i++)
    {
      /* set read ACK */
      retCode = fpga_alc_capture_cmd(RAW_CAPTURE_CMD, 0x0003 | ifbit);
      
      /* clear read ACK */
      retCode = fpga_alc_capture_cmd(RAW_CAPTURE_CMD, 0x0001 | ifbit);
    }

  /* clear the start bit */
  retCode = fpga_alc_capture_cmd(RAW_CAPTURE_CMD, 0x0);

  return retCode;
}

int dbe_raw_capture(int argc, void **argv, void **retVal, int *retLen)
{
  int j;

  FILE * fp_log = (FILE *)NULL;
  char filename[MAX_LEN];
  time_t now;
  struct tm ntm;

  int ifreq = 0;

  clock_t start;
  double duration;

  int retCode;

  char * usrfilename = (char *)NULL;

  now = time(NULL);
  gmtime_r(&now, &ntm);

  ntm.tm_year += 1900;
  ntm.tm_mon++;


  if (pthread_mutex_trylock(&mutexDataCollection))
    {
      sprintf(*retVal,"!dbe_raw_capture?%d:Operation in progress already!;\n", VSIS_RET_EXECUTION_ERROR);
      *retLen = strlen(*retVal);
      return -VSIS_RET_EXECUTION_ERROR;
    }

  if (argv[0]) /* if not defined use 0 as default */
    {
      ifreq = (int)*(unsigned long*)argv[0];
    }

  start = clock();

  retCode = grab_raw_data(ifreq, raw_samples);

  duration = ((double)(clock() - start)/CLOCKS_PER_SEC);

  printf("Raw Capture -- Time Elapsed: %f\n", duration);

  usrfilename = (char *)argv[1];
  
  memset(filename, 0x0, MAX_LEN);

  if (usrfilename)
    {
      sprintf(filename, "/home/roach/rdbe_sw/data_capture/%s", usrfilename);
    }
  else
    {
      sprintf(filename, "/home/roach/rdbe_sw/data_capture/raw_capture_%02d_%02d_%d_%02d_%02d_%02d.txt",
	      ntm.tm_mon,
	      ntm.tm_mday,
	      ntm.tm_year,
	      ntm.tm_hour,
	      ntm.tm_min,
	      ntm.tm_sec);
    }
  *retLen = 0;

  fp_log = fopen(filename, "w");

  if ((FILE *)NULL == fp_log)
    {
      sprintf(*retVal,"!dbe_raw_capture?%d:file open failed;\n", VSIS_RET_EXECUTION_ERROR);
      *retLen = strlen(*retVal);
      pthread_mutex_unlock(&mutexDataCollection);
      return -VSIS_RET_EXECUTION_ERROR;
    }

  for(j=0; j<RAW_SAMPLES_MAX; j++)
    {
      fprintf(fp_log, "%d\n", raw_samples[j]);
    }

  fflush(fp_log);
  fclose(fp_log);

  sprintf(*retVal,"!dbe_raw_capture?0:%f;\n", duration);
  *retLen = strlen(*retVal);
  pthread_mutex_unlock(&mutexDataCollection);
  return VSIS_RET_SUCCESS;

}
void mib_socket_dbe_raw_capture(int fd, int ifreq, unsigned char * buf, int bytes)
{
  int i;
  int nodelay = 1;
  int retCode;
  
  pthread_mutex_lock(&mutexDataCollection);
  
  retCode = grab_raw_data(ifreq, buf);

  pthread_mutex_unlock(&mutexDataCollection);

  setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, (char *)&nodelay, sizeof(nodelay));
  
  for(i=0; i<bytes /* RAW_SAMPLES_MAX */ ; i += 1024)
    {
      retCode = send(fd, &buf[i], 1024, MSG_NOSIGNAL);
      if (retCode < 0)
	break;
    }

  return;
}

void socket_dbe_raw_capture(int fd, int ifreq, unsigned char * buf, int bytes)
{
  int i;
  int nodelay = 1;
  int retCode;
  
  pthread_mutex_lock(&mutexDataCollection);
  
  retCode = bp_grab_raw_data(ifreq, buf);

  pthread_mutex_unlock(&mutexDataCollection);

  setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, (char *)&nodelay, sizeof(nodelay));
  
  for(i=0; i<bytes /* RAW_SAMPLES_MAX */ ; i += 1024)
    {
      retCode = send(fd, &buf[i], 1024, MSG_NOSIGNAL);
      if (retCode < 0)
	break;
    }

  return;
}

/**
 * Definition of the dbe_rawc_capture command
 */
void insert_dbe_raw_capture(void)
{
   // add to the global list of available commands
   char *name = "dbe_raw_capture";
   char *usage= "dbe_raw_capture=;";
   int nParams = 2;
   int cmdType = CMD_VSIS_COMMAND;
   int paramTypes[2] = {CMD_PARAM_INTEGER, CMD_PARAM_STRING};
   cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_raw_capture, cmdType);
}

#ifdef _FFT_SUPPORT_ /* TEMPORARY */ /* Per Matt's request. It is temporary */

#define FFT_CAPTURE_START_ADDR  (unsigned long)0xA00002
#define FFT_CAPTURE_END_ADDR    (unsigned long)0xC00020
#define FFT_CAPTURE_CMD         (unsigned long)0xA00000

#define FFT_DATA_MASK           0x7FFFFFF  /* 0x3FFFF  18 bit */

typedef struct
{
  unsigned int real;
  unsigned int imag;
} FFT_DATA_TYPE;

FFT_DATA_TYPE fft_samples[4][RAW_SAMPLES];

int grab_fft_data(int ifreq, unsigned int data_mask)
{
  int j=0;
  unsigned short lsb_data, msb_data;
  int retCode;
  int ifbit;
  unsigned long offset;
  
  ifbit = ifreq << 2;

  /* tell the FPGA to start collection */
  retCode = fpga_alc_capture_cmd(FFT_CAPTURE_CMD, 0x0001 | ifbit);

  /* sleep for 40 us. 1 ms should be plenty */
  usleep(1000);

  /* every read we get four bytes for 8192 reads */
  for(j=0; j<RAW_SAMPLES; j++)
    {
      int data;
      offset = FFT_CAPTURE_START_ADDR;
      for (data=0; data<4; data++)
	{
	  /* do this 4 times */
	  /* read the real part */
	  /* LSB 16 bits */
	  retCode = fpga_alc_capture(offset, &lsb_data);
	  offset += 2;
	  /* MSB 16 bits */
	  retCode = fpga_alc_capture(offset, &msb_data);
	  /* pack the data */
	  fft_samples[data][j].real = (((msb_data << 16) | lsb_data) & data_mask);
	  offset += 2;
	  /* read the imaginary part */
	  /* LSB 16 bits */
	  retCode = fpga_alc_capture(offset, &lsb_data);
	  offset += 2;
	  /* MSB 16 bits */
	  retCode = fpga_alc_capture(offset, &msb_data);
	  /* pack the data */
	  fft_samples[data][j].imag = (((msb_data << 16) | lsb_data) & data_mask);
	  offset += 2;
	}
      
      /* set read ACK */
      retCode = fpga_alc_capture_cmd(FFT_CAPTURE_CMD, 0x0003 | ifbit);

      /* clear read ACK */
      retCode = fpga_alc_capture_cmd(FFT_CAPTURE_CMD, 0x0001 | ifbit);
    }

  /* clear the start bit */
  retCode = fpga_alc_capture_cmd(FFT_CAPTURE_CMD, 0x0);

  return retCode;
}

extern char roach_ip[];

int dbe_fft_capture(int argc, void **argv, void **retVal, int *retLen)
{
  int j, data;

  FILE * fp_log = (FILE *)NULL;
  char filename[MAX_LEN];

  int ifreq = 0;

  clock_t start;
  double duration;

  char * data_mask_str = (char *)0;
  unsigned int data_mask;

  int retCode;
  int signed_extended;
  unsigned int sign_mask; /*  = ~(FFT_DATA_MASK >> 1); */

  int ip[4];

  if (pthread_mutex_trylock(&mutexFftData))
    {
      sprintf(*retVal,"!dbe_fft_capture?%d:Operation in progress already!;\n", VSIS_RET_EXECUTION_ERROR);
      *retLen = strlen(*retVal);
      return -VSIS_RET_EXECUTION_ERROR;
    }

  if (argv[0]) /* if not defined use 0 as default */
    {
      ifreq = (int)*(unsigned long*)argv[0];
    }

  if (argv[1])
    {
      data_mask_str = (char *)argv[1];
      sscanf(data_mask_str, "%x", &data_mask);
    }
  else
    data_mask = FFT_DATA_MASK;

  sign_mask = ~(data_mask >> 1);


  start = clock();

  retCode = grab_fft_data(ifreq, data_mask);

  duration = ((double)(clock() - start)/CLOCKS_PER_SEC);

  printf("FFT Capture -- Time Elapsed: %f\n", duration);

  memset(filename, 0x0, MAX_LEN);

  *retLen = 0;

  sscanf(roach_ip, "%d.%d.%d.%d", &ip[0], &ip[1], &ip[2], &ip[3]);

  for(data=0; data<4; data++)
    {
      sprintf(filename, "/home/roach/rdbe_sw/data_capture/%d_%d_real.txt", ip[3], data);
      fp_log = fopen(filename, "w");

      if ((FILE *)NULL == fp_log)
	{
	  sprintf(*retVal,"!fft_raw_capture?%d:file open failed;\n", VSIS_RET_EXECUTION_ERROR);
	  *retLen = strlen(*retVal);
	  pthread_mutex_unlock(&mutexFftData);
	  return -VSIS_RET_EXECUTION_ERROR;
	}

      for(j=0; j<RAW_SAMPLES; j++)
	{
	  signed_extended = fft_samples[data][j].real;
	  if (signed_extended & sign_mask)
	    signed_extended |= sign_mask;
	  
	  fprintf(fp_log, "%d\n", signed_extended);
	}

      fflush(fp_log);
      fclose(fp_log);

      /* imaginary part */
      sprintf(filename, "/home/roach/rdbe_sw/data_capture/%d_%d_img.txt", ip[3], data);
      fp_log = fopen(filename, "w");

      if ((FILE *)NULL == fp_log)
	{
	  sprintf(*retVal,"!dbe_fft_capture?%d:file open failed;\n", VSIS_RET_EXECUTION_ERROR);
	  *retLen = strlen(*retVal);
	  pthread_mutex_unlock(&mutexFftData);
	  return -VSIS_RET_EXECUTION_ERROR;
	}

      for(j=0; j<RAW_SAMPLES; j++)
	{
	  signed_extended = fft_samples[data][j].imag;
	  if (signed_extended & sign_mask)
	    signed_extended |= sign_mask;
	  
	  fprintf(fp_log, "%d\n", signed_extended);
	}

      fflush(fp_log);
      fclose(fp_log);
    }
  sprintf(*retVal,"!dbe_fftcapture?0:%f;\n", duration);
  *retLen = strlen(*retVal);
  pthread_mutex_unlock(&mutexFftData);
  return VSIS_RET_SUCCESS;

}

void insert_dbe_fft_capture(void)
{
   // add to the global list of available commands
   char *name = "dbe_fft_capture";
   char *usage= "dbe_fft_capture=;";
   int nParams = 2;
   int cmdType = CMD_VSIS_COMMAND;
   int paramTypes[2] = {CMD_PARAM_UNSIGNEDLONG, CMD_PARAM_STRING};
   cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_fft_capture, cmdType);
}

#endif /* TO BE REMOVED */

/**
 * Definition of the dbe_reset set command
 */
void insert_dbe_init_set(void)
{
  char *name = "dbe_init";
  char *usage= "dbe_init = ;";
  int nParams = 0;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[0] = {};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_init_set, cmdType);
}


/**
 * set the IF attenuation and solor mode
 * @param argc   - 0
 * @param argv   -
 * @param retVal - <return code>
 * @param retLen - length of
 * @return       - 0 on success negative return code otherwise
 * This function has to remmeber previous settings for either IFa & IFb.
 * the same settings needs to be retrasmitted.
 */


int dbe_alc_set(int argc, void **argv, void **retVal, int *retLen)
{
  int retCode = -1;
  int i;

  int intFreq;
  int both = 0;

  unsigned char db_cmd = 0;
  unsigned char bits_cmd = 0;
  unsigned char solar_mode = 0x1; /* default to off */

  unsigned char att_set = 0;

  unsigned short alc_cmd = 0;

  char * solar_mode_str;

  int ret = VSIS_RET_SUCCESS;;

  // initialize variables
  *retLen = 0;

  // get the parameters
  if (argv[0])
    {
      intFreq = (int)*(unsigned long*)argv[0];

      if ((intFreq > 1) ||
	  (intFreq < 0))
	{
	  sprintf(*retVal,"!dbe_alc=%d;\n", VSIS_RET_PARAMETER_ERROR);
	  *retLen = strlen(*retVal);
	  return -VSIS_RET_PARAMETER_ERROR;
	}
    }
  else  /* it mens apply command to both IFa & IFb */
    both = 1;

  if (argv[1])
    db_cmd   = (unsigned char)*(unsigned long*)argv[1];
  /* if attenuation command not provided => use default (0) */

  solar_mode_str = (char*)argv[2];
  if (solar_mode_str)
    {
      if (0 == strcmp("on", solar_mode_str))
	solar_mode = 0x2;
    }

  /* transform  the Db into our presentation */
  for (i=0; i<=4 ;i++)
    bits_cmd |= (db_cmd & (1 << (4-i)));

  /* setting for the current IF */
  att_set = (bits_cmd << 3) | solar_mode;

  if (both)
    alc_cmd = ((att_set << 8) | att_set);
  else
    /* the command to send to the FPGA */
    alc_cmd = ((att_set << (8 * !intFreq)) | ((pre_if_cmd[!intFreq]) << (8 * intFreq)));

  /* gard access to the previous settings */
  pthread_mutex_lock(&mutexAlc);

  retCode = fpga_alc_set_control(alc_cmd);
  if (!retCode)
    {
      /* update the previous values */
      
      if (both)
	{
	  intFreq = 0;
	  pre_if_cmd[intFreq] = att_set;
	  pre_if_cmd[!intFreq] = att_set;
	}
      else
	pre_if_cmd[intFreq] = att_set;

      sprintf(*retVal,"!dbe_alc=%d;\n", VSIS_RET_SUCCESS);
      ret = VSIS_RET_SUCCESS;
    }
  else
    {
      sprintf(*retVal,"!dbe_alc=%d;\n", VSIS_RET_EXECUTION_ERROR);
      ret = VSIS_RET_EXECUTION_ERROR;
    }
  *retLen = strlen(*retVal);
  pthread_mutex_unlock(&mutexAlc);
  return ret;
}

/**
 * Definition of the dbe_alc command
 * Setts the attunuation for the IFs (A &B) and solor mode
 */
void insert_dbe_alc_set(void)
{
   // add to the global list of available commands
   char *name = "dbe_alc";
   char *usage= "dbe_alc= <if>:<att>:<smode>;";
   int nParams = 3;
   int cmdType = CMD_VSIS_COMMAND;
   int paramTypes[3] = {CMD_PARAM_UNSIGNEDLONG, CMD_PARAM_UNSIGNEDLONG, CMD_PARAM_STRING};
   cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_alc_set, cmdType);
}

/*
 * get the IF attenuation and solor mode setting
 * @param argc   - 1
 * @param argv   - if (a|b)
 * @param retVal - <return code>
 * @param retLen - length of
 * @return       - 0 on success negative return code otherwise
 * This function returns the last commands passed to IF A & B.
 */
int dbe_alc_get(int argc, void **argv, void **retVal, int *retLen)
{
  int retCode = -1;
  int i;

  unsigned short intFreq;
  unsigned short att_cmd;
  unsigned char a_att, b_att;
  unsigned a_db = 0, b_db = 0;
  unsigned char a_sol, b_sol;

  char a_sol_str[] = "undef";
  char b_sol_str[] = "undef";
  int full_mode = 0;

  // initialize variables
  *retLen = 0;

  // get the parameters
  if (argv[0])
    {
      intFreq = (unsigned short)*(unsigned long*)argv[0];
      if (intFreq > 1)
	{
	  sprintf(*retVal,"!dbe_alc?%d;\n", VSIS_RET_PARAMETER_ERROR);
	  *retLen = strlen(*retVal);
	  return -VSIS_RET_PARAMETER_ERROR;
	}
    }
  else /* do all the Ifs */
    full_mode = 1;


  retCode = fpga_alc_get_control(&att_cmd);

  a_att = (att_cmd & 0xF800) >> 11;
  a_sol = (att_cmd & 0x0300) >> 8;

  for(i=0; i<=4; i++)
    a_db += (a_att & (1 << (4-i)));

  if (0x1 == a_sol)
    strcpy(a_sol_str, "off");
  else if (0x2 == a_sol)
    strcpy(a_sol_str, "on");

  b_att = (att_cmd & 0xF8) >> 3;
  b_sol = (att_cmd & 0x3);

  for(i=0; i<=4; i++)
    b_db += (b_att & (1 << (4-i)));


  if (0x1 == b_sol)
    strcpy(b_sol_str, "off");
  else if (0x2 == b_sol)
    strcpy(b_sol_str, "on");

  if (full_mode)
    {
      sprintf(*retVal, "!dbe_alc?%d:0:%d:%s:1:%d:%s;\n", retCode, a_db, a_sol_str, b_db, b_sol_str);
    }
  else
    {
      if (intFreq)
	sprintf(*retVal, "!dbe_alc?%d:1:%d:%s;\n", retCode, b_db, b_sol_str);
      else
	sprintf(*retVal, "!dbe_alc?%d:0:%d:%s;\n", retCode, a_db, a_sol_str);
    }

  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS;
}

/**
 * Definition of the dbe_alc query
 * Readback the commands for the attunuation for the IFs (A &B) and solor mode
 */
void insert_dbe_alc_get(void)
{
  // add to the global list of available commands
  char *name = "dbe_alc";
  char *usage= "dbe_alc?[if];";
  int nParams = 1;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[1] = {CMD_PARAM_UNSIGNEDLONG};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_alc_get, cmdType);
}

int dbe_fs_set(int argc, void **argv, void **retVal, int *retLen)
{
  // initialize variables
  int retCode = -1;
  int ret;

  /* char * reset_pll_str; */
  unsigned char reset_pll = 0;
  /* char * sync_pps_str; */
  unsigned char sync_pps = 0;

  unsigned char cmd = 0x80;

  *retLen = 0;

  if (argv[0])
    {
      /* this got to be the synchronize pps */
      if (0 == strcasecmp(argv[0], "on"))
	sync_pps = 1;
      else if (0 == strcasecmp(argv[0], "off"))
	sync_pps = 0;
      else
	{
	  sprintf(*retVal,"!dbe_fs?%d:need a valid input for Sync PPS;\n", VSIS_RET_PARAMETER_ERROR);
	  *retLen = strlen(*retVal);
	  return -VSIS_RET_PARAMETER_ERROR;
	}
    }

  if (argv[1])
    {
       /* this got to be the synchronize pps */
      if (0 == strcasecmp(argv[1], "on"))
	reset_pll = 1;
      else if (0 == strcasecmp(argv[1], "off"))
	reset_pll = 0;
      else
	{
	  sprintf(*retVal,"!dbe_fs?%d:need a valid input for Reset PLL;\n", VSIS_RET_PARAMETER_ERROR);
	  *retLen = strlen(*retVal);
	  return -VSIS_RET_PARAMETER_ERROR;
	}
    }

  cmd |= (reset_pll << 1) | sync_pps;

  retCode = fpga_fs_set_control(cmd);
   if (!retCode)
    {
      sprintf(*retVal,"!dbe_fs:%d;\n", VSIS_RET_SUCCESS);
      ret = VSIS_RET_SUCCESS;
    }
  else
    {
      sprintf(*retVal,"!dbe_fs:%d:%d;\n",VSIS_RET_EXECUTION_ERROR, retCode);
      ret = VSIS_RET_EXECUTION_ERROR;
    }
 
   *retLen = strlen(*retVal);
   return ret;
}

void insert_dbe_fs_set(void)
{
  // add to the global list of available commands
  char *name = "dbe_fs";
  char *usage= "dbe_fs = <fs1><fs2>;";
  int nParams = 2;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[2] = {CMD_PARAM_STRING, CMD_PARAM_STRING};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_fs_set, cmdType);
}


/*
 * get the ALC PPS Status and PPS Sync
 * @param argc   - 0
 * @param argv   -
 * @param retVal - <return code>
 * @param retLen - length of
 * @return       - 0 on success negative return code otherwise
 * This function returns the pps status and pps sync for the ALC.
 */
int dbe_alc_fs_get(int argc, void **argv, void **retVal, int *retLen)
{
  // initialize variables
  int retCode = -1;
  int ret;

  unsigned short synth_status;
  unsigned int pps_sync;

  *retLen = 0;

  retCode = fpga_alc_get_pps_status(&synth_status);
  if (!retCode)
    {
      retCode = fpga_alc_get_sync_status(&pps_sync);
      if (!retCode)
	{
	  sprintf(*retVal,"!dbe_fs?%d:%d:%d:%u;\n", VSIS_RET_SUCCESS, synth_status & 0x1, (synth_status & 0x2) >> 1, pps_sync);
	  ret = VSIS_RET_SUCCESS;
	}
      else
	{
	  sprintf(*retVal,"!dbe_fs?%d:%d;\n", VSIS_RET_EXECUTION_ERROR, retCode);
	  ret = VSIS_RET_EXECUTION_ERROR;
	}
    }
  else
    {
      sprintf(*retVal,"!dbe_fs?%d:%d;\n", VSIS_RET_EXECUTION_ERROR, retCode);
      ret = VSIS_RET_EXECUTION_ERROR;
    }

  *retLen = strlen(*retVal);
  return ret;
}


/**
 * Definition of the dbe_alc_pps query
 * Read the pps sattus and PPS sysnc for ALC.
 */
void insert_dbe_fs_get(void)
{
  // add to the global list of available commands
  char *name = "dbe_fs";
  char *usage= "dbe_fs?;";
  int nParams = 0;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[0] = {};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_alc_fs_get, cmdType);
}


/*
 * get the ALC FPGA version
 * @param argc   - 0
 * @param argv   -
 * @param retVal - <return code>
 * @param retLen - length of
 * @return       - 0 on success negative return code otherwise
 * This function returns the ALC FPGA version.
 */
int dbe_alc_fpgaver_get(int argc, void **argv, void **retVal, int *retLen)
{
  // initialize variables
  int retCode = -1;
  int ret;

  unsigned short ver;

  *retLen = 0;

  retCode = fpga_alc_get_ver(&ver);
  if (!retCode)
    {
      sprintf(*retVal,"!dbe_alc_fpgaver?%d:0x%04x;\n", VSIS_RET_SUCCESS, ver);
      ret = VSIS_RET_SUCCESS;
    }
  else
    {
      sprintf(*retVal,"!dbe_alc_pps?%d;\n", VSIS_RET_EXECUTION_ERROR);
      ret = VSIS_RET_EXECUTION_ERROR;
    }

  *retLen = strlen(*retVal);
  return ret;
}


/**
 * Definition of the dbe_alc_fpgaver query
 * Read the ALC FPGA version.
 */
void insert_dbe_alc_fpgaver_get(void)
{
  // add to the global list of available commands
  char *name = "dbe_alc_fpgaver";
  char *usage= "dbe_alc_fpgaver?;";
  int nParams = 0;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[0] = {};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_alc_fpgaver_get, cmdType);
}

int dbe_execute(int argc, void **argv, void **retVal, int *retLen)
{
  // initialize variables
  int retCode = 0;

  char config_file_name[MAX_FILE_NAME_LEN];
  char perso_name[MAX_FILE_NAME_LEN];

  char * dot_ptr = (char *)NULL;

  if (!argv[0])
    {
      sprintf(*retVal,"!dbe_execute=%d;\n", VSIS_RET_PARAMETER_ERROR);
      retCode = VSIS_RET_PARAMETER_ERROR;
    }
  else
    {
      memset(config_file_name, '\0', MAX_FILE_NAME_LEN * sizeof(char));
      if (0 == strcasecmp("reboot", argv[0]))
	system(argv[0]);
      else if (0 == strcasecmp("init", argv[0]))
	{
	  if (!current_settings.personality_load_status)
	    {
	      /* the previous personality load failed. Return an error ? */
	      sprintf(*retVal,"!dbe_execute=4;\n");
	    }
	  else
	    {	  
	      /* If we are here, supposedly the load was successful look for the config file */
	  
	      /* The config file should be with the same name as the personality file */	      
	      memset(perso_name, '\0', MAX_FILE_NAME_LEN * sizeof(char));
	      
	      if ('\0' == *current_settings.personality_file_name)
		{
		  /* use the default config file */
		  sprintf(config_file_name, "%sconf/default.conf", HAL_RDBE_HOME);
		}
	      else
		{
		  dot_ptr = strchr(current_settings.personality_file_name, '.');
		  if ((char *)NULL != dot_ptr)
		    strncpy(perso_name, 
			    current_settings.personality_file_name, 
			    (size_t)(dot_ptr - &current_settings.personality_file_name[0]));
		  else
		    strcpy(perso_name, current_settings.personality_file_name);
		  
		  sprintf(config_file_name, "%sconf/%s.conf",  HAL_RDBE_HOME, perso_name);
		}
	      
	      /* process the config file and execute commands */
	      retCode = processConfigFile(config_file_name);
	      sprintf(*retVal,"!dbe_execute=%d;\n", retCode);
	      /* enable the ISR once finish initialization */
	      fpga_isr_enable(0);
	      /* Initialize VDIF setup */
	      setupVdifStationID();
	    }
	}
      else if (0 == strcasecmp("quantize", argv[0]))
	{
	  sprintf(*retVal,"!dbe_execute=8:not supported;\n");
	}
      else if (0 == strcasecmp("powerup", argv[0]))
	{
#if 0 /* added and removed per Matt's request */
	  fpga_write_Adc_reload(1);
	  usleep(1000);
	  fpga_write_Adc_reload(0);
#endif
	  /* Matt prefers to have a seperate file for power up */
	  /* The config file should be with the same name as the personality file */	      
	  memset(perso_name, '\0', MAX_FILE_NAME_LEN * sizeof(char));
	  
	  if ('\0' == *current_settings.personality_file_name)
	    {
	      /* use the default config file */
	      sprintf(config_file_name, "%sconf/default.pwr", HAL_RDBE_HOME);
	    }
	  else
	    {
	      dot_ptr = strchr(current_settings.personality_file_name, '.');
	      if ((char *)NULL != dot_ptr)
		strncpy(perso_name, 
			current_settings.personality_file_name, 
			(size_t)(dot_ptr - &current_settings.personality_file_name[0]));
	      else
		strcpy(perso_name, current_settings.personality_file_name);
	      
	      sprintf(config_file_name, "%sconf/%s.pwr",  HAL_RDBE_HOME, perso_name);
	    }
	  
	  /* process the config file and execute commands */
	  retCode = processConfigFile(config_file_name);
	  sprintf(*retVal,"!dbe_execute=%d;\n", retCode);

	  /* enable the ISR once finish initialization */
	  fpga_isr_enable(0);
	  /* Initialize VDIF setup */
	  setupVdifStationID();
	}
    }
  
  *retLen = strlen(*retVal);
  return retCode;
}

void insert_dbe_execute(void)
{
  // add to the global list of available commands
  char *name = "dbe_execute";
  char *usage= "dbe_execute=<cmd>;";
  int nParams = 1;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[1] = {CMD_PARAM_STRING};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_execute, cmdType);
}

/********************* In support of the dbe_1pps_mon. ***********************/

int setupMulticast(struct sockaddr_in * server_addr, 
		   struct sockaddr_in * client_addr,
		   unsigned int * multicast_ip,
		   short port)
{
  int fd;
  unsigned char ttl = 10;
  char ip[16];

  fd = socket(AF_INET, SOCK_DGRAM, 0);
  if (-1 == fd)
    return -1;
  
  memset(server_addr, 0, sizeof(struct sockaddr_in));
  server_addr->sin_family = AF_INET;
  /* choose an unused port at random */
  server_addr->sin_port = htons(0);
  server_addr->sin_addr.s_addr = inet_addr(roach_ip);
      
  if( bind(fd, (struct sockaddr *)server_addr, sizeof(struct sockaddr)) == -1)
    {
      close(fd);
      return -1;
    }
      
  /* Set the multicast packet TTL to 10 */
  if( setsockopt(fd, IPPROTO_IP, IP_MULTICAST_TTL, &ttl, sizeof(unsigned char) )<0)
    {
      close(fd);
      return -1;
    }

  /* now set up the IP Address */
  memset(client_addr, 0, sizeof(struct sockaddr_in));
  client_addr->sin_family = AF_INET;
  /* choose an unused port at random */
  client_addr->sin_port = htons(port);

  sprintf(ip, "%d.%d.%d.%d", multicast_ip[0], multicast_ip[1], multicast_ip[2], multicast_ip[3]); 
  inet_aton((char *)ip, &(client_addr->sin_addr));

  return fd;
}

/**
 * Implement data send command
 * @param argc   - 4
 * @param argv   - <state>:<ts>[:<te>][:<delta>]
 * @param retVal - <return code>
 * @param retLen - length of
 * @return       - 0 on success negative return code otherwise
 */

enum MulticastState
{
  MULTICAST_ENABLED,
  MULTICAST_DISABLED,
  MULTICAST_CLOSE,
};

/******************************* 1PPS ****************/
#define ONE_PPS_MON_PORT 20020

enum MulticastState one_pps_status = MULTICAST_DISABLED;

unsigned int one_pps_multicast_ip[IP_LEN];

pthread_mutex_t mutex_one_pps = PTHREAD_MUTEX_INITIALIZER;

int one_pps_mon_multicast_sockfd;
struct sockaddr_in one_pps_mon_client_addr;
struct sockaddr_in one_pps_mon_server_addr;

/******************************* END 1PPS ****************/

/********************************* TSYS *****************/
#define TSYS_MON_PORT 20021

enum MulticastState tsys_mon_status = MULTICAST_DISABLED;
unsigned int tsys_mon_multicast_ip[IP_LEN];

pthread_mutex_t mutex_tsys_mon = PTHREAD_MUTEX_INITIALIZER;

int tsys_mon_multicast_sockfd;
struct sockaddr_in tsys_mon_client_addr;
struct sockaddr_in tsys_mon_server_addr;

int diode_switch_freq = 10; /* 10 Khz */
/*
 * Tsys thread. Loops for ever wating for a green light to start
 * broadcasting the tsys values.
 */

struct chan
{
     double tsys_on;
     double tsys_off;
};

struct tsys_data_struct
{
     struct chan inp[MAX_CHANNELS];
};

struct tsys_data_test
{
     unsigned short interface;
     unsigned short channel;
     unsigned long long tsys_on;
     unsigned long long tsys_off;
};

struct tsys {
     char read_time[14];
     unsigned  int interval:16;       
     struct tsys_data_test tsys_data_1[32];
};

struct tsys tsys_out;


int interval;

#define MAX_DC   4

typedef struct
{
  unsigned long long psn;
  unsigned long long psf;

  long long vsn;
  long long vsf;
} TSYS_DATA;

struct ddc_tsys_data_struct
{
  char read_time[16];
  unsigned int on_count;
  unsigned int off_count;
  TSYS_DATA data[MAX_DC];
} ddc_tsys;

/******************************* END TSYS ***************/

/*
 * 1pps thread. Loops for ever wating for a green light to start
 * broadcasting the dot time.
 */
void *one_pps_thread(void *arg)
{
  int retCode = -1;
  unsigned long dotTime = 0;
  int rc;
  char str_time[14] = {};
  
  /* --- ALLOCATE MEMORY FOR TSYS DATA*/
  unsigned long long tsys_val_on;
  unsigned long long tsys_val_off;
  unsigned long tsys_on_low;
  unsigned long tsys_on_high;
  unsigned long tsys_off_low;
  unsigned long tsys_off_high;
  int int_cntr = 1;
  int intFreq;
  int channel;
  unsigned long tdotTime = 0;
  unsigned long tsysdotTime = 0;
  int k;
  int rd;

  int dc;

  while(1)
    {
      /* wait for a green light */
      pthread_mutex_lock(&mutex_one_pps);
      
      while(1)
	{	 
	  if (MULTICAST_CLOSE == one_pps_status)
	    {
	      /* close the socket */
	      rd = close(one_pps_mon_multicast_sockfd);
	      //printf("rd pps: %d, \n",rd);
	      one_pps_status = MULTICAST_DISABLED;
	      //if (MULTICAST_DISABLED == tsys_mon_status)
	      //fpga_isr_disable(0);
	      break;
	    }
	  
	  if (MULTICAST_CLOSE == tsys_mon_status)
	    {
	      /* close the socket */
	      rd = close(tsys_mon_multicast_sockfd);
	      //printf("rd t: %d, \n",rd);
	      tsys_mon_status = MULTICAST_DISABLED;
	      //if (MULTICAST_DISABLED == one_pps_status)
	      //fpga_isr_disable(0);
	      break;
	    }
	  
	  fpga_isr_rd();
	  if (MULTICAST_ENABLED == one_pps_status)
	    {
	      
	      // Get the DOT running time in BCD
	      retCode = fpga_get_dot(&dotTime);
	      if (-1 != retCode)
		{
		  /* process the DOT */
		  Bcd2Human(dotTime, str_time, 0);
		  
		  /* send the DOT time */
		  rc = sendto(one_pps_mon_multicast_sockfd,
			      (char *)str_time,
			      strlen(str_time),
			      0,
			      (struct sockaddr*)&one_pps_mon_client_addr,
			      sizeof(struct sockaddr_in));
		  if (-1 == rc)
		    perror("1pps thread sendto");
		}
	    } // END IF (MULTICAST_ENABLESD == one_pps_status)
	  
	  if (MULTICAST_ENABLED == tsys_mon_status)
	    {
	      /* are we DDC or PFBG */
	      if (0 == strcmp("DDC", current_settings.personality_type))
		{
		  fpga_ddc_tsys_get_on_count(&ddc_tsys.on_count);
		  fpga_ddc_tsys_get_off_count(&ddc_tsys.off_count);

		  for (dc = 0; dc < MAX_DC; dc++)
		    {
		      fpga_ddc_tsys_get_power_tsys_off(dc, &ddc_tsys.data[dc].psf);
		      fpga_ddc_tsys_get_power_tsys_on(dc, &ddc_tsys.data[dc].psn);
		      fpga_ddc_tsys_get_voltage_tsys_off(dc, &ddc_tsys.data[dc].vsf);
		      fpga_ddc_tsys_get_voltage_tsys_on(dc, &ddc_tsys.data[dc].vsn);
		    }

		  retCode = fpga_get_dot(&tdotTime);		  
		  Bcd2Human(tdotTime, ddc_tsys.read_time, 0);

		  /* send the tsys data  */
		  rc = sendto(tsys_mon_multicast_sockfd,
			      (char *)&ddc_tsys,
			      sizeof(ddc_tsys),
			      0,
			      (struct sockaddr*)&tsys_mon_client_addr,
			      sizeof(struct sockaddr_in));
		  if (-1 == rc)
		    perror("tsys thread sendto");
		}
	      else
		{ /* PFBG Mode */
		  /* get all of the tsys data */
		  for (intFreq = 0; intFreq <MAX_IFS; intFreq++)
		    {
		      for (channel=0; channel<MAX_CHANNELS; channel++)
			{
			  k = intFreq * 16 + channel;
			  // --- READ THE TSYS_ON DATA
			  retCode = fpga_get_tsys_on(intFreq, channel, &tsys_on_low, &tsys_on_high);
			  if (!retCode)
			    {
			      // --- PAD IT
			      //lsb_pad_frac2dbl(&tsys_val_on);
			      
			      // --- READ THE TSYS_OFF DATA
			      retCode = fpga_get_tsys_off(intFreq, channel, &tsys_off_low, &tsys_off_high );
			      if (!retCode)
				{
				  // --- PAD IT
				  //lsb_pad_frac2dbl(&tsys_val_off);
				  // IF THE INTERVAL COUNTER IS > 0 SUM THE TSYS VALUES
				  if (int_cntr > 1)
				    {
				      tsys_val_on = ((((unsigned long long)(tsys_on_high) & 0x0000ffff)<< 32) | tsys_on_low);
				      tsys_val_off = ((((unsigned long long)(tsys_off_high) & 0x0000ffff) << 32) | tsys_off_low);
				      tsys_out.tsys_data_1[k].tsys_on += tsys_val_on;
				      tsys_out.tsys_data_1[k].tsys_off += tsys_val_off;
				      // --- IF THE INTERVAL COUNTER EQUALS THE INTERVAL CALCULATE THE AVERAGE 
				      if (int_cntr == interval)
					{
					  tsys_out.tsys_data_1[k].channel = channel;
					  tsys_out.tsys_data_1[k].interface = intFreq;
					  tsys_out.tsys_data_1[k].tsys_on /= interval;
					  tsys_out.tsys_data_1[k].tsys_off /= interval;
					}
				    }
				  // --- ELSE IT IS THE FIRST SECOND OF DATA, AND ASSIGN THEM.
				  else
				    {
				      tsys_out.tsys_data_1[k].channel = channel;
				      tsys_out.tsys_data_1[k].interface = intFreq;
				      tsys_val_on = (((unsigned long long)(tsys_on_high) & 0x0000ffff) << 32) | tsys_on_low;
				      tsys_val_off = (((unsigned long long)(tsys_off_high) & 0x0000ffff) << 32) | tsys_off_low;
				      tsys_out.tsys_data_1[k].tsys_on = tsys_val_on;
				      tsys_out.tsys_data_1[k].tsys_off = tsys_val_off;					
				    }
				} // --- END  if (!retCode) FOR FPGA_GET_TSYS_OFF DATA
			    } // --- END  if (!retCode) FOR FPGA_GET_TSYS_ON DATA
			} // ---- END for (channel=0; channel<MAX_CHANNELS; channel++)
		    } // --- END for (intFreq = 0; intFreq <MAX_IFS; intFreq++) 
	      
		  // --- IF THE INTERVAL COUNTER EQUALS TO THE SET INTERVAL,  TRANSMIT THE TSYS DATA
		  if (int_cntr == interval)
		    {
		      retCode = fpga_get_dot(&tdotTime);
		      if (-1 != retCode)
			{
			  /* process the DOT */
			  tsysdotTime = tdotTime - interval;
			  //printf("t: dT: %lu tdT %lu \n", tdotTime, tsysdotTime);
			  Bcd2Human(tdotTime, str_time, 0);
			  /* --- insert the dot time into the header, along with the interval */
			  //printf("t: d st %s\n", str_time);
			  strcpy(tsys_out.read_time,str_time);
			  //printf("readtime = %llu, %s \n", tsys_out.read_time, str_time);
			  tsys_out.interval =  interval;		     }
		      
		      /* send the tsys data  */
		      rc = sendto(tsys_mon_multicast_sockfd,
				  (char *)&tsys_out,
				  sizeof(tsys_out),
				  0,
				  (struct sockaddr*)&tsys_mon_client_addr,
				  sizeof(struct sockaddr_in));
		      if (-1 == rc)
			perror("tsys thread sendto");
		      else
			// --- RESET IT TO 1
			int_cntr = 1;		  
		    }
		  else
		    // --- INCREMENT THE INTERVAL COUNTER
		    int_cntr ++;
		} // END IF (MULTICAST_ENABLED == tsys_mon_status)
	    }
	  
	}
    }
}

int dbe_1pps_mon(int argc, void **argv, void **retVal, int *retLen)
{
  char * state = (char *)NULL;
  char * multicastIP = (char *)NULL;

  int rc;
  enum MulticastState requested_one_pps_status;

  // initialize variables
  *retLen = 0;

  state = (char *)argv[0];
  multicastIP = (char *)argv[1];

  if (state)
    {
      if (0 == strcmp(state, "enable"))
	requested_one_pps_status = MULTICAST_ENABLED;
      else if (0 == strcmp(state, "disable"))
	requested_one_pps_status = MULTICAST_DISABLED;
    }
  else
    {
      sprintf(*retVal, "!dbe_1pps_mon=%d:state is required;\n", VSIS_RET_PARAMETER_ERROR);
      *retLen = strlen(*retVal);
      return -VSIS_RET_PARAMETER_ERROR;
    }

  if ((MULTICAST_ENABLED == requested_one_pps_status) &&
      (MULTICAST_ENABLED == one_pps_status))
    {
      /* already enabled return with error */
      sprintf(*retVal, "!dbe_1pps_mon=%d:multicast already enabled;\n", VSIS_RET_EXECUTION_ERROR);
      *retLen = strlen(*retVal);
      return -VSIS_RET_EXECUTION_ERROR;
    }
    
  if (MULTICAST_ENABLED == requested_one_pps_status)
    {
      /* we only need the IP in case we are enabling the multicast */
      if (multicastIP)
	{
	  /* let's make sure we have a valid multicast @ */
	  rc = sscanf(multicastIP, "%u.%u.%u.%u",
		      &one_pps_multicast_ip[0], 
		      &one_pps_multicast_ip[1], 
		      &one_pps_multicast_ip[2], 
		      &one_pps_multicast_ip[3]);
	  if (rc < IP_LEN)
	    {
	      sprintf(*retVal, "!dbe_1pps_mon=%d:incomplete IP address;\n", VSIS_RET_PARAMETER_ERROR);
	      *retLen = strlen(*retVal);
	      one_pps_status = MULTICAST_DISABLED;
	      return -VSIS_RET_PARAMETER_ERROR;
	    }

	  /* make sure that the given IP is not already in use by the other thread */
	  if (MULTICAST_ENABLED == tsys_mon_status)
	    {
	      if ((one_pps_multicast_ip[0] == tsys_mon_multicast_ip[0]) &&
		  (one_pps_multicast_ip[1] == tsys_mon_multicast_ip[1]) &&
		  (one_pps_multicast_ip[2] == tsys_mon_multicast_ip[2]) &&
		  (one_pps_multicast_ip[3] == tsys_mon_multicast_ip[3]))
		{
		  sprintf(*retVal, "!dbe_tsys_mon=%d:IP address already in use!;\n", VSIS_RET_PARAMETER_ERROR);
		  *retLen = strlen(*retVal);
		  tsys_mon_status = MULTICAST_DISABLED;
		  return -VSIS_RET_PARAMETER_ERROR;
		}
	    }

	  /* now make sure it is within a valid range */
	  if ((239 != one_pps_multicast_ip[0]) ||
	      (one_pps_multicast_ip[1] > 255) ||
	      (one_pps_multicast_ip[2] > 255) ||
	      (one_pps_multicast_ip[3] > 255) ||
	      (one_pps_multicast_ip[2] < 1))
	    {
	      sprintf(*retVal, "!dbe_1pps_mon=%d:invalid IP address;\n", VSIS_RET_PARAMETER_ERROR);
	      *retLen = strlen(*retVal);
	      one_pps_status = MULTICAST_DISABLED;
	      return -VSIS_RET_PARAMETER_ERROR;
	    }
	}
      else
	{
	  sprintf(*retVal, "!dbe_1pps_mon=%d:IP address required;\n", VSIS_RET_PARAMETER_ERROR);
	  *retLen = strlen(*retVal);
	  one_pps_status = MULTICAST_DISABLED;
	  return -VSIS_RET_PARAMETER_ERROR;
	}

     /* set up the multicast IP */
      one_pps_mon_multicast_sockfd = setupMulticast(&one_pps_mon_server_addr,
						    &one_pps_mon_client_addr,
						    one_pps_multicast_ip,
						    ONE_PPS_MON_PORT);
      if (-1 == one_pps_mon_multicast_sockfd)
	{
	  sprintf(*retVal, "!dbe_1pps_mon=%d:failed setup multicast;\n", VSIS_RET_EXECUTION_ERROR);
	  *retLen = strlen(*retVal);
	  one_pps_status = MULTICAST_DISABLED;
	  return -VSIS_RET_EXECUTION_ERROR;
	}
      
      one_pps_status = MULTICAST_ENABLED;
      /* enable the 1pps interrupt */
      if(tsys_mon_status != MULTICAST_ENABLED)
      {
	   /* enable the 1pps interrupt */
      fpga_isr_enable(0);
      /* give the green light for the 1pps thread */
      pthread_mutex_unlock(&mutex_one_pps);
    }
    }
  else
    {
	 /* --- SET 1PPS STATUS TO CLOSE SO SOCKETS ARE CLOSED PROPERLY */
      if (one_pps_status != MULTICAST_DISABLED)
	   one_pps_status = MULTICAST_CLOSE;
      // --- moved to thread, to close the sockets properly
      //if(tsys_mon_status == MULTICAST_DISABLED)
	   /* disable the 1pps interrupt */
      //   fpga_isr_disable(0);
    }

  sprintf(*retVal, "!dbe_1pps_mon=%d;\n", VSIS_RET_SUCCESS);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS;
}


void insert_dbe_1pps_mon_set(void)
{
  // add to the global list of available commands
  char *name = "dbe_1pps_mon";
  char *usage= "dbe_1pps_mon=<state>:<destination multicast IP>;";
  int nParams = 2;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[2] = {CMD_PARAM_STRING, CMD_PARAM_STRING};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_1pps_mon, cmdType);
}

int dbe_1pps_mon_get(int argc, void **argv, void **retVal, int *retLen)
{
  char ip[16];
  // initialize variables
  *retLen = 0;
  if (MULTICAST_DISABLED == one_pps_status)
    sprintf(*retVal, "!dbe_1pps_mon=%d:disabled;\n", VSIS_RET_SUCCESS);
  else
    {
      sprintf(ip, "%d.%d.%d.%d", 
	      one_pps_multicast_ip[0], 
	      one_pps_multicast_ip[1], 
	      one_pps_multicast_ip[2], 
	      one_pps_multicast_ip[3]);

      sprintf(*retVal, "!dbe_1pps_mon=%d:enabled:%s:%d;\n", VSIS_RET_SUCCESS, ip, ONE_PPS_MON_PORT);
    }
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS;
}


void insert_dbe_1pps_mon_get(void)
{
  // add to the global list of available commands
  char *name = "dbe_1pps_mon";
  char *usage= "dbe_1pps_mon ? ;";
  int nParams = 0;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[] = {};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_1pps_mon_get, cmdType);
}
/***************************** End 1pps_mon suppot ****************/

/************************** Implements dbe_tsys_mon ****************/

/* port used to broadcast tsys data */
short tsys_port;

int dbe_tsys_mon(int argc, void **argv, void **retVal, int *retLen)
{
  char * state = (char *)NULL;
  char * multicastIP = (char *)NULL;
  int rc;
  
  enum MulticastState requested_tsys_mon_status;
  
  state = (char *)argv[0];
  multicastIP = (char *)argv[1];
  if (argv[2])
    {
      tsys_port = (unsigned short)*(unsigned long*)argv[2];
    }
  else
    tsys_port = TSYS_MON_PORT;
  
  if (argv[3])
    {
      interval = (int)*(int*)argv[3];
      //printf("argv[3] is present %d\n", interval);
    }
  else
    {
      //printf("argv[3] is NOT present \n");
      interval = 6;
    }
  
  /* printf("interval set to %d\n", interval); */
  
  if (state)
    {
      if (0 == strcmp(state, "enable"))
	requested_tsys_mon_status = MULTICAST_ENABLED;
      else if (0 == strcmp(state, "disable"))
	requested_tsys_mon_status = MULTICAST_DISABLED;
    }
  else
    {
      sprintf(*retVal, "!dbe_tsys_mon=%d;\n", VSIS_RET_PARAMETER_ERROR);
      *retLen = strlen(*retVal);
      return -VSIS_RET_PARAMETER_ERROR;
    }
  
  if ((MULTICAST_ENABLED == requested_tsys_mon_status) && 
      (MULTICAST_ENABLED == tsys_mon_status))
    {
      /* already enabled return with error */
      sprintf(*retVal, "!dbe_tsys_mon=%d:multicast already enabled;\n", VSIS_RET_EXECUTION_ERROR);
      *retLen = strlen(*retVal);
      return -VSIS_RET_EXECUTION_ERROR;
    }
  
  if (MULTICAST_ENABLED == requested_tsys_mon_status)
    {
      /* we only need the IP in case we are enabling the multicast */
      if (multicastIP)
	{
	  /* let's make sure we have a valid multicast @ */
	  rc = sscanf(multicastIP, "%u.%u.%u.%u",
		      &tsys_mon_multicast_ip[0], 
		      &tsys_mon_multicast_ip[1], 
		      &tsys_mon_multicast_ip[2], 
		      &tsys_mon_multicast_ip[3]);
	  if (rc < IP_LEN)
	    {
	      sprintf(*retVal, "!dbe_tsys_mon=%d:incomplete IP address;\n", VSIS_RET_PARAMETER_ERROR);
	      *retLen = strlen(*retVal);
	      tsys_mon_status = MULTICAST_DISABLED;
	      return -VSIS_RET_PARAMETER_ERROR;
	    }
	  /* make sure that the given IP is not already in use by the other thread */
	  if (MULTICAST_ENABLED == one_pps_status)
	    {
	      if ((tsys_mon_multicast_ip[0] == one_pps_multicast_ip[0]) &&
		  (tsys_mon_multicast_ip[0] == one_pps_multicast_ip[1]) &&
		  (tsys_mon_multicast_ip[0] == one_pps_multicast_ip[2]) &&
		  (tsys_mon_multicast_ip[0] == one_pps_multicast_ip[3]))
		{
		  sprintf(*retVal, "!dbe_tsys_mon=%d:IP address already in use!;\n", VSIS_RET_PARAMETER_ERROR);
		  *retLen = strlen(*retVal);
		  tsys_mon_status = MULTICAST_DISABLED;
		  return -VSIS_RET_PARAMETER_ERROR;
		}
	    }
	  /* now make sure it is within a valid range */
	  if ((239 != tsys_mon_multicast_ip[0]) ||
	      (tsys_mon_multicast_ip[1] > 255) ||
	      (tsys_mon_multicast_ip[2] > 255) ||
	      (tsys_mon_multicast_ip[3] > 255) ||
	      (tsys_mon_multicast_ip[2] < 1))
	    {
	      sprintf(*retVal, "!dbe_tsys_mon=%d:invalid IP address;\n", VSIS_RET_PARAMETER_ERROR);
	      *retLen = strlen(*retVal);
	      tsys_mon_status = MULTICAST_DISABLED;
	      return -VSIS_RET_PARAMETER_ERROR;
	    }
	}
      else
	{
	  sprintf(*retVal, "!dbe_tsys_mon=%d:IP address required;\n", VSIS_RET_PARAMETER_ERROR);
	  *retLen = strlen(*retVal);
	  tsys_mon_status = MULTICAST_DISABLED;
	  return -VSIS_RET_PARAMETER_ERROR;
	}

      /* now process the command */
      /* set up the multicast IP */
      tsys_mon_multicast_sockfd = setupMulticast(&tsys_mon_server_addr,
						 &tsys_mon_client_addr,
						 tsys_mon_multicast_ip,
						 tsys_port);
      if (-1 == tsys_mon_multicast_sockfd)
	{
	  sprintf(*retVal, "!dbe_tsys_mon=%d:failed setup multicast;\n", VSIS_RET_EXECUTION_ERROR);
	  *retLen = strlen(*retVal);
	  tsys_mon_status = MULTICAST_DISABLED;
	  return -VSIS_RET_EXECUTION_ERROR;
	}

      tsys_mon_status = MULTICAST_ENABLED;
      /* give the green light for the tsys thread */
      if(one_pps_status != MULTICAST_ENABLED)
      {
	   /* enable the 1pps interrupt */
	   fpga_isr_enable(0);

	   /* give the green light for the pps thread */
	   pthread_mutex_unlock(&mutex_one_pps);
      }
    }
  else
  {
       if(tsys_mon_status != MULTICAST_DISABLED)
	    tsys_mon_status = MULTICAST_CLOSE;

  }
  sprintf(*retVal, "!dbe_tsys_mon=%d;\n", VSIS_RET_SUCCESS);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS;
}

void insert_dbe_tsys_mon_set(void)
{
  // add to the global list of available commands
  char *name = "dbe_tsys_mon";
  char *usage= "dbe_tsys_mon=<state>:<destination multicast IP>:[port]:[interval];";
  int nParams = 4;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[4] = {CMD_PARAM_STRING, CMD_PARAM_STRING, CMD_PARAM_UNSIGNEDLONG, CMD_PARAM_INTEGER};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_tsys_mon, cmdType);
}

int dbe_tsys_mon_get(int argc, void **argv, void **retVal, int *retLen)
{
  char ip[16];
  // initialize variables
  *retLen = 0;
  if (MULTICAST_DISABLED == tsys_mon_status)
    sprintf(*retVal, "!dbe_tsys_mon=%d:disabled;\n", VSIS_RET_SUCCESS);
  else
    {
      sprintf(ip, "%d.%d.%d.%d", 
	      tsys_mon_multicast_ip[0], 
	      tsys_mon_multicast_ip[1], 
	      tsys_mon_multicast_ip[2], 
	      tsys_mon_multicast_ip[3]);
      
      sprintf(*retVal, "!dbe_tsys_mon=%d:enabled:%s:%d:%d;\n", VSIS_RET_SUCCESS, ip, tsys_port, interval);
    }
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS;
}


void insert_dbe_tsys_mon_get(void)
{
  // add to the global list of available commands
  char *name = "dbe_tsys_mon";
  char *usage= "dbe_tsys_mon ? ;";
  int nParams = 0;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[] = {};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_tsys_mon_get, cmdType);
}

int dbe_tsys_conf_set(int argc, void **argv, void **retVal, int *retLen)
{
  int freq;

  if (argv[0])
    freq = (int)*(unsigned long*)argv[0];
  else
    {
      sprintf(*retVal, "!dbe_tsys_conf_set=%d;\n", VSIS_RET_PARAMETER_ERROR);
      *retLen = strlen(*retVal);
      return -VSIS_RET_PARAMETER_ERROR;
    }

  if ((freq >= 10) && (freq <= 100))
    {
      diode_switch_freq = freq;
      sprintf(*retVal, "!dbe_tsys_conf_set=%d;\n", VSIS_RET_SUCCESS);
      *retLen = strlen(*retVal);
      return VSIS_RET_SUCCESS;
    }
  else
    {
      sprintf(*retVal, "!dbe_tsys_conf_set=%d;\n", VSIS_RET_PARAMETER_ERROR);
      *retLen = strlen(*retVal);
      return -VSIS_RET_PARAMETER_ERROR;
    }
}

void insert_dbe_tsys_conf_set(void)
{
   // add to the global list of available commands
  char *name = "dbe_tsys_conf";
  char *usage= "dbe_tsys_conf=<freq>;";
  int nParams = 1;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[1] = {CMD_PARAM_UNSIGNEDLONG};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_tsys_conf_set, cmdType);
}

int dbe_tsys_conf_get(int argc, void **argv, void **retVal, int *retLen)
{
  sprintf(*retVal, "!dbe_tsys_conf=%d:%d;\n", VSIS_RET_SUCCESS, diode_switch_freq);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS;
}

void insert_dbe_tsys_conf_get(void)
{
  // add to the global list of available commands
  char *name = "dbe_tsys_conf";
  char *usage= "dbe_tsys_conf ? ;";
  int nParams = 0;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[0] = {};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_tsys_conf_get, cmdType);
}

/************************** End dbe_tsys_mon ********************/

/******************** IO channel assignemnt */

/* assign the output channels to input channels */
#define MAX_OUTPUTS   16

int dbe_ioch_assign_set(int argc, void **argv, void **retVal, int *retLen)
{
  int i, j, k;
  char * sep = (char *)0;
  char * argPtr = (char *)0;
  int start_ch, end_ch, temp;
  int inputchannel, threadid = 0;
  int retCode = 0, ret;
  unsigned char in;

  short outputs[MAX_OUTPUTS];

  for(i=0; i<MAX_OUTPUTS; i++)
    outputs[i] = -1;

  /* --- ADDED J COUNTER FOR THE ASSIGNMENT INTO OUTPUT[] VERSUS USING THE START_CH --- car */
  for (i=0, j=0; i<argc; i +=3, j++)
    {
      in = 0;
      argPtr = (char *) argv[i];

      if ((char *)0 == argPtr)
	{
	  if (0 == i)
	    { /* this is the first time */
	      sprintf(*retVal, "!dbe_ioch_assign=%d:input is needed!\n", VSIS_RET_PARAMETER_ERROR);
	      *retLen = strlen(*retVal);
	      return -VSIS_RET_PARAMETER_ERROR;
	    }
	  else
	    goto bailout;
	}

      /* make sure we are not getting more than MAX_OUTPUTS */
      if (j >= MAX_OUTPUTS)
	{
	  sprintf(*retVal, "!dbe_ioch_assign=%d:too many inputs!\n", VSIS_RET_PARAMETER_ERROR);
	  *retLen = strlen(*retVal);
	  return -VSIS_RET_PARAMETER_ERROR;
	}
      inputchannel = atoi(argPtr);

      //printf("Input Channal is %d\n", inputchannel);

      if ((inputchannel < 0) || (inputchannel > 1))
	{
	  sprintf(*retVal, "!dbe_ioch_assign=%d:invalid input channel!\n", VSIS_RET_PARAMETER_ERROR);
	  *retLen = strlen(*retVal);
	  return -VSIS_RET_PARAMETER_ERROR;
	}
      /* next shoul be the channel. it could be a number or a range */
      argPtr = (char *)argv[i+1];
      if ((char *)0 == argPtr)
	{
	  sprintf(*retVal, "!dbe_ioch_assign=%d:output channel is needed!\n", VSIS_RET_PARAMETER_ERROR);
	  *retLen = strlen(*retVal);
	  return -VSIS_RET_PARAMETER_ERROR;
	}
      /* now check if what we got is a number or a range */
      sep = strchr(argPtr, '-');
      if ((char *)0 == sep)
	{
	  /* safe to assume it is a number */
	  start_ch = atoi(argPtr);

	  //printf("IF Channal is %d\n", start_ch);

	  if ((start_ch >= 0) && (start_ch < MAX_OUTPUTS))
	    {
	      //outputs[start_ch] = ((inputchannel << 4) | start_ch);
	      outputs[j] = ((inputchannel << 4) | start_ch);
	      //printf("output IF Channal index %d is assigned %d\n", j, outputs[j]);
	    }
	}
      else
	{
	  /* we got a range */
	  ret = sscanf(argPtr, "%d-%d", &start_ch, &end_ch);
	  if (ret < 2)
	    {
	      sprintf(*retVal, "!dbe_ioch_assign=%d:range require 2 values!\n", VSIS_RET_PARAMETER_ERROR);
	      *retLen = strlen(*retVal);
	      return -VSIS_RET_PARAMETER_ERROR;
	    }

	  if (((start_ch < 0) || (start_ch >= MAX_OUTPUTS)) ||
	      ((end_ch < 0) || (end_ch >= MAX_OUTPUTS)))
	    {
	      sprintf(*retVal, "!dbe_ioch_assign=%d:output channel outside the range!\n", VSIS_RET_PARAMETER_ERROR);
	      *retLen = strlen(*retVal);
	      return -VSIS_RET_PARAMETER_ERROR;
	    }

	  if (end_ch < start_ch)
	    {
	      temp = end_ch;
	      end_ch = start_ch;
	      start_ch = temp;
	    }
	  if ((end_ch - start_ch) >=  MAX_OUTPUTS - j)
	    {
	      sprintf(*retVal, "!dbe_ioch_assign=%d:too many inputs!\n", VSIS_RET_PARAMETER_ERROR);
	      *retLen = strlen(*retVal);
	      return -VSIS_RET_PARAMETER_ERROR;
	    }
	  for(k=start_ch; k<=end_ch; k++, j++)
	    outputs[j] = ((inputchannel << 4) | k);
	}
      /* next should be the thread id */
      argPtr = (char *)argv[i+2];
      if (argPtr)
	{
	  threadid = atoi(argPtr);
	  //printf("threadID %d\n", threadid);
	}
      
    }

 bailout:

  /* now our array is ready dump it to the FPGA */
  for(i=0; i<MAX_OUTPUTS; i++)
    {
      retCode = 0;
      if (-1 != outputs[i])
	{
	  /* --- SLEEP BEFORE WRITE, SUCCESSIVE WRITES FAILS */
	  usleep(40);
	  retCode = fpga_set_channel_select(i, outputs[i]);
	}

      if (retCode)
	break;
    }
  
  if (!retCode)
    {
      sprintf(*retVal,"!dbe_ioch_assign=%d;\n", VSIS_RET_SUCCESS);
      ret = VSIS_RET_SUCCESS;
    }
  else
    {
      sprintf(*retVal,"!dbe_ioch_assign=%d:%d;\n", VSIS_RET_EXECUTION_ERROR, retCode);
      ret = -VSIS_RET_EXECUTION_ERROR;
    }

  *retLen = strlen(*retVal);
  return ret;
}

void insert_dbe_ioch_assign_set(void)
{
  // add to the global list of available commands
  char *name = "dbe_ioch_assign";
  char *usage= "dbe_ioch_assign=<input>:<channel(s)>:[threadID]:[<input>]:[<channel>]:[<threadID>];";
  int nParams = 84;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[84];
  int i;

  for(i=0; i<84;i++) 
    paramTypes[i]= CMD_PARAM_STRING;

  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_ioch_assign_set, cmdType);
}

int dbe_ioch_assign_get(int argc, void **argv, void **retVal, int *retLen)
{
  int retCode = 0, ret;
  int i;
  int offset = 0;

  short outputs[MAX_OUTPUTS];

  for(i=0; i<MAX_OUTPUTS; i++)
    outputs[i] = -1;

  for (i=0; i<MAX_OUTPUTS; i++)
    {
      retCode = fpga_get_channel_select(i, (unsigned short *)&outputs[i]);
      if (retCode)
	break;
    }
  
  if (!retCode)
    {
      offset = sprintf(*retVal, "!dbe_ioch_assign?0");
      for(i=0; i<MAX_OUTPUTS;i++)
	if (-1 != outputs[i])
	  offset += sprintf(*retVal+offset, ":%d:%d:-", (outputs[i] & 0x10) >> 4, (outputs[i]&0xf));
      sprintf(*retVal+offset, ":\n");
      ret = VSIS_RET_SUCCESS;      
    }
  else
    {
      sprintf(*retVal,"!dbe_ioch_assign?%d:%d;\n", VSIS_RET_EXECUTION_ERROR, retCode);
      ret = -VSIS_RET_EXECUTION_ERROR;
    }
  
  *retLen = strlen(*retVal);
  return ret;
}

void insert_dbe_ioch_assign_get(void)
{
  // add to the global list of available commands
  char *name = "dbe_ioch_assign";
  char *usage= "dbe_ioch_assign ? ;";
  int nParams = 0;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[] = {};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_ioch_assign_get, cmdType);
}
/***************End IO channel assignemnt **********************/
/****************** XBAR ********************/
int dbe_xbar_set(int argc, void **argv, void **retVal, int *retLen)
{
  short dc[8];
  int retCode, i;

  // initialize variables  
  *retLen = 0;

  for(i=0; i<8; i++)
    {
      dc[i] = -1;

      if (argv[i])
	dc[i] = (short)*(long int*) argv[i];

      if ((dc[i] > 7) || (dc < 0))
	{
	  sprintf(*retVal,"!dbe_xbar=%d:parameter error;\n", VSIS_RET_PARAMETER_ERROR);
	  *retLen = strlen(*retVal);
	  return VSIS_RET_PARAMETER_ERROR;
	}       
    }

  retCode = fpga_xbar_set(dc);

  sprintf(*retVal,"!dbe_xbar=%d;\n", VSIS_RET_SUCCESS);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS;


}
void insert_dbe_xbar_set(void)
{
  // add to the global list of available commands
  char *name = "dbe_xbar";
  char *usage= "dbe_xbar =  <DC0src>:<DC1src>:<DC2src>:<DC3src>:<DC4src>:<DC5src>:<DC6src>:<DC7src>:";
  int nParams = 8;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[8] = {CMD_PARAM_INTEGER, CMD_PARAM_INTEGER, CMD_PARAM_INTEGER, CMD_PARAM_INTEGER,
		       CMD_PARAM_INTEGER, CMD_PARAM_INTEGER, CMD_PARAM_INTEGER, CMD_PARAM_INTEGER};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_xbar_set, cmdType);
}

int dbe_xbar_get(int argc, void **argv, void **retVal, int *retLen)
{
  short dc[8];
  short raw[8];
  int retCode;
  /* int i, k; */

  // initialize variables  
  *retLen = 0;

  memset(dc, 0, 8 * sizeof(short));
  memset(raw, 0, 8 * sizeof(short));
    
  /* retCode = fpga_xbar_get(raw); */
  retCode = fpga_xbar_get(dc);
  if (!retCode)
    {
#if 0
      for (i=0; i<8; i++)
	{
	  if (raw[i])
	    {
	      for (k=0; k<8; k++)
		{
		  if ((raw[i] & (1 << k)) >> k)
		    {
		     dc[k] = i;
		    }
		}
	    }
	}
#endif
      sprintf(*retVal,"!dbe_xbar?%d:%d:%d:%d:%d:%d:%d:%d:%d;\n", 
	      VSIS_RET_SUCCESS,
	      dc[0], dc[1], dc[2], dc[3], dc[4], dc[5], dc[6], dc[7]);
    }
  else
    {
      sprintf(*retVal,"!dbe_xbar?%d:%d;\n", VSIS_RET_EXECUTION_ERROR, retCode);
    }
  *retLen = strlen(*retVal);
  return retCode;
}
void insert_dbe_xbar_get(void)
{
  // add to the global list of available commands
  char *name = "dbe_xbar";
  char *usage= "dbe_xbar ? ";
  int nParams = 0;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[0] = {};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_xbar_get, cmdType);
}

/**************End XBAR *********************/

/*************** DECIMATION RATES ************/
int dbe_ddc_rate_set(int argc, void **argv, void **retVal, int *retLen)
{
  short dc_rate[8] = {0};
  int retCode, i;

  // initialize variables  
  *retLen = 0;
  
  for (i=0; i<8; i++)
    {
      if (argv[i])
	dc_rate[i] = (short)*(long int*) argv[i];
  
      if ((dc_rate[i] < 4) || (dc_rate[i] > 2048))
	{
	  sprintf(*retVal,"!dbe_ddc_rate=%d:parameter error;\n", 
		  VSIS_RET_PARAMETER_ERROR);
	  *retLen = strlen(*retVal);
	  return VSIS_RET_PARAMETER_ERROR;
	}
    }

  retCode = fpga_ddc_rate_set(dc_rate);


  sprintf(*retVal,"!dbe_ddc_rate=%d;\n", VSIS_RET_SUCCESS);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS;
}

/**
 * Definition of the dbe_ddc_rate_set command
 */
void insert_dbe_ddc_rate_set(void)
{
  char *name = "dbe_ddc_rate";
  char *usage= "dbe_ddc_rate = [DC0]:[DC1]:[DC2]:[DC3]:[DC4]:[DC5]:[DC6]:[DC8]";
  int nParams = 8;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[8] = {CMD_PARAM_INTEGER, CMD_PARAM_INTEGER, CMD_PARAM_INTEGER, CMD_PARAM_INTEGER,
		       CMD_PARAM_INTEGER, CMD_PARAM_INTEGER, CMD_PARAM_INTEGER, CMD_PARAM_INTEGER};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_ddc_rate_set, cmdType);
}

int dbe_ddc_rate_get(int argc, void **argv, void **retVal, int *retLen)
{
  short dc_rate[8];
  int retCode, i, offset = 0;

  // initialize variables  
  *retLen = 0;

  retCode = fpga_ddc_rate_get(dc_rate);

  offset += sprintf(*retVal,"!dbe_ddc_rate=%d", VSIS_RET_SUCCESS);
  for (i=0; i<8; i++)
    {
      offset += sprintf(*retVal+offset,":%d", dc_rate[i]);
    }

  offset = sprintf(*retVal+offset,";\n");

  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS;
}

/**
 * Definition of the dbe_ddc_rate_get command
 */
void insert_dbe_ddc_rate_get(void)
{
  char *name = "dbe_ddc_rate";
  char *usage= "dbe_ddc_rate ?";
  int nParams = 0;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[0] = {};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_ddc_rate_get, cmdType);
}

/*************** END DECIMATION **************/

/*************** LO TUNING *******************/

#define TWO_POWER_32           4294967296
#define CLOCK_RATE             256000000
#define ONE_MHZ                1000000
#define TWO_POWER_32_ONE_MHZ   4294967296000000

//#define UP_CONV_LOIF          16777216 /* (2^32*1000000)/256000000 */
//#define DOWN_CONV_LOIF        5.9604644775390625e-08 /* 256000000/(2^32*1000000) */

int dbe_dc_cfg_set(int argc, void **argv, void **retVal, int *retLen)
{
  short dc = 0, rate = 0;
  double freq = 0.0;
  int retCode;
  unsigned long lofreq;

  const unsigned int up_conv_loif = 16777216;
  
  short sb_stat = 0;

  char * ts = (char *)NULL;

  unsigned long tOn = 0;

  // initialize variables  
  *retLen = 0;
  
  if (argv[0])
    dc = (short)*(long int*) argv[0];
  if (argv[1])
    rate = (short)*(long int*) argv[1];
  if (argv[2])
    freq = (double)*(double*) argv[2];

  if (argv[3])
    {
      sb_stat = (short)*(long int*)argv[3];
      sb_stat &= 0x1;
    }

  ts = (char *)argv[4];

  if (ts)
    {
      if (string2JD(ts, &tOn))
	{
	  sprintf(*retVal,"!dbe_dc_cfg?%d;\n", VSIS_RET_PARAMETER_ERROR);
	  *retLen = strlen(*retVal);
	  return -VSIS_RET_PARAMETER_ERROR; /*error */
	}
    }
  else
    {
      sprintf(*retVal, "!dbe_dc_cfg=%d;\n", VSIS_RET_PARAMETER_ERROR);
      *retLen = strlen(*retVal);
      return -VSIS_RET_PARAMETER_ERROR;
    }
#if 0
  if ((dc < 0) || (dc > 7) ||
      (rate < 0) ||
      ((rate <= 8) && ((rate != 1) && (rate != 2) && (rate != 4) && (rate != 8))) || 
      (rate > 2048) ||
      (freq < 0.06) || (freq > 128.0))
    {
      sprintf(*retVal,"!dbe_dc_cfg=%d:parameter error;\n", 
	      VSIS_RET_PARAMETER_ERROR);
      *retLen = strlen(*retVal);
      return VSIS_RET_PARAMETER_ERROR;
    }
#endif
  //lofreq = (freq * TWO_POWER_32_ONE_MHZ)/CLOCK_RATE;
  lofreq = freq * up_conv_loif;

  retCode = fpga_ddc_lo_set_stime(dc, tOn);
  retCode = fpga_ddc_set_sideband_select(dc, sb_stat);
  retCode = fpga_ddc_lo_set(dc, rate, lofreq);
  


  sprintf(*retVal,"!dbe_dc_cfg=%d;\n", VSIS_RET_SUCCESS);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS;
}

/**
 * Definition of the dbe_ddc_rate_set command
 */
void insert_dbe_dc_cfg_set(void)
{
  char *name = "dbe_dc_cfg";
  char *usage= "dbe_dc_cfg = <DC>:<rate>:<LO Frequency>:<SB>:<Ts>;";
  int nParams = 5;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[5] = {CMD_PARAM_INTEGER, CMD_PARAM_INTEGER, CMD_PARAM_REAL, CMD_PARAM_INTEGER, CMD_PARAM_TIME};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_dc_cfg_set, cmdType);
}

int dbe_dc_cfg_get(int argc, void **argv, void **retVal, int *retLen)
{
  short dc_rate[8];
  unsigned long lofreq[8];
  unsigned long tOn[8];
  int retCode, dc, offset = 0;
  char str_time[14] = {};
  short stat = 0;

  const double down_conv_loif = 5.9604644775390625e-08;

  // initialize variables  
  *retLen = 0;

  retCode = fpga_ddc_lo_get(dc_rate, lofreq, tOn);

  retCode = fpga_ddc_get_sideband_select(&stat);

  offset += sprintf(*retVal,"!dbe_dc_cfg=%d", VSIS_RET_SUCCESS);
  for (dc=0; dc<8; dc++)
    {
     
      Bcd2Human(tOn[dc], str_time, 0);
      offset += sprintf(*retVal+offset,":%d:%3.6f:%d:%s", 
			dc_rate[dc], 
			(double)lofreq[dc] * down_conv_loif, 
			(stat & (1 << dc)) >> dc, 
			str_time);
    }

  offset = sprintf(*retVal+offset,";\n");

  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS;
}

/**
 * Definition of the dbe_dc_cfg_get command
 */
void insert_dbe_dc_cfg_get(void)
{
  char *name = "dbe_dc_cfg";
  char *usage= "dbe_dc_cfg ?";
  int nParams = 0;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[0] = {};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_dc_cfg_get, cmdType);
}

int dbe_tsys_diode_ctl_set(int argc, void **argv, void **retVal, int *retLen)
{
  int retCode;
  short diode_period = 80, blank_time = 200;

  if (argv[0])
    diode_period = (short)*(long int*) argv[0];
  if (argv[1])
    blank_time = (short)*(long int*) argv[1];

  // initialize variables  
  *retLen = 0;

  /* retCode = fpga_tsys_diode_ctl_set(diode_period, blank_time); */
  if(argv[0])
       retCode = fpga_tsys_diode_set_period(diode_period); 

  if(argv[1])
       retCode = fpga_tsys_diode_set_blanking(blank_time); 

  sprintf(*retVal,"!dbe_tsys_diode_ctl=%d;\n", VSIS_RET_SUCCESS);

  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS;
}

void insert_dbe_tsys_diode_ctl_set(void)
{
  char *name = "dbe_tsys_diode_ctl";
  char *usage= "dbe_tsys_diode_ctl = <diode_period> : <blank_time>";
  int nParams = 2;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[2] = {CMD_PARAM_INTEGER, CMD_PARAM_INTEGER};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_tsys_diode_ctl_set, cmdType);
}

int dbe_tsys_diode_ctl_get(int argc, void **argv, void **retVal, int *retLen)
{
  int retCode;
  unsigned short dp_round, blank_time;
  unsigned long accum_cnt_on,accum_cnt_off;
  unsigned short da, db, bt;
  unsigned long diode_ab, accum_cnt;
  float diode_period, dp_frac;
  // initialize variables  
  *retLen = 0;

  retCode = fpga_tsys_diode_get_control(&da, &db, &bt, &accum_cnt_on, &accum_cnt_off);
  /* retCode = fpga_tsys_diode_ctl_get(&diode_period, &blank_time, &accum_cnt); */
  
  diode_ab = (db * 65536) + da;
  //printf("diode_ab is %d, da is %d db = %d \n", diode_ab, da, db);
  /* --- round the value */
  if (0 == strcmp("DDC", current_settings.personality_type))
    {
      diode_period = (256e6/(diode_ab+1)) / 2;
    }
  else
    diode_period = (64e6/(diode_ab+1)) / 2;

  dp_frac = diode_period - (int)diode_period; 
  if (dp_frac >= 0.5) dp_round = (int)(diode_period+=1);
  else dp_round = (int)diode_period;
  //printf("diode_period is %f, dp_frac is %f dp_round = %d \n", diode_period, dp_frac, dp_round);

  /* MUST CONVERT THE BLANK TIME GIVEN from clock secs to USECS  */
  if (0 == strcmp("DDC", current_settings.personality_type))
    {
      blank_time = (bt + 1)/256;
    }
  else
    blank_time = (bt + 1)/64; /* --- here chet */

  //printf("blank_time is %d, bt is %d \n", blank_time, bt);
  //printf("dp is %d, bt is %d, ac is %d, \n", dp_round, blank_time, accum_cnt);

  accum_cnt = accum_cnt_on + accum_cnt_off;
  //printf("accum_cnt = %lu, on = %lu, off=%lu\n", accum_cnt, accum_cnt_on, accum_cnt_off);
  sprintf(*retVal,"!dbe_tsys_diode_ctl?%d:%d:%d:%lu;\n", VSIS_RET_SUCCESS,
	  dp_round, blank_time, accum_cnt);

  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS;
}

void insert_dbe_tsys_diode_ctl_get(void)
{
  char *name = "dbe_tsys_diode_ctl";
  char *usage= "dbe_tsys_diode_ctl ?";
  int nParams = 0;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[0] = {};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_tsys_diode_ctl_get, cmdType);
}

/*************** END LO TUNING ***************/

int dbe_ddc_scale_get(int argc, void **argv, void **retVal, int *retLen)
{
  int retCode;
  short scale;
  short dc = 0;

  // initialize variables  
  *retLen = 0;

  if (argv[0])
    dc = (short)*(long int*) argv[0];

  retCode = fpga_ddc_tsys_get_scale(dc, &scale);

  sprintf(*retVal,"!dbe_ddc_scale?%d:%d;\n", VSIS_RET_SUCCESS, scale);

  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS;
}

void insert_dbe_ddc_scale_get(void)
{
  char *name = "dbe_ddc_scale";
  char *usage= "dbe_ddc_scale ?";
  int nParams = 1;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[1] = {CMD_PARAM_INTEGER};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_ddc_scale_get, cmdType);
}

int dbe_ddc_scale_set(int argc, void **argv, void **retVal, int *retLen)
{
  int retCode;
  short scale = 0;
  short chan = 0;

  if (argv[0])
    chan = (short)*(long int*) argv[0];

  if (argv[1])
    scale = (short)*(long int*) argv[1];

  // initialize variables  
  *retLen = 0;

  retCode = fpga_ddc_tsys_set_scale(chan, scale); 

  sprintf(*retVal,"!dbe_ddc_scale=%d;\n", VSIS_RET_SUCCESS);

  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS;
}

void insert_dbe_ddc_scale_set(void)
{
  char *name = "dbe_ddc_scale";
  char *usage= "dbe_ddc_scale = <scale>";
  int nParams = 2;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[2] = {CMD_PARAM_INTEGER, CMD_PARAM_INTEGER};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_ddc_scale_set, cmdType);
}

/********************** FPGA BINARY INFO **************************/

#define TARGET_BORAD_IBOB      0x00
#define TARGET_BORAD_ROACH1    0x01
#define TARGET_BORAD_ROACH2    0x02

#define C_ID_HAYSTACK          0x00
#define C_ID_NRAO              0x01

#define P_TYPE_PFBG_START      (unsigned char)0x00
#define P_TYPE_PFBG_END        (unsigned char)0x7F

#define P_TYPE_DDC_START       (unsigned char)0x80
#define P_TYPE_DDC_END         (unsigned char)0xFF

#define O_FORMAT_MARK5B        0x00

int dbe_fpga_bin_info_get(int argc, void **argv, void **retVal, int *retLen)
{
  int retCode;
  char t_board[10];
  char c_id[10];
  char p_type[10];
  char format[10];

  FPGA_BIN_INFO fpga_info;

  
  retCode = fpga_get_fpga_binary_info(&fpga_info);

  if (!retCode)
    {
      switch(fpga_info.target_board)
	{
	case TARGET_BORAD_IBOB:
	  strcpy(t_board, "IBOB");
	  break;
	case TARGET_BORAD_ROACH1:
	  strcpy(t_board, "ROACH1");
	  break;
	case TARGET_BORAD_ROACH2:
	  strcpy(t_board, "ROACH2");
	  break;
	default:
	  strcpy(t_board, "UNKNOWN");
	  break;
	}

      if (C_ID_HAYSTACK == fpga_info.c_id)
	strcpy(c_id, "HAYSTACK");
      else if (C_ID_NRAO == fpga_info.c_id)
	strcpy(c_id, "NRAO");
      else
	strcpy(c_id, "UNKOWN");

      if ((fpga_info.p_type >= P_TYPE_PFBG_START) && 
	  (fpga_info.p_type <= P_TYPE_PFBG_END))
	strcpy(p_type, "PFBG");
      else if ((fpga_info.p_type >= P_TYPE_DDC_START) && 
	       (fpga_info.p_type <= P_TYPE_DDC_END))
	strcpy(p_type, "DDC");
      else
	strcpy(p_type, "UNKOWN");

      if (O_FORMAT_MARK5B == fpga_info.o_format)
	strcpy(format, "MARK5B");
      else
	strcpy(format, "UNKOWN");

      sprintf(*retVal,"!dbe_fpga_bin_info?%d:%s:%s:%d:%d:%d:%s:%d:%s;\n", VSIS_RET_SUCCESS,
	      t_board,
	      c_id,
	      fpga_info.rev_major_int,
	      fpga_info.rev_major_frac,
	      fpga_info.rev_minor,
	      format,
	      fpga_info.p_type,
	      p_type);
      *retLen = strlen(*retVal);
      return VSIS_RET_SUCCESS;
    }
  else
    {
      sprintf(*retVal,"!dbe_fpga_bin_info?%d:%d\n", VSIS_RET_EXECUTION_ERROR, retCode);
      *retLen = strlen(*retVal);
      return VSIS_RET_EXECUTION_ERROR;
    }
}

void insert_dbe_fpga_bin_info_get(void)
{
  char *name = "dbe_fpga_bin_info";
  char *usage= "dbe_fpga_bin_info?";
  int nParams = 0;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[0] = {};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_fpga_bin_info_get, cmdType);
}


int dbe_fpga_sys_status_get(int argc, void **argv, void **retVal, int *retLen)
{
  int retCode;
  unsigned short status = 0;

  
  retCode = fpga_get_fpga_status(&status);

  if (!retCode)
    {
      sprintf(*retVal,"!dbe_fpga_sys_status?%d:%04X;\n", VSIS_RET_SUCCESS, status);
      *retLen = strlen(*retVal);
      return VSIS_RET_SUCCESS;
    }
  else
    {
      sprintf(*retVal,"!dbe_fpga_sys_status?%d:%d\n", VSIS_RET_EXECUTION_ERROR, retCode);
      *retLen = strlen(*retVal);
      return VSIS_RET_EXECUTION_ERROR;
    }
}

void insert_dbe_fpga_sys_status_get(void)
{
  char *name = "dbe_fpga_sys_status";
  char *usage= "dbe_fpga_sys_status?";
  int nParams = 0;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[0] = {};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_fpga_sys_status_get, cmdType);
}

/********************** END FPGA BINARY INFO **********************/

int dbe_ddc_chan_count_set(int argc, void **argv, void **retVal, int *retLen)
{
  int retCode = 0;
  short count = 0;

  if (argv[0])
    count = (short)*(long int*) argv[0];

  // initialize variables  
  *retLen = 0;

  /* retCode = fpga_ddc_set_vdif_Log2NumChan(&count); */

  sprintf(*retVal,"!dbe_ddc_chan_count=%d;\n", VSIS_RET_SUCCESS);

  *retLen = strlen(*retVal);

  return VSIS_RET_SUCCESS;
}

void insert_dbe_ddc_chan_count_set(void)
{
  char *name = "dbe_ddc_chan_count";
  char *usage= "dbe_ddc_chan_count = <count>";
  int nParams = 1;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[1] = {CMD_PARAM_INTEGER};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_ddc_chan_count_set, cmdType);
}


int dbe_ddc_bits_sample_set(int argc, void **argv, void **retVal, int *retLen)
{
  int retCode;
  int i;
  short bs[8];

  for(i=0; i<8; i++)
    if (argv[i])
      bs[i] = (short)*(long int*) argv[i];
    else
      bs[i] = 0;

  // initialize variables  
  *retLen = 0;

  retCode = fpga_ddc_set_vdif_Bits_Per_Sample(bs); 

  sprintf(*retVal,"!dbe_ddc_bits_sample=%d;\n", VSIS_RET_SUCCESS);

  *retLen = strlen(*retVal);

  return VSIS_RET_SUCCESS;
}

void insert_dbe_ddc_bits_sample_set(void)
{
  char *name = "dbe_ddc_bits_sample";
  char *usage= "dbe_ddc_bits_sample = <bs0><bs1><bs2><bs3>";
  int nParams = 8;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[8] = {CMD_PARAM_INTEGER, CMD_PARAM_INTEGER, CMD_PARAM_INTEGER, CMD_PARAM_INTEGER,
		       CMD_PARAM_INTEGER, CMD_PARAM_INTEGER, CMD_PARAM_INTEGER, CMD_PARAM_INTEGER};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_ddc_bits_sample_set, cmdType);
}


int dbe_vdif_threads_id_set(int argc, void **argv, void **retVal, int *retLen)
{
  int retCode;
  int i;
  short thids[8];

  for(i=0; i<8; i++)
    if (argv[i])
      thids[i] = (short)*(long int*) argv[i];
    else
      thids[i] = 0;

  // initialize variables  
  *retLen = 0;

  retCode = fpga_ddc_set_vdif_thread_ids(thids); 

  sprintf(*retVal,"!dbe_vdif_threads_id=%d;\n", VSIS_RET_SUCCESS);

  *retLen = strlen(*retVal);

  return VSIS_RET_SUCCESS;
}

void insert_dbe_vdif_threads_id_set(void)
{
  char *name = "dbe_vdif_threads_id";
  char *usage= "dbe_vdif_threads_id = <thid0><thid1><thid2><thid3><thid4><thid5><thid6><thid7>";
  int nParams = 8;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[8] = {CMD_PARAM_INTEGER, CMD_PARAM_INTEGER, CMD_PARAM_INTEGER, CMD_PARAM_INTEGER,
		       CMD_PARAM_INTEGER, CMD_PARAM_INTEGER, CMD_PARAM_INTEGER, CMD_PARAM_INTEGER};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_vdif_threads_id_set, cmdType);
}


//// ADDED FOR RMS MONITOR TEST
#define RMS_MON_PORT 20030
#define PWR_DATA_MAX 8192

int multicast_var = 0;

//sem_t mon_var_sem;

float cur_rms[2];
float cur_mean[2];
int cur_max[2];

unsigned char fast_raw_samples[PWR_DATA_MAX];
double d_fast_raw_samples[PWR_DATA_MAX];

/* Return the k-th smallest item in array x of length len */
double quick_select(int k, double *x, int len)
{
  inline void swap(int a, int b)
    {
      double t = x[a];
      x[a] = x[b], x[b] = t;
    }
  
  int left = 0, right = len - 1;
  int pos, i;
  double pivot;
 
  while (left < right)
    {
      pivot = x[k];
      swap(k, right);
      for (i = pos = left; i < right; i++)
	{
	  if (x[i] < pivot)
	    {
	      swap(i, pos);
	      pos++;
	    }
	}
      swap(right, pos);
      if (pos == k) break;
      if (pos < k) left = pos + 1;
      else right = pos - 1;
    }
  return x[k];
}

#define SUNBEGIN  40587  /* MJD of Jan 1, 1970 */
#define SEC_DAY    86400 /* seconds per day */

double timeStamp()
{
  struct timeval tv;
  double now_time;

  gettimeofday(&tv, NULL);

  now_time = (double)tv.tv_sec +  (double)tv.tv_usec*0.000001;

  return (now_time/SEC_DAY + SUNBEGIN);
}

void *var_monitor(void *arg)
{
  double si = 0.0;
  double ss = 0.0;
  int comp;
  
  int max[2] = {0, 0};

  int j, ifr;
  int cntr = 0;
  int rc, status;
  struct timespec abs_timeout, rem;

  double var_data[2];
  double var_time_stamp[2];
  double mad[2];
  double median;

  float l_cur_mean[2];
  int l_cur_max[2];

  int fd;
  struct sockaddr_in rms_mon_client_addr;
  struct sockaddr_in rms_mon_server_addr;

  unsigned int rms_mup[4] = {239,193,2,30};

  int ip[4];

  char msg[128];

  clock_t start;
  double duration;

  abs_timeout.tv_sec = 0;
  //abs_timeout.tv_nsec = 1000000; /* 1 ms */
  abs_timeout.tv_nsec = 100000000; /* 100 ms */

#if 0
  status = sem_init(&mon_var_sem, 0, 0);
  if (-1 == status)
    perror("mon_var_sem");
#endif

  sscanf(roach_ip, "%d.%d.%d.%d", &ip[0], &ip[1], &ip[2], &ip[3]);
  /* Special case for ATR & DEV */
  if ((77 == ip[3]) || (79 == ip[3]))
    {
      if (79 == ip[3])
	rms_mup[3] += 1;
    }
  else if (13 == ip[3])
    rms_mup[3] += 1;

  fd = setupMulticast(&rms_mon_server_addr,
		      &rms_mon_client_addr,
		      rms_mup,
		      RMS_MON_PORT);

  if (fd < 0)
    fd = 0;

  while(1)
    {      
      /* from now on every 100 ms compute variance */	  
      for (ifr=0; ifr<2; ifr++)
	{
	  max[ifr] = 0;
	  pthread_mutex_lock(&mutexDataCollection);

	  start = clock();

	  status = bp_grab_raw_data(ifr, fast_raw_samples);

	  duration = ((double)(clock() - start)/CLOCKS_PER_SEC);
	  /* store the timestamp */
	  var_time_stamp[ifr] = timeStamp();
	  
	  pthread_mutex_unlock(&mutexDataCollection);

	  si = 0.0;
	  ss = 0.0;
	  
	  for (j=0; j<PWR_DATA_MAX; j++)
	    {
	      comp = fast_raw_samples[j] - 128;
	      if (comp > max[ifr])
		max[ifr] = comp;

	      si += comp;
	      ss += comp*comp;
	    }
	  
	  ss /= PWR_DATA_MAX;
	  si /= PWR_DATA_MAX;
	  
	  var_data[ifr] = sqrt(ss-si*si);
	  l_cur_mean[ifr] = si;
	  l_cur_max[ifr] = max[ifr];
            
	  if ( multicast_var) /* only do this when asked to multicast */
	    {
	      /* compute MAD: MAD = median (|Xi - median(Xj)|) */
	      for (j=0; j<PWR_DATA_MAX; j++)
		{
		  d_fast_raw_samples[j] = (double)fast_raw_samples[j];
		}
	      
	      median = (quick_select(4096, d_fast_raw_samples, 8192) + quick_select(4095, d_fast_raw_samples, 4096))/2;
	      
	      for (j=0; j<PWR_DATA_MAX; j++)
		{
		  d_fast_raw_samples[j] = fabs(d_fast_raw_samples[j] - median);
		}
	      mad[ifr] = (quick_select(4096, d_fast_raw_samples, PWR_DATA_MAX) + quick_select(4095, d_fast_raw_samples, 4096))/2;
	    } /* if ( multic... */
	} /* for(ifr=0... */

      pthread_mutex_lock(&mutex_rms);
      for(j=0; j<2; j++)
	{
	  cur_rms[j] =  var_data[j];
	  cur_mean[j] = l_cur_mean[j];
	  cur_max[j] = l_cur_max[j];
	}
      pthread_mutex_unlock(&mutex_rms);

      if ( multicast_var) /* only do this when asked to multicast */
	{
	  sprintf(msg, "%5.10f,%5.5f,%5.5f,%5.5f,%5.5f,%5.7f", 
		  var_time_stamp[0], var_data[0], mad[0], var_data[1], mad[1], duration);
	  rc = sendto(fd, 
		      (char *)msg, /* &var_data, */
		      strlen(msg), /* sizeof(var_data), */
		      0, 
		      (struct sockaddr*)&rms_mon_client_addr,
		      sizeof(struct sockaddr_in));
	  if (rc < 0)
	    perror("sendto");
	}/* if ( multic... */
      
      nanosleep(&abs_timeout, &rem);
    } /* while (1... */
}

int dbe_var_mon(int argc, void **argv, void **retVal, int *retLen)
{
  // initialize variables
  int retCode = 0;
  int cmd;


  if (!argv[0])
    {
      sprintf(*retVal,"!dbe_var_mon=%d;\n", VSIS_RET_PARAMETER_ERROR);
      retCode = VSIS_RET_PARAMETER_ERROR;
    }
  else
    {
      cmd = (int)*(unsigned long*)argv[0];
      if ((cmd > 1) || (cmd < 0))
	{
	  sprintf(*retVal,"!dbe_var_mon=%d;\n", VSIS_RET_PARAMETER_ERROR);
	  *retLen = strlen(*retVal);
	  retCode = -VSIS_RET_PARAMETER_ERROR;
	}
      
      multicast_var = cmd;
      
      sprintf(*retVal,"!dbe_var_mon=%d;\n", VSIS_RET_SUCCESS);
      
      *retLen = strlen(*retVal);      
    }
  return retCode;
}


void insert_dbe_var_mon(void)
{
  // add to the global list of available commands
  char *name = "dbe_var_mon";
  char *usage= "dbe_var_mon=<cmd>;";
  int nParams = 1;
  int cmdType = CMD_VSIS_COMMAND;
  int paramTypes[1] = {CMD_PARAM_UNSIGNEDLONG};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_var_mon, cmdType);
}

int dbe_rms(int argc, void **argv, void **retVal, int *retLen)
{
  // initialize variables
  int retCode = 0;

  pthread_mutex_lock(&mutex_rms);
  sprintf(*retVal,"!dbe_rms=%d:%.3f:%.3f:%.3f:%.3f:%d:%d;\n", VSIS_RET_SUCCESS, 
	  cur_rms[0], cur_rms[1],
	  cur_mean[0], cur_mean[1],
	  cur_max[0], cur_max[1]);
	  
  pthread_mutex_unlock(&mutex_rms);

  *retLen = strlen(*retVal);      
  
  return retCode;
}


void insert_dbe_rms(void)
{
  // add to the global list of available commands
  char *name = "dbe_rms";
  char *usage= "dbe_rms ? ";
  int nParams = 0;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[] = {};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_rms, cmdType);
}

// END RMS MONIUTOR TEST

#ifdef _PCAL_ /* it will never be defined. */

void insert_dbe_pcal_set(void);
void insert_dbe_pcal_get(void);

#endif

/**
 * Initializes command lists with basic command set
 */
void cmd_base_initialize(void)
{
  insert_dbe_list_cmd();
  insert_dbe_help_cmd();
  insert_dbe_arp_get();
  insert_dbe_arp_set();
  insert_dbe_data_connect_get();
  insert_dbe_data_connect_set();
  insert_dbe_data_format_get();
  insert_dbe_data_format_set();
  insert_dbe_data_send_get();
  insert_dbe_data_send_set();
  insert_dbe_dot();
  insert_dbe_dot_inc_get();
  insert_dbe_dot_inc_set();
  insert_dbe_dot_get();
  insert_dbe_dot_set();
  insert_dbe_dot_set_nw();
  insert_dbe_hw_version_get();
  insert_dbe_ifconfig_get();
  insert_dbe_ifconfig_set();

  insert_dbe_mac_set();
  insert_dbe_mac_get();

  insert_dbe_init_set();
  insert_dbe_opt_level_get();
  insert_dbe_opt_level_set();
  insert_dbe_packet_get();
  insert_dbe_packet_set();
  insert_dbe_personality_get();
  insert_dbe_personality_set();
  insert_dbe_quantize_get();
  insert_dbe_quantize_set();

  insert_dbe_ddc_quantize_set();
  insert_dbe_ddc_quantize_get();

  insert_dbe_ddc_quantize_hold_set();
  insert_dbe_ddc_quantize_hold_get();

  insert_dbe_xbar_set();
  insert_dbe_xbar_get();

  insert_dbe_ddc_rate_set();
  insert_dbe_ddc_rate_get();

  insert_dbe_dc_cfg_set();
  insert_dbe_dc_cfg_get();

  insert_dbe_tsys_diode_ctl_set();
  insert_dbe_tsys_diode_ctl_get();

  insert_dbe_ddc_scale_get();
  insert_dbe_ddc_scale_set();

  insert_dbe_ddc_chan_count_set();

  insert_dbe_ddc_bits_sample_set();
  insert_dbe_vdif_threads_id_set();

  insert_dbe_fpga_bin_info_get();
  insert_dbe_fpga_sys_status_get();

  insert_dbe_reset_set();
  insert_dbe_status_get();
  insert_dbe_sw_version_get();
  insert_dbe_tid2addr_get();
  insert_dbe_tid2addr_set();

  /* added is support of channel assignment */
  insert_dbe_ioch_assign_set();
  insert_dbe_ioch_assign_get();

  /* added in support of the ALC */
  insert_dbe_alc_set();
  insert_dbe_alc_get();

  insert_dbe_alc_fpgaver_get();

  insert_dbe_fs_set();
  insert_dbe_fs_get();

#ifdef _FFT_SUPPORT_
  insert_dbe_raw_capture();
  insert_dbe_fft_capture();
#endif
  insert_dbe_execute();

  /* added in support for the 1pps */
  insert_dbe_1pps_mon_set();
  insert_dbe_1pps_mon_get();

  /* added in support for Tsys */
  insert_dbe_tsys_mon_set();
  insert_dbe_tsys_mon_get();

  insert_dbe_tsys_conf_set();
  insert_dbe_tsys_conf_get();

  insert_dbe_ipps_get();
  insert_dbe_ipps_set();

  insert_dbe_rms();
  insert_dbe_var_mon();

#ifdef _PCAL_
  insert_dbe_pcal_set();
  insert_dbe_pcal_get();
#endif

  // remove below
  insert_bc_mode_get();
  insert_bc_mode_set();
  insert_dbe_clock_get();
  insert_dbe_clock_set();
};

/*
 * save settings for later use.
 * filename should be .rdbe_serial#
 */
int saveSettings(void)
{
  FILE * set_fp = (FILE *)NULL;
  char filename[MAX_FILE_NAME_LEN] = {0};

  sprintf(filename, "/home/roach/.rdbe_%s", roach_ip);

  /* guard access to the settings file */
  pthread_mutex_lock(&mutexSettings);
  set_fp = fopen(filename, "w");
  if ((FILE *)NULL == set_fp)
    {
      /* error */
      return 1;
    }

  /* write our settings structure into the file */
  /*
   * What to save?:
   *    if (up/down)
   *    personality
   *    type is it needed?
   */

  fprintf(set_fp, "ifstate=%d\n", current_settings.ifstate);
  fprintf(set_fp, "personality_load=%d\n", current_settings.personality_load_status);
  fprintf(set_fp, "personality=%s\n", current_settings.personality_file_name);
  fprintf(set_fp, "personality_type=%s\n", current_settings.personality_type);

  fclose(set_fp);

  pthread_mutex_unlock(&mutexSettings);

  return 0;
}

int setupVdifStationID()
{
  int ip[4];
  short st_id, db_n;
  /* set up specific things for VDIF: Station ID, DBE NUM etc...*/
  sscanf(roach_ip, "%d.%d.%d.%d", &ip[0], &ip[1], &ip[2], &ip[3]);
  st_id = 100-ip[2];
  fpga_ddc_set_vdif_StationID(&st_id);
  db_n = ip[3]-11; 
  fpga_ddc_set_vdif_DBEnum(&db_n);

  return 0;
}

int LoadSavedSettings(void)
{
  FILE * set_fp = (FILE *)NULL;
  char filename[MAX_FILE_NAME_LEN] = {0};
  char line[MAX_FILE_NAME_LEN];
  char cmd[MAX_FILE_NAME_LEN];
  int retCode = -1;
  int status, n, os_diff;
  struct sysinfo sys_info;

  char *ptr[6];
  int init_cntr = 0;


  memset(&current_settings, '\0', sizeof(rdbe_settings_t));

  /* this get's called first */
  status = sem_init(&dot_set_ops, 0, 0);
  if (-1 == status)
    perror("dot_set_ops");

  /* start the dot set Thread */
  if (0 != pthread_create(&dot_set_task, 0, dotset_thread, 0))
    fprintf(logfp, "Failed to start dot set task.\n");
  else
    fprintf(logfp, "dot set task started.\n");  

  /* prepare the personality cmd for default setup */
  memset(cmd, '\0', MAX_FILE_NAME_LEN * sizeof(char));
  sprintf(cmd, "dbe_personality=PFBG:PFBG_1_5_0.bin;");

  sprintf(filename, "/home/roach/.rdbe_%s", roach_ip);
  
  set_fp = fopen(filename, "r");  

  if ((FILE *)NULL != set_fp)
    {
      /* Load the saved settings */
      while(1)
	{
	  memset(line, '\0', MAX_FILE_NAME_LEN * sizeof(char));
	  if ((char *)NULL == fgets(line, MAX_FILE_NAME_LEN, set_fp))
	    break;
	  
	  if (0 == strncasecmp(line, "ifstate=", 8))
	    sscanf(line, "ifstate=%d\n", &current_settings.ifstate);
	  else if (0 == strncasecmp(line, "personality_load=", 17))
	    sscanf(line, "personality_load=%d\n", &current_settings.personality_load_status);
	  else if (0 == strncasecmp(line, "personality=", 12))
	    sscanf(line, "personality=%s\n", current_settings.personality_file_name);
	  else if (0 == strncasecmp(line, "personality_type=", 17))
	    sscanf(line, "personality_type=%s\n", current_settings.personality_type);
	}
      
      fclose(set_fp);
      
      if (current_settings.personality_load_status)
	{
	  /* only do this when the system has been booted recentely */
	  status = sysinfo(&sys_info);
	  if (0 == status)
	    {
	      if (sys_info.uptime > 600) /* don't reload it. */
		goto bailout;
	    }
	  if (('\0' != current_settings.personality_file_name[0]) &&
	      ('\0' != current_settings.personality_type))
	    sprintf(cmd, "dbe_personality=%s:%s;", 
		    current_settings.personality_type, 
		    current_settings.personality_file_name);     
	}
    } 
  /* now we do the setup */
  retCode = processCmd(cmd);
  /*
   * 06.17.2015 Trying to get around sometimes the rdbeserver is stuck
   * wating on the 1PPS interrupt.
   */
  sleep(10);
  while(1) /* do this till clock is in sync */
    {
#if 0
      while(1)
	{
	  fprintf(logfp, "one load\n");
	  /* now we do the setup */
	  retCode = processCmd(cmd);
	  if (0 == retCode)
	    break;	  
	  sleep(10);
	}
#endif      
      /* we need to init the FPGA using the powerup init script version */
      retCode = processCmd("dbe_execute=powerup;");
      if (-1 == retCode)
	fprintf(logfp, "dbe_execute=powerup -1\n");
      sleep(1);
      fpga_set_1pps_status(1);
#if 0 /* no need since we don't wait for it. */
      /* enable the 1pps interrupt. Though it is already done at the end of dbe_Execute=init */
      sleep(1);
#endif
      /* we need to set the clock */
      retCode = processCmd("dbe_dot_set=;");

      /* 
       * this is preventing the server from coming up when the FPGA fails
       * to generate the 1PPS interrupt. Let's just sleep for 1 second instead.
       */

#if 0
      fpga_isr_rd();
#else
      sleep(1);
#endif
      memset(respBuf, '\0', MAX_FILE_NAME_LEN * sizeof(char));
      /* check the dot time, if in sync bail out */
      retCode = processCmd("dbe_dot?;");
      /* check response */
      n = messageparse(respBuf, ptr, 6);
      if (ptr[4])
	{
	  os_diff = atoi(ptr[4]);
	  if (0 == os_diff)
	    break;
	}

      if (init_cntr++ > 5) /* we're not going to do this for ever */
	break;
    }

 bailout:
  setupVdifStationID();


  // MAYBE ONLY FOR TESTING
  /* start the rms (variance) monitor Thread */
  if (0 != pthread_create(&var_mon_task, 0, var_monitor, 0))
    fprintf(logfp, "Failed to start Var Mon task.\n");
  else
    fprintf(logfp, "Var Mon task started.\n");
  // ENDS HERE
#if 0
  // Added for PCAL */
  if (0 != pthread_create(&pcal_task, 0, pcal_thread, 0))
    fprintf(logfp, "Failed to start Pcal task.\n");
  else
    fprintf(logfp, "Pcal task started.\n");
#endif
  return 0;
}

/*
 * Retreive the IP address of the RDBE.
 * return: string representing the IP address in format xxx.xxx.xxx.xxx
 *         NULL if not found.
 */

char * getmyIP(void)
{
  int so;
  struct if_nameindex *pidx, *pidx2;
  struct ifreq req;

  if ((so = socket(PF_INET, SOCK_DGRAM, 0)) < 0)
    {
      perror("socket");
      return NULL;
    }
   
   pidx = pidx2 = if_nameindex();
   while ((pidx != NULL) && (pidx->if_name != NULL))
   {
     if (0 == strcmp("eth0", pidx->if_name))
       {
	 strncpy(req.ifr_name, pidx->if_name, IFNAMSIZ);
	 if (ioctl(so, SIOCGIFADDR, &req) < 0)
	   {
	     if (errno == EADDRNOTAVAIL)
	       {
		 pidx++;
		 continue;
	       }
	     perror("ioctl");
	     close(so);
	     if_freenameindex(pidx2);
	     return NULL;
	   }
	 close(so);
	 if_freenameindex(pidx2);
	 return inet_ntoa(((struct sockaddr_in*)&req.ifr_addr)->sin_addr);
       }
     pidx++;
   }
   if_freenameindex(pidx2);
   close(so);
   return NULL;
}

#if 0

void *mib_raw_capture_thread(void *arg)
{
  int lfd;
  int fd;
  int optval = 1; // reuse option for the port number
  int status;
  int clilen;
  int ret = -1;
  int ifreq;

  char buf[10];

  struct sockaddr_in serv_addr;
  struct sockaddr_in client;

  fd_set rfds;
  struct timeval tv;
  int retval;

  ssize_t rc;

  // try to open streaming socket default protocol (tcp)
  lfd = socket(AF_INET, SOCK_STREAM, 0);
  if(lfd <= 0)
    pthread_exit(&ret);
  
  /* set the reuse option to avoid EADDRINUSE error */
  setsockopt(lfd, SOL_SOCKET,SO_REUSEADDR,&optval,sizeof(int));
  
  bzero((char *) &serv_addr, sizeof(serv_addr));
  serv_addr.sin_family      = AF_INET;
  serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
  serv_addr.sin_port        = htons(5020);
  
  status = bind(lfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr));
  if (status < 0)
    {
      perror("mib_raw_capture server thread bind");
      pthread_exit(&ret);
    }

  status = listen( lfd, 2);
  if( status < 0 )
    { 
      perror( "listen" ); 
      pthread_exit(&ret); 
    }
 
  while(1)
    {
      clilen = sizeof( client );
      fd = accept(lfd, (struct sockaddr *)&client, (socklen_t *)&clilen);
      if(fd < 0 )
	{
	  if( errno == EINTR ) continue;
	  perror("mib_raw_capture server thread accept");
	  pthread_exit(&ret);
	}
      else
	{
	  /* first we need to get the if to collect data for */
	  FD_ZERO(&rfds);
	  FD_SET(fd, &rfds);

	  /* Wait up to 10 seconds. */
	  tv.tv_sec = 10;
	  tv.tv_usec = 0;
	  
	  retval = select(fd+1, &rfds, NULL, NULL, &tv);
	  switch(retval)
	    {
	    case -1:
	    case 0:
	      /* we timed out or error. Close connx and return */
	      break;
	    default:
	      /* we got data: read the if value  */
	      memset(buf, '\0', 10);
	      rc = recv(fd,(void *)buf, 1, 0);
	      if (rc > 0)
		{
		  ifreq = atoi(buf);
		  if ((0 == ifreq) || (1 == ifreq))
		    {
		      fcntl(fd, F_SETFL, O_NONBLOCK);
		      mib_socket_dbe_raw_capture(fd, ifreq, mib_raw_samples, RAW_SAMPLES_MAX);
		    }
		}
	      break;	      
	    }
	  close(fd);
	}     
    }
}

#else

void *mib_raw_capture_thread(void *arg)
{
  int lfd;
  int fd;
  int optval = 1; // reuse option for the port number
  int status;
  int clilen;
  int ret = -1;
  int ifreq;

  char buf[10];

  struct sockaddr_in serv_addr;
  struct sockaddr_in client;

  fd_set rfds;
  struct timeval tv;
  int retval;

  ssize_t rc;

  // try to open streaming socket default protocol (tcp)
  lfd = socket(AF_INET, SOCK_STREAM, 0);
  if(lfd <= 0)
    pthread_exit(&ret);
  
  /* set the reuse option to avoid EADDRINUSE error */
  setsockopt(lfd, SOL_SOCKET,SO_REUSEADDR,&optval,sizeof(int));
  
  bzero((char *) &serv_addr, sizeof(serv_addr));
  serv_addr.sin_family      = AF_INET;
  serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
  serv_addr.sin_port        = htons(5020);
  
  status = bind(lfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr));
  if (status < 0)
    {
      perror("mib_raw_capture server thread bind");
      pthread_exit(&ret);
    }

  status = listen( lfd, 2);
  if( status < 0 )
    { 
      perror( "listen" ); 
      pthread_exit(&ret); 
    }
 
  while(1)
    {
      clilen = sizeof( client );
      fd = accept(lfd, (struct sockaddr *)&client, (socklen_t *)&clilen);
      if(fd < 0 )
	{
	  if( errno == EINTR ) continue;
	  perror("mib_raw_capture server thread accept");
	  continue;
	}
      /* service this connection till dropped */
      while(1)
	{
	  memset(buf, '\0', 10);
	  rc = recv(fd,(void *)buf, 1, 0);
	  if (rc <= 0)
	    break;
	  if (rc > 0)
	    {
	      ifreq = atoi(buf);
	      if ((0 == ifreq) || (1 == ifreq))
		mib_socket_dbe_raw_capture(fd, ifreq, mib_raw_samples, RAW_SAMPLES_MAX);
	    }
	}
      close(fd);     
    }
}
#endif

#if 0
void *raw_capture_thread(void *arg)
{
  int lfd;
  int fd;
  int optval = 1; // reuse option for the port number
  int status;
  int clilen;
  int ret = -1;
  int ifreq;

  char buf[10];

  struct sockaddr_in serv_addr;
  struct sockaddr_in client;

  fd_set rfds;
  struct timeval tv;
  int retval;

  ssize_t rc;

  // try to open streaming socket default protocol (tcp)
  lfd = socket(AF_INET, SOCK_STREAM, 0);
  if(lfd <= 0)
    pthread_exit(&ret);
  
  /* set the reuse option to avoid EADDRINUSE error */
  setsockopt(lfd, SOL_SOCKET,SO_REUSEADDR,&optval,sizeof(int));
  
  bzero((char *) &serv_addr, sizeof(serv_addr));
  serv_addr.sin_family      = AF_INET;
  serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
  serv_addr.sin_port        = htons(5050);
  
  status = bind(lfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr));
  if (status < 0)
    {
      perror("raw_capture server thread bind");
      pthread_exit(&ret);
    }

  status = listen( lfd, 2);
  if( status < 0 )
    { 
      perror( "listen" ); 
      pthread_exit(&ret); 
    }
 
  while(1)
    {
      clilen = sizeof( client );
      fd = accept(lfd, (struct sockaddr *)&client, (socklen_t *)&clilen);
      if(fd < 0 )
	{
	  if( errno == EINTR ) continue;
	  perror("raw_capture server thread accept");
	  pthread_exit(&ret);
	}
      else
	{
	  /* first we need to get the if to collect data for */
	  FD_ZERO(&rfds);
	  FD_SET(fd, &rfds);

	  /* Wait up to 10 seconds. */
	  tv.tv_sec = 10;
	  tv.tv_usec = 0;
	  
	  retval = select(fd+1, &rfds, NULL, NULL, &tv);
	  switch(retval)
	    {
	    case -1:
	    case 0:
	      /* we timed out or error. Close connx and return */
	      break;
	    default:
	      /* we got data: read the if value  */
	      memset(buf, '\0', 10);
	      rc = recv(fd,(void *)buf, 1, 0);
	      if (rc > 0)
		{
		  ifreq = atoi(buf);
		  if ((0 == ifreq) || (1 == ifreq)) /* bpplotter only take 8192 bytes */
		    socket_dbe_raw_capture(fd, ifreq, raw_samples, 8192);
		}
	      break;	      
	    }
	  close(fd);
	}     
    }
}
#endif
/*
 * This version takes as input the IF and the number of sweeps.
 */
void *raw_capture_thread(void *arg)
{
  int lfd;
  int fd;
  int optval = 1; // reuse option for the port number
  int status;
  int clilen;
  int ret = -1;
  int ifreq;

  char buf[32];

  struct sockaddr_in serv_addr;
  struct sockaddr_in client;

  fd_set rfds;
  struct timeval tv;
  int retval, i;

  ssize_t rc;
  int sweeps;

  // try to open streaming socket default protocol (tcp)
  lfd = socket(AF_INET, SOCK_STREAM, 0);
  if(lfd <= 0)
    pthread_exit(&ret);
  
  /* set the reuse option to avoid EADDRINUSE error */
  setsockopt(lfd, SOL_SOCKET,SO_REUSEADDR,&optval,sizeof(int));
  
  bzero((char *) &serv_addr, sizeof(serv_addr));
  serv_addr.sin_family      = AF_INET;
  serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
  serv_addr.sin_port        = htons(5050);
  
  status = bind(lfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr));
  if (status < 0)
    {
      perror("raw_capture server thread bind");
      pthread_exit(&ret);
    }

  status = listen( lfd, 2);
  if( status < 0 )
    { 
      perror( "listen" ); 
      pthread_exit(&ret); 
    }
 
  while(1)
    {
      clilen = sizeof( client );
      fd = accept(lfd, (struct sockaddr *)&client, (socklen_t *)&clilen);
      if(fd < 0 )
	{
	  if( errno == EINTR ) continue;
	  perror("raw_capture server thread accept");
	  pthread_exit(&ret);
	}
      else
	{
	  /* first we need to get the if to collect data for */
	  FD_ZERO(&rfds);
	  FD_SET(fd, &rfds);

	  /* Wait up to 10 seconds. */
	  tv.tv_sec = 10;
	  tv.tv_usec = 0;
	  
	  retval = select(fd+1, &rfds, NULL, NULL, &tv);
	  switch(retval)
	    {
	    case -1:
	    case 0:
	      /* we timed out or error. Close connx and return */
	      break;
	    default:
	      /* we got data: read the if value  */
	      memset(buf, '\0', 32);
	      rc = recv(fd,(void *)buf, 32, 0);
	      if (rc > 0)
		{
		  //ifreq = atoi(buf);
		  retval = sscanf(buf, "%d %d", &ifreq, &sweeps);
		  if (retval != 2)
		    {
		      close(fd);
		      continue;
		    }
		  if ((0 == ifreq) || (1 == ifreq)) /* bpplotter only take 8192 bytes */
		    {
		      for(i=0; i<sweeps; i++)
			socket_dbe_raw_capture(fd, ifreq, raw_samples, 8192);
		    }
		}
	      break;	      
	    }
	  close(fd);
	}     
    }
}

#ifdef _PCAL_ /* Never defined! According to Mat it will be handled by the xcube */
/*
 * Part of PCAL module.
 */

#define TWO_2_49              562949953421312
#define PCAL_START_ADDR       0xA00000
#define PCAL_END_ADDR         0xA00FFF

sem_t sem_pcal;

int dbe_pcal_set(int argc, void **argv, void **retVal, int *retLen)
{
  unsigned short intFreq;
  unsigned long long phi_inc_reg;
  unsigned short value;

  if (argv[0])
    {
      intFreq = (unsigned short)*(unsigned long*)argv[0];
      if ((intFreq != 1) && (intFreq != 5))
	{
	  sprintf(*retVal,"!dbe_pcal%d:only 1 or 5;\n", VSIS_RET_PARAMETER_ERROR);
	  *retLen = strlen(*retVal);
	  return -VSIS_RET_PARAMETER_ERROR;
	}
    }
  else
    {
      sprintf(*retVal,"!dbe_pcal%d:input required;\n", VSIS_RET_PARAMETER_ERROR);
      *retLen = strlen(*retVal);
      return -VSIS_RET_PARAMETER_ERROR;
    }

  phi_inc_reg = intFreq * 2199023.255552; /* 256000000) * TWO_2_49; */

  value = phi_inc_reg & 0xFFFF;
  util_write_short_fpga(0xA00000, 1, &value);

  value = (phi_inc_reg & 0xFFFF0000) >> 16;
  util_write_short_fpga(0xA00001, 1, &value);

  value = (phi_inc_reg & 0xFFFF00000000) >> 32;
  util_write_short_fpga(0xA00002, 1, &value);

  sprintf(*retVal,"!dbe_pcal%d;\n", VSIS_RET_SUCCESS);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS;
}
void insert_dbe_pcal_set(void)
{
   // add to the global list of available commands
   char *name = "dbe_pcal";
   char *usage= "dbe_pcal=<freq>;";
   int nParams = 1;
   int cmdType = CMD_VSIS_COMMAND;
   int paramTypes[1] = {CMD_PARAM_UNSIGNEDLONG};
   cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_pcal_set, cmdType);
}

int dbe_pcal_get(int argc, void **argv, void **retVal, int *retLen)
{
  sem_post(&sem_pcal);
  sprintf(*retVal,"!dbe_pcal?%d;\n", VSIS_RET_SUCCESS);
  *retLen = strlen(*retVal);
  return VSIS_RET_SUCCESS;
}

void insert_dbe_pcal_get(void)
{
  // add to the global list of available commands
  char *name = "dbe_pcal";
  char *usage= "dbe_pcal?";
  int nParams = 0;
  int cmdType = CMD_VSIS_QUERY;
  int paramTypes[0] = {};
  cmd_insert_cmd_desc(name, usage, nParams, paramTypes, dbe_pcal_get, cmdType);
}



#define PCAL_PORT 20040

unsigned int pcal_data[0x400];

void *pcal_thread(void *arg)
{
  int fd;
  struct sockaddr_in pcal_client_addr;
  struct sockaddr_in pcal_server_addr;
  unsigned int offset;
  int i, rc;
  unsigned short lo, hi;

  clock_t start;
  double duration;

  unsigned int pcal_mup[4] = {239,193,2,40};
  int ip[4];

  rc = sem_init(&sem_pcal, 0, 0);
  if (-1 == rc)
    perror("sem_pcal");

  sscanf(roach_ip, "%d.%d.%d.%d", &ip[0], &ip[1], &ip[2], &ip[3]);
  /* Special case for ATR & DEV */
  if ((77 == ip[3]) || (79 == ip[3]))
    {
      if (79 == ip[3])
	pcal_mup[3] += 1;
    }
  else if (13 == ip[3])
    pcal_mup[3] += 1;

  /* set up the multicast IP */
  fd = setupMulticast(&pcal_server_addr,
		       &pcal_client_addr,
		       pcal_mup,
		       PCAL_PORT);
  if (fd < 0)
    fd = 0;
  
  while(1)
    {
      sem_wait(&sem_pcal);
      fpga_isr_rd();

      start = clock();

      for(offset = 0xA00000, i=0; offset<0xA00FFF; offset += 4)
	{
	  util_read_short_fpga(offset, 1, &lo);
	  util_read_short_fpga(offset+1, 1, &hi);
	  pcal_data[i++] = (hi << 16) | lo;
	  util_read_short_fpga(offset+2, 1, &lo);
	  util_read_short_fpga(offset+3, 1, &hi);
	  pcal_data[i++] = (hi << 16) | lo;
	}

      duration = ((double)(clock() - start)/CLOCKS_PER_SEC);

      /* multicast the data */
      rc = sendto(fd,
		  (char *)&pcal_data[0],
		  0x400*sizeof(unsigned int),
		  0,
		  (struct sockaddr*)&pcal_client_addr,
		  sizeof(struct sockaddr_in));
      
      printf("duration: %.7f\n", duration);
      printf("sent: %d bytes\n", rc);
    }
  close(fd);
}

#endif

#define NBRE_DAYS_SINCE_JAN_1_LEAP  182

void *dotset_thread(void *arg)
{
  struct timespec abs_timeout, rem;
  int retCode = -1;
  struct tm dotTime;
  time_t secsToSet;
  unsigned long bcdTimeCode = 0x0l;

  short epoch_ref = 0;
  unsigned long secs_ref_epoch;
  int nbre_days_ref;
  int nbre_days_jan;

  struct timeval tv;
#ifdef _DEBUG_1PPS_
  short val = 1;
#endif

  abs_timeout.tv_sec = 0;
  abs_timeout.tv_nsec = 100000000; /* 100 ms */

  /*
   * struct tm {
   *   int tm_sec;    number of seconds after the minute, normally in the range 0 to 59, but can be up to 60 to allow for
   *                  leap seconds.
   *   int tm_min;    number of minutes after the hour, in the range 0 to 59.
   *   int tm_hour;   number of hours past midnight, in the range 0 to 23.
   *   int tm_mday;   day of the month, in the range 1 to 31.
   *   int tm_mon;    number of months since January, in the range 0 to 11.
   *   int tm_year;   number of years since 1900.
   *   int tm_wday;   number of days since Sunday, in the range 0 to 6.
   *   int tm_yday;   number of days since January 1, in the range 0 to 365.
   *   int tm_isdst;  daylight saving time
   *  };
   */
  while(1)
    {
      sem_wait(&dot_set_ops);
      fpga_isr_rd();

#ifdef _DEBUG_1PPS_
      val = 1;
      util_write_short_fpga((unsigned int)(0x20), 1, &val);
      val = 0;
      usleep(20000);
      util_write_short_fpga((unsigned int)(0x20), 1, &val);
#endif
      nanosleep(&abs_timeout, &rem);
      gettimeofday(&tv, NULL);

      secsToSet = time(NULL);
      localtime_r(&secsToSet, &dotTime);
      
      // create BCD from time code
      time2JD(&dotTime, &bcdTimeCode);
      retCode = fpga_set_dot(bcdTimeCode);

      /* set the VDIF fields REF is Jan 2000 */
      epoch_ref = (dotTime.tm_year - 100 ) * 2;
      if (dotTime.tm_mon >= 6)
	epoch_ref += 1;

      if (0 == dotTime.tm_year % 4)
	nbre_days_jan = 182;
      else
	nbre_days_jan = 181;
      
      nbre_days_ref = dotTime.tm_yday;
      if (dotTime.tm_mon > 5)
	nbre_days_ref -= nbre_days_jan;

      secs_ref_epoch = nbre_days_ref * 86400 +  dotTime.tm_hour * 3600 + dotTime.tm_min * 60 + dotTime.tm_sec;
      	
      fpga_ddc_set_vdif_epoch(&epoch_ref, &secs_ref_epoch);

      fprintf(logfp, "dot was set: %ld:%ld\n", tv.tv_sec, tv.tv_usec);
    }
}

void trim(char *str)
{
  int i, l;
	
  if(str == 0) return;
  
  l = strlen(str);
  if(l <= 1) return;
  
  for(i = l-1; i > 0; i--) if(str[i] > ' ') break;
  str[i+1] = 0;
}

/* used to parse the returned message from executing cmd internally */
int messageparse(char *message, char **ptr, int maxparams)
{
  int i, N=0;
  
  memset(ptr, '\0', maxparams * sizeof(char *));

  for(i = 0; message[i]; i++)
    if(message[i] >= 'A' && message[i] <= 'Z')
      message[i] += ('a'-'A');
  for(i = 0; (message[i] != '=') &&
	(message[i] != '?'); i++) if(!message[i]) return 0;
  
  for(i++; i < MAX_FILE_NAME_LEN; i++) 
    {
      if(message[i] == ':')		/* parameter divider */
	{
	  message[i] = 0;		/* Terminate string */
	  trim(ptr[N]);		/* Trim whitespace */
	  
	  N++;
	  if(N >= maxparams) return N;
	  ptr[N] = 0;
	  
	  continue;
	}
      if(message[i] == '\n' || message[i] == 0 
	 || message[i] == ';')	/* end of message */
	{
	  message[i] = 0;		/* Terminate string */
	  trim(ptr[N]);		/* Trim whitespace */
	  
	  return N+1;	/* We found this many parameters */
	}
      if(message[i] > ' ' && ptr[N] == 0)
	ptr[N] = message+i;
    }
  
  /* No 0 termination before maximum message length?  send error */
  return -1;
}

