/*
 * print_buffer.c
 *
 *  Created on: Jul 15, 2009
 *      Author: Mikael Taveniku XCube Communication Inc.
 *      License: GPL
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "PrintBuffer.h"



static char *PrintBufferPtr = 0;
static unsigned long PrintBufferCurrentIndex = 0;
unsigned long PrintBufferMaxLen = 0;

int PrintBufferCreate(unsigned long length) {

	if(PrintBufferPtr) free(PrintBufferPtr);
	PrintBufferPtr = 0;
	PrintBufferCurrentIndex = 0;
	PrintBufferMaxLen = 0;

	PrintBufferPtr = (char *) malloc(length);
	if(!PrintBufferPtr){
		return -1;
	}
	return 0;
}

int PrintBufferDestroy() {
	if(PrintBufferPtr) free(PrintBufferPtr);
	PrintBufferPtr = 0;
	PrintBufferCurrentIndex = 0;
	PrintBufferMaxLen = 0;
	return 0;
}


char* PrintBufferGetCurrent() {
	if(PrintBufferPtr){
		return &PrintBufferPtr[PrintBufferCurrentIndex];
	}
	return 0;
}

int PrintBufferInsert( char *str){
	int len;
	if(str){
		len = strlen(str);
		if(len + PrintBufferCurrentIndex < PrintBufferMaxLen){
			memcpy(&PrintBufferPtr[PrintBufferCurrentIndex], str, len);
			PrintBufferCurrentIndex += len;
			PrintBufferPtr[PrintBufferCurrentIndex] = '\0';
			return len;
		} else {
			//TODO: add code to write partial results
		}
	}
	return 0;
}

int PrintBufferClear(){
	PrintBufferCurrentIndex = 0;
	if(PrintBufferPtr) PrintBufferPtr[0] = '\0';
	return 0;
}

