/*
 * ioctl_util.c
 *
 *  Created on: Sep 25, 2009
 *      Author: micke
 */

#include "rdbe_exports.h"     // device driver information access functions and types
#include "ioctl_util.h"
#include <stdio.h>

extern int serv_rdbe_ioctl(int funNo, char*arg); // defined in server main for now



/*
 * Internal utility functions
 */
// #define WORDSWAP_LONG
//#define BYTE_SWAP_SHORT
#define BYTE_REVRESE_LONG

/**
 * Word swap a long upper and lower 16 bits
 * @param value - pointer to a long
 */
void word_swap_long(void *value)
{
  unsigned short *tmp, shVal;
  tmp = value;
  shVal = tmp[0];
  tmp[0]=tmp[1];
  tmp[1] = shVal;
  //unsigned long *tmp = value;
  //*tmp = (*tmp>>16) | (*tmp<<16);
}

/**
 * swap endiannes on a 16 bit entity
 * @param ptr - pointer to the start of the word
 */
void byte_swap_short(void *ptr)
{
  unsigned char tmp;
  tmp = *(unsigned char*)ptr;
  *(unsigned char*)ptr = *(unsigned char*)(ptr+1);
  *(unsigned char*)(ptr+1) = tmp;
}

/**
 * byte reverse a long
 * @param ptr
 */
void byte_reverse_long(void *ptr)
{
  unsigned char tmp;
  tmp = *(unsigned char*)ptr;
  *(unsigned char*) ptr    = *(unsigned char*)(ptr+3);
  *(unsigned char*)(ptr+3) = tmp;
  tmp = *(unsigned char*)(ptr+1);
  *(unsigned char*)(ptr+1) = *(unsigned char*)(ptr+2);
  *(unsigned char*)(ptr+2) = tmp;
}

/**
 * Device read command that interface to the IOCTL command of the RDBE driver.
 * This is a function that is intended to be used by the commands that need r/w access to hardware
 * on the device.
 * @param ioctlCmd -
 * @param access_type - data type 1, 2, or 4 bytes.
 * @param offset - starting offset of read - same alignment as datatype required
 * @param numWords - number of words to read
 * @param retBuf - buffer containing returned data
 * @return - 0 on success
 */
int util_dev_rd_cmd(int ioctlCmd, unsigned long accessType, unsigned long offset, unsigned long numWords, void *retBuf)
{
  rdbe_rdwr_cmd_t cmd; // command to send
  
  cmd.access_type = accessType;
  cmd.len         = numWords;
  cmd.ofs         = offset;
  cmd.buf         = retBuf;
  
  printf("\nCalling ioctl with DEV=%d CMD=%d ParPtr=%p, BUFPtr=%p Length=%lu \n", 0, ioctlCmd, &cmd, cmd.buf, cmd.len);
  serv_rdbe_ioctl(ioctlCmd, (char *)&cmd);
  
  return 0; // all went well
}

/**
 * Read number of access type words from FPGA at offset offset
 * @param offset - start address - must be aligned with the data type
 * @param accessType - 1, 2, or 4 byte WORDS
 * @param numWords - number of words of data type
 * @param retBuf - return data from operation
 * @return - 0 on success
 */
int util_read_fpga(unsigned accessType, unsigned long offset, unsigned long numWords, void *retBuf)
{
  switch (accessType) {
  case 1:
    return util_read_byte_fpga(offset, numWords, retBuf);
  case 2:
    return util_read_short_fpga(offset, numWords, retBuf);
  case 4:
    return util_read_long_fpga(offset, numWords, retBuf);
  default:
    return -1;
  }
}

/**
 * Write number of access type words from FPGA at offset offset
 * @param offset - start address - must be aligned with the data type
 * @param accessType - 1, 2, or 4 byte WORDS
 * @param numWords - number of words of data type
 * @param retBuf - return data from operation
 * @return - 0 on success
 */
int util_write_fpga(unsigned long offset, unsigned accessType, unsigned long numWords, void *retBuf)
{
  switch (accessType) {
  case 1:
    return util_write_byte_fpga(offset, numWords, retBuf);
  case 2:
    return util_write_short_fpga(offset, numWords, retBuf);
  case 4:
    return util_write_long_fpga(offset, numWords, retBuf);
  default:
    return -1;
  }
}

/**
 * Read number of words 16 bit from FPGA at offset offset
 * @param offset - address in FPGA
 * @param numWords
 * @param retBuf - returned buffer allocated by caller
 * @return - 0 on success
 */
int util_read_byte_fpga(unsigned long offset, unsigned long numWords, void *retBuf)
{
  rdbe_rdwr_cmd_t cmd;
  cmd.access_type = 1; // word
  cmd.len = numWords;
  cmd.ofs = offset;
  cmd.buf = retBuf;
  serv_rdbe_ioctl(RDBE_FPGA_READ, (char*)&cmd);
  return 0;
}

/**
 * Write number of words 8 bit to FPGA at offset offset
 * @param offset - address in FPGA
 * @param numWords
 * @param retBuf
 * @return - 0 on success
 */
int util_write_byte_fpga(unsigned long offset, unsigned long numWords, void *retBuf)
{
  rdbe_rdwr_cmd_t cmd;
  cmd.access_type = 1; // byte
  cmd.len = numWords;
  cmd.ofs = offset;
  cmd.buf = retBuf;
  serv_rdbe_ioctl(RDBE_FPGA_WRITE, (char*)&cmd);
  return 0;
}

/**
 * Read number of words 16 bit from FPGA at offset offset
 * @param offset - address in FPGA
 * @param numWords
 * @param retBuf - returned buffer allocated by caller
 * @return - 0 on success
 */
int util_read_short_fpga(unsigned long offset, unsigned long numWords, void *retBuf)
{
  rdbe_rdwr_cmd_t cmd;
  cmd.access_type = 2; // word
  cmd.len = numWords;
  cmd.ofs = offset;
  cmd.buf = retBuf;
  serv_rdbe_ioctl(RDBE_FPGA_READ, (char*)&cmd);
#ifdef BYTE_SWAP_SHORT
  int i;
  unsigned short *tmp = (unsigned short*)retBuf; // type conversion
  for(i=0;i<numWords;i++){
    byte_swap_short(&tmp[i]);
  }
#endif
  return 0;
}

/**
 * Write number of words 16 bit to FPGA at offset offset
 * @param offset - address in FPGA
 * @param numWords
 * @param retBuf
 * @return - 0 on success
 */
int util_write_short_fpga(unsigned long offset, unsigned long numWords, void *retBuf)
{
  rdbe_rdwr_cmd_t cmd;
  cmd.access_type = 2; // word
  cmd.len = numWords;
  cmd.ofs = offset;
  cmd.buf = retBuf;
#ifdef BYTE_SWAP_SHORT
  int i;
  unsigned short *tmp = (unsigned short*)retBuf; // type conversion
  for(i=0;i<numWords;i++){
    byte_swap_short(&tmp[i]);
  }
#endif
  serv_rdbe_ioctl(RDBE_FPGA_WRITE, (char*)&cmd);
  return 0;
}

/**
 * Read number of Long 32 bit from FPGA at offset offset
 * @param offset - address in FPGA -- must be 32 bit aligned
 * @param numLong - number of 32 bit entities to read
 * @param retBuf - returned buffer allocated by caller
 * @return - 0 on success
 */
int util_read_long_fpga(unsigned long offset, unsigned long numLong, void *retBuf)
{
  rdbe_rdwr_cmd_t cmd;
  cmd.access_type = 4; // Long
  cmd.len = numLong;
  cmd.ofs = offset;
  cmd.buf = retBuf;
  serv_rdbe_ioctl(RDBE_FPGA_READ, (char*)&cmd);
#ifdef WORDSWAP_LONG
  unsigned long *tmp = (unsigned long*)retBuf; // just a type conversion really
  int i;
  for(i=0; i<numLong;i++){
    word_swap_long(&tmp[i]);
  }
#endif
#ifdef BYTE_REVERSE_LONG
  unsigned long *tmp = (unsigned long*)retBuf; // just a type conversion really
  int i;
  for(i=0; i<numLong;i++){
    byte_reverse_long(&tmp[i]);
  }
#endif
  return 0;
}

/**
 * Write number of long 32 bit to FPGA at offset offset
 * @param offset - address in FPGA - must be 32 bit aligned
 * @param numLong - number of long-words to write
 * @param dataBuf - buffer with data to write from
 * @return - 0 on success
 */
int util_write_long_fpga(unsigned long offset, unsigned long numLong, void *dataBuf)
{
  rdbe_rdwr_cmd_t cmd;
  cmd.access_type = 4; // Long
  cmd.len = numLong;
  cmd.ofs = offset;
  cmd.buf = dataBuf;
#ifdef WORDSWAP_LONG
  unsigned long *tmp = (unsigned long*)dataBuf; // just a type conversion really
  int i;
  for(i=0; i<numLong;i++){
    word_swap_long(&tmp[i]);
  }
#endif
#ifdef BYTE_REVERSE_LONG
  unsigned long *tmp = (unsigned long*)dataBuf; // just a type conversion really
  int i;
  for(i=0; i<numLong;i++){
    word_swap_long(&tmp[i]);
  }
#endif
  serv_rdbe_ioctl(RDBE_FPGA_WRITE, (char*)&cmd);
  return 0;
}

/**
 * Calls the RDBE driver for a ISR read
 * this routine hangs until an interrupt occurs in the FPGA
 */
int util_isr_rd(void)
{
  return serv_rdbe_ioctl(RDBE_ISR_READ, (char*)0);
}
