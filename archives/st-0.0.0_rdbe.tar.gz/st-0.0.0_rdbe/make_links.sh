#!/bin/bash
ln -s /usr2/st/antcn/VLBIsend.py bin/
#ln -s /usr2/st/autoftp/autoftp bin/
#ln -s /usr2/st/jbscr/lgput_jv bin/lgput
#ln -s /usr2/st/mk5logd/mk5logd.py bin/
