/* fmset.h - header for fmset */
#define ROW             8
#define SLEEP_TIME      500
#define NSEM_NAME       "fs   "
