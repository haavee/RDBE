/* declaration of pointer to stcom */

extern struct stcom *stm_addr;
