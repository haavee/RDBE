/* stparams.h - dummy
 *
 * This file contains parameters needed by several
 * station programs.
 */

#define STM_KEY    ftok("/usr2/st",1)
#define STM_SIZE   4096  /* use multiples of a page (4096) */
