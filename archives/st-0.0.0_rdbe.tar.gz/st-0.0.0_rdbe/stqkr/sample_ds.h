  struct sample {
    double avg[MAX_ONOFF_DET];
    double sig[MAX_ONOFF_DET];
    double stm;
    int count;
  };
