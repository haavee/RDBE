# statib package
version = "1.1"